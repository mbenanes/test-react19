= tempo orchestrator supervisor front

tempo orchestrator supervisor front. Can be used to see technical error on a customer order.

== Features

show information about a customer order:

- show all events (view by tempo-orchestrator or payment-scheduler)
- show the nominal diagram sequence
- show link to access to PSR or TOR logs (link available on diagram lifelines)

== environments links

- https://tempo-orchestrator-supervisor-front-ps2ydx-sit.nprd-02-a9ef.priv.manawa.adeo.cloud/[SIT]
- https://tempo-orchestrator-supervisor-front-jbasfk-uat1.nprd-02-a9ef.priv.manawa.adeo.cloud/[UAT1]
- https://tempo-orchestrator-supervisor-front-prep.nprd-02-a9ef.priv.manawa.adeo.cloud/[PREPROD]
- https://tempo-orchestrator-supervisor-front.prod-04-ce7a.priv.manawa.adeo.cloud/[PROD]

== Start the project

=== Localy

---

npm install
npm run serve

---

=== On an environment

NOTE: this not work since oauth has been added.

---

npm install
make start-application-<env-name>

---

<env-name> can be sit, uat1, prep or prod

=== Test Oauth locally

To test oauth2 locally, you should:

. Start your API server on port 80 (use the spring profile local-oauth to start the server)
. Start your nginx revers proxy

- ***
  docker build . -t test-oauth
  docker run -e API_URL=http://<your-ip> -p 8080:8080 test-oauth
  ***
- . start your front server using
- ***
  ## make start-application-test-oauth
-

## == New bpm

## to use the new bpm, use the url http:{host}/customer-order-bpmn/{customerOrderId}

# tempo-orchestrator-supervisor-front

This template should help get you started developing with Vue 3 in Vite.

## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur).

## Type Support for `.vue` Imports in TS

TypeScript cannot handle type information for `.vue` imports by default, so we replace the `tsc` CLI with `vue-tsc` for type checking. In editors, we need [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) to make the TypeScript language service aware of `.vue` types.

## Customize configuration

See [Vite Configuration Reference](https://vite.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Type-Check, Compile and Minify for Production

```sh
npm run build
```

### Run Unit Tests with [Vitest](https://vitest.dev/)

```sh
npm run test:unit
```

### Lint with [ESLint](https://eslint.org/)

```sh
npm run lint
```
