import PropertiesActivator from 'bpmn-js-properties-panel/lib/PropertiesActivator'

import processProps from 'bpmn-js-properties-panel/lib/provider/bpmn/parts/ProcessProps'
import eventProps from 'bpmn-js-properties-panel/lib/provider/bpmn/parts/EventProps'
import linkProps from 'bpmn-js-properties-panel/lib/provider/bpmn/parts/LinkProps'
import documentationProps from 'bpmn-js-properties-panel/lib/provider/bpmn/parts/DocumentationProps'
import idProps from 'bpmn-js-properties-panel/lib/provider/bpmn/parts/IdProps'
import nameProps from 'bpmn-js-properties-panel/lib/provider/bpmn/parts/NameProps'

import eventIdentitfierProps from './parts/EventIdentitfierProps'

function createGeneralTabGroups(
  element: any,
  bpmnFactory: any,
  canvas: any,
  elementRegistry: any,
  translate: any,
) {
  const generalGroup = {
    id: 'general',
    label: 'General',
    entries: [],
  }
  idProps(generalGroup, element, translate)
  nameProps(generalGroup, element, bpmnFactory, canvas, translate)
  processProps(generalGroup, element, translate)

  const detailsGroup = {
    id: 'details',
    label: 'Details',
    entries: [],
  }
  linkProps(detailsGroup, element, translate)
  eventProps(detailsGroup, element, bpmnFactory, elementRegistry, translate)

  const documentationGroup = {
    id: 'documentation',
    label: 'Documentation',
    entries: [],
  }

  documentationProps(documentationGroup, element, bpmnFactory, translate)

  return [generalGroup, detailsGroup, documentationGroup]
}

function createTempoTabGroups(element: any) {
  const eventIdentifierGroup = {
    id: 'event-identifier-group',
    label: 'Event identifier',
    entries: [],
  }

  eventIdentitfierProps(eventIdentifierGroup, element)

  return [eventIdentifierGroup]
}

export default class TORPropertiesProvider extends PropertiesActivator {
  constructor(
    private eventBus: any,
    private bpmnFactory: any,
    private canvas: any,
    private elementRegistry: any,
    private translate: any,
  ) {
    super(eventBus)
  }

  getTabs(element: any) {
    const generalTab = {
      id: 'general',
      label: 'General',
      groups: createGeneralTabGroups(
        element,
        this.bpmnFactory,
        this.canvas,
        this.elementRegistry,
        this.translate,
      ),
    }

    const tempoTab = {
      id: 'tor',
      label: 'Tempo',
      groups: createTempoTabGroups(element),
    }

    return [generalTab, tempoTab]
  }
}
