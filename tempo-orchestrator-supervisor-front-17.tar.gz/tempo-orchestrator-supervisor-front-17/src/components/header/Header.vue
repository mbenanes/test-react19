<template>
  <header>
    <a class="title-link" href="/">
      <img src="/logo-tempo.png" alt="log-tempo" class="temp-icon" />
      <h1 class="title">Tempo Supervisor</h1>
    </a>

    <div class="search-form">
      <search-box />
    </div>

    <div class="rule-engine">
      <div class="rule-engine-container" :class="{ 'loading-spinner': isRuleEngineReLoading }">
        <cached-icon
          :size="28"
          :show="hasLoadedCustomerOrder && isUserAdmin"
          @click="launchRuleEngineAndReload()"
        />
      </div>
      <div class="rule-engine-container-error-message-container">
        <span class="rule-engine-container-error-message" v-if="ruleEngineReloadError != ''">{{
          ruleEngineReloadError
        }}</span>
        <span class="rule-engine-container-error-message" v-if="ruleEngineReloaded"
          >TOR rule engine reloaded !</span
        >
      </div>
    </div>

    <action-link />

    <div class="environment">
      {{ environmentName }}
    </div>
  </header>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-facing-decorator'
import FilterIcon from 'vue-material-design-icons/Filter.vue'
import CachedIcon from 'vue-material-design-icons/Cached.vue'
import MagnifyIcon from 'vue-material-design-icons/Magnify.vue'
import Badge from '@/components/badged/Badge.vue'
import { launchTorRuleEngine } from '@/services/alerts.service'
import SearchBox from './SearchBox.vue'
import ActionLink from './ActionLink.vue'
import { useCommandStore, useAppStore } from '@/store'
import { HttpError } from '@/services/http.service'

@Component({
  methods: { launchTorRuleEngine },
  components: {
    FilterIcon,
    CachedIcon,
    MagnifyIcon,
    Badge,
    SearchBox,
    ActionLink,
  },
})
class Header extends Vue {
  private commandStore = useCommandStore()
  private userStore = useAppStore()

  public ruleEngineReloadError = ''
  public ruleEngineReloaded = false
  public isRuleEngineReLoading = false

  get environmentName(): string {
    const environment = this.userStore.configuration?.environmentName ?? ''
    if (environment.length < 1) return environment
    return environment.charAt(0).toUpperCase() + environment.slice(1)
  }

  get customerOrderId(): string | undefined {
    return this.commandStore.customerOrderId
  }

  get buCode(): string | undefined {
    return this.commandStore.buCode
  }

  get hasLoadedCustomerOrder(): boolean {
    return this.commandStore.customerOrderMetadata !== undefined
  }

  public isUserAdmin(): boolean {
    return this.userStore.isUserAdmin()
  }

  public async launchRuleEngineAndReload(): Promise<void> {
    // Initiate Variables
    this.isRuleEngineReLoading = true
    this.ruleEngineReloaded = false
    this.ruleEngineReloadError = ''

    if (!this.customerOrderId || !this.buCode) {
      return
    }

    try {
      await launchTorRuleEngine(this.customerOrderId, this.buCode)
      setTimeout(() => this.reloadOrder(), 3000)
    } catch (e) {
      const error = e as HttpError

      // Handle the error based on the structure defined in HttpError
      if (error?.response?.data?.detail) {
        this.ruleEngineReloadError = 'Error : ' + error.response.data.status
      } else {
        this.ruleEngineReloadError = 'Sorry! The server seems to be down. Please try later.'
      }
    } finally {
      setTimeout(() => {
        this.isRuleEngineReLoading = false
      }, 700)
    }
  }

  private reloadOrder() {
    this.$router.push({ name: 'CustomerOrderView', params: { id: this.customerOrderId } })
    this.ruleEngineReloaded = true
  }
}

export default Header
</script>

<style scoped lang="scss">
header {
  background-color: var(--primary-color);
  padding: 6px 16px;
  padding-right: 0;
  display: flex;
  flex-direction: row;
  align-items: center;
  // background-image: url('/assets/bg-2.jpg');
  background-size: cover;
  background-position: center;

  .title-link {
    font-weight: bold;
    color: white;
    flex: 0 1 auto;
    font-size: 20px;
    text-decoration: none;
    display: inline-flex;
  }

  .temp-icon {
    padding-left: 25px;
    padding-right: 3px;
    height: 44px;
  }

  .title,
  .environment {
    font-weight: bold;
    color: white;
    flex: 0 1 auto;
    font-size: 20px;
  }

  .environment {
    background-color: rgba(0, 0, 0, 0.3);
    height: 130%;
    padding: 8px 22px;
    width: fit-content;
    align-content: center;
    cursor: pointer;
  }

  .environment:hover {
    background-color: rgba(0, 0, 0, 0.4);
  }

  .search-form {
    display: flex;
    flex: 1 1 auto;
    gap: 10px;
    justify-content: center;
    flex-direction: row;
    text-align: center;
  }

  .rule-engine {
    padding: 0 15px;
    min-width: fit-content;
    display: inline-flex;
  }

  .rule-engine-container {
    position: relative;
    color: white;
    padding: 0 6px;
    padding-top: 5px;
  }

  .loading-spinner {
    animation: spin 1s linear infinite;
  }

  .rule-engine-container-error-message {
    margin-top: 20px;
  }

  .rule-engine-container-error-message-container {
    position: relative;
    color: white;
    margin-top: 5px;
  }
}
</style>
