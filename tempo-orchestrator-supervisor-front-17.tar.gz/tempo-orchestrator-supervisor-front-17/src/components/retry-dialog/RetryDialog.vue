<template>
  <popin @close="close()">
    <template v-slot:header> Retry the event </template>
    <template v-slot:body>
      <template v-if="retryReponse === undefined">
        <div>
          <div>
            Are you sure you want to retry the event from the topic:
            <span class="highlighted">{{ event.metadata.topic }}</span
            >, offset: <span class="highlighted">{{ event.metadata.offset }}</span
            >, partition: <span class="highlighted">{{ event.metadata.partition }}</span
            >, in the <span class="highlighted">{{ environmentName }}</span> environment
          </div>
          <div v-if="isMultiConsumer">
            For which API do you want to retry the event?
            <select v-model="selectedConsumerApi">
              <option value=""></option>
              <option
                v-for="consumer in event.metadata.consumerApi"
                :key="consumer"
                :value="consumer"
              >
                {{ consumer }}
              </option>
            </select>
          </div>
        </div>
        <div class="error" v-if="retryError != ''">
          {{ retryError }}
        </div>
      </template>
      <template v-else>
        <div>
          The event has been replayed on the topic:
          <span class="highlighted">{{ retryReponse.topic }}</span
          >, offset: <span class="highlighted">{{ retryReponse.offset }}</span
          >, partition: <span class="highlighted">{{ retryReponse.partition }}</span> with the id:
          <span class="highlighted">{{ retryReponse.id }}</span>
        </div>
      </template>
    </template>
    <template v-slot:footer v-if="retryReponse === undefined">
      <template v-if="retryReponse === undefined">
        <button @click="retry()" class="warning" :disabled="canNotRetry">Retry</button>
        <button @click="close()">Cancel</button>
      </template>
      <template v-else>
        <button @click="close()" class="primary">Understood</button>
      </template>
    </template>
  </popin>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-facing-decorator'
import Popin from './Popin.vue'
import { OrchestratorEvent, RetryReponse } from '@/models'
import { retryEvent } from '@/services/CustomerOrder.service'
import { useAppStore } from '@/store'
import { HttpError } from '@/services/http.service'

@Component({
  components: {
    Popin,
  },
})
class RetryDialog extends Vue {
  private store = useAppStore()

  @Prop()
  public event?: OrchestratorEvent

  public retryReponse?: RetryReponse = undefined

  public retryInProgess = false

  public selectedConsumerApi?: string = ''

  public retryError = ''

  public created(): void {
    if (!this.isMultiConsumer) {
      this.selectedConsumerApi = this.event?.metadata.consumerApi[0]
    }
  }

  public close(): void {
    this.$emit('close')
  }

  public async retry(): Promise<void> {
    if (this.event && this.selectedConsumerApi) {
      try {
        this.retryInProgess = true
        this.retryReponse = await retryEvent(this.event, this.selectedConsumerApi)
      } catch (e) {
        const error = e as HttpError
        if (error?.response?.data.detail) {
          this.retryError = error.response.data.detail
        } else {
          this.retryError = 'Sorry! The server seems to be down. Please try later.'
        }
      }
      this.retryInProgess = false
    }
  }

  get canNotRetry(): boolean {
    return this.selectedConsumerApi === '' || this.retryInProgess
  }

  get isMultiConsumer(): boolean {
    if (this.event?.metadata.consumerApi) {
      return this.event.metadata.consumerApi.length > 1
    }
    return false
  }

  get environmentName(): string {
    return this.store.configuration?.environmentName ?? ''
  }
}

export default RetryDialog
</script>

<style scoped lang="scss"></style>
