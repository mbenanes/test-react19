<template>
  <div class="nav-tabs">
    <slot></slot>
    <tab v-if="allowToAddTab" label="+" @click="onAdd()" />
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-facing-decorator'
import Tab from '@/components/nav-tabs/Tab.vue'

@Component({
  components: {
    Tab,
  },
})
class NavTabs extends Vue {
  @Prop({
    default: false,
  })
  public isReadOnly?: boolean

  @Prop({
    default: false,
  })
  public allowToAddTab?: boolean

  onAdd() {
    this.$emit('add')
  }
}

export default NavTabs
</script>

<style scoped lang="scss">
.nav-tabs {
  display: flex;
  background-color: rgba(0, 0, 0, 0.03);
  border-bottom: 2px solid rgba(0, 0, 0, 0.125);
}
</style>
