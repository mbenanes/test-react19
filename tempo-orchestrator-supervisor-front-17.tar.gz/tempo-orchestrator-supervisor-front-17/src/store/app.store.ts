import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { Configuration, User } from '@/models/user.model'
import axios from 'axios'

const apiUrl = import.meta.env.VITE_API_URL

// Define the store
export const useAppStore = defineStore('app', () => {
  const configuration = ref<Configuration | undefined>(undefined)
  const isAuthenticated = ref<boolean>(true)
  const user = ref<User | undefined>(undefined)

  // Computed properties or getters (if needed)
  const isAuthenticatedComputed = computed(() => isAuthenticated.value)

  const updateConfiguration = (newConfiguration: Configuration) => {
    configuration.value = newConfiguration
  }

  const updateUser = (newUser: User) => {
    user.value = newUser
  }

  const loadConfiguration = async () => {
    try {
      const response = await axios.get(apiUrl + '/supervisor/configuration')
      updateConfiguration(response.data)
    } catch (error) {
      console.error('Error loading configuration', error)
    }
  }

  const loadUserInfo = async () => {
    try {
      const response = await axios.get(apiUrl + '/login/me')
      updateUser(response.data)
    } catch (error) {
      console.error('Error loading user info', error)
    }
  }

  const isUserAdmin = (): boolean => {
    return user.value?.authorities.includes('ADMIN') ?? false
  }

  const hasAuthorities = (authorities: string[]): boolean => {
    return authorities.some((authority) => user.value?.authorities.includes(authority)) ?? false
  }

  // Return state, getters, and actions
  return {
    configuration,
    isAuthenticated,
    user,
    isAuthenticatedComputed,
    updateConfiguration,
    updateUser,
    loadConfiguration,
    loadUserInfo,
    isUserAdmin,
    hasAuthorities,
  }
})
