import axios from 'axios'
import queryString from 'query-string'
import { get, type Page } from './http.service'
import type { BuCodeType } from '@/models'
const apiUrl = import.meta.env.VITE_API_URL

export interface AlertEvent {
  eventType: string
  functionalType: string
}

export interface Alert {
  id: string
  eventId: string
  lineId: string
  buCode: string
  customerOrderId: string
  deliveryType: string
  alertName: string
  closingEvents: AlertEvent[]
  createdAt: string
  expectedClosingEventDate: string
  ticketNumber: string
  numberOfComment: number
}

export interface AlertComment {
  id: string
  comment: string
  createdAt: string
  createdBy: string
}

export interface AlertFilters {
  name: string
  values: FilterOption[]
}

export interface FilterOption {
  value: string | BuCodeType
  count: number
}

export const getAlerts = async (
  page: number,
  customerOrderId: string,
  selectedFilters: { [key: string]: string[] },
  sortingDirection: string,
): Promise<Page<Alert>> => {
  const params: { [key: string]: string[] | string } = {}

  if (customerOrderId.length > 0) {
    params.customerOrderId = customerOrderId
  }
  for (const filter of Object.entries(selectedFilters)) {
    const filterName = filter[0]
    params[filterName] = filter[1]
  }

  params.sortingDirection = sortingDirection
  params.page = `${page}`
  params.pageSize = '20'

  return await get<Page<Alert>>(apiUrl + '/supervisor/alerts', {
    params: params,
    paramsSerializer: function (params) {
      return queryString.stringify(params, { arrayFormat: 'none' })
    },
  })
}

export const getAlertFilters = async (): Promise<AlertFilters[]> => {
  return await get<AlertFilters[]>(apiUrl + '/supervisor/alerts/filters')
}

export const getAlertsForCustomerOrder = async (customerOrderId: string): Promise<Alert[]> => {
  const result = await axios.get(
    '/supervisor/alerts?pageSize=100&customerOrderId=' + customerOrderId,
  )
  return result.data.data
}

export const deleteAlert = async (alertId: string): Promise<void> => {
  const result = await axios.delete(apiUrl + '/supervisor/alerts/' + alertId)
  return result.data
}

export const generateValuateStockBackoResponse = async (eventId: string): Promise<void> => {
  const result = await axios.post(
    apiUrl + '/supervisor/alerts/' + eventId + '/generateValuateStockResponse',
  )
  return result.data
}

export const launchTorRuleEngine = async (
  customerOrderId: string,
  buCode: string,
): Promise<void> => {
  const result = await axios.post(
    apiUrl +
      '/supervisor/technical/customerOrder/' +
      customerOrderId +
      '/launchTorRuleEngine?buCode=' +
      buCode,
  )
  return result.data
}

export const addComment = async (alertId: string, comment: string): Promise<AlertComment> => {
  const result = await axios.post(apiUrl + '/supervisor/alerts/' + alertId + '/comments', {
    comment: comment,
  })
  return result.data
}

export const getComments = async (alertId: string): Promise<AlertComment[]> => {
  const result = await axios.get(apiUrl + '/supervisor/alerts/' + alertId + '/comments')
  return result.data
}
