import router from './router'
import './assets/styles/style.css'
import { createPinia } from 'pinia'
import { createApp } from 'vue'
import App from './App.vue'
import FlagIcon from 'vue-flag-icon'
import Vue3Material from 'vue3-material'

createApp(App).use(router).use(createPinia()).use(Vue3Material).use(FlagIcon).mount('#app')
