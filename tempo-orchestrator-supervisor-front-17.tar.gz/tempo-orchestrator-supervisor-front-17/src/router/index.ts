import { createRouter, createWebHistory } from 'vue-router'
import CustomerOrderView from '../views/CustomerOrderView.vue'
import HomeView from '../views/HomeView.vue'
import AlertsView from '../views/AlertsView.vue'
import FlowChartView from '../views/FlowChartView.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'HomeView',
      component: () => HomeView,
    },
    {
      path: '/customer-order/:id',
      name: 'CustomerOrderView',
      component: () => CustomerOrderView,
    },
    {
      path: '/flowchart',
      name: 'FlowChartView',
      component: () => FlowChartView,
    },
    {
      path: '/alerts',
      name: 'AlertsView',
      component: () => AlertsView,
    },
    {
      path: '/:catchAll(.*)',
      redirect: { name: 'HomeView' },
    },
  ],
})

export default router
