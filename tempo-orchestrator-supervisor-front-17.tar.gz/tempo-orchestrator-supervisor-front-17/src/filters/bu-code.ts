import { COUNTRY_CODES, type BuCodeType } from '@/models'

export const findBuCode = (countryCode: string): BuCodeType | undefined => {
  const buCode = Object.keys(COUNTRY_CODES).find(
    (buCode) => COUNTRY_CODES[buCode as BuCodeType].code === countryCode,
  )
  return buCode as BuCodeType | undefined
}

export const getBuCode = (value: BuCodeType): string => {
  if (!value) return ''

  const country = COUNTRY_CODES[value]
  return country ? country.code : value
}

export const getFlagCode = (value: BuCodeType): string | undefined => {
  if (!value) return undefined

  const country = COUNTRY_CODES[value]
  return country ? country.flag : undefined
}
