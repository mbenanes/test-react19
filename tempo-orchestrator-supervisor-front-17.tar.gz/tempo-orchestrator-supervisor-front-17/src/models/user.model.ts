export interface Actor {
  name: string
  logURL: string
}

export interface Configuration {
  actors: Actor[]
  tempoComposerSupervisor: string
  environmentName: string
  actionButtons: ActionButton[]
}

export interface ActionButton {
  name: string
  url: string
  displayedOnHome: boolean
  displayedOnCustomerOrderPage: boolean
  authoritiesRestrictions: string[]
}

export interface User {
  authorities: string[]
  userInfo: UserInfo
}

export interface UserInfo {
  claims: Claims
  address: Address
  fullName: string
  zoneInfo?: any
  email: string
  subject: string
  profile?: any
  givenName: string
  familyName: string
  middleName?: any
  nickName?: any
}

export interface Claims {
  sub: string
  mail: string
  title: string
  employeeNumber: string
  uid: string
  email: string
  name: string
}

export interface Address {
  formatted?: any
  streetAddress?: any
  locality?: any
  region?: any
  postalCode?: any
  country?: any
}

export type AuthorityType = 'BASIC' | 'ADMIN'
