## Description

<!-- If your PR is linked with a Jira please include the jira issue id -->

TO-<number>

<!--
  If not,
      - include a summary of the change and which issue is fixed.
      - include any relevant motivation and context.
  If you don't do a baby step,
      - include some tips on how review this Pull Request.
-->

## Checklist

- [ ] I have performed a self-review of my own code.
- [ ] I have added cucumber tests that prove my fix is effective or that my feature works.
- [ ] Assign the pull request to yourself.

### You send a new event

- [ ] If it's a domain or technical event, I updated the `app-infrastructure.json` `managed-subjects` part.
- [ ] If it's a command message, I updated the `app-infrastructure.json` `used-subjects` part and the `managed-subjects.SANDBOX-OUT` part.
- [ ] If this event uses a new topic, I updated the C2 model on the project `archi/container-context.dot` file.
- [ ] If this event is sent to a new partner, I updated the C1 model on the project `archi/level-context.dot` file.
- [ ] Fill the corresponding vault configuration in the [deployment follow-up file](https://docs.google.com/spreadsheets/d/1LJJFakT6QbmgTXyKOCW3szJDc8aDFd69kGTem3FcN_s/edit?gid=0#gid=0)

### You consume a new event

- [ ] Add the event on the `app-infrastructure.json` `sandbox-in` part.
- [ ] Fill the corresponding vault configuration in the [deployment follow-up file](https://docs.google.com/spreadsheets/d/1LJJFakT6QbmgTXyKOCW3szJDc8aDFd69kGTem3FcN_s/edit?gid=0#gid=0)

### You update an avro dependency version

Update the avro version

- [ ] In the project.
- [ ] In the acceptance testing project.
- [ ] In the `app-infrastructure.json` file.

### You call a new REST endpoint

- [ ] If this rest endpoint is provided by a new partner, I updated the C1 model on the project `archi/level-context.dot` file.
- [ ] Fill the corresponding vault configuration in the [deployment follow-up file](https://docs.google.com/spreadsheets/d/1LJJFakT6QbmgTXyKOCW3szJDc8aDFd69kGTem3FcN_s/edit?gid=0#gid=0)

### You create a new sql request or create a new table

- [ ] I created an index for the new sql request.

### You have to run a SQL script manually

- [ ] add in the [deployment follow-up file](https://docs.google.com/spreadsheets/d/1LJJFakT6QbmgTXyKOCW3szJDc8aDFd69kGTem3FcN_s/edit?gid=0#gid=0) that this sql script has to be run

### You add a new specific external configuration or feature flipping 

- [ ] add this configuration in the [deployment follow-up file](https://docs.google.com/spreadsheets/d/1LJJFakT6QbmgTXyKOCW3szJDc8aDFd69kGTem3FcN_s/edit?gid=0#gid=0)
