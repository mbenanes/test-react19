package com.adeo.sales.customerorder.tempoorchestrator.model.line.payment;

import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LineExecutionPaymentExecution {
    private Flags<PaymentOperationType> flags = new Flags<>();

    public boolean hasNoCaptureOrCaptureRequested() {
        return this.flags.hasNotFlags(List.of(PaymentOperationType.CAPTURE_REQUESTED, PaymentOperationType.CAPTURED));
    }

    @JsonIgnore
    public boolean isCaptured() {
        return this.flags.hasFlag(PaymentOperationType.CAPTURED) &&
            this.flags.hasNotFlags(List.of(PaymentOperationType.CANCEL_CAPTURE_REQUESTED,
                PaymentOperationType.CAPTURE_CANCELED));
    }

    @JsonIgnore
    public boolean isAuthorized() {
        return this.flags.hasFlag(PaymentOperationType.AUTHORIZED) &&
            (this.flags.lastFlagIs(PaymentOperationType.CAPTURE_FAILED) ||
                this.flags.hasNotFlags(List.of(PaymentOperationType.CAPTURED,
                    PaymentOperationType.CAPTURE_REQUESTED,
                    PaymentOperationType.CANCEL_AUTHORIZATION_REQUESTED,
                    PaymentOperationType.AUTHORIZATION_CANCEL_FAILED,
                    PaymentOperationType.AUTHORIZATION_CANCELED)));
    }

    public PaymentOperationType getLastFlag() {
        Flag lastFlag = this.getFlags().getLastFlag();
        if (lastFlag != null) {
            final var lastFlagType = lastFlag.getType();
            return PaymentOperationType.valueOf(lastFlagType);
        }
        return null;
    }
}
