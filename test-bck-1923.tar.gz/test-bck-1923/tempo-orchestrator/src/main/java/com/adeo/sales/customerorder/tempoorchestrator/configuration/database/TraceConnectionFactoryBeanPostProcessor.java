package com.adeo.sales.customerorder.tempoorchestrator.configuration.database;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tags;
import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.proxy.ProxyConnectionFactory;
import io.r2dbc.spi.ConnectionFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.actuate.metrics.r2dbc.ConnectionPoolMetrics;

public class TraceConnectionFactoryBeanPostProcessor implements BeanPostProcessor {

    private final MeterRegistry meterRegistry;

    public TraceConnectionFactoryBeanPostProcessor(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        if (bean instanceof ConnectionPool) {
            (new ConnectionPoolMetrics((ConnectionPool) bean, beanName, Tags.empty())).bindTo(meterRegistry);
        }
        if (bean instanceof ConnectionFactory) {
            return wrapConnectionFactory((ConnectionFactory) bean);
        }
        return bean;
    }

    private ConnectionFactory wrapConnectionFactory(ConnectionFactory bean) {
        ProxyConnectionFactory.Builder builder = ProxyConnectionFactory.builder(bean);
        builder.listener(new OpenTracingProxyExecutionListener());
        return builder.build();
    }
}
