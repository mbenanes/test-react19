package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception;

public class ProductConfigurationContainsServiceType extends RuntimeException {
    public ProductConfigurationContainsServiceType(String itemType) {
        super("The product configuration contains the service type " + itemType + " .");
    }
}
