package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.batch;

import com.adeo.sales.customerorder.tempoorchestrator.model.Clock;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.PaymentOperationType;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LineExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.service.CaptureService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Component;
import org.springframework.transaction.ReactiveTransactionManager;
import org.springframework.transaction.reactive.TransactionalOperator;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.utils.LockUtils.getTransactionDefinition;

@Component
@RequiredArgsConstructor
@Slf4j
public class AutoCaptureBatchApplicationService {
    private final LineExecutionRepository lineExecutionRepository;
    private final CaptureService captureService;
    private final ReactiveTransactionManager transactionManager;

    public Mono<Void> apply(OffsetDateTime limitExpirationDate) {
        return this.getLineExecutions(limitExpirationDate)
            .flatMapIterable(lineExecutions -> lineExecutions.stream().collect(Collectors.groupingBy(LineExecution::getCustomerOrderId)).values())
            .flatMap(this::askCapture)
            .flatMapSequential(Flux::fromIterable)
            .collectList()
            .doOnNext(customerOrderLines -> log.info("INTERNAL {} customer order lines has been automatically captured", customerOrderLines.size()))
            .filter(list -> !list.isEmpty())
            .flatMap(lineExecutionRepository::upsert)
            .transform(TransactionalOperator.create(transactionManager, getTransactionDefinition(this))::transactional);
    }

    @NotNull
    private Mono<List<LineExecution>> getLineExecutions(OffsetDateTime limitExpirationDate) {
        return lineExecutionRepository.getSFWorSFPLinesWhereAuthorizationWillExpireBefore(limitExpirationDate)
            .switchIfEmpty(MonoUtil.infoLog("INTERNAL 0 line executions has been automatically captured"))
            .collectList();
    }

    private Mono<List<LineExecution>> askCapture(List<LineExecution> lines) {
        final var firstLine = lines.get(0);
        List<LineExecution> linesToCapture = lines.stream().filter(lineExecution -> StringUtils.isNotEmpty(lineExecution.getPayment().getDepositLegacyNumber())).toList();
        linesToCapture.forEach(lineExecution -> lineExecution.getPayment().getPaymentExecution().getFlags().raiseFlag(PaymentOperationType.CAPTURE_REQUESTED));
        return this.captureService.sendCommandCaptureOnDeposit(CustomerOrder.builder()
                .id(firstLine.getCustomerOrderId())
                .buCode(firstLine.getBuCode())
                .paymentSchedule(new Clock(firstLine.getPayment().getPaymentScheduleId(), 1))
                .build(), linesToCapture)
            .thenReturn(lines);
    }

}
