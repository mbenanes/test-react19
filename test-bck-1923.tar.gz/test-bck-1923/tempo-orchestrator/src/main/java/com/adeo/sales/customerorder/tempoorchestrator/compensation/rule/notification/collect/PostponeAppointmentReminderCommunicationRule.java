package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.collect;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_APPOINTMENT_REMINDER_NOTIFICATION_NOT_SENT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CAPTURED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECT_APPOINTMENT_DATE_EXIST;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_ONLINE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.NotificationStatus.NOTIFICATION_REQUESTED_POSTPONED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@AllArgsConstructor
@Rule(name = "PostponeAppointmentReminderCommunicationRule",
    description = "Postpone appointment reminder notification to customer.",
    priority = 1001)
public class PostponeAppointmentReminderCommunicationRule {

    private final OutgoingNotificationService notificationService;

    private static final Predicate<LineExecution> IS_RESERVE_AND_COLLECT_VALIDATED_CAPTURE_AND_HAS_APPOINTMENT_DATE_WITHOUT_REMINDER = IS_CAPTURED
        .and(IS_LINE_COMPOSITION_VALIDATED)
        .and(IS_COLLECT_APPOINTMENT_DATE_EXIST)
        .and(IS_APPOINTMENT_REMINDER_NOTIFICATION_NOT_SENT)
        .and(IS_EXTERNAL_SYSTEM_TEMPO);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(IS_RESERVE_AND_COLLECT_VALIDATED_CAPTURE_AND_HAS_APPOINTMENT_DATE_WITHOUT_REMINDER) &&
            context.isCustomerOrderMatches(IS_VALIDATED.and(IS_PLACE_TYPE_ONLINE));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var reserveAndCollectLines = context.getOrderData().getExistingLineExecutions().stream()
            .filter(IS_RESERVE_AND_COLLECT_VALIDATED_CAPTURE_AND_HAS_APPOINTMENT_DATE_WITHOUT_REMINDER)
            .toList();

        return MonoUtil.infoLog("INTERNAL send notification appointment reminder for order {}", context.getOrderData().getExistingCustomerOrder().getId())
            .then(
                Mono.when(notificationService.sendAppointmentReminderDayBeforeNotification(context.getOrderData().getExistingCustomerOrder(), context.getOrderData().getExistingLineExecutions()),
                    notificationService.sendAppointmentReminderHoursBeforeNotification(context.getOrderData().getExistingCustomerOrder(), context.getOrderData().getExistingLineExecutions())
                ))
            .then(Mono.fromRunnable(() -> reserveAndCollectLines.forEach(lineExecution -> {
                lineExecution.getDelivery().getCollect().setAppointmentReminderNotificationStatus(NOTIFICATION_REQUESTED_POSTPONED);
                lineExecution.increaseVersion();
            })));
    }
}
