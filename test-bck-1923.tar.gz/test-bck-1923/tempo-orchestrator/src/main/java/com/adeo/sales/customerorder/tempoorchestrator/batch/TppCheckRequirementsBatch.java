package com.adeo.sales.customerorder.tempoorchestrator.batch;

import brave.Tracer;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.batch.TppCheckRequirementsBatchApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Component
@Slf4j
public class TppCheckRequirementsBatch {

    public static final String TASK_NAME = "batch-tpp-check-requirements";
    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final Tracer tracer;
    private final TppCheckRequirementsBatchApplicationService tppCheckRequirementsBatchApplicationService;

    @Scheduled(cron = "${tpp.checkrequirements.batch.cron}")
    @SchedulerLock(name = "tppCheckRequirementsScheduler", lockAtLeastFor = "${tpp.checkrequirements.batch.lockAtLeastFor}", lockAtMostFor = "${tpp.checkrequirements.batch.lockAtLeastFor}")
    public void launchTppCheckRequirements() {
        final var span = this.tracer.nextSpan().name(TASK_NAME);
        this.tracer.withSpanInScope(span.start());
        this.mappedDiagnosticContext.enrichCurrentSpan(MappedDiagnosticContext.SOURCE_CONTEXT_KEY, TASK_NAME);
        log.info("INTERNAL start tpp check requirements batch");
        this.tppCheckRequirementsBatchApplicationService.apply()
            .doOnTerminate(() -> {
                span.finish();
                log.info("INTERNAL end tpp check requirements batch");
            })
            .subscribe();
    }

}
