package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_PAYMENT_AUTHORIZATION_DELAYED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_A_DELAYED_PAYMENT_MEAN;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PENDING_VALIDATION;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_ONLINE;
import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.NotificationStatus.NOTIFICATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.NotificationStatus.NOTIFICATION_REQUESTED_POSTPONED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@AllArgsConstructor
@Rule(name = "SendWaitingForPaymentCommunicationRule",
    description = "Send customer order waiting for payment notification to customer (long payment).",
    priority = 1000)
public class SendWaitingForPaymentCommunicationRule {

    private final OutgoingNotificationService notificationService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var mailIsNotAlreadySent = context.getOrderData().getExistingCustomerOrder().getWaitingForPaymentNotificationStatus() == null;

        return mailIsNotAlreadySent &&
            context.isCustomerOrderMatches(IS_PENDING_VALIDATION.and(IS_PLACE_TYPE_ONLINE)) &&
            context.hasAtLeastOneLine(HAS_PAYMENT_AUTHORIZATION_DELAYED.and(IS_A_DELAYED_PAYMENT_MEAN));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return MonoUtil.infoLog("INTERNAL send notification order waiting for payment for order {}", context.getOrderData().getExistingCustomerOrder().getId())
            .then(
                Mono.when(notificationService.sendWaitingForPaymentNotification(context.getOrderData().getExistingCustomerOrder()),
                    notificationService.sendWaitingForPaymentReminderNotification(context.getOrderData().getExistingCustomerOrder())
                ))
            .then(Mono.fromRunnable(() -> {
                context.getOrderData().getExistingCustomerOrder().setWaitingForPaymentNotificationStatus(NOTIFICATION_REQUESTED);
                context.getOrderData().getExistingCustomerOrder().setWaitingForPaymentReminderNotificationStatus(NOTIFICATION_REQUESTED_POSTPONED);
                context.getOrderData().getExistingLineExecutions().forEach(LineExecution::increaseVersion);
            }));
    }


}
