package com.adeo.sales.customerorder.tempoorchestrator.service.impl;

import com.adeo.bomp.order.avro.create.v3.Create3POrderAvro;
import com.adeo.bomp.order.avro.delivery.AbortDeliveryAvro;
import com.adeo.bomp.order.avro.delivery.StartDeliveryAvro;
import com.adeo.bomp.order.avro.delivery.parameter.AbortDeliveryParameterAvro;
import com.adeo.bomp.order.avro.delivery.parameter.StartDeliveryParameterAvro;
import com.adeo.bomp.order.avro.delivery.parameter.line.CustomerOrderLineAvro;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.ThirdPartyDeliveryCommandManager;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.specific.SpecificRecord;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.configuration.ApplicationProperties.TEMPO_SYSTEM_NAME;

@Slf4j
@Primary
@Component
public class ThirdPartyBOMPDeliveryCommandManagerImpl implements ThirdPartyDeliveryCommandManager {
    public static final String CAPTURED_STATUS = "CAPTURED";
    public static final String ABORT_STATUS = "ABORT";
    private final EventProducer eventProducer;
    private final List<String> startDeliveryTopics;
    private final List<String> cancelCustomerOrderLinesTopics;
    private final List<String> createCustomerOrderTopics;
    private final List<String> sandboxOutTopics;
    private final String productExecutionResponse;

    public ThirdPartyBOMPDeliveryCommandManagerImpl(
        TopicsProperties properties,
        EventProducer eventProducer
    ) {
        this.eventProducer = eventProducer;
        this.startDeliveryTopics = properties.getBompStartDelivery();
        this.cancelCustomerOrderLinesTopics = properties.getBompCancelCustomerOrderLines();
        this.createCustomerOrderTopics = properties.getBompCreateCustomerOrder();
        this.sandboxOutTopics = properties.getBompSandboxOut();
        this.productExecutionResponse = properties.getProductExecutionResponse();
    }

    @Override
    public Mono<Void> createCommand(List<LineExecution> lines, CustomerOrder customerOrder) {
        if (lines.isEmpty()) {
            log.info("INTERNAL no 3P line to create");
            return Mono.empty();
        }

        log.info("INTERNAL ask to start the delivery for following lines: {}", LineExecution.joinLineIds(lines));

        final var command = this.buildCreateCustomerOrderAvro(customerOrder.getId());
        return sendKafkaMessage(this.createCustomerOrderTopics, customerOrder.getId(), customerOrder.getBuCode(), command);
    }

    @Override
    public Mono<Void> abortCustomerOrderLines(List<LineExecution> rejectedLines, CustomerOrder customerOrder) {
        if (rejectedLines.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask to cancel the delivery for following lines: {}", LineExecution.joinLineIds(rejectedLines));

        final var command = this.buildAbortDeliveryAvro(rejectedLines, customerOrder);
        return sendKafkaMessage(this.cancelCustomerOrderLinesTopics, customerOrder.getId(), customerOrder.getBuCode(), command);
    }

    @Override
    public Mono<Void> startDelivery(List<LineExecution> lines, CustomerOrder customerOrder) {
        if (lines.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask to start the delivery for following lines: {}", LineExecution.joinLineIds(lines));

        final var command = this.buildStartDeliveryAvro(lines, customerOrder);
        return sendKafkaMessage(this.startDeliveryTopics, customerOrder.getId(), customerOrder.getBuCode(), command);
    }

    private AbortDeliveryAvro buildAbortDeliveryAvro(List<LineExecution> lines, CustomerOrder customerOrder) {
        var customerOrderLineAvros = lines.stream()
            .map(lineExecution -> CustomerOrderLineAvro.newBuilder()
                .setVersion(lineExecution.getVersion())
                .setType(TEMPO_SYSTEM_NAME)
                .setBompId(lineExecution.getExternalSystem().getId())
                .setCustomerOrderId(customerOrder.getId())
                .setCustomerOrderLineId(lineExecution.getLineId())
                .setStatus(ABORT_STATUS)
                .build())
            .collect(Collectors.toList());

        return AbortDeliveryAvro.newBuilder()
            .setId(UUID.randomUUID().toString())
            .setType("AbortDeliveryAvro")
            .setCommandResponseTopicName(productExecutionResponse)
            .setParameterBuilder(
                AbortDeliveryParameterAvro.newBuilder()
                    .setLines(customerOrderLineAvros)
            )
            .build();
    }

    private StartDeliveryAvro buildStartDeliveryAvro(List<LineExecution> lines, CustomerOrder customerOrder) {
        var linesToStart = lines.stream()
            .map(customerOrderLine -> CustomerOrderLineAvro.newBuilder()
                .setBompId(customerOrderLine.getExternalSystem().getId())
                .setCustomerOrderId(customerOrder.getId())
                .setCustomerOrderLineId(customerOrderLine.getLineId())
                .setVersion(customerOrderLine.getVersion())
                .setStatus(CAPTURED_STATUS)
                .setType(TEMPO_SYSTEM_NAME)
                .build())
            .collect(Collectors.toList());

        return StartDeliveryAvro.newBuilder()
            .setId(UUID.randomUUID().toString())
            .setType("StartDeliveryAvro")
            .setParameterBuilder(StartDeliveryParameterAvro.newBuilder().setLines(linesToStart))
            .setCommandResponseTopicName(this.productExecutionResponse)
            .build();
    }

    private Create3POrderAvro buildCreateCustomerOrderAvro(String customerOrderId) {
        return Create3POrderAvro.newBuilder()
            .setCustomerOrderId(customerOrderId)
            .build();
    }

    private <T extends SpecificRecord & GenericRecord> Mono<Void> sendKafkaMessage(List<String> topics, String customerOrderId, String buCode, T avro) {
        return Mono.when(
            eventProducer.sendEvents(topics, customerOrderId, buCode, avro, true),
            eventProducer.sendEvents(this.sandboxOutTopics, customerOrderId, buCode, avro, false)
        );
    }
}
