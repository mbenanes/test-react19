package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CustomerOrderLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderLineRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple5;
import reactor.util.function.Tuples;

import java.util.List;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_COMPLETE_FOR_SFW;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_RECEIVED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_SHIPPED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_INCOTERM_DDP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_INCOTERM_EXW;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_PARTNER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_STOCK_VALUATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_STOCK_VALUATION_SUCCESS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_PROCESSING;
import static reactor.function.TupleUtils.function;


@RequiredArgsConstructor
@Service
@Slf4j
public class UnlockSoldeAutoRunService {

    private static final Predicate<LineExecution> IS_EXTERNAL_SYSTEM_TEMPO_DELIVERED_LINE =
        IS_EXTERNAL_SYSTEM_TEMPO
            .and(IS_SHIPPED_BY_PARTNER
                .and((IS_DELIVERY_SHIPPED.or(IS_DELIVERY_RECEIVED)).and(IS_INCOTERM_EXW)
                        .or(IS_DELIVERY_RECEIVED.and(IS_INCOTERM_DDP))))
            .or(IS_DELIVERY_COMPLETE_FOR_SFW);

    private static final Predicate<LineExecution> REFLM_IS_ABSENT =
        line -> line.getComposition().getOffer().getRefLM() == null;

    private static final Predicate<LineExecution> DEPOSIT_LEGACY_NUMBER_IS_ABSENT =
        line -> line.getPayment().getDepositLegacyNumber() == null;

    private final RuleEngineService ruleEngineService;
    private final LegacyNumberService legacyNumberService;
    private final CustomerOrderLineRepository customerOrderLineRepository;

    public Mono<Void> unlockSoldeAuto(String customerOrderId, String buCode) {
        return ruleEngineService.lockAndGetData(customerOrderId, buCode)
            .flatMap(data -> updateInformations(data.getT1(), data.getT2(), data.getT3(), data.getT4(), data.getT5()))
            .flatMap(function(ruleEngineService.startRuleEngineAndUpdateLines()));
    }

    private Mono<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> updateInformations(CustomerOrder customerOrder, List<LineExecution> lineExecutions, List<Alert> alerts, List<ExecutionAction> executionActions, List<Execution> executions) {

        if (executionActions.stream().anyMatch(IS_EXECUTION_ACTION_PROCESSING)) {
            return Mono.error(new IllegalStateException("An execution action is in progress"));
        }

        var lineExecutionsWithoutReflm = filterLines(lineExecutions, IS_EXTERNAL_SYSTEM_TEMPO_DELIVERED_LINE
            .and(IS_STOCK_VALUATION_REQUESTED)
            .and(REFLM_IS_ABSENT));

        var lineExecutionsWithoutDepositLegacyNumber = filterLines(lineExecutions, IS_EXTERNAL_SYSTEM_TEMPO_DELIVERED_LINE
            .and(IS_STOCK_VALUATION_REQUESTED.or(IS_STOCK_VALUATION_SUCCESS))
            .and(DEPOSIT_LEGACY_NUMBER_IS_ABSENT));

        return processLines(customerOrder, lineExecutions, alerts, executionActions, executions,
            lineExecutionsWithoutReflm, lineExecutionsWithoutDepositLegacyNumber);
    }

    private List<LineExecution> filterLines(List<LineExecution> lineExecutions, Predicate<LineExecution> condition) {
        return lineExecutions.stream().filter(condition).toList();
    }

    private Mono<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> processLines(CustomerOrder customerOrder, List<LineExecution> lineExecutions, List<Alert> alerts, List<ExecutionAction> executionActions, List<Execution> executions, List<LineExecution> lineExecutionsWithoutReflm, List<LineExecution> lineExecutionsWithoutDepositLegacyNumber) {

        if (!lineExecutionsWithoutReflm.isEmpty() && !lineExecutionsWithoutDepositLegacyNumber.isEmpty()) {
            return updateDepositAndRefLM(customerOrder, lineExecutionsWithoutReflm, lineExecutionsWithoutDepositLegacyNumber)
                .thenReturn(Tuples.of(customerOrder, lineExecutions, alerts, executionActions, executions));
        }

        if (!lineExecutionsWithoutReflm.isEmpty()) {
            return updateRefLM(lineExecutionsWithoutReflm)
                .thenReturn(Tuples.of(customerOrder, lineExecutions, alerts, executionActions, executions));
        }

        if (!lineExecutionsWithoutDepositLegacyNumber.isEmpty()) {
            return legacyNumberService.retrieveLegacyNumbersAndUpdateLines(lineExecutionsWithoutDepositLegacyNumber, customerOrder)
                .thenReturn(Tuples.of(customerOrder, lineExecutions, alerts, executionActions, executions));
        }

        return Mono.error(new IllegalStateException("Nothing can be done automatically"));
    }

    private Mono<Void> updateDepositAndRefLM(CustomerOrder customerOrder,
                                             List<LineExecution> lineExecutionsWithoutReflm,
                                             List<LineExecution> lineExecutionsWithoutDepositLegacyNumber) {
        return legacyNumberService.retrieveLegacyNumbersAndUpdateLines(lineExecutionsWithoutDepositLegacyNumber, customerOrder)
            .then(updateRefLM(lineExecutionsWithoutReflm));
    }

    private Mono<Void> updateRefLM(List<LineExecution> lineExecutionsWithoutReflm) {
        return customerOrderLineRepository.getByLineId(lineExecutionsWithoutReflm.stream()
                .map(LineExecution::getLineId)
                .toList())
            .collectList()
            .doOnNext(customerOrderLines -> lineExecutionsWithoutReflm.forEach(line -> updateRefLMForLine(line, customerOrderLines)))
            .then();
    }

    private void updateRefLMForLine(LineExecution lineExecution, List<CustomerOrderLine> customerOrderLines) {
        customerOrderLines.stream()
            .filter(customerOrderLine -> customerOrderLine.getId().equals(lineExecution.getLineId()))
            .findFirst()
            .ifPresent(customerOrderLine -> lineExecution.getComposition().getOffer().setRefLM(customerOrderLine.getOffer().getRefLM()));
    }


}
