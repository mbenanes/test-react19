package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception;

public class CustomerOrderAlreadyExists extends RuntimeException {

    public CustomerOrderAlreadyExists() {
        super("the customer order already exists on database");
    }
}
