package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.backo.input;

import lombok.Builder;
import lombok.Value;

import java.util.List;

@Builder
@Value
public class StockValorizedInput {
    String deliveryLegacyNumber;
    String storeCode;
    String buCode;
    boolean succeed;
    List<String> productReferences;
}
