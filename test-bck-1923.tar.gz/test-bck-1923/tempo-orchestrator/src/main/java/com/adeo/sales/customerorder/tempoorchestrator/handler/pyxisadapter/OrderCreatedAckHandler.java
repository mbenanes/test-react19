package com.adeo.sales.customerorder.tempoorchestrator.handler.pyxisadapter;

import com.adeo.pyxis.adapter.avro.CustomerOrderCreationAck;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.PyxisOrderCreatedApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.input.PyxisOrderInput;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
@Component
@Slf4j
public class OrderCreatedAckHandler implements EventHandler<CustomerOrderCreationAck> {

    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final PyxisOrderCreatedApplicationService pyxisOrderCreatedApplicationService;

    @Override
    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    public Mono<Void> handle(CustomerOrderCreationAck event, EventMetaData eventMetaData) {
        final var customerOrderId = event.getTempoOrderId();
        final var buCode = event.getBuCode();
        mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderId);
        log.info("CustomerOrderCreationAck consumes {} - message id: {}", eventMetaData.getTopic(), eventMetaData.getId().orElse("no id"));

        final var pyxisOrderId = event.getCustomerOrderNumber();

        return pyxisOrderCreatedApplicationService.apply(
            PyxisOrderInput.builder()
                .customerOrderId(customerOrderId)
                .buCode(buCode)
                .lineIds(event.getTempoLineIds())
                .pyxisOrderNumber(pyxisOrderId)
                .storeCode(event.getStoreCode())
                .build()
        );
    }

    @Override
    public Class<?> getManagedEvent() {
        return CustomerOrderCreationAck.class;
    }
}
