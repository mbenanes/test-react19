package com.adeo.sales.customerorder.tempoorchestrator.model.line;

public enum ActionType {
    VALIDATION,
    REQUEST_STOCK_RESERVATION,
    SALES_VALORIZATION_VALIDATION,
    CONFIRMATION,
    VENDOR_ORDER_CREATION,
    PREPARATION,
    DELIVERY,
    OWNERSHIP_TRANSFER,
    SHIPPING;


}
