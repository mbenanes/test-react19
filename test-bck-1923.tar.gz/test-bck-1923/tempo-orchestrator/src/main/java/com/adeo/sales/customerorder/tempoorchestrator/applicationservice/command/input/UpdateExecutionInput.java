package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class UpdateExecutionInput {
    private String requestId;

    private String customerOrderId;
    private String buCode;
    private String appSource;
    private OwnerRequest ownerRequest;
    private ActionType action;
    private List<ExecutionData> executionsToUpdate;
}
