package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.input;

import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
public class CapturePaymentCapturedInput {

    private String customerOrderId;
    private String buCode;
    private List<CapturedLine> capturedLines;

    @Builder
    @AllArgsConstructor
    @Getter
    public static class CapturedLine {
        private String lineId;
        private LineType lineType;
    }

}
