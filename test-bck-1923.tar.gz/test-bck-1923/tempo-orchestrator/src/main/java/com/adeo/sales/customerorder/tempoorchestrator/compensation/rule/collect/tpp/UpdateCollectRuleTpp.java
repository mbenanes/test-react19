package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.collect.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDeliveryCollect;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.service.CustomerOrderCollectService;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.UpdateLineQuantityCollectDto;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_DECREASE_QUANTITY_ACTION_PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_DECREASE_QUANTITY_COLLECT_IS_THE_NEXT_STEP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "UpdateCollectRuleTpp",
    description = "Cancel collect for lines in pickup orchestrated by TEMPO",
    priority = 1000)
public class UpdateCollectRuleTpp {
    public static final Predicate<ExecutionAction> IS_ACTION_EXECUTION_TO_PROCESS = IS_DECREASE_QUANTITY_ACTION_PROCESSING.and(IS_DECREASE_QUANTITY_COLLECT_IS_THE_NEXT_STEP);
    private final CustomerOrderCollectService collectService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneExecutionAction(IS_ACTION_EXECUTION_TO_PROCESS);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return Mono.justOrEmpty(context.getFirstExecutionActionByPredicate(IS_ACTION_EXECUTION_TO_PROCESS))
            .flatMap(actionToExecute -> {
                final Map<String, List<UpdateLineQuantityCollectDto>> UpdateLineQuantityCollectDtoByExecution = actionToExecute.getImpactedExecutions().stream()
                    .filter(impactedExecution -> impactedExecution.isNextStepTypeIs(DECREASE_QUANTITY_COLLECT))
                    .flatMap(impactedExecution -> impactedExecution.getImpactedLines().stream()
                        .filter(impactedLine -> impactedLine.isNextStepIsOfType(DECREASE_QUANTITY_COLLECT))
                        .map(impactedLine -> context.getOrderData().getLineExecutionByIdAndExecutionId(impactedLine.getLineId(), impactedExecution.getCurrentExecutionId())
                            .map(lineExecution -> {
                                BigDecimal quantityToReduce = Optional.ofNullable(impactedLine.getQuantity()).orElse(BigDecimal.ZERO);

                                final LineExecutionDeliveryCollect collect = lineExecution.getDelivery().getCollect();

                                return UpdateLineQuantityCollectDto.builder()
                                    .lineId(lineExecution.getLineId())
                                    .collectLineIdentifier(collect.getCollectLineIdentifier())
                                    .storeId(lineExecution.getPayment().getStoreId())
                                    .collectIdentifier(collect.getCollectId())
                                    .quantity(lineExecution.getQuantity().subtract(quantityToReduce))
                                    .reason(impactedLine.getReason())
                                    .build();
                            })))
                    .flatMap(Optional::stream)
                    .collect(Collectors.groupingBy(UpdateLineQuantityCollectDto::getCollectIdentifier));



                return Flux.fromStream(UpdateLineQuantityCollectDtoByExecution.entrySet().stream())
                    .map(Map.Entry::getValue)
                    .flatMap(updateLineQuantityCollectDtos -> MonoUtil.infoLog("INTERNAL request collect update quantities for lines: {}", UpdateLineQuantityCollectDto.joinLineIds(updateLineQuantityCollectDtos))
                        .then(this.collectService.updateCustomerOrderCollect(updateLineQuantityCollectDtos, context.getOrderData().getExistingCustomerOrder()))
                        .doOnSuccess(customerOrderCollectQuantityUpdateRequested -> actionToExecute.getImpactedExecutions()
                            .stream()
                            .filter(impactedExecution -> impactedExecution.getImpactedLines().stream()
                                .map(ImpactedLine::getLineId)
                                .anyMatch(impactedLineId -> updateLineQuantityCollectDtos.stream()
                                    .map(UpdateLineQuantityCollectDto::getLineId)
                                    .anyMatch(lineIdToUpdate -> lineIdToUpdate.equals(impactedLineId))))
                            .forEach(impactedExecution -> impactedExecution.flagAllImpactedLinesStepsByType(DECREASE_QUANTITY_COLLECT, ImpactedLineStep.Status.PROCESSING))))
                    .then();
            });
    }

}
