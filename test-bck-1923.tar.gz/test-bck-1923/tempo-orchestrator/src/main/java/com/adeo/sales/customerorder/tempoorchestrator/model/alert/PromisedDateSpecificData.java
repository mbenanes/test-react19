package com.adeo.sales.customerorder.tempoorchestrator.model.alert;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.Map;

@Getter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class PromisedDateSpecificData extends AlertSpecificData {
    private static final List<String> REASON_WITH_DELIVERY_DATE = List.of(
        AlertReason.FORECASTED_LATE.name(), AlertReason.FORECASTED_EARLY.name(), AlertReason.FORECASTED_LATE_ON_SHIPPED.name()
    );

	private String step;
	private DeliveryDate newPromiseDate;

    private PromisedDateSpecificData(PromisedDateSpecificData from) {
        super(from);
        this.step = from.step;
        this.newPromiseDate = from.newPromiseDate;
    }

	@Override
	public Map<String, Object> getDomainSpecificData() {
		final var domainSpecificData = super.getDomainSpecificData();

		if (REASON_WITH_DELIVERY_DATE.contains(this.reason)) {
			domainSpecificData.put("deliveryDate", this.newPromiseDate);
		}

		return domainSpecificData;
	}

    @Override
    public AlertSpecificData copy() {
        return new PromisedDateSpecificData(this);
    }
}
