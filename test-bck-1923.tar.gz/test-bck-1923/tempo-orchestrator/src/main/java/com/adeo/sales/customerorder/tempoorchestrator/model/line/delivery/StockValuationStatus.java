package com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery;

public enum StockValuationStatus {
    STOCK_VALUATION_REQUESTED,
    STOCK_VALUATION_SUCCEED,
    STOCK_VALUATION_FAILED
}
