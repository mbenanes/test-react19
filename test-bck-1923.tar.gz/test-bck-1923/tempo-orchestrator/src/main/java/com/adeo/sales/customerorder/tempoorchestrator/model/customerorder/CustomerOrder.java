package com.adeo.sales.customerorder.tempoorchestrator.model.customerorder;

import com.adeo.sales.customerorder.tempoorchestrator.model.Clock;
import com.adeo.sales.customerorder.tempoorchestrator.model.LegacyNumbersStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentPlaceType;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(of = {"id", "version"})
public class CustomerOrder {

    private String id;

    private CollectStatus collectStatus;

    private String customerOrderNumber;

    private CustomerOrderStatus status;

    private Integer version;

    private String buCode;

    private Clock paymentSchedule;

    private Clock paymentExecutionPolicy;
    private Clock quotation;
    private Clock delivery;
    private Clock deliveryFromDST;
    private String dematCode;
    private LegacyNumbersStatus dematCodeStatus;
    private NotificationStatus notificationStatus;

    private NotificationStatus waitingForPaymentNotificationStatus;

    private NotificationStatus waitingForPaymentReminderNotificationStatus;

    private NotificationStatus longPaymentCanceledNotificationStatus;

    private NotificationStatus cancelNotificationStatus;
    private PostponedEventStatus autoCancellation;

    private String cancelationReason;

    private ProductOffer productOffer;

    private Customer customer;

    private OffsetDateTime firstValidatedAt;

    private CustomerOrderPlaceType orderPlaceType;
    private PaymentPlaceType paymentPlaceType;
    private List<CustomerOrderConfiguration> configurations;

    private CustomerOrderMetadata metadata;
    private boolean haveToCheckTppRequirements = false;
    private boolean isCountMetricGenerated = false;

    @JsonIgnore
    private boolean versionIncreased;

    /**
     * properties not used now, but persisted on database
     * This is use by Jackson to serialize/deserialize properties not mapped on Java class
     */
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private Map<String, Object> ignoredProperties = new HashMap<>();

    public CustomerOrder(String id, String buCode, Integer version) {
        this.id = id;
        this.buCode = buCode;
        this.version = version;
    }

    @JsonAnyGetter
    public Map<String, Object> any() {
        return ignoredProperties;
    }

    @JsonAnySetter
    public void set(String name, Object value) {
        ignoredProperties.put(name, value);
    }

    public Clock getQuotation() {
        if (this.quotation == null) {
            this.quotation = new Clock();
        }
        return quotation;
    }

    public PaymentPlaceType getPaymentPlaceType(){
        if (this.paymentPlaceType == null) {
            this.paymentPlaceType = PaymentPlaceType.ONLINE;
        }
        return paymentPlaceType;
    }

    public Clock getDelivery() {
        if (this.delivery == null) {
            this.delivery = new Clock();
        }
        return delivery;
    }

    public Clock getDeliveryFromDST() {
        if (this.deliveryFromDST == null) {
            this.deliveryFromDST = new Clock();
        }
        return deliveryFromDST;
    }

    public Clock getPaymentExecutionPolicy() {
        if (this.paymentExecutionPolicy == null) {
            this.paymentExecutionPolicy = new Clock();
        }
        return paymentExecutionPolicy;
    }

}
