package com.adeo.sales.customerorder.tempoorchestrator.service.ucc;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPaymentRequirements;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.ulys.ulyscashingcommitment.avro.beans.CustomerOrderCommitmentOperationRequest;
import com.adeo.ulys.ulyscashingcommitment.avro.beans.CustomerOrderOperationCommitmentOperationRequestItem;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECTABLE_DELIVERY_TYPE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.service.ucc.UCCCustomerOrderCommitmentOperationService.UCCSalesEnum.OWNERSHIP_TRANSFER;
import static java.util.function.Predicate.not;

@Slf4j
@Component
@RequiredArgsConstructor
public class UCCCustomerOrderCommitmentOperationService {

    private final TopicsProperties topicsProperties;
    private final EventProducer eventProducer;

    public Mono<String> askOwnerShipTransfer(int customerOrderVersion, List<LineExecution> lineExecutions) {
        String sourceId = UUID.randomUUID().toString();
        final String customerOrderId = lineExecutions.get(0).getCustomerOrderId();
        final String buCode = lineExecutions.get(0).getBuCode();

        final List<CustomerOrderOperationCommitmentOperationRequestItem> customerOrderOperationCommitmentOperationRequestItems = lineExecutions.stream()
            .map(lineExecution -> CustomerOrderOperationCommitmentOperationRequestItem.newBuilder()
                .setCustomerOrderCartItemId(lineExecution.getLineId())
                .setAmount(lineExecution.getPaymentRequirements().getAmount())
                .setQuantity(lineExecution.getQuantity())
                .build())
            .collect(Collectors.toList());

        //add delivery information to commitment
        Optional<LineExecution> lineExecutionWithDeliveryOptional = lineExecutions.stream().filter(IS_OFFER.and(not(IS_COLLECTABLE_DELIVERY_TYPE))).findFirst();
        if(lineExecutionWithDeliveryOptional.isPresent()){
            final BigDecimal totalDeliveryAmount = lineExecutions.stream()
                .map(LineExecution::getPaymentRequirements)
                .map(LineExecutionPaymentRequirements::getDeliveryAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

            final String executionDeliveryId = lineExecutions.get(0).getDelivery().getIdDelivery();
            final CustomerOrderOperationCommitmentOperationRequestItem customerOrderOperationCommitmentOperationRequestdeliveryItem = CustomerOrderOperationCommitmentOperationRequestItem.newBuilder()
                .setCustomerOrderCartItemId(executionDeliveryId)
                .setAmount(totalDeliveryAmount)
                .setQuantity(BigDecimal.ONE)
                .build();

            customerOrderOperationCommitmentOperationRequestItems.add(customerOrderOperationCommitmentOperationRequestdeliveryItem);
        }

        final CustomerOrderCommitmentOperationRequest request = CustomerOrderCommitmentOperationRequest.newBuilder()
            .setCustomerOrderId(customerOrderId)
            .setSourceId(sourceId)
            .setCustomerOrderVersion(customerOrderVersion)
            .setType(OWNERSHIP_TRANSFER.name())
            .setItems(customerOrderOperationCommitmentOperationRequestItems)
            .build();

        return Mono.just(request)
            .then(Mono.zip(this.eventProducer.sendEvents(this.topicsProperties.getUccCustomerOrderCommitmentRequest(), customerOrderId, buCode, request, true),
                this.eventProducer.sendEvents(this.topicsProperties.getBompSandboxOut(), customerOrderId, buCode, request, false)))
            .thenReturn(sourceId);
    }

    public enum UCCSalesEnum {
        OWNERSHIP_TRANSFER
    }
}
