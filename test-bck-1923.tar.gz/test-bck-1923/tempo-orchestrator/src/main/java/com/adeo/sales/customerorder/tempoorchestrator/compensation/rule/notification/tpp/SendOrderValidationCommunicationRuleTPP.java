package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_CREATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_DATE_CONFIRMED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_PYXIS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_ONLINE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SERVICE_ALONE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_STORE_SELF_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.NotificationStatus.NOTIFICATION_REQUESTED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@AllArgsConstructor
@Rule(name = "SendOrderValidationCommunicationRuleTPP",
    description = "Send customer order validation notification to customer.",
    priority = 1000)
public class SendOrderValidationCommunicationRuleTPP {

    private final OutgoingNotificationService notificationService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var mailIsNotAlreadySent = context.getOrderData().getExistingCustomerOrder().getNotificationStatus() == null;

        return mailIsNotAlreadySent &&
            context.isCustomerOrderMatches(IS_VALIDATED) &&
            (
                (context.isCustomerOrderMatches(IS_PLACE_TYPE_ONLINE) &&
                    context.hasAtLeastOneLine(IS_LINE_COMPOSITION_VALIDATED
                        .and(PAYMENT_ORCHESTRATED_BY_TPP)
                        .and(not(IS_STORE_SELF_SERVICE))
                        .and(IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT)
                        .and(IS_DELIVERY_DATE_CONFIRMED.or(IS_LINE_SERVICE.and(IS_SERVICE_ALONE)))))
                    ||
                    (context.isCustomerOrderMatches(IS_PLACE_TYPE_IN_STORE)
                        && context.hasAtLeastOneLine(IS_LINE_COMPOSITION_VALIDATED
                        .and(PAYMENT_ORCHESTRATED_BY_TPP)
                        .and(not(IS_STORE_SELF_SERVICE))
                        .and(IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT)
                        .and(not(IS_EXTERNAL_SYSTEM_PYXIS).or(IS_EXTERNAL_SYSTEM_PYXIS.and(IS_DELIVERY_CREATED)))
                        .and(IS_DELIVERY_DATE_CONFIRMED.or(IS_LINE_SERVICE.and(IS_SERVICE_ALONE)))))
            );
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return MonoUtil.infoLog("INTERNAL send notification order validation for order {}", context.getOrderData().getExistingCustomerOrder().getId())
            .then(this.notificationService.sendValidationNotification(context.getOrderData().getExistingCustomerOrder()))
            .then(Mono.fromRunnable(() -> context.getOrderData().getExistingCustomerOrder().setNotificationStatus(NOTIFICATION_REQUESTED)));
    }
}
