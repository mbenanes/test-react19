package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.collect.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDeliveryCollect;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_COLLECT_CREATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_APPOINTMENT_REMINDER_NOTIFICATION_NOT_SENT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECTED_LINE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECT_APPOINTMENT_DATE_EXIST;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CONFIRMATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.getNotAssociatedWithAServiceLinesWithPredicate;
import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.NotificationStatus.NOTIFICATION_REQUESTED_POSTPONED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@AllArgsConstructor
@Rule(name = "PostponeAppointmentReminderCommunicationTPPRule",
    description = "Postpone appointment reminder notification to customer.",
    priority = 1001)
public class PostponeAppointmentReminderCommunicationTPPRule {

    private final OutgoingNotificationService notificationService;

    private static final Predicate<LineExecution> IS_COLLECT_VALIDATED_AND_HAS_APPOINTMENT_DATE_WITHOUT_REMINDER = IS_LINE_COMPOSITION_VALIDATED
        .and(IS_CONFIRMATION_REQUIREMENT_COMPLIANT)
        .and(HAS_COLLECT_CREATED.and(IS_COLLECT_APPOINTMENT_DATE_EXIST).and(not(IS_COLLECTED_LINE)))
        .and(IS_APPOINTMENT_REMINDER_NOTIFICATION_NOT_SENT)
        .and(IS_EXTERNAL_SYSTEM_TEMPO);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.isCustomerOrderMatches(IS_VALIDATED) &&
            !getNotAssociatedWithAServiceLinesWithPredicate(context, IS_COLLECT_VALIDATED_AND_HAS_APPOINTMENT_DATE_WITHOUT_REMINDER).isEmpty();
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var linesToNotify = getNotAssociatedWithAServiceLinesWithPredicate(context, IS_COLLECT_VALIDATED_AND_HAS_APPOINTMENT_DATE_WITHOUT_REMINDER);
        return Flux.fromIterable(context.getOrderData().getExecutionsWithLines(linesToNotify))
            .flatMap(executionWithLines ->
                MonoUtil.infoLog("INTERNAL send notification appointment reminder for order {} and collect {}",
                        context.getOrderData().getExistingCustomerOrder().getId(),
                        executionWithLines.getLineExecutions().stream().findFirst()
                            .map(LineExecution::getDelivery)
                            .map(LineExecutionDelivery::getCollect)
                            .map(LineExecutionDeliveryCollect::getCollectLineIdentifier)
                            .orElse("unknown")
                    )
                    .then(
                        Mono.when(this.notificationService.sendAppointmentReminderDayBeforeNotification(context.getOrderData().getExistingCustomerOrder(), executionWithLines.getLineExecutions()),
                            this.notificationService.sendAppointmentReminderHoursBeforeNotification(context.getOrderData().getExistingCustomerOrder(), executionWithLines.getLineExecutions())
                        ))
                    .doOnSuccess(unused -> executionWithLines.getLineExecutions().forEach(lineExecution -> {
                        lineExecution.getDelivery().getCollect().setAppointmentReminderNotificationStatus(NOTIFICATION_REQUESTED_POSTPONED);
                        lineExecution.increaseVersion();
                    }))
            )
            .then();
    }
}
