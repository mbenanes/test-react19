package com.adeo.sales.customerorder.tempoorchestrator.service.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@AllArgsConstructor
@Builder
@NoArgsConstructor
@Data
public class UpdateLineQuantityCollectDto {
    private String lineId;
    private String collectLineIdentifier;
    private String collectIdentifier;
    private String storeId;
    private String reason;
    private BigDecimal quantity;

    public static List<String> joinLineIds(List<UpdateLineQuantityCollectDto> list) {
        return list.stream().map(UpdateLineQuantityCollectDto::getLineId).toList();
    }
}
