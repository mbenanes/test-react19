package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.alerting.input;

import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
public class AlertClosedInput {
    private final String customerOrderId;
    private final String buCode;
    private final String alertId;
    private final Boolean isConsideredDelivered;
    private final List<String> impactedLineIds;
}
