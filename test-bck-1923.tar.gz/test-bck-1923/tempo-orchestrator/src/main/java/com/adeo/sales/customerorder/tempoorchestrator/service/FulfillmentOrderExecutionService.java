package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import reactor.core.publisher.Mono;

import java.util.List;

public interface FulfillmentOrderExecutionService {

    Mono<Void> createOrderExecution(List<LineExecution> lines, CustomerOrder customerOrder);


}
