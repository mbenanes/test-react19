package com.adeo.sales.customerorder.tempoorchestrator.handler.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.PaymentRequirementActionExecutionResponseApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentRequirementActionExecutionResponseInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentRequirementActionExecutionResponseInput.Line;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppAllowedStatus;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ActionType;
import com.adeo.sales.tpp.avro.command.PaymentRequirementActionExecutionResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppAllowedStatus.APPROVED;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppAllowedStatus.FAILED;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppAllowedStatus.REJECTED;


@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentRequirementActionExecutionResponseEventHandler implements EventHandler<PaymentRequirementActionExecutionResponse> {

    private final MappedDiagnosticContext mappedDiagnosticContext;

    private final PaymentRequirementActionExecutionResponseApplicationService applicationService;

    @Override
    public Mono<Void> handle(PaymentRequirementActionExecutionResponse event, EventMetaData eventMetaData) {
        String status = event.getStatus();

        final TppAllowedStatus tppStatus;
        try {
            tppStatus = TppAllowedStatus.valueOf(status);
        } catch (IllegalArgumentException illegalArgumentException) {
            log.error("PaymentRequirementActionExecutionResponse consumes {} - message id: {} - the status {} is not handled by TOR, the message is ignored.", eventMetaData.getTopic(), eventMetaData.getId().orElse("no id"), status);
            return Mono.empty();
        }

        String customerOrderID = event.getCustomerOrderId();
        String buCode = event.getBuId();
        this.mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderID, buCode);

        String actionType = event.getPaymentRequirementActionExecutionCreationRequest().getPaymentRequirementActionType();
        String operationId = event.getPaymentRequirementActionExecutionOperationSourceId();
        Instant statusDate = event.getStatusDate();
        Boolean isUnexecAction = event.getPaymentRequirementActionExecutionCreationRequest().getPaymentRequirementActionExecution().get(0).getQuantity().compareTo(BigDecimal.ZERO) < 0;

        log.info("PaymentRequirementActionExecutionResponse actionType {}  consumes {} - message id: {}", actionType, eventMetaData.getTopic(), eventMetaData.getId().orElse("no id"));
        String errorMessage = null;
        String tppErrorType = null;
        if (FAILED.equals(tppStatus) && event.getFailedReason() != null) {
            errorMessage = event.getFailedReason().getDescription();
            tppErrorType = event.getFailedReason().getValue();
        } else if (REJECTED.equals(tppStatus) && event.getRejectedReason() != null) {
            tppErrorType = event.getRejectedReason().getValue();
            errorMessage = event.getRejectedReason().getDescription();
        }

        //retreive amount to ownershiptransfer
        List<Line> lines;
        if (ActionType.OWNERSHIP_TRANSFER.name().equals(event.getPaymentRequirementActionExecutionCreationRequest().getPaymentRequirementActionType())) {
            lines = extractLinesInfoToOwnerShipTransfert(event, tppStatus);
        } else {
            lines = extractLineInfo(event);
        }

        return this.applicationService.apply(PaymentRequirementActionExecutionResponseInput.builder()
            .customerOrderId(customerOrderID)
            .customerOrderExecutionPlanId(event.getCustomerOrderExecutionPlanId())
            .buCode(buCode)
            .operationId(operationId)
            .status(tppStatus)
            .isUnexecAction(isUnexecAction)
            .tppErrorType(tppErrorType)
            .errorMessage(errorMessage)
            .statusDate(statusDate)
            .lines(lines)
            .customerOrderPaymentExecutionPolicyVersion(event.getPaymentRequirementActionExecutionCreationRequest().getCustomerOrderPaymentExecutionPolicyVersion())
            .actionType(actionType)
            .build());
    }


    private static List<Line> extractLineInfo(PaymentRequirementActionExecutionResponse event) {
        return event.getPaymentRequirementActionExecutionCreationRequest().getPaymentRequirementActionExecution().stream()
            .map(paymentRequirementActionExecutionItem -> Line.builder()
                .id(paymentRequirementActionExecutionItem.getCustomerOrderCartItemId())
                .build())
            .toList();
    }

    private static List<Line> extractLinesInfoToOwnerShipTransfert(PaymentRequirementActionExecutionResponse event, TppAllowedStatus tppStatus) {
        List<Line> lines = null;
        if (APPROVED.equals(tppStatus) && event.getOwnershipTransfer() != null && !event.getOwnershipTransfer().isEmpty()) {
            lines = event.getOwnershipTransfer().stream()
                .map(ownershipTransfer -> Line.builder()
                    .amount(ownershipTransfer.getAllocatedAmount())
                    .deliveryAmount(ownershipTransfer.getDeliveryAllocatedAmount())
                    .id(ownershipTransfer.getCustomerOrderCartItemId())
                    .build())
                .collect(Collectors.toList());
        } else if (FAILED.equals(tppStatus) || REJECTED.equals(tppStatus)) {
            lines = extractLineInfo(event);
        } else {
            log.error("The response of Requirement OWNERSHIPTRANSFER has no lines value and amout operationId {} ", event.getPaymentRequirementActionExecutionOperationSourceId());
        }
        return lines;
    }

    @Override
    public Class<?> getManagedEvent() {
        return PaymentRequirementActionExecutionResponse.class;
    }
}
