package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.DeliveryStepUpdatedInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.service.UpdateDeliveryInformationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import static reactor.function.TupleUtils.function;

@RequiredArgsConstructor
@Slf4j
@Component
public class DeliveryStepUpdatedApplicationService {
    private final RuleEngineService ruleEngineService;

    private final UpdateDeliveryInformationService updateDeliveryInformationService;


    public Mono<Void> apply(DeliveryStepUpdatedInput input) {
        if (input.getLines().isEmpty()) {
            log.info("INTERNAL no line has been received on the Delivery event.");
            return Mono.empty();
        }

        return ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode())
            .onErrorResume(CustomerOrderNotFound.class, error -> MonoUtil.infoLog(error.getMessage()))
            .flatMap(function((customerOrder, lineExecutions, alerts, executionActions, executions) ->
                this.updateDeliveryInformationService.apply(input, lineExecutions, executionActions, alerts)
                    .then(this.ruleEngineService.startRuleEngineAndUpdateLines(customerOrder, lineExecutions, alerts, executionActions, executions)))
            )
            .then();
    }


}
