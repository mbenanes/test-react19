package com.adeo.sales.customerorder.tempoorchestrator.handler;

import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.messaging.Message;

import java.util.Optional;

@SuppressWarnings("rawtypes")
public class EventMetaData {
    private final String id;
    @Getter
    private final String topic;
    private final Message message;

    public EventMetaData(String eventId, Message message) {
        this.id = eventId;
        this.topic = (String) message.getHeaders().get("kafka_receivedTopic");
        this.message = message;
    }

    public EventMetaData(String id, String topic) {
        this.id = id;
        this.topic = topic;
        this.message = null;
    }

    public Optional<String> getHeader(String name) {
        return Optional.ofNullable(this.message)
            .map(Message::getHeaders)
            .flatMap(headers -> Optional.ofNullable(headers.get(name)))
            .filter(byte[].class::isInstance)
            .map(header -> new String((byte[]) header));
    }

    public String getBuCode() {
        if (this.message.getHeaders() != null && this.message.getHeaders().get("bu-code") != null) {
            return new String((byte[]) this.message.getHeaders().get("bu-code"));
        }
        return null;
    }

    public String getLabelBu(){
        if (this.message.getHeaders() != null && this.message.getHeaders().get("x-bu-code") != null) {
            return new String((byte[]) this.message.getHeaders().get("x-bu-code"));
        }
        return null;

    }

    public String getBusinessUnit() {
        if (this.message.getHeaders() != null && this.message.getHeaders().get("BUSINESS_UNIT") != null) {
            if (byte[].class.isInstance(this.message.getHeaders().get("BUSINESS_UNIT"))) {
                return new String((byte[]) this.message.getHeaders().get("BUSINESS_UNIT"));
            } else if (String.class.isInstance(this.message.getHeaders().get("BUSINESS_UNIT"))) {
                return (String) message.getHeaders().get("BUSINESS_UNIT");
            }
        }
        return StringUtils.EMPTY;
    }

    public Optional<String> getId() {
        return Optional.ofNullable(id);
    }

    public String getType() {
        if (message == null) {
            return "unknown";
        }
        return message.getPayload().getClass().getSimpleName();
    }

}
