package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception;

import com.adeo.sales.customerorder.tempoorchestrator.handler.ulys.CashingPaymentStatus;


public class StateNotManagedException extends RuntimeException {
    public StateNotManagedException(CashingPaymentStatus status) {
        super("the cashing status " + status.name() + " is not managed on an authorization feedback.");
    }
}
