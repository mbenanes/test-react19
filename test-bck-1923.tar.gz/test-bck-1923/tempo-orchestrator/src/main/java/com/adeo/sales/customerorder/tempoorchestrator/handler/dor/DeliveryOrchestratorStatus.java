package com.adeo.sales.customerorder.tempoorchestrator.handler.dor;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum DeliveryOrchestratorStatus {
    RESERVED("Reserved"),
    SHIPPED("Shipped"),
    DELIVERED("Delivered"),
    READY_TO_PREPARE("Ready to prepare");

    private final String value;
}
