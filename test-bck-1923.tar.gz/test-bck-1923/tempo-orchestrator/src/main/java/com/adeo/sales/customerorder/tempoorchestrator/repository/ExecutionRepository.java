package com.adeo.sales.customerorder.tempoorchestrator.repository;

import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface ExecutionRepository {
    Flux<Execution> getExecutionFromOrder(String customerOrderId, String buCode);

    Mono<Void> update(List<Execution> executions);

    Mono<Void> save(List<Execution> executions);

    Mono<Void> delete(String customerOrderId, String idExecution);

    class NoExecutionUpsertedException extends RuntimeException {
        public NoExecutionUpsertedException() {
            super("No execution has been upserted");
        }
    }
}
