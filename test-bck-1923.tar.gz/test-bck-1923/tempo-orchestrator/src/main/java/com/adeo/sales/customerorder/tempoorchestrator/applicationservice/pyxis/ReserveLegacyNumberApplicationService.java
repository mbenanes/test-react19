package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis;

import com.adeo.sales.customerorder.external.api.client.legacyacl.dto.LegacyNumberType;
import com.adeo.sales.customerorder.external.api.client.tco.TcoApiClient;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderAlreadyExists;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.input.ReserveLegacyNumberInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.Clock;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecutionComposition;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment;
import com.adeo.sales.customerorder.tempoorchestrator.service.LegacyNumberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@Slf4j
@RequiredArgsConstructor
@Service
public class ReserveLegacyNumberApplicationService {
    private final RuleEngineService ruleEngineService;
    private final LegacyNumberService legacyNumberService;
    private final TcoApiClient tcoApiClient;

    public Mono<Void> apply(ReserveLegacyNumberInput input) {
        return this.updateLinesAndStartRuleEngine(input)
            .onErrorResume(CustomerOrderNotFound.class, error -> this.initCustomerOrder(input)
                .onErrorResume(
                    CustomerOrderAlreadyExists.class,
                    errorCreation -> this.updateLinesAndStartRuleEngine(input)
                ));
    }

    @NotNull
    private Mono<Void> updateLinesAndStartRuleEngine(ReserveLegacyNumberInput input) {
        return this.ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode())
            .doOnNext(
                consumer((customerOrder, lineExecutions) -> this.setLegacyNumber(customerOrder, lineExecutions, input))
            )
            .flatMap(function(this.ruleEngineService.startRuleEngineAndUpdateLines()));
    }

    protected Mono<Void> initCustomerOrder(ReserveLegacyNumberInput input) {
        return tcoApiClient.getTempoConsolidatedOrder(input.getCustomerOrderId(), input.getBuCode())
            .flatMap(tempoConsolidatedOrder -> {
                Function<com.adeo.sales.customerorder.external.api.client.tco.dto.Clock, Clock> mapClockFunction = clock -> new Clock(clock.getId(), clock.getVersion());
                CustomerOrder customerOrderToCreate = CustomerOrder.builder()
                    .id(input.getCustomerOrderId())
                    .buCode(input.getBuCode())
                    .orderPlaceType(CustomerOrderPlaceType.IN_STORE.name().equals(tempoConsolidatedOrder.getOrderPlaceType()) ? CustomerOrderPlaceType.IN_STORE : CustomerOrderPlaceType.ONLINE)
                    .paymentSchedule(Optional.ofNullable(tempoConsolidatedOrder.getTechnicalDependenciesInformation().getPaymentSchedule()).map(mapClockFunction).orElse(null))
                    .paymentExecutionPolicy(Optional.ofNullable(tempoConsolidatedOrder.getTechnicalDependenciesInformation().getPaymentExecutionPolicy()).map(mapClockFunction).orElse(null))
                    .version(1)
                    .build();

                List<LineExecution> lines = tempoConsolidatedOrder.getOfferLines().stream().map(offerline -> LineExecution.builder()
                        .version(1)
                        .lineId(offerline.getId())
                        .lineType("SERVICE".equals(offerline.getItemType()) ? LineType.SERVICE : LineType.OFFER)
                        .externalSystem(ExternalSystem.builder()
                            .build())
                        .customerOrderId(input.getCustomerOrderId())
                        .lineType(LineType.OFFER)
                        .buCode(input.getBuCode())
                        .payment(LineExecutionPayment.builder()
                            .paymentExecutionSystem(customerOrderToCreate.getPaymentSchedule() != null ? LineExecutionPayment.PaymentExecutionSystem.PSR : LineExecutionPayment.PaymentExecutionSystem.TPP)
                            .build())
                        .delivery(LineExecutionDelivery.builder().build())
                        .isSoldByAThirdPartyVendor(offerline.getOffer().isSoldByAThirdPartyVendor())
                        .quantity(offerline.getQuantity())
                        .composition(LineExecutionComposition.builder()
                            .quantity(offerline.getQuantity())
                            .build())
                        .build())
                    .toList();

                this.setLegacyNumber(customerOrderToCreate, lines, input);

                return this.ruleEngineService.createOrderAndStartRuleEngine(customerOrderToCreate, lines);
            });
    }

    private void setLegacyNumber(CustomerOrder customerOrder, List<LineExecution> lineExecutions, ReserveLegacyNumberInput input) {
        lineExecutions.forEach(lineExecution -> input.getLines()
            .stream()
            .filter(inputLine -> inputLine.getLineId().equals(lineExecution.getLineId()))
            .forEach(inputLine -> {
                ReserveLegacyNumberInput.Line.LegacyNumber depositLegacyNumber = inputLine.getLegacyNumbers().stream()
                    .filter(inputLegacyNumber -> LegacyNumberType.DEPOSIT.name().equals(inputLegacyNumber.getType()))
                    .findFirst()
                    .orElse(null);

                ReserveLegacyNumberInput.Line.LegacyNumber bvLegacyNumber = inputLine.getLegacyNumbers().stream()
                    .filter(inputLegacyNumber -> LegacyNumberType.BV.name().equals(inputLegacyNumber.getType()))
                    .findFirst()
                    .orElse(null);

                ReserveLegacyNumberInput.Line.LegacyNumber customerOrderLegacyNumber = inputLine.getLegacyNumbers().stream()
                    .filter(inputLegacyNumber -> LegacyNumberType.CUSTOMER_ORDER.name().equals(inputLegacyNumber.getType()))
                    .findFirst()
                    .orElse(null);

                this.legacyNumberService.mapLegacyNumbers(customerOrder, lineExecution, bvLegacyNumber, customerOrderLegacyNumber, depositLegacyNumber, false);
            }));
    }
}
