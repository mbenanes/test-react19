package com.adeo.sales.customerorder.tempoorchestrator.model.legacy;

public enum CustomerOrderLineCompositionOrderStatus {
    PENDING,
    VALIDATED,
    DECREASE_QUANTITY_REQUESTED,
    CANCELED_REQUESTED,
    CANCELED,
    UNKNOWN
}
