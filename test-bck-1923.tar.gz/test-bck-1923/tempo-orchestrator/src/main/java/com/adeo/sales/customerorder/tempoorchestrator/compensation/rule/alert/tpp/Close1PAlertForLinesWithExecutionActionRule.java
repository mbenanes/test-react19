package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.HAS_ALERT_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_REASON_CUSTOMER_CANCELLATION_FAILURE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_REASON_FORECASTED_LATE_ON_SHIPPED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_TYPE_PROMISE_DATE_NOT_CLOSED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.getAlertsContainingLineByPredicate;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_TO_EXECUTE;
import static com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService.ClosingReason.CANCELED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Close1PAlertForLinesWithExecutionAction",
    description = "Close promised date alert an reason in (LATE, FORECASTED_LATE, CREATION_FAILURE, OUT_OF_STOCK)",
    priority = 900)
public class Close1PAlertForLinesWithExecutionActionRule {
    private final AlertMessageService notifier;

    private static final Predicate<Alert> IS_ALERT_CLOSABLE =
        HAS_ALERT_ID
            .and(IS_TYPE_PROMISE_DATE_NOT_CLOSED)
            .and(not(IS_REASON_FORECASTED_LATE_ON_SHIPPED))
            .and(not(IS_REASON_CUSTOMER_CANCELLATION_FAILURE));

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        List<Alert> openedAlerts = context.getAlertData().getAlertsFilterBy(IS_ALERT_CLOSABLE);
        List<ExecutionAction> executionActions = context.getExecutionActionsByPredicate(IS_EXECUTION_ACTION_TO_EXECUTE.or(IS_EXECUTION_ACTION_PROCESSING));

        Set<String> impactedLineIdsInExecutionActions = executionActions.stream().flatMap(executionAction -> executionAction.getAllImpactedLines().stream()).map(ImpactedLine::getLineId).collect(Collectors.toSet());

        Set<String> impactedLineIdsInAlerts = openedAlerts.stream().flatMap(alert -> alert.getImpactedLinesIds().stream()).collect(Collectors.toSet());

        return impactedLineIdsInExecutionActions.stream().anyMatch(impactedLineIdsInAlerts::contains);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {

        List<ExecutionAction> executionActions = context.getExecutionActionsByPredicate(IS_EXECUTION_ACTION_TO_EXECUTE.or(IS_EXECUTION_ACTION_PROCESSING));

        Set<String> impactedLineIdsInExecutionActions = executionActions.stream().flatMap(executionAction -> executionAction.getAllImpactedLines().stream()).map(ImpactedLine::getLineId).collect(Collectors.toSet());

        final var closableAlertForConsideredDeliveredLines = getAlertsContainingLineByPredicate(context, impactedLineIdsInExecutionActions.stream().toList(), IS_ALERT_CLOSABLE);

        return MonoUtil.infoLog("INTERNAL request close 1P alert for alerts: {} because lines have pending execution actions", Alert.joinAlertIds(closableAlertForConsideredDeliveredLines))
            .then(Mono.when(
                closableAlertForConsideredDeliveredLines.stream()
                    .map(alert -> this.notifier.sendCloseAlertMessage(alert, CANCELED))
                    .collect(Collectors.toList())
            ));
    }
}
