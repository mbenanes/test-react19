package com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation;

import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertSpecificData;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Map;

@Getter
@SuperBuilder
@NoArgsConstructor
public class PaymentOperationFailedSpecificData extends AlertSpecificData {
    private String operationId;

    private PaymentOperationFailedSpecificData(PaymentOperationFailedSpecificData from) {
        super(from);
        this.operationId = from.operationId;
    }

    @Override
    public Map<String, Object> getDomainSpecificData() {
        final var domainSpecificData = super.getDomainSpecificData();

        domainSpecificData.put("operationId", this.operationId);

        return domainSpecificData;
    }

    @Override
    public AlertSpecificData copy() {
        return new PaymentOperationFailedSpecificData(this);
    }
}
