package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentAdjustmentActionExecutionResponseInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppAllowedStatus;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppErrorType;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.RefundResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.util.Collection;
import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_DECREASE_QUANTITY_ACTION_PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType.IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP;
import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentAdjustmentActionExecutionResponseApplicationService {

    private final RuleEngineService ruleEngineService;

    @Transactional
    public Mono<Void> apply(PaymentAdjustmentActionExecutionResponseInput input) {
        return this.ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode())
            .doOnNext(consumer(
                (customerOrder, lineExecutions, alerts, executionActions) ->
                    executionActions
                        .stream()
                        .filter(IS_DECREASE_QUANTITY_ACTION_PROCESSING)
                        .forEach(executionAction -> {
                            if(input.getRejectedAmount() != null) {
                                addRefundResultIfNecessary(input, executionAction);
                            }
                            if (!TppAllowedStatus.APPROVED.name().equals(input.getStatus()) && !TppErrorType.PAYMENT_EXECUTION_POLICY_VERSION_MISMATCH.name().equals(input.getTppErrorType())) {
                                    executionAction.getFlags().raiseFlag(ExecutionActionStatus.FAILED);
                            }
                            this.updateExecutionAction(input, customerOrder, executionAction, lineExecutions);
                        }))
            )
            .flatMap(function(this.ruleEngineService.startRuleEngineAndUpdateLines()));
    }

    private void addRefundResultIfNecessary(PaymentAdjustmentActionExecutionResponseInput input, ExecutionAction executionAction) {
        final RefundResult refundResultFromTPP = RefundResult.builder().rejectedRefundAmount(input.getRejectedAmount()).adjustmentsId(input.getPaymentAdjustmentActionIds()).build();

        boolean refundResultsNotExisting = executionAction.getRefundResults()
                                                            .stream()
                                                            .noneMatch(refundResult -> refundResult.equals(refundResultFromTPP));

        if(refundResultsNotExisting) {
            final List<String> executedAdjustmentIds = executionAction.getImpactedExecutions()
                .stream()
                .map(ImpactedExecution::getImpactedLines)
                .flatMap(Collection::stream)
                .filter(impactedLine -> impactedLine.isCurrentStepIsType(EXECUTE_ADJUSTMENT_TPP))
                .map(ImpactedLine::getPaymentAdjustmentActionId)
                .toList();

            if(executedAdjustmentIds.containsAll(input.getPaymentAdjustmentActionIds())){
                executionAction.getRefundResults().add(refundResultFromTPP);
            }
        }
    }

    private void updateExecutionAction(PaymentAdjustmentActionExecutionResponseInput input, CustomerOrder customerOrder, ExecutionAction executionAction, List<LineExecution> lineExecutions) {
        input.getPaymentAdjustmentActionIds()
            .forEach(paymentAdjustmentActionIdReceivedByTPP -> executionAction.getImpactedExecutions()
                .forEach(impactedExecution -> impactedExecution.getImpactedLines()
                    .stream()
                    .filter(impactedLine -> paymentAdjustmentActionIdReceivedByTPP.equals(impactedLine.getPaymentAdjustmentActionId()) && impactedLine.isCurrentStepIsType(ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP))
                    .forEach(impactedLine -> impactedLine.getCurrentStep()
                        .ifPresent(currentStep -> {
                            if (TppErrorType.PAYMENT_EXECUTION_POLICY_VERSION_MISMATCH.name().equals(input.getTppErrorType())
                                && customerOrder.getPaymentExecutionPolicy().getVersion() <= input.getTppVersion()) {
                                currentStep.getFlags().raiseFlag(ImpactedLineStep.Status.CREATED);
                                LineExecution.getCorrespondingLineAndExecution(lineExecutions, impactedLine.getLineId(), impactedExecution.getCurrentExecutionId())
                                    .ifPresent(lineExecution -> lineExecution.getPaymentRequirements().setVersionMismatch(true));
                            } else {
                                currentStep.getFlags().raiseFlagIfNot(completedExecutedAdjustmentStep(input, customerOrder) ? ImpactedLineStep.Status.COMPLETED : ImpactedLineStep.Status.FAILED);
                            }
                        }))
                ));
    }

    private static boolean completedExecutedAdjustmentStep(PaymentAdjustmentActionExecutionResponseInput input, CustomerOrder customerOrder) {
        return TppAllowedStatus.APPROVED.name().equals(input.getStatus()) || (IN_STORE.equals(customerOrder.getOrderPlaceType()) && input.getRejectedAmount() != null);
    }
}
