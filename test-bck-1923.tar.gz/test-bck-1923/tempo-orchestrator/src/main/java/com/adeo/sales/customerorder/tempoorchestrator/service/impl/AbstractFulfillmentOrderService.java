package com.adeo.sales.customerorder.tempoorchestrator.service.impl;

import com.adeo.sales.customerorder.external.api.client.cpr.ConfiguredProductRepositoryApiClient;
import com.adeo.sales.customerorder.external.api.client.cpr.dto.ConfiguredProduct;
import com.adeo.sales.customerorder.external.api.client.cpr.dto.Measurement;
import com.adeo.sales.customerorder.external.api.client.csr.ConfiguratorSimulationsRepositoryApiClient;
import com.adeo.sales.customerorder.external.api.client.csr.dto.OfferItem;
import com.adeo.sales.customerorder.external.api.client.csr.dto.Simulation;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.ProductConfigurationContainsServiceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.ProductOfferLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import com.adeo.sis.dor.avro.business.fulfillmentorder.FulfillmentOrderLineConfiguredProductAvro;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.util.function.Tuple2;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static java.lang.String.join;

@RequiredArgsConstructor
@Slf4j
@Component
public abstract class AbstractFulfillmentOrderService {

    private final ConfiguredProductRepositoryApiClient configuredProductRepositoryApiClient;
    private final ConfiguratorSimulationsRepositoryApiClient configuratorSimulationsRepositoryApiClient;
    private final static String HEIGHT = "HEIGHT";
    private final static String WIDTH = "WIDTH";
    private final static String DEPTH = "DEPTH";
    private final static String WEIGHT = "WEIGHT";

    public Flux<Simulation> getSimulations(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        return Flux.fromStream(productOfferLineFilter(customerOrder, lineExecutions, "configurationComponent")
                .stream()
                .map(ProductOfferLine::getConfigurationId)
                .filter(Objects::nonNull)
                .distinct())
                .flatMap(configurationId -> configuratorSimulationsRepositoryApiClient.getSimulation(configurationId, customerOrder.getBuCode())
                        .switchIfEmpty(MonoUtil.warnLog("Simulation not found", configurationId)));
    }

    public Flux<ConfiguredProduct> getConfiguredProducts(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        return Flux.fromStream(productOfferLineFilter(customerOrder, lineExecutions, "configuredProduct")
                .stream()
                .map(ProductOfferLine::getConfiguredProductId)
                .filter(Objects::nonNull)
                .distinct())
                .flatMap(configuredProductId -> configuredProductRepositoryApiClient.getConfiguredProduct(configuredProductId, customerOrder.getBuCode())
                        .switchIfEmpty(MonoUtil.warnLog("Configured product not found", configuredProductId)));
    }

    public Optional<FulfillmentOrderLineConfiguredProductAvro> buildFulfillmentOrderLineConfiguredProduct(CustomerOrder customerOrder, List<LineExecution> lineExecutions, String lineId, Tuple2<List<Simulation>, List<ConfiguredProduct>> tuple) {
        return customerOrder.getProductOffer().getItems()
            .stream()
            .filter(productOfferLine -> productOfferLine.getId().equals(lineId))
            .map(productOfferLine -> {
                var lineExecution = LineExecution.getById(lineExecutions, productOfferLine.getId()).orElse(null);
                if (lineExecution == null) {
                    return Optional.<FulfillmentOrderLineConfiguredProductAvro>empty();
                }
                var executionSelector = lineExecution.getComposition().getExecutionSelector();
                if ((executionSelector == null) || ("configurationComponent".equals(executionSelector) && null != lineExecution.getExternalSystem() && lineExecution.getExternalSystem().isPyxis())) {
                    return Optional.<FulfillmentOrderLineConfiguredProductAvro>empty();
                }
                return switch (executionSelector) {
                    case "configuredProduct" ->
                        convertConfiguredProductToFulfillmentOrderLineConfiguredProductAvro(productOfferLine, tuple.getT2());
                    case "configurationComponent" ->
                        convertSimulationToFulfillmentOrderLineConfiguredProductAvro(productOfferLine, tuple.getT1());
                    default -> Optional.<FulfillmentOrderLineConfiguredProductAvro>empty();
                };
            })
            .flatMap(Optional::stream)
            .findFirst();

    }

    private List<ProductOfferLine> productOfferLineFilter(CustomerOrder customerOrder, List<LineExecution> lineExecutions, String executionSelector) {
        return customerOrder.getProductOffer().getItems()
                .stream()
                .filter(productOfferLine -> LineExecution.getById(lineExecutions, productOfferLine.getId()).stream()
                        .filter(lineExecution -> lineExecution.getComposition().getExecutionSelector() != null)
                        .anyMatch(lineExecution -> executionSelector.equals(lineExecution.getComposition().getExecutionSelector())))
            .toList();
    }

    private Optional<FulfillmentOrderLineConfiguredProductAvro> convertConfiguredProductToFulfillmentOrderLineConfiguredProductAvro(ProductOfferLine productOfferLine, List<ConfiguredProduct> configuredProducts) {

        return configuredProducts.stream()
                .filter(products -> productOfferLine.getConfiguredProductId().equals(products.getIdentifier()))
                .findFirst()
                .map(configuredProduct -> {
                    final BigDecimal heightValue = initMeasurementValue(configuredProduct, HEIGHT);
                    final String heightUnit = initMeasurementUnit(configuredProduct, HEIGHT);
                    final BigDecimal widthValue = initMeasurementValue(configuredProduct, WIDTH);
                    final String widthUnit = initMeasurementUnit(configuredProduct, WIDTH);
                    final BigDecimal depthValue = initMeasurementValue(configuredProduct, DEPTH);
                    final String depthUnit = initMeasurementUnit(configuredProduct, DEPTH);
                    final BigDecimal weightValue = initMeasurementValue(configuredProduct, WEIGHT);
                    final String weightUnit = initMeasurementUnit(configuredProduct, WEIGHT);
                    final String volume = initVolume(depthValue, heightValue, widthValue);
                    final var manufacturingLeadTime = configuredProduct.getManufacturingLeadTime();
                    return FulfillmentOrderLineConfiguredProductAvro.newBuilder()
                            .setConfiguredProductGrossWeight(weightValue)
                            .setConfiguredProductGrossWeightMeasurementUnit(weightUnit)
                            .setConfiguredProductVolume(volume)
                            .setConfiguredProductPurchasePrice(null != configuredProduct.getPurchasePrice() ? BigDecimal.valueOf(configuredProduct.getPurchasePrice()) : null)
                            .setConfiguredProductTechnicalLabel(configuredProduct.getTechnicalLabel())
                            .setConfiguredProductManufacturingLeadTimeValue(null != manufacturingLeadTime && null != manufacturingLeadTime.getValue() ? BigDecimal.valueOf(manufacturingLeadTime.getValue()) : null)
                            .setConfiguredProductManufacturingLeadTimeUnit(null != manufacturingLeadTime && null != manufacturingLeadTime.getUnit() ? manufacturingLeadTime.getUnit() : null)
                            .setConfiguredProductHeight(heightValue)
                            .setConfiguredProductHeightMeasurementUnit(heightUnit)
                            .setConfiguredProductDepth(depthValue)
                            .setConfiguredProductDepthMeasurementUnit(depthUnit)
                            .setConfiguredProductWidth(widthValue)
                            .setConfiguredProductWidthMeasurementUnit(widthUnit)
                            .setConfiguredProductManufacturedBy(configuredProduct.getManufacturedBy())
                            .setConfiguredProductIdentifier(configuredProduct.getIdentifier())
                            .build();
                });
    }

    private Optional<FulfillmentOrderLineConfiguredProductAvro> convertSimulationToFulfillmentOrderLineConfiguredProductAvro(ProductOfferLine productOfferLine, List<Simulation> simulations) {
        return simulations.stream()
                .filter(simulation -> productOfferLine.getConfigurationId().equals(simulation.getSimulationId()))
                .map(simulation -> {
                    if (isProductConfiguredWithService(simulation.getOfferItems())) {
                        throw new ProductConfigurationContainsServiceType("INSTALLATION_SERVICE");
                    } else {
                        return simulation;
                    }
                })
                .map(simulation -> simulation.getOfferItems().stream()
                        .filter(offerItem -> offerItem.getId().equals(productOfferLine.getOffer().getRefLM()))
                        .findFirst()
                        .map(offerItem -> FulfillmentOrderLineConfiguredProductAvro.newBuilder()
                                .setConfiguredProductTechnicalLabel(null != offerItem.getTechnicalLabels() ? join(",", offerItem.getTechnicalLabels()) : null)
                                .setConfiguredProductPurchasePrice(null != offerItem.getPurchasePrice() ? BigDecimal.valueOf(offerItem.getPurchasePrice()) : null)
                                .build())
                )
            .flatMap(Optional::stream)
            .findFirst();
    }

    private boolean isProductConfiguredWithService(List<OfferItem> offerItems) {
        return offerItems.stream().anyMatch(offerItem -> "INSTALLATION_SERVICE".equals(offerItem.getItemType())) &&
                offerItems.stream().anyMatch(offerItem -> offerItem.getConfiguredProductId() != null);
    }

    private BigDecimal initMeasurementValue(ConfiguredProduct configuredProduct, String type) {
        return configuredProduct.getMeasurements().stream().filter(measurement -> measurement.getType().equals(type)).findFirst().map(measurement -> BigDecimal.valueOf(measurement.getValue())).orElse(null);
    }

    private String initMeasurementUnit(ConfiguredProduct configuredProduct, String type) {
        return configuredProduct.getMeasurements().stream().filter(measurement -> measurement.getType().equals(type)).findFirst().map(Measurement::getUnit).orElse(null);
    }

    private String initVolume(BigDecimal depth, BigDecimal height, BigDecimal width) {
        return (depth == null || height == null || width == null) ? null : depth.multiply(height).multiply(width).toString();
    }

}
