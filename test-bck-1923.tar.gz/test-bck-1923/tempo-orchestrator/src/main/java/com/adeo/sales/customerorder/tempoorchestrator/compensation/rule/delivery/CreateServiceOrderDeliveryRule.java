package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery;


import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.PyxisPartyCommandService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_PAYMENT_AUTHORIZATION_DELAYED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_PAYMENT_AUTHORIZED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_A_DELAYED_PAYMENT_MEAN;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_EXECUTION_NOT_STARTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_PYXIS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PENDING_VALIDATION_OR_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SERVICE_ALONE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.CREATION_REQUESTED;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "CreateServiceOrderDeliveryRule",
    description = "Create the service line order via Pyxis adapter",
    priority = 1000)
public class CreateServiceOrderDeliveryRule {

    private final PyxisPartyCommandService pyxisPartyCommandService;

    private static final Predicate<LineExecution> SHOULD_CREATE_SERVICE_ORDER =
        IS_1P
            .and(PAYMENT_ORCHESTRATED_BY_PSR)
            .and(IS_LINE_SERVICE)
            .and(IS_SERVICE_ALONE)
            .and(IS_LINE_COMPOSITION_VALIDATED)
            .and(IS_DELIVERY_EXECUTION_NOT_STARTED)
            .and(IS_EXTERNAL_SYSTEM_PYXIS)
            .and(HAS_PAYMENT_AUTHORIZED.or(HAS_PAYMENT_AUTHORIZATION_DELAYED.and(IS_A_DELAYED_PAYMENT_MEAN)));


    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(SHOULD_CREATE_SERVICE_ORDER) && context.isCustomerOrderMatches(IS_PENDING_VALIDATION_OR_VALIDATED);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final List<LineExecution> lineServiceToCreate = context.getOrderData().getLineExecutionsByPredicate(SHOULD_CREATE_SERVICE_ORDER);

        final Flux<Void> createPyxisServiceOnlyOrderMono = Flux.fromIterable(lineServiceToCreate)
            .flatMap(lineExecution -> pyxisPartyCommandService.createPyxisServiceOnlyOrder(lineExecution, context.getOrderData().getExistingCustomerOrder()));
        final Mono<Object> logMono = MonoUtil.infoLog("INTERNAL request pyxis service order creation for lines: {}", LineExecution.joinLineIds(lineServiceToCreate));

        return logMono.thenMany(createPyxisServiceOnlyOrderMono)
            .then(Mono.fromRunnable(() -> lineServiceToCreate.forEach(lineExecution -> {
                lineExecution.getDelivery().getFlags().raiseFlag(CREATION_REQUESTED);
                lineExecution.increaseVersion();
            })));

    }

}
