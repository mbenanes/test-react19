package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.CommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.service.UpdateAvailableActionService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.DELIVERY_CANCELLATION_IS_ALREADY_DOING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_ABORT_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_COMPLETE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_CREATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_EXECUTION_NOT_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_EXECUTION_STARTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_REJECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXECUTION_CANCELABLE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SERVICE_ALONE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_PARTNER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Abort1PDelivery",
    description = "Abort first party line delivery.",
    priority = 1000)
public class Abort1PDeliveryRule {

    private final UpdateAvailableActionService updateAvailableActionService;

    private static final Predicate<LineExecution> LINE_SHOULD_BE_ABORT = IS_1P
        .and(PAYMENT_ORCHESTRATED_BY_PSR)
        .and(IS_LINE_COMPOSITION_CANCELED)
        .and(IS_EXECUTION_CANCELABLE.or(not(IS_EXECUTION_CANCELABLE).and(IS_SHIPPED_BY_PARTNER)))
        .and((IS_DELIVERY_EXECUTION_NOT_CANCELED.and(IS_DELIVERY_REJECTED)).or(not(DELIVERY_CANCELLATION_IS_ALREADY_DOING)))
        .and(not(IS_DELIVERY_CREATION_REQUESTED))
        .and(IS_DELIVERY_EXECUTION_STARTED)
        .and(not(IS_DELIVERY_COMPLETE))
        .and(not(IS_DELIVERY_ABORT_REQUESTED))
        .and(not(IS_LINE_SERVICE).and(not(IS_SERVICE_ALONE)));

    private final CommandEventService commandEventService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return !context.getOrderData().getLineExecutionsByPredicate(LINE_SHOULD_BE_ABORT).isEmpty();
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var lines = context.getOrderData().getLineExecutionsByPredicate(LINE_SHOULD_BE_ABORT);
        if (lines.isEmpty()) {
            log.info("INTERNAL no line can be canceled on DOR system.");
            return Mono.empty();
        }

        return MonoUtil.infoLog("INTERNAL request delivery abort for 1P lines: {}", LineExecution.joinLineIds(lines))
            .then(this.commandEventService.cancelCustomerOrderLines(lines, context.getOrderData().getExistingCustomerOrder()))
            .then(Mono.fromRunnable(() -> lines.forEach(lineExecution -> {
                final var delivery = lineExecution.getDelivery();
                delivery.getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.ABORT_REQUESTED);
                this.updateAvailableActionService.apply(context.getOrderData().getExistingLineExecutions(), lineExecution, context.getOrderData().getExistingCustomerOrder(), false);
                if (lineExecution.getExternalSystem().isTempo()) {
                    delivery.setIsDeliveryDateUpdatable(false);
                }
                lineExecution.increaseVersion();
            })));
    }
}
