package com.adeo.sales.customerorder.tempoorchestrator.handler.dor;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.DeliveryStepUpdatedApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.DeliveryStepUpdatedInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.DORStatus;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.FixedDeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.RangeDeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.ShippingPoint;
import com.adeo.sis.dor.avro.business.fulfillmentorder.FulfillmentOrderLineAvro;
import com.adeo.supply.avro.common.types.v1.LocationType;
import com.adeo.supply.fulfillmentorder.fulfillmentorderStatusUpdated.v1.FulfillmentOrderStatusUpdatedAvro;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class FulfillmentOrderStatusUpdateAvroHandler implements EventHandler<FulfillmentOrderStatusUpdatedAvro> {
    private static final List<String> IGNORED_STATUS = List.of("ERROR", "UNKNOWN");
    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final DeliveryStepUpdatedApplicationService deliveryStepUpdatedApplicationService;

    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    @Override
    public Mono<Void> handle(FulfillmentOrderStatusUpdatedAvro event, EventMetaData metaData) {
        final var customerOrderId = event.getFulfillmentOrderExternalReference().getCustomerOrderIdentifier();
        final String messageId = metaData.getId().orElse(null);

        this.mappedDiagnosticContext.injectEventMinimalBUData(metaData, customerOrderId, event.getBusinessUnitIdentifier());
        log.info("FulfillmentMapExecutionAvro consumes {} - message id: {}", metaData.getTopic(), metaData.getId().orElse("no id"));

        return this.updateLineDeliveryInformation(messageId, event, customerOrderId);
    }

    private Mono<Void> updateLineDeliveryInformation(final String messageId, FulfillmentOrderStatusUpdatedAvro event, String customerOrderId) {
        return this.deliveryStepUpdatedApplicationService.apply(toInput(messageId, event, customerOrderId))
            .onErrorResume(IllegalArgumentException.class, illegalArgumentException -> {
                log.warn("StepStatus not mapped this event will be ignored : {}", illegalArgumentException.getMessage());
                return Mono.empty();
            });
    }

    private DeliveryStepUpdatedInput toInput(final String messageId, FulfillmentOrderStatusUpdatedAvro event, String customerOrderId) {
        return DeliveryStepUpdatedInput.builder()
            .messageId(messageId)
            .customerOrderId(customerOrderId)
            .buCode(event.getBusinessUnitIdentifier())
            .lines(event.getFulfillmentOrderLines()
                .stream()
                .filter(fulfillmentOrderLineAvro -> !IGNORED_STATUS.contains(fulfillmentOrderLineAvro.getFulfillmentOrderLineStatus())
                    && EnumUtils.isValidEnum(DORStatus.class, fulfillmentOrderLineAvro.getFulfillmentOrderLineStatus()))
                .map(this::buildDeliveryLinesUpdateInputLines).collect(Collectors.toList()))
            .build();
    }

    private DeliveryStepUpdatedInput.Line buildDeliveryLinesUpdateInputLines(FulfillmentOrderLineAvro line) {
        return DeliveryStepUpdatedInput.Line.builder()
            .lineId(line.getFulfillmentOrderLineIdentifier())
            .isCancelable(line.getIsModifiableDelivery())
            .legacyOrderNumber(line.getFulfillmentOrderLineExternalReference() != null ? line.getFulfillmentOrderLineExternalReference().getCustomerOrderLegacyIdentifier() : null)
            .storeCode(line.getInvoicingLocation().getInvoicingLocationIdentifier())
            .incoterm(line.getFulfillmentOrderLineExternalReference() != null ? line.getFulfillmentOrderLineExternalReference().getIncotermCode() : null)
            .shippingPoint(line.getShippingLocation() != null ? getShippingPoint(line.getShippingLocation().getShippingLocationType()) : null)
            .status(DORStatus.valueOf(line.getFulfillmentOrderLineStatus()))
            .estimatedDeliveryDate(getEstimatedDeliveryDate(line))
            .foQuantities(DeliveryStepUpdatedInput.Line.FoQuantities.builder()
                .cancelledQuantity(line.getFulfillmentOrderLineCancelledQuantity())
                .initialQuantity(line.getFulfillmentOrderLineOrderedQuantity())
                .executedQuantity(line.getFulfillmentOrderLineExecutedQuantity())
                .build())
            .build();
    }

    private ShippingPoint getShippingPoint(LocationType locationType) {
        if(locationType == null){
            return null;
        }
        try {
            return ShippingPoint.valueOf(locationType.name());
        } catch (IllegalArgumentException iae) {
            return null;
        }
    }

    private DeliveryDate getEstimatedDeliveryDate(FulfillmentOrderLineAvro line) {
        final var startDate = line.getAvailableToPromiseMinDeliveryDate();
        final var endDate = getDeliveryEndDate(line);
        if (startDate == null && endDate == null) {
            return null;
        } else if (startDate == null) {
            return new FixedDeliveryDate(endDate.atOffset(ZoneOffset.UTC));
        } else if (endDate == null) {
            return new FixedDeliveryDate(startDate.atOffset(ZoneOffset.UTC));
        } else if (startDate.equals(endDate)) {
            return new FixedDeliveryDate(endDate.atOffset(ZoneOffset.UTC));
        } else {
            return new RangeDeliveryDate(startDate.atOffset(ZoneOffset.UTC), endDate.atOffset(ZoneOffset.UTC));
        }

    }

    private static Instant getDeliveryEndDate(FulfillmentOrderLineAvro line) {
        final Instant deliveryDateAtDeliveryLocation = line.getDeliveryDateAtDeliveryLocation();
        final Instant availableToPromiseMaxDeliveryDate = line.getAvailableToPromiseMaxDeliveryDate();
        if(deliveryDateAtDeliveryLocation != null && deliveryDateAtDeliveryLocation.isAfter(availableToPromiseMaxDeliveryDate)) {
            return deliveryDateAtDeliveryLocation;
        }
        return availableToPromiseMaxDeliveryDate;
    }

    @Override
    public Class<?> getManagedEvent() {
        return FulfillmentOrderStatusUpdatedAvro.class;
    }
}
