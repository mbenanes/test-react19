package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.legacynumber.tpp;

import com.adeo.featuretoggle.FeatureRepository;
import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.LegacyNumberService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_PYXIS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPING_REQUIREMENT_COMPLETED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.atLeastOneLineHasNoLegacyNumber;
import static com.adeo.sales.customerorder.tempoorchestrator.configuration.FeatureToggleConfiguration.RETRIEVE_LEGACY_NUMBER_REST;

@Component
@Slf4j
@AllArgsConstructor
@Rule(name = "RetrieveLegacyNumbersRuleTpp",
    description = "Retrieve legacy numbers by type for an order for TPP.",
    priority = 9)
public class RetrieveLegacyNumbersRuleTpp {
    private final LegacyNumberService legacyNumberService;
    private final FeatureRepository featureRepository;

    @Condition
    public Mono<Boolean> when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return featureRepository.getFeature(RETRIEVE_LEGACY_NUMBER_REST).isEnabled()
            .map(featureEnabled -> featureEnabled && context.hasAtLeastOneLine(IS_1P) &&
                atLeastOneLineHasNoLegacyNumber(context) &&
                (context.isCustomerOrderMatches(IS_PLACE_TYPE_IN_STORE) || context.hasAtLeastOneLine(IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT.and(IS_EXTERNAL_SYSTEM_PYXIS.or(IS_SHIPPING_REQUIREMENT_COMPLETED)))));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        List<LineExecution> existingLineExecutions = context.getOrderData().getExistingLineExecutions();
        CustomerOrder existingCustomerOrder = context.getOrderData().getExistingCustomerOrder();
        return this.legacyNumberService.retrieveLegacyNumbersAndUpdateLines(existingLineExecutions, existingCustomerOrder);
    }

}
