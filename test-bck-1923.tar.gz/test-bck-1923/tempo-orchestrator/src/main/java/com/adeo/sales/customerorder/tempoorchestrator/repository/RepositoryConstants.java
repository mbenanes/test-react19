package com.adeo.sales.customerorder.tempoorchestrator.repository;

public final class RepositoryConstants {
    private RepositoryConstants() {
    }

    public static final String ID = "id";
    public static final String IDS = "ids";
    public static final String BU_CODE = "buCode";
    public static final String CUSTOMER_ORDER_ID = "customerOrderId";
    public static final String FUNCTIONAL_TYPE = "functionalType";
    public static final String IMPACTED_LINE_IDS = "impactedLinesIds";
    public static final String DELIVERY_LEGACY_NUMBER = "deliveryLegacyNumber";
    public static final String STORE_ID = "storeId";
    public static final String TYPES = "types";
    public static final String EXPIRATION_DATE = "expirationDate";
    public static final String ALLOWED_PAYMENT_EXECUTION_STATUS = "allowedPaymentExecutionStatus";
    public static final String ALLOWED_COMPOSITION_STATUS = "allowedCompositionStatus";
    public static final String CORRELATION_ID = "correlation_id";
    public static final String APPLIED_AT = "applied_at";
    public static final String DATA = "data";
    public static final String VERSION = "version";
    public static final String CREATED_AT = "created_at";
    public static final String LAST_MODIFIED_AT = "last_modified_at";
    public static final String PER_PAGE = "perPage";
    public static final String OFFSET = "offset";
}
