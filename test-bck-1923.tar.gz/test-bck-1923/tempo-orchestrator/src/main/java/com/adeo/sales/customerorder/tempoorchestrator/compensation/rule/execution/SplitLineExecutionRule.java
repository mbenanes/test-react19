package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.execution;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDeliveryCollect;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.repository.impl.ExecutionPostgresRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.impl.LineExecutionPostgresRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.TreeSet;
import java.util.UUID;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_ALL_STEP_ARE_DONE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_REASON_IS_CANCELLATION;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_REASON_IS_REMAINING_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_SPLIT_ACTION_PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_SPLIT_LINE_EXECUTION_IS_THE_NEXT_STEP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction.getActionExecutionReason;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionReasonEnum.REMAINING_COLLECT;

@Component
@Slf4j
@Rule(name = "SplitLineExecutionRule",
    description = "split execution for lines if necessary",
    priority = 12)
@RequiredArgsConstructor
public class SplitLineExecutionRule {

    private final LineExecutionPostgresRepository lineExecutionPostgresRepository;
    private final ExecutionPostgresRepository executionPostgresRepository;

    private static final Predicate<ExecutionAction> IS_SPLIT_EXECUTION_ACTION_TO_PROCESS =
        IS_SPLIT_ACTION_PROCESSING
            .and(IS_EXECUTION_ACTION_REASON_IS_REMAINING_COLLECT.or(IS_EXECUTION_ACTION_REASON_IS_CANCELLATION))
            .and(IS_SPLIT_LINE_EXECUTION_IS_THE_NEXT_STEP);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.allLinesMatchs(PAYMENT_ORCHESTRATED_BY_TPP) &&
            context.hasAtLeastOneExecutionAction(IS_SPLIT_EXECUTION_ACTION_TO_PROCESS);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return Mono.justOrEmpty(context.getFirstExecutionActionByPredicate(IS_SPLIT_EXECUTION_ACTION_TO_PROCESS))
            .flatMap(executionAction -> Mono.justOrEmpty(getActionExecutionReason(executionAction))
                .flatMap(splitReason -> {
                    Execution newExecution = Execution.builder()
                        .id(UUID.randomUUID().toString())
                        .customerOrderId(context.getCustomerOrderId())
                        .buCode(context.getBuCode())
                        .build();

                    final List<LineExecution> lineExecutionsToUpdateExecution = this.retrieveLineExecutionToUpdate(context, executionAction, newExecution, splitReason);
                    newExecution.setExecutionStatus(this.generateExecutionStatusFlags(lineExecutionsToUpdateExecution));

                    final List<LineExecution> lineExecutionsToCreate = this.retrieveLineExecutionToCreate(context, executionAction, splitReason, newExecution);

                    if (!lineExecutionsToCreate.isEmpty()) {
                        context.getOrderData().getExistingLineExecutions().addAll(lineExecutionsToCreate);
                    }

                    return this.saveExecution(context, executionAction, newExecution, lineExecutionsToUpdateExecution, lineExecutionsToCreate);
                })
            );
    }

    private List<LineExecution> retrieveLineExecutionToUpdate(RuleEngineContext context, ExecutionAction executionAction, Execution newExecution, String splitReason) {
        return executionAction.getImpactedExecutions()
            .stream()
            .flatMap(impactedExecution -> impactedExecution.getImpactedLines()
                .stream()
                .filter(impactedLine -> impactedLine.getNextStep().stream().anyMatch(step -> step.getType() == ImpactedLineStep.Type.SPLIT_LINE_EXECUTION))
                .filter(impactedLine ->
                    context.getOrderData().getLineExecutionByIdAndExecutionId(impactedLine.getLineId(), impactedExecution.getCurrentExecutionId())
                        .stream()
                        .anyMatch(lineExecution -> lineExecution.getQuantity().compareTo(impactedLine.getQuantity()) == 0)
                )
                .map(impactedLine -> {
                    final Optional<LineExecution> optionalLineExecution = context.getOrderData().getLineExecutionByIdAndExecutionId(impactedLine.getLineId(), impactedExecution.getCurrentExecutionId());
                    return optionalLineExecution.map(lineExecution -> {
                        lineExecution.setNewExecutionId(newExecution.getId());
                        if (REMAINING_COLLECT.name().equals(splitReason)) {
                            lineExecution.getDelivery().setAppointmentDate(null);
                            lineExecution.getDelivery().setCollect(LineExecutionDeliveryCollect.builder().build());
                            lineExecution.getPaymentRequirements().getDeliveryFlags().clearFlags();
                            lineExecution.getPaymentRequirements().getPreparationFlags().clearFlags();
                            return lineExecution;
                        }
                        return lineExecution;
                    });

                })
            )
            .flatMap(Optional::stream)
            .toList();
    }

    private Flags<ExecutionStatus> generateExecutionStatusFlags(List<LineExecution> lineExecutions) {
        Flags<ExecutionStatus> flags = new Flags<>();
        if (lineExecutions.stream().anyMatch(IS_DELIVERY_CANCELED)) {
            flags.raiseFlag(ExecutionStatus.CANCELED);
        } else {
            flags.raiseFlag(ExecutionStatus.CREATED);
            flags.raiseFlag(ExecutionStatus.VALIDATED);
            flags.raiseFlag(ExecutionStatus.CONFIRMED);
            final TreeSet<Flag> flagsHistories = lineExecutions.stream()
                .map(LineExecution::getDelivery)
                .map(LineExecutionDelivery::getFlags)
                .map(Flags::getOrderedByDateFlags)
                .findFirst()
                .orElse(flags.getOrderedByDateFlags());

            flags.setOrderedByDateFlags(flagsHistories);
        }
        return flags;
    }

    private List<LineExecution> retrieveLineExecutionToCreate(RuleEngineContext context, ExecutionAction executionAction, String splitReason, Execution newExecution) {
        return executionAction.getImpactedExecutions()
            .stream()
            .flatMap(impactedExecution -> impactedExecution.getImpactedLines()
                .stream()
                .filter(impactedLine -> impactedLine.getNextStep().stream().anyMatch(step -> step.getType() == ImpactedLineStep.Type.SPLIT_LINE_EXECUTION))
                .filter(impactedLine ->
                    context.getOrderData().getLineExecutionByIdAndExecutionId(impactedLine.getLineId(), impactedExecution.getCurrentExecutionId())
                        .stream()
                        .anyMatch(lineExecution -> lineExecution.getQuantity().compareTo(impactedLine.getQuantity()) != 0)
                )
                .map(impactedLine -> {
                    final Optional<LineExecution> optionalLineExecution = context.getOrderData().getLineExecutionByIdAndExecutionId(impactedLine.getLineId(), impactedExecution.getCurrentExecutionId());
                    return optionalLineExecution.map(lineExecution -> {
                        final BigDecimal quantityToExecute = lineExecution.getQuantity().subtract(impactedLine.getQuantity());
                        lineExecution.setQuantity(quantityToExecute);
                        lineExecution.getComposition().setQuantity(quantityToExecute);
                        if (REMAINING_COLLECT.name().equals(splitReason)) {
                            final var newLineExecution = lineExecution.cloneLineExecution();
                            newLineExecution.setQuantity(impactedLine.getQuantity());
                            newLineExecution.getComposition().setQuantity(impactedLine.getQuantity());
                            newLineExecution.setInitialQuantity(lineExecution.getInitialQuantity());
                            newLineExecution.setExecutionId(newExecution.getId());
                            newLineExecution.getDelivery().setAppointmentDate(null);
                            newLineExecution.getDelivery().setCancelable(true);
                            newLineExecution.getDelivery().setCollect(LineExecutionDeliveryCollect.builder().build());
                            newLineExecution.getPaymentRequirements().getDeliveryFlags().clearFlags();
                            newLineExecution.getPaymentRequirements().getShippingFlags().clearFlags();
                            newLineExecution.getPaymentRequirements().getPreparationFlags().clearFlags();
                            return newLineExecution;
                        }
                        //Should never happen now because we only handle split on remaining collect
                        return lineExecution;
                    });

                })
            )
            .flatMap(Optional::stream)
            .toList();
    }

    private Mono<Void> saveExecution(RuleEngineContext context,
                                     ExecutionAction executionAction,
                                     Execution newExecution,
                                     List<LineExecution> lineExecutionsToUpdateExecution,
                                     List<LineExecution> lineExecutionsToCreate) {
        return this.executionPostgresRepository.save(List.of(newExecution))
            .then(Mono.when(lineExecutionsToUpdateExecution.isEmpty() ? Mono.empty() : this.lineExecutionPostgresRepository.updateExecutionId(lineExecutionsToUpdateExecution),
                lineExecutionsToCreate.isEmpty() ? Mono.empty() : this.lineExecutionPostgresRepository.save(lineExecutionsToCreate)))
            .then(Mono.fromRunnable(() -> {
                lineExecutionsToUpdateExecution
                    .forEach(lineExecution -> {
                        lineExecution.setExecutionId(lineExecution.getNewExecutionId());
                        lineExecution.setNewExecutionId(null);
                    });
                context.getOrderData().getExecutions().add(newExecution);
            })).then(Mono.fromRunnable(() -> {
                    executionAction.getImpactedExecutions()
                        .stream()
                        .filter(impactedExecution -> impactedExecution.isNextStepTypeIs(ImpactedLineStep.Type.SPLIT_LINE_EXECUTION))
                        .forEach(impactedExecution -> impactedExecution
                            .getImpactedLines()
                            .forEach(impactedLine -> {
                                Optional<LineExecution> lineExecutionOptional = LineExecution.getCorrespondingLine(lineExecutionsToCreate, impactedLine.getLineId())
                                    .or(() -> LineExecution.getCorrespondingLine(lineExecutionsToUpdateExecution, impactedLine.getLineId()));
                                lineExecutionOptional.ifPresent(lineExecution -> {
                                    if (!impactedExecution.getCurrentExecutionId().equals(lineExecution.getExecutionId())) {
                                        impactedExecution.setCurrentExecutionId(lineExecution.getExecutionId());
                                    }
                                });
                                impactedLine.getNextStep().ifPresent(step -> step.getFlags().raiseFlagIfNot(ImpactedLineStep.Status.COMPLETED));
                            }));

                    if (IS_ALL_STEP_ARE_DONE.test(executionAction)) {
                        executionAction.getFlags().raiseFlagIfNot(ExecutionActionStatus.COMPLETED);
                    }
                }
            ));
    }

}
