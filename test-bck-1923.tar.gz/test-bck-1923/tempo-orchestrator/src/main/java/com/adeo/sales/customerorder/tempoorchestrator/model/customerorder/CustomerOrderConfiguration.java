package com.adeo.sales.customerorder.tempoorchestrator.model.customerorder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class CustomerOrderConfiguration {
    private String label;
    private String configuratorId;
    private Instant expirationDate;
    private String configurationId;
    private String configurationType;
    private String configuratorLabel;
    private Integer configurationVersion;
}
