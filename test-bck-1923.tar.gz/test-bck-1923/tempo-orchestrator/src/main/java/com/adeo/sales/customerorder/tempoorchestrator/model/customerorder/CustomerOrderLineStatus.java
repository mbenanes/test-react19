package com.adeo.sales.customerorder.tempoorchestrator.model.customerorder;

import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineCompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLinePaymentExecutionStatus;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public enum CustomerOrderLineStatus {
    VALIDATED(
        CustomerOrderLineCompositionOrderStatus.VALIDATED,
        CustomerOrderLineDeliveryStatus.CREATION_REQUESTED,
        CustomerOrderLinePaymentExecutionStatus.NONE,
        NotificationStatus.NOTIFICATION_REQUESTED
    ),
    VENDOR_ACCEPTED(
        CustomerOrderLineCompositionOrderStatus.VALIDATED,
        CustomerOrderLineDeliveryStatus.ACCEPTED,
        CustomerOrderLinePaymentExecutionStatus.NONE,
        NotificationStatus.NOTIFICATION_REQUESTED
    ),
    VENDOR_REJECTED(
        CustomerOrderLineCompositionOrderStatus.CANCELED_REQUESTED,
        CustomerOrderLineDeliveryStatus.REJECTED,
        CustomerOrderLinePaymentExecutionStatus.NONE,
        NotificationStatus.NOTIFICATION_REQUESTED
    ),
    CANCELED(
        CustomerOrderLineCompositionOrderStatus.CANCELED,
        CustomerOrderLineDeliveryStatus.ABORTED,
        CustomerOrderLinePaymentExecutionStatus.NONE,
        NotificationStatus.NOTIFICATION_REQUESTED
    ),
    PAYMENT_CAPTURED(
        CustomerOrderLineCompositionOrderStatus.VALIDATED,
        CustomerOrderLineDeliveryStatus.ACCEPTED,
        CustomerOrderLinePaymentExecutionStatus.CAPTURED,
        NotificationStatus.NOTIFICATION_REQUESTED
    ),
    SHIPPING(
        CustomerOrderLineCompositionOrderStatus.VALIDATED,
        CustomerOrderLineDeliveryStatus.SHIPPING_REQUESTED,
        CustomerOrderLinePaymentExecutionStatus.CAPTURED,
        NotificationStatus.NOTIFICATION_REQUESTED
    ),
    SHIPPED(
        CustomerOrderLineCompositionOrderStatus.VALIDATED,
        CustomerOrderLineDeliveryStatus.SHIPPED,
        CustomerOrderLinePaymentExecutionStatus.CAPTURED,
        NotificationStatus.NOTIFICATION_REQUESTED
    ),
    RECEIVED(
        CustomerOrderLineCompositionOrderStatus.VALIDATED,
        CustomerOrderLineDeliveryStatus.RECEIVED,
        CustomerOrderLinePaymentExecutionStatus.CAPTURED,
        NotificationStatus.NOTIFICATION_REQUESTED
    ),
    CLOSED(
        CustomerOrderLineCompositionOrderStatus.UNKNOWN,
        CustomerOrderLineDeliveryStatus.CLOSED,
        CustomerOrderLinePaymentExecutionStatus.UNKNOWN,
        NotificationStatus.NOTIFICATION_REQUESTED
    );

    private final CustomerOrderLineCompositionOrderStatus associatedCompositionOrderStatus;
    private final CustomerOrderLineDeliveryStatus associatedDeliveryStatus;
    private final CustomerOrderLinePaymentExecutionStatus associatedPaymentStatus;
    private final NotificationStatus associatedOrderNotificationStatus;

    CustomerOrderLineStatus(CustomerOrderLineCompositionOrderStatus associatedCompositionOrderStatus, CustomerOrderLineDeliveryStatus associatedDeliveryStatus, CustomerOrderLinePaymentExecutionStatus associatedPaymentStatus, NotificationStatus associatedOrderNotificationStatus) {
        this.associatedCompositionOrderStatus = associatedCompositionOrderStatus;
        this.associatedDeliveryStatus = associatedDeliveryStatus;
        this.associatedPaymentStatus = associatedPaymentStatus;
        this.associatedOrderNotificationStatus = associatedOrderNotificationStatus;
    }
}
