package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.log;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.ApplicationProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.PromisedDateSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_CREATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_DELAY_ALERT_REASON;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_TYPE_PROMISE_DATE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.hasAtLeastOneCommonLineExecution;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_ESTIMATED_DELIVERY_DATE_IN_PAST;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COMPOSITION_CANCELLED_OR_DELIVERY_SHIPPED_OR_DELIVERED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_ESTIMATED_DELIVERY_DATE_COME_FROM_DELIVERY;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.isEstimatedDeliveryDateIsDifferentThanCustomerKnownDeliveryDate;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "LogOnDelayAlertWhenExistingAlreadyCreationPendingDelayAlertRule",
    description = "warn log if received delay alert when are existing open delay alert",
    priority = 990)
public class LogOnDelayAlertWhenExistingAlreadyCreationPendingDelayAlertRule {

    private final ApplicationProperties applicationProperties;
    private static final Predicate<Alert> IS_PENDING_DELAY_ALERT = IS_TYPE_PROMISE_DATE.and(IS_DELAY_ALERT_REASON).and(IS_CREATION_REQUESTED);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var creationRequestedAlerts = context.getAlertData().getAlertsFilterBy(IS_PENDING_DELAY_ALERT);

        return context.getOrderData().getExistingLineExecutions().stream()
            .filter(IS_ESTIMATED_DELIVERY_DATE_COME_FROM_DELIVERY
                .and(not(IS_COMPOSITION_CANCELLED_OR_DELIVERY_SHIPPED_OR_DELIVERED))
                .and(not(HAS_ESTIMATED_DELIVERY_DATE_IN_PAST))
                .and(isEstimatedDeliveryDateIsDifferentThanCustomerKnownDeliveryDate(applicationProperties.getOffsetDayForProcessingNewAlert011PromiseDate())))
            .anyMatch(hasOnCreationRequestedAlert(creationRequestedAlerts));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var openDelayAlerts = context.getAlertData().getAlertsFilterBy(IS_PENDING_DELAY_ALERT);
        final var linesWithAlertToCreate = context.getOrderData().getLineExecutionsByPredicate(
            IS_ESTIMATED_DELIVERY_DATE_COME_FROM_DELIVERY
                .and(not(IS_COMPOSITION_CANCELLED_OR_DELIVERY_SHIPPED_OR_DELIVERED))
                .and(not(HAS_ESTIMATED_DELIVERY_DATE_IN_PAST))
                .and(isEstimatedDeliveryDateIsDifferentThanCustomerKnownDeliveryDate(applicationProperties.getOffsetDayForProcessingNewAlert011PromiseDate()))
                .and(isNotTooCloseToThePreviousOne(openDelayAlerts))
        );

        openDelayAlerts.stream()
            .filter(alert -> hasAtLeastOneCommonLineExecution(alert, linesWithAlertToCreate))
            .forEach(alert -> {
                final var lineIds = linesWithAlertToCreate.stream()
                    .map(LineExecution::getLineId)
                    .filter(id -> alert.getImpactedLinesIds().contains(id))
                    .collect(Collectors.joining());

                log.warn(
                    "The following alerts {} can not be closed because status is CREATION_REQUESTED. Abort new alert creation for lines {}. The alert will be created on alert creation ack..",
                    alert.getId(), lineIds
                );
            });

        return Mono.empty();
    }

    private Predicate<LineExecution> isNotTooCloseToThePreviousOne(List<Alert> openDelayAlerts) {
        return line -> openDelayAlerts.stream()
            .filter(alert -> hasAtLeastOneCommonLineExecution(alert, List.of(line)))
            .filter(alert -> ((PromisedDateSpecificData) alert.getSpecificData()).getNewPromiseDate() != null)
            .noneMatch(existingAlert -> {
                final var newEstimatedDeliveryDate = line.getDelivery().getEstimatedDeliveryDate();
                final var previousAlertNewPromisedDate = ((PromisedDateSpecificData) existingAlert.getSpecificData()).getNewPromiseDate();
                final var nbDayBetweenNewDateAndLastAlertDate = previousAlertNewPromisedDate.nbDayBetweenAbs(newEstimatedDeliveryDate);
                return nbDayBetweenNewDateAndLastAlertDate <= this.applicationProperties.getOffsetDayForProcessingNewAlert011PromiseDate();
            });
    }

    private Predicate<LineExecution> hasOnCreationRequestedAlert(List<Alert> creationRequestedAlerts) {
        return line -> creationRequestedAlerts.stream()
            .anyMatch(alert -> hasAtLeastOneCommonLineExecution(alert, List.of(line)));
    }
}
