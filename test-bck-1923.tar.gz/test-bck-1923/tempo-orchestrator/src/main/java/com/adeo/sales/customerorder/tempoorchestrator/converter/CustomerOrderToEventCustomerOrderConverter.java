package com.adeo.sales.customerorder.tempoorchestrator.converter;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

@Component
public class CustomerOrderToEventCustomerOrderConverter
    implements Converter<CustomerOrder, com.adeo.sales.customerorder.tempoorchestrator.data.CustomerOrder> {

    private final ObjectMapper objectMapper;

    public CustomerOrderToEventCustomerOrderConverter(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper.copy()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    /**
     * As we don't map all fields on java class for CustomerOrder
     * We use JSON to convert CustomerOrder to com.adeo.sales.customerorder.tempoorchestrator.data.CustomerOrder
     * The non mapped fields are on ignoredProperties attribute
     */
    @Override
    public com.adeo.sales.customerorder.tempoorchestrator.data.CustomerOrder convert(CustomerOrder customerOrder) {
        try {
            final var outputStream = new ByteArrayOutputStream();
            objectMapper.writeValue(outputStream, customerOrder);
            return objectMapper.readValue(new ByteArrayInputStream(outputStream.toByteArray()), com.adeo.sales.customerorder.tempoorchestrator.data.CustomerOrder.class);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
