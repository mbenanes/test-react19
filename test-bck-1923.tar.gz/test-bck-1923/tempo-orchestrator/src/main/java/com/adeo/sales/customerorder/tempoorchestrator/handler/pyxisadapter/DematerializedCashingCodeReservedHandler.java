package com.adeo.sales.customerorder.tempoorchestrator.handler.pyxisadapter;

import com.adeo.pyxis.adapter.avro.DematerializedCashingCodeReserved;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.PyxisDematcodeApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.input.DematCodeInput;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
@Component
@Slf4j
public class DematerializedCashingCodeReservedHandler implements EventHandler<DematerializedCashingCodeReserved> {

    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final PyxisDematcodeApplicationService pyxisDematcodeApplicationService;

    @Override
    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    public Mono<Void> handle(DematerializedCashingCodeReserved event, EventMetaData eventMetaData) {
        final var customerOrderId = event.getCustomerOrderId();
        final var buCode = eventMetaData.getBuCode();

        mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderId);
        log.info("DematerializedCashingCodeReserved consumes {} - message id: {}", eventMetaData.getTopic(), eventMetaData.getId().orElse("no id"));

        return pyxisDematcodeApplicationService.apply(
            DematCodeInput.builder()
                .customerOrderId(customerOrderId)
                .buCode(buCode)
                .dematCode(event.getDematerializedCashingCode())
                .build()
        );
    }

    @Override
    public Class<?> getManagedEvent() {
        return DematerializedCashingCodeReserved.class;
    }
}
