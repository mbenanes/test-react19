package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.cancelation;


import com.adeo.featuretoggle.FeatureRepository;
import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.FeatureToggleConfiguration;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.CustomerOrderService;
import com.adeo.sales.customerorder.tempoorchestrator.service.UpdateAvailableActionService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.BiPredicateHelper.and;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_DELIVERY_REJECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_BOMP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_NOT_ALREADY_CANCELED_ON_TCO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Cancel3pLinesRuleOnVendorRejection",
    description = "cancel third party lines when the lines are refused and toggle feature rejected by seller is deactivated",
    priority = 1000)
public class Cancel3pLinesRuleOnVendorRejectionRule {

    private final FeatureRepository featureRepository;
    private final CustomerOrderService customerOrderService;
    private final UpdateAvailableActionService updateAvailableActionService;

    private static final String CANCELATION_REASON = "REJECTED_BY_SELLER";

    @Condition
    public Mono<Boolean> when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return and(
            Mono.just(!findCancellableBompLines(context).isEmpty()),
            FeatureToggleConfiguration.isRejectedBySellerUsingAlertingFeatureDisabled(context.getBuCode(), this.featureRepository)
        );
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var linesToCancel = findCancellableBompLines(context);
        return MonoUtil.infoLog("INTERNAL send cancel command on 3P lines: {}", LineExecution.joinLineIds(linesToCancel))
            .then(this.customerOrderService.sendCancelCustomerOrderLines(context.getOrderData().getExistingCustomerOrder(), linesToCancel, CANCELATION_REASON))
            .then(Mono.fromRunnable(() -> linesToCancel.forEach(line -> this.updateExecutionInformations(context, line))));
    }

    private void updateExecutionInformations(RuleEngineContext context, LineExecution line) {
        line.getComposition().setCancellationReason(CANCELATION_REASON);
        line.getComposition().getFlags().raiseFlag(CompositionOrderStatus.CANCELED_REQUESTED);
        this.updateAvailableActionService.apply(context.getOrderData().getExistingLineExecutions(), line, context.getOrderData().getExistingCustomerOrder(), false);
        line.increaseVersion();
    }


    private List<LineExecution> findCancellableBompLines(RuleEngineContext context) {
        final var ruleEngineContextLineExecutionPredicate = IS_EXTERNAL_SYSTEM_BOMP
            .and(IS_NOT_ALREADY_CANCELED_ON_TCO)
            .and(HAS_DELIVERY_REJECTED)
            .and(PAYMENT_ORCHESTRATED_BY_PSR);
        return context.getOrderData().getLineExecutionsByPredicate(ruleEngineContextLineExecutionPredicate);
    }
}
