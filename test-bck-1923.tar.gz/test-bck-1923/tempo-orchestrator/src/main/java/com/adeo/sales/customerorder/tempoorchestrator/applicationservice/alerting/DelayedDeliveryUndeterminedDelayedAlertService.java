package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.alerting;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.DelayedLine;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.FulfillmentMapExecutionDelayAlertInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DelayType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@Component
@Slf4j
@RequiredArgsConstructor
public class DelayedDeliveryUndeterminedDelayedAlertService {

    private final RuleEngineService ruleEngineService;

    public Mono<Void> apply(FulfillmentMapExecutionDelayAlertInput input) {
        final var lineIds = this.getManagedLines(input);
        final var isInputValid = this.validateInput(lineIds);

        if (!isInputValid) {
            return Mono.empty();
        }

        return this.ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode())
            .doOnNext(consumer((customerOrder, lineExecutions) -> this.markLinesAsUnknownDelay(lineExecutions, input.getDelayedLines())))
            .flatMap(function(ruleEngineService.startRuleEngineAndUpdateLines()));
    }

    private void markLinesAsUnknownDelay(List<LineExecution> lineExecutions, List<DelayedLine> delayedLines) {
        List<String> impactedLines = delayedLines.stream().map(DelayedLine::getLineId).toList();
        lineExecutions
            .stream()
            .filter(lineExecution -> impactedLines.contains(lineExecution.getLineId()))
            .forEach(lineExecution -> lineExecution.getDelivery().setDelayType(DelayType.UNKNOWN_DELAY));
    }

    protected List<String> getManagedLines(FulfillmentMapExecutionDelayAlertInput input) {
        return input.getDelayedLines()
            .stream()
            .filter(this::isAlertManaged)
            .map(DelayedLine::getLineId)
            .collect(Collectors.toList());
    }

    protected boolean validateInput(List<String> lineIds) {
        if (lineIds.isEmpty()) {
            log.info("no alert to create");
            return false;
        }
        return true;
    }

    protected boolean isAlertManaged(DelayedLine delayedLine) {
        if (!"015".contains(delayedLine.getCode())) {
            log.info("the delay code {} for the line {} is not supported", delayedLine.getCode(), delayedLine.getLineId());
            return false;
        } else {
            return true;
        }
    }

}
