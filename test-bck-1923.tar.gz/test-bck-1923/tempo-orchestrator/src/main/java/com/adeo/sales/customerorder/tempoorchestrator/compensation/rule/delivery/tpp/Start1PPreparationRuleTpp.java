package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.FullfillmentPreparationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_DELIVERY_PREPARATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CONFIRMATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_DATE_CONFIRMED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_RESERVATION_REJECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_RESERVED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_RESERVED_OR_RESERVATION_FAILED_AND_RESERVATION_REQUIRED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_PYXIS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_IMMEDIATE_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PREPARATION_REQUIREMENT_COMPLETED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_RESERVATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.NO_TPP_REQUIREMENT_IN_PROGRESS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.PREPARATION_REQUESTED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Start1PPreparationRuleTpp",
    description = "Start 1P preparation after reservation in store on the 1P Delivery System with tpp",
    priority = 1001)
public class Start1PPreparationRuleTpp {
    private final FullfillmentPreparationService fullfillmentPreparationService;
    private static final Predicate<LineExecution> IS_1P_OFFER_VALIDATED =
        IS_1P
            .and(IS_OFFER)
            .and(IS_LINE_COMPOSITION_VALIDATED);

    private static final Predicate<LineExecution> LINE_SHOULD_BE_PREPARED =
        PAYMENT_ORCHESTRATED_BY_TPP
            .and(IS_1P_OFFER_VALIDATED)
            .and(IS_DELIVERY_DATE_CONFIRMED)
            .and(not(HAS_DELIVERY_PREPARATION_REQUESTED))
            .and(IS_CONFIRMATION_REQUIREMENT_COMPLIANT)
            .and(IS_DELIVERY_RESERVED_OR_RESERVATION_FAILED_AND_RESERVATION_REQUIRED)
            .and(NO_TPP_REQUIREMENT_IN_PROGRESS)
            .and(IS_PREPARATION_REQUIREMENT_COMPLETED)
            .and(not(IS_IMMEDIATE_COLLECT));

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(LINE_SHOULD_BE_PREPARED)
            && !(context.isCustomerOrderMatches(IS_PLACE_TYPE_IN_STORE) && context.hasAtLeastOneLine(IS_EXTERNAL_SYSTEM_PYXIS));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var linesToCreate = context.getOrderData().getLineExecutionsByPredicate(LINE_SHOULD_BE_PREPARED);
        return MonoUtil.infoLog("INTERNAL request delivery preparation for 1P lines with TPP: {}", LineExecution.joinLineIds(linesToCreate))
            .then(this.fullfillmentPreparationService.createOrderPreparation(linesToCreate, context.getOrderData().getExistingCustomerOrder()))
            .then(Mono.fromRunnable(() -> linesToCreate.forEach(lineExecution -> {
                lineExecution.getDelivery().getFlags().raiseFlag(PREPARATION_REQUESTED);
                lineExecution.increaseVersion();
            })));
    }
}
