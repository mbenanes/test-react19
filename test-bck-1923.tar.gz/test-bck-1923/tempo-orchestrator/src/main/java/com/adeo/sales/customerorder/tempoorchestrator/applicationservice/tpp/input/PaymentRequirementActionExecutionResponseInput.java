package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

@Builder
@Getter
public class PaymentRequirementActionExecutionResponseInput {
    private String customerOrderId;
    private String customerOrderExecutionPlanId;
    private String buCode;
    private TppAllowedStatus status;
    private String tppErrorType;
    private String errorMessage;
    private Instant statusDate;
    private String actionType;
    private String operationId;
    private Boolean isUnexecAction;
    private List<Line> lines;
    private Integer customerOrderPaymentExecutionPolicyVersion;

    @Builder
    @Data
    public static class Line {
        private String id;
        private BigDecimal amount;
        private BigDecimal deliveryAmount;
    }

}
