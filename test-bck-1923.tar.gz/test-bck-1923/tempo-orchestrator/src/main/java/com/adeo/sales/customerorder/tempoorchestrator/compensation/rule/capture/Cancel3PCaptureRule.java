package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.capture;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.CaptureService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_3P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CAPTURED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_SHIPPING_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.PaymentOperationType.CANCEL_CAPTURE_REQUESTED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Cancel3PCapture",
    description = "cancel third party line capture.",
    priority = 1000)
public class Cancel3PCaptureRule {
    private static final Predicate<LineExecution> IS_3P_CANCELED = IS_3P
        .and(IS_CAPTURED)
        .and(IS_LINE_COMPOSITION_CANCELED)
        .and(not(IS_DELIVERY_SHIPPING_REQUESTED))
        .and(PAYMENT_ORCHESTRATED_BY_PSR);

    private final CaptureService captureService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(IS_3P_CANCELED);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var cancelCaptureLines = context.getOrderData().getLineExecutionsByPredicate(IS_3P_CANCELED);

        return MonoUtil.infoLog("INTERNAL request cancel capture for 3P lines: {}", LineExecution.joinLineIds(cancelCaptureLines))
            .then(this.captureService.sendCommandCancelCapture(context.getOrderData().getExistingCustomerOrder(), cancelCaptureLines))
            .then(Mono.fromRunnable(() -> cancelCaptureLines.forEach(lineExecution -> {
                lineExecution.getPayment().getPaymentExecution().getFlags().raiseFlag(CANCEL_CAPTURE_REQUESTED);
                lineExecution.increaseVersion();
            })));
    }
}
