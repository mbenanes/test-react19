package com.adeo.sales.customerorder.tempoorchestrator.handler.bomp;

import com.adeo.bomp.order.model.avro.vendororderlines.State;
import com.adeo.bomp.order.model.avro.vendororderlines.VendorOrderlinesAcceptanceDecisionDone;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.VendorOrderLinesVendorDecisionApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.input.VendorOrderLinesVendorDecisionInput;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.ApplicationProperties;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import static com.adeo.sales.customerorder.tempoorchestrator.handler.bomp.BompMessageReader.getCustomerOrderId;
import static com.adeo.sales.customerorder.tempoorchestrator.handler.bomp.BompMessageReader.getExternalOrchestratorId;
import static com.adeo.sales.customerorder.tempoorchestrator.handler.bomp.BompMessageReader.getLineIds;
import static com.adeo.sales.customerorder.tempoorchestrator.handler.bomp.BompMessageReader.noReason;
import static com.adeo.sales.customerorder.tempoorchestrator.handler.bomp.BompMessageReader.reason;
import static com.adeo.sales.customerorder.tempoorchestrator.handler.bomp.BompMessageReader.withStatus;

@Slf4j
@RequiredArgsConstructor
@Component
public class VendorOrderLinesAcceptanceDecisionDoneHandler implements EventHandler<VendorOrderlinesAcceptanceDecisionDone> {

    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final VendorOrderLinesVendorDecisionApplicationService vendorOrderLinesVendorDecisionApplicationService;
    private final ApplicationProperties applicationProperties;

    @Override
    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    public Mono<Void> handle(VendorOrderlinesAcceptanceDecisionDone event, EventMetaData eventMetaData) {
        final var orderLines = event.getState();
        final var buCode = event.getState().getChannel().getBuCode().toString();
        final var customerOrderId = getCustomerOrderId(orderLines);

        if (this.applicationProperties.getNonManagedBuCodes().contains(buCode)) {
            return Mono.empty();
        }

        this.mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderId, orderLines.getChannel().getBuCode().toString());
        log.info("INTERNAL {} consumes {} - message id: {}", event.getClass().getSimpleName(), eventMetaData.getTopic(), eventMetaData.getId().orElse("no id"));

        final var bompId = getExternalOrchestratorId(orderLines);
        final var acceptedLineIds = getLineIds(orderLines, withStatus(State.ACCEPTED));
        final var refusedLineIds = getLineIds(orderLines, withStatus(State.REFUSED).and(noReason().or(reason("REFUSED")).or(reason("ACCEPTANCE_TIMEOUT"))));

        return this.vendorOrderLinesVendorDecisionApplicationService.apply(VendorOrderLinesVendorDecisionInput.builder()
            .customerOrderId(customerOrderId)
            .buCode(buCode)
            .bompId(bompId)
            .acceptedLineIds(acceptedLineIds)
            .refusedLineIds(refusedLineIds)
            .orderLineids(getLineIds(orderLines))
            .build());
    }

    @Override
    public Class<VendorOrderlinesAcceptanceDecisionDone> getManagedEvent() {
        return VendorOrderlinesAcceptanceDecisionDone.class;
    }
}
