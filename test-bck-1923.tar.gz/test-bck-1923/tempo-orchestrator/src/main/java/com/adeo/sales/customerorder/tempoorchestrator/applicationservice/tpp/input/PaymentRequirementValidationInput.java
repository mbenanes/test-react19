package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

import java.time.Instant;
import java.util.List;

@Builder
@Getter
public class PaymentRequirementValidationInput {
    String customerOrderId;
    String buCode;
    List<Line> lines;
    String executionPolicyId;
    int executionPolicyVersion;

    @Builder
    @Data
    public static class Line {
        private String id;
        private Compliance validationRequirementCompliance;
        private Compliance stockReservationRequirementCompliance;
        private Compliance confirmationRequirementCompliance;
        private Compliance vendorOrderCreationRequirementCompliance;
        private Compliance salesValorizationRequirementCompliance;

        @Builder
        @Getter
        public static class Compliance {
            private boolean compliant;
            private String operationId;
            private Instant date;
            private String reason;
        }
    }

}
