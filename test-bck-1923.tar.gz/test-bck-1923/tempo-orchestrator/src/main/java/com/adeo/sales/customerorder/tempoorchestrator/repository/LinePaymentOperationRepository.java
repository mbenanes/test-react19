package com.adeo.sales.customerorder.tempoorchestrator.repository;

import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.LinePaymentOperationHistory;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Collection;

public interface LinePaymentOperationRepository {
    Flux<LinePaymentOperationHistory> getLinePaymentOperationsByOrderId(final String customerOrderId, final String buCode);

    Mono<Void> saveLinesOperation(final Collection<LinePaymentOperationHistory> linePaymentOperationHistories);
}
