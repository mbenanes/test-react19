package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command;


import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.ExecutionData;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.LineData;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.UpdateExecutionInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.ExecutionAndLineNotFoundError;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.QuantityNotValidError;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

import static reactor.function.TupleUtils.function;

@Component
@AllArgsConstructor
@Slf4j
public class DecreaseQuantityApplicationService {

    private final RuleEngineService ruleEngineService;


    public Mono<Void> apply(UpdateExecutionInput input) {
        return ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode())
            .flatMap(function((customerOrder, lineExecutions, alerts, executionActions, executions) ->
                Mono.when(createDecreaseQuantityAction(executionActions, lineExecutions, input))
                    .then(this.ruleEngineService.startRuleEngineAndUpdateLines(customerOrder, lineExecutions, alerts, executionActions, executions)))
            );
    }

    private Mono<Void> createDecreaseQuantityAction(List<ExecutionAction> executionActions, List<LineExecution> lineExecutions, UpdateExecutionInput input) {
        final var intiFlags = new Flags<ExecutionActionStatus>();
        intiFlags.raiseFlag(ExecutionActionStatus.CREATED);

        return Flux.fromIterable(input.getExecutionsToUpdate())
            .flatMap(executionData -> Flux.fromIterable(executionData.getLineData())
                .doOnNext(lineData -> stopIfActionIsNotPossible(executionData,
                    lineData,
                    getExistingActionsForExecutionAndLine(executionActions, executionData.getExecutionId(), lineData.getLineId()),
                    getCorrespondingLine(lineExecutions, executionData.getExecutionId(), lineData.getLineId()))))
            .collectList()
            .then(Mono.fromRunnable(() -> executionActions.add(ExecutionAction.builder()
                .requestId(input.getRequestId())
                .customerOrderId(input.getCustomerOrderId())
                .buCode(input.getBuCode())
                .createdAt(Instant.now())
                .appSource(input.getAppSource())
                .appSourceRequestId(input.getRequestId())
                .ownerRequest(input.getOwnerRequest())
                .actionType(ExecutionActionType.valueOf(input.getAction().name()))
                .impactedExecutions(input.getExecutionsToUpdate().stream()
                    .map(executionData -> ImpactedExecution.builder()
                        .currentExecutionId(executionData.getExecutionId())
                        .initialExecutionId(executionData.getExecutionId())
                        .impactedLines(executionData.getLineData().stream()
                            .map(lineData -> ImpactedLine.builder()
                                .lineId(lineData.getLineId())
                                .reason(lineData.getReason())
                                .quantity(lineData.getQuantity())
                                .build())
                            .collect(Collectors.toList()))
                        .build())
                    .collect(Collectors.toList()))
                .flags(intiFlags)
                .build())))
            .then();
    }

    private List<ExecutionAction> getExistingActionsForExecutionAndLine(List<ExecutionAction> executionActions, String executionId, String lineId) {
        return executionActions.stream()
            .filter(executionAction -> executionAction.getLastFlag() != null && !executionAction.getLastFlag().equals(ExecutionActionStatus.COMPLETED))
            .filter(executionAction -> executionAction.getImpactedExecutions().stream()
                .anyMatch(impactedExecution -> impactedExecution.getCurrentExecutionId().equals(executionId)
                    && impactedExecution.getImpactedLines().stream().anyMatch(impactedLineAndQuantity -> impactedLineAndQuantity.getLineId().equals(lineId)))
            ).collect(Collectors.toList());
    }

    private LineExecution getCorrespondingLine(List<LineExecution> lineExecutions, String executionId, String lineId) {
        return lineExecutions.stream()
            .filter(lineExecution -> lineExecution.getExecutionId().equals(executionId)
                && lineExecution.getLineId().equals(lineId))
            .findAny()
            .orElse(null);
    }

    private void stopIfActionIsNotPossible(ExecutionData executionData, LineData lineData, List<ExecutionAction> executionActions, LineExecution lineExecution) {
        if (lineExecution == null) {
            throw new ExecutionAndLineNotFoundError("No data found for execution " + executionData.getExecutionId() + " and  line " + lineData.getLineId());
        }
        if (lineExecution.getQuantity().compareTo(getSumOfQuantityDecreaseRequestedForLineId(executionActions, lineData)) < 0) {
            throw new QuantityNotValidError("Decrease quantity requested is more than executed quantity for execution " + executionData.getExecutionId() + " and  line " + lineData.getLineId());
        }
    }

    private BigDecimal getSumOfQuantityDecreaseRequestedForLineId(List<ExecutionAction> executionActions, LineData line) {
        BigDecimal lineQuantity = line.getQuantity();
        BigDecimal sumOfQuantityDecrease = executionActions.stream()
            .flatMap(executionAction -> executionAction.getImpactedExecutions().stream())
            .flatMap(impactedExecution -> impactedExecution.getImpactedLines().stream())
            .filter(actionLineData -> actionLineData.getLineId().equals(line.getLineId()))
            .map(ImpactedLine::getQuantity)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        return lineQuantity.add(sumOfQuantityDecrease);
    }
}
