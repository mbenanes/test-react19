package com.adeo.sales.customerorder.tempoorchestrator.model.line.execution;

import java.util.Arrays;

public enum ExecutionActionReasonEnum {

    REMAINING_COLLECT, CANCELLATION, UNKNOWN;

    public static ExecutionActionReasonEnum fromString(String stringValue) {
        return Arrays.stream(ExecutionActionReasonEnum.values()).filter(value -> value.name().equals(stringValue)).findFirst().orElse(UNKNOWN);
    }
}
