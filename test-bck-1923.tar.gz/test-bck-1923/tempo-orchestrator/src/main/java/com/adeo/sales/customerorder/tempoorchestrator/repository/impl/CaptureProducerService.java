package com.adeo.sales.customerorder.tempoorchestrator.repository.impl;

import com.adeo.sales.customerorder.paymentscheduler.command.capturecustomerorderlinespayment.CaptureCustomerOrderLinesPayment;
import com.adeo.sales.customerorder.paymentscheduler.command.capturecustomerorderlinespayment.CaptureCustomerOrderLinesPaymentParameter;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.command.CancelCaptureOnDepositPayment;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.command.CancelCaptureOnDepositPaymentParameter;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.command.CancelCapturePayment;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.command.CancelCapturePaymentCustomerOrderLine;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.command.CancelCapturePaymentLine;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.command.CancelCapturePaymentParameter;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.command.CaptureOnDepositPayment;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.command.CaptureOnDepositPaymentCustomerOrderLine;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.command.CaptureOnDepositPaymentParameter;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.CaptureService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.specific.SpecificRecord;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class CaptureProducerService implements CaptureService {

    private final EventProducer eventProducer;
    private final TopicsProperties properties;

    @Override
    public Mono<Void> sendCommandCaptureOnDeposit(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        if (!lineExecutions.isEmpty()) {
            log.info("INTERNAL ask a capture on deposit for the following lines {}", LineExecution.joinLineIds(lineExecutions));
            final var customerOrderId = customerOrder.getId();
            final var paymentScheduleId = customerOrder.getPaymentSchedule().getId();
            final var buCode = customerOrder.getBuCode();
            final var command = this.buildPaymentCaptureOnDepositCommand(lineExecutions, customerOrderId, paymentScheduleId);
            return sendCommand(customerOrderId, buCode, command);
        }
        return Mono.empty();
    }

    @Override
    public Mono<Void> sendCommandCaptureCustomerOrderLines(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        if (!lineExecutions.isEmpty()) {
            log.info("INTERNAL ask a capture for the following lines {}", LineExecution.joinLineIds(lineExecutions));
            final var customerOrderId = customerOrder.getId();
            final var buCode = customerOrder.getBuCode();
            final var command = this.buildPaymentCaptureCommand(lineExecutions, customerOrder);
            return sendCommand(customerOrderId, buCode, command);
        }
        return Mono.empty();
    }

    @Override
    public Mono<Void> sendCommandCancelCaptureOnDeposit(CustomerOrder updatedCustomerOrder, List<LineExecution> lineExecutions) {
        if (!lineExecutions.isEmpty()) {
            log.info("INTERNAL ask cancel capture for the following lines {}", LineExecution.joinLineIds(lineExecutions));
            final var customerOrderId = updatedCustomerOrder.getId();
            final var buCode = updatedCustomerOrder.getBuCode();
            final var command = this.buildCancelCaptureOnDepositCommand(updatedCustomerOrder, lineExecutions);
            return this.sendCommand(customerOrderId, buCode, command);
        }
        return Mono.empty();
    }

    @Override
    public Mono<Void> sendCommandCancelCapture(CustomerOrder updatedCustomerOrder, List<LineExecution> thirdPartyLinesToCancelCapture) {
        if (!thirdPartyLinesToCancelCapture.isEmpty()) {
            log.info("INTERNAL ask cancel capture for the following lines {}", LineExecution.joinLineIds(thirdPartyLinesToCancelCapture));
            final var customerOrderId = updatedCustomerOrder.getId();
            final var buCode = updatedCustomerOrder.getBuCode();
            final var command = buildCancelCaptureCommand(thirdPartyLinesToCancelCapture, customerOrderId);
            return sendCommand(customerOrderId, buCode, command);
        }
        return Mono.empty();
    }

    private CancelCapturePayment buildCancelCaptureCommand(List<LineExecution> lineExecutions, String customerOrderId) {

        final var lines = lineExecutions.stream().map(this::buildCancelCaptureOrderLines).collect(Collectors.toList());

        final var parameter = CancelCapturePaymentParameter.newBuilder()
            .setCustomerOrderId(customerOrderId)
            .setCustomerOrderLines(lines);

        return CancelCapturePayment.newBuilder()
            .setId(UUID.randomUUID().toString())
            .setParameterBuilder(parameter)
            .setType("CancelCapturePayment")
            .build();
    }

    private CancelCapturePaymentLine buildCancelCaptureOrderLines(LineExecution customerOrderLine) {
        return CancelCapturePaymentLine.newBuilder()
            .setCustomerOrderLineId(customerOrderLine.getLineId())
            .build();
    }

    private CancelCaptureOnDepositPayment buildCancelCaptureOnDepositCommand(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        final var paymentScheduleId = customerOrder.getPaymentSchedule().getId();
        final var lines = lineExecutions.stream().map(this::buildCancelAskOwnershipTransferOrderLines).collect(Collectors.toList());
        final var parameter = CancelCaptureOnDepositPaymentParameter.newBuilder()
            .setCustomerOrderId(customerOrder.getId())
            .setPaymentScheduleId(paymentScheduleId)
            .setCustomerOrderLines(lines);

        return CancelCaptureOnDepositPayment.newBuilder()
            .setId(UUID.randomUUID().toString())
            .setParameterBuilder(parameter)
            .setCommandResponseTopicName(this.properties.getPaymentSchedulerResponse())
            .setType("CancelCaptureOnDepositPayment")
            .build();
    }

    private CancelCapturePaymentCustomerOrderLine buildCancelAskOwnershipTransferOrderLines(LineExecution lineExecution) {
        return CancelCapturePaymentCustomerOrderLine.newBuilder()
            .setCustomerOrderLineId(lineExecution.getLineId())
            .setDepositId(lineExecution.getPayment().getDepositLegacyNumber() != null ? lineExecution.getPayment().getDepositLegacyNumber() : "no-deposit-id") // an ugly hack to handle cancel capture for pixys lines after an alert, Must be remove with PSR V3 ...
            .build();
    }

    private CaptureCustomerOrderLinesPayment buildPaymentCaptureCommand(List<LineExecution> lineExecutions, CustomerOrder customerOrder) {
        final var parameterBuilder = this.buildCaptureCustomerOrderLinesParameterBuilder(lineExecutions, customerOrder);

        return CaptureCustomerOrderLinesPayment.newBuilder()
            .setId(UUID.randomUUID().toString())
            .setType("CaptureCustomerOrderLinesPayment")
            .setParameterBuilder(parameterBuilder)
            .setCommandResponseTopicName(this.properties.getPaymentSchedulerResponse())
            .build();
    }

    private CaptureCustomerOrderLinesPaymentParameter.Builder buildCaptureCustomerOrderLinesParameterBuilder(List<LineExecution> custlineExecutionsmerOrderLines, CustomerOrder customerOrder) {
        var lines = custlineExecutionsmerOrderLines.stream().map(lineExecution -> this.buildCustomerOrderLines(customerOrder, lineExecution)).collect(Collectors.toList());

        return CaptureCustomerOrderLinesPaymentParameter.newBuilder()
            .setLines(lines)
            .setCustomerOrderId(customerOrder.getId());
    }

    private com.adeo.sales.customerorder.paymentscheduler.state.CustomerOrderLine buildCustomerOrderLines(CustomerOrder customerOrder, LineExecution lineExecution) {
        final var vendorId = customerOrder.getProductOffer().getOfferLineById(lineExecution.getLineId())
            .stream()
            .map(offerLine -> offerLine.getOffer().getVendorId())
            .findFirst()
            .orElse(null);
        return com.adeo.sales.customerorder.paymentscheduler.state.CustomerOrderLine
            .newBuilder()
            .setId(lineExecution.getLineId())
            .setCustomerOrderId(customerOrder.getId())
            .setVendorId(vendorId)
            .build();
    }

    private CaptureOnDepositPayment buildPaymentCaptureOnDepositCommand(List<LineExecution> lineExecutions, String customerOrderId, String paymentScheduleId) {
        final var parameterBuilder = this.buildCaptureOnDepositParameterBuilder(lineExecutions, customerOrderId, paymentScheduleId);

        return CaptureOnDepositPayment.newBuilder()
            .setId(UUID.randomUUID().toString())
            .setType("CaptureOnDepositPayment")
            .setParameterBuilder(parameterBuilder)
            .setCommandResponseTopicName(this.properties.getPaymentSchedulerResponse())
            .build();
    }

    private CaptureOnDepositPaymentParameter.Builder buildCaptureOnDepositParameterBuilder(List<LineExecution> lineExecutions, String customerOrderId, String paymentScheduleId) {
        final var linesToCaptureOnDeposit = lineExecutions.stream().map(this::buildCustomerOrderLinesOnDeposit).collect(Collectors.toList());

        return CaptureOnDepositPaymentParameter.newBuilder()
            .setCustomerOrderId(customerOrderId)
            .setPaymentScheduleId(paymentScheduleId)
            .setCustomerOrderLines(linesToCaptureOnDeposit);
    }

    private CaptureOnDepositPaymentCustomerOrderLine buildCustomerOrderLinesOnDeposit(LineExecution lineExecution) {
        return CaptureOnDepositPaymentCustomerOrderLine.newBuilder()
            .setCustomerOrderLineId(lineExecution.getLineId())
            .setDepositId(lineExecution.getPayment().getDepositLegacyNumber())
            .build();
    }

    private <T extends SpecificRecord & GenericRecord> Mono<Void> sendCommand(String customerOrderId, String buCode, T command) {
        return this.eventProducer.sendEvents(this.properties.getPaymentScheduler(), customerOrderId, buCode, command);
    }

}
