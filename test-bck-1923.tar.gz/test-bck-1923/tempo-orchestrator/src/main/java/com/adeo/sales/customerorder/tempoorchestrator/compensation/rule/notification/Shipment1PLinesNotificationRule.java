package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_SHIPPED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_PARTNER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_WAREHOUSE;
import static com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService.NotificationType.CUSTOMER_ORDER_SHIPMENT;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Shipment1PLinesNotification",
    description = "send a mail CUSTOMER_ORDER_SHIPMENT when a line is in shipment",
    priority = 1000)
public class Shipment1PLinesNotificationRule {
    private static final OutgoingNotificationService.NotificationType MAIL_TEMPLATE = CUSTOMER_ORDER_SHIPMENT;
    private static final Predicate<LineExecution> SHIPMENT_MAIL_NOT_ALREADY_SENT =
        line -> !line.isMailAlreadySent(MAIL_TEMPLATE.templateType);
    private static final Predicate<LineExecution> LINE_SHOULD_SEND_SHIPMENT_MAIL =
        IS_DELIVERY_SHIPPED.and(IS_SHIPPED_BY_PARTNER.or(IS_SHIPPED_BY_WAREHOUSE).or(IS_SHIPPED_BY_STORE.and(IS_EXTERNAL_SYSTEM_TEMPO))).and(SHIPMENT_MAIL_NOT_ALREADY_SENT);

    private final OutgoingNotificationService notificationService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(LINE_SHOULD_SEND_SHIPMENT_MAIL);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var shippedLineToSendMail = context.getOrderData().getLineExecutionsByPredicate(LINE_SHOULD_SEND_SHIPMENT_MAIL);

        return MonoUtil.infoLog("INTERNAL send notification type {} for lines {}", MAIL_TEMPLATE, LineExecution.joinLineIds(shippedLineToSendMail))
            .then(this.notificationService.sendMailForLines(shippedLineToSendMail, MAIL_TEMPLATE.templateType, context.getOrderData().getExistingCustomerOrder()))
            .then(Mono.fromRunnable(() -> {
                shippedLineToSendMail.forEach(line -> {
                    line.mailIsSent(MAIL_TEMPLATE.templateType);
                    line.increaseVersion();
                });
            }));
    }
}
