package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception;

public class QuantityNotValidError extends RuntimeException {

    public QuantityNotValidError(String error) {
        super(error);
    }

}
