package com.adeo.sales.customerorder.tempoorchestrator.batch;

import brave.Tracer;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.batch.AutoCaptureBatchApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.ApplicationProperties;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;

@RequiredArgsConstructor
@Component
@Slf4j
public class AutoCaptureBatch {
    public static final String TASK_NAME = "batch-auto-capture";

    private final ApplicationProperties properties;
    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final Tracer tracer;
    private final AutoCaptureBatchApplicationService applicationService;

    @Scheduled(cron = "${autocapture.batch.cron}")
    @SchedulerLock(name = "autoCaptureScheduler", lockAtLeastFor = "${autocapture.batch.lockAtLeastFor}", lockAtMostFor = "${autocapture.batch.lockAtLeastFor}")
    public void launchAutoCapture() {
        executeAutoCapture().subscribe();
    }

    public Mono<Void> executeAutoCapture() {
        final var span = this.tracer.nextSpan().name(TASK_NAME);
        this.tracer.withSpanInScope(span.start());
        this.mappedDiagnosticContext.enrichCurrentSpan(MappedDiagnosticContext.SOURCE_CONTEXT_KEY, TASK_NAME);

        log.info("INTERNAL start auto capture batch");
        final var limitExpirationDate = OffsetDateTime.now().plusDays(properties.getNumberOfDayBeforeExpirationForAutoCapture());
        return this.applicationService.apply(limitExpirationDate)
            .doOnTerminate(() -> {
                span.finish();
                log.info("INTERNAL end auto capture batch");
            });
    }


}
