package com.adeo.sales.customerorder.tempoorchestrator.handler.collect;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.collect.CustomerOrderCollectApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.tempocollect.avro.event.CustomerOrderCollectExecuted;
import com.adeo.tempocollect.avro.model.CustomerOrderCollectItem;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.util.List;

@Component
@Slf4j
public class CustomerOrderCollectExecutedHandler extends CustomerOrderCollectCommon implements EventHandler<CustomerOrderCollectExecuted> {

    public CustomerOrderCollectExecutedHandler(MappedDiagnosticContext mappedDiagnosticContext, CustomerOrderCollectApplicationService customerOrderCollectApplicationService) {
        super(mappedDiagnosticContext, customerOrderCollectApplicationService);
    }

    @Override
    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    public Mono<Void> handle(CustomerOrderCollectExecuted event, EventMetaData eventMetaData) {
        List<CustomerOrderCollectItem> customerOrderCollectItems = event.getState().getCustomerOrderCollectItems();
            return handleCollectEvent(event.getState().getStatus(), event.getState().getIdentifier(), event.getState(), eventMetaData, customerOrderCollectItems, this.getManagedEvent().getSimpleName());
    }

    @Override
    public Class<?> getManagedEvent() {
        return CustomerOrderCollectExecuted.class;
    }
}
