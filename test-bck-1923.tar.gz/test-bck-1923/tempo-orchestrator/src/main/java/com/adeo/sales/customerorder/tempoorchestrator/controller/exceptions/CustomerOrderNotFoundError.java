package com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderNotFound;

public class CustomerOrderNotFoundError extends HttpConvertibleException {

    private static final long serialVersionUID = 1L;

    public CustomerOrderNotFoundError(CustomerOrderNotFound error) {
        super(error.getMessage());
    }

    @Override
    public ErrorResponse toError() {
        return ErrorResponse.builder()
            .status(404)
            .code("CUSTOMER_ORDER_NOT_FOUND_ISSUE")
            .title("The customer order id cannot be found.")
            .detail(this.getMessage())
            .build();
    }
}
