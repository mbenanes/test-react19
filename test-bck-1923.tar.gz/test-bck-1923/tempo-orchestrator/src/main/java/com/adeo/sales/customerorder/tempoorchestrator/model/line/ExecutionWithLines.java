package com.adeo.sales.customerorder.tempoorchestrator.model.line;

import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExecutionWithLines {

    private Execution execution;
    private List<LineExecution> lineExecutions;

    public String getExecutionId() {
        return this.execution.getId();
    }

    public List<String> getLineIds() {
        return LineExecution.lineIds(this.lineExecutions);
    }

}
