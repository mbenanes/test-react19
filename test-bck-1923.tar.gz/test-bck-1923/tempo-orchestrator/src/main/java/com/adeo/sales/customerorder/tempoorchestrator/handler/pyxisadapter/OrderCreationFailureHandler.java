package com.adeo.sales.customerorder.tempoorchestrator.handler.pyxisadapter;

import com.adeo.pyxis.adapter.avro.CustomerOrderCreationFailure;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.PyxisOrderCreationFailureApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.input.PyxisOrderInput;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
@Component
@Slf4j
public class OrderCreationFailureHandler implements EventHandler<CustomerOrderCreationFailure> {

    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final PyxisOrderCreationFailureApplicationService applicationService;

    @Override
    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    public Mono<Void> handle(CustomerOrderCreationFailure event, EventMetaData eventMetaData) {
        final var customerOrderId = event.getTempoOrderId();
        final var buCode = event.getBuCode();
        mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderId);
        log.info("CustomerOrderCreationFailure consumes {} - message id: {}", eventMetaData.getTopic(), eventMetaData.getId().orElse("no id"));
        return applicationService.apply(PyxisOrderInput.builder()
            .buCode(buCode)
            .customerOrderId(customerOrderId)
            .lineIds(event.getTempoLineIds())
            .build());
    }


    @Override
    public Class<?> getManagedEvent() {
        return CustomerOrderCreationFailure.class;
    }
}
