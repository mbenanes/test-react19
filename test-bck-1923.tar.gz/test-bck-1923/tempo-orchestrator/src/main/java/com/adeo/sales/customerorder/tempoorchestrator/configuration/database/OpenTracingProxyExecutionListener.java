package com.adeo.sales.customerorder.tempoorchestrator.configuration.database;

import io.opentracing.Span;
import io.opentracing.log.Fields;
import io.opentracing.tag.Tags;
import io.opentracing.util.GlobalTracer;
import io.r2dbc.proxy.core.MethodExecutionInfo;
import io.r2dbc.proxy.core.QueryExecutionInfo;
import io.r2dbc.proxy.core.QueryInfo;
import io.r2dbc.proxy.listener.ProxyMethodExecutionListener;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static java.util.stream.Collectors.joining;

public class OpenTracingProxyExecutionListener implements ProxyMethodExecutionListener {

    private static final String TAG_THREAD_ID = "threadId";
    private static final String TAG_THREAD_NAME = "threadName";
    private static final String TAG_CONNECTION_ID = "connectionId";
    private static final String TAG_TRANSACTION_SAVEPOINT = "savepoint";

    private final Map<String, Span> connectionSpans = new ConcurrentHashMap<>();
    private final Map<String, Span> transactionSpans = new ConcurrentHashMap<>();

    @Override
    public void beforeCreateOnConnectionFactory(MethodExecutionInfo methodExecutionInfo) {
        final var connectionSpan = GlobalTracer.get()
            .buildSpan("postgresql.connection")
            .withTag(Tags.SPAN_KIND, Tags.SPAN_KIND_CLIENT)
            .start();

        methodExecutionInfo.getValueStore().put("ot.connectionSpan", connectionSpan);
    }

    @Override
    public void afterCreateOnConnectionFactory(MethodExecutionInfo methodExecutionInfo) {
        final var connectionSpan = methodExecutionInfo.getValueStore().get("ot.connectionSpan", Span.class);

        final var thrown = methodExecutionInfo.getThrown();
        if (thrown != null) {
            connectionSpan
                .setTag(Tags.ERROR, true)
                .log(Map.of(Fields.ERROR_OBJECT, thrown))
                .finish();
            return;
        }

        if (methodExecutionInfo.getConnectionInfo() == null) {
            connectionSpan.finish();
            return;
        }

        if (methodExecutionInfo.getConnectionInfo() != null) {
            final var connectionId = methodExecutionInfo.getConnectionInfo().getConnectionId();

            connectionSpan
                .setTag(TAG_THREAD_ID, String.valueOf(methodExecutionInfo.getThreadId()))
                .setTag(TAG_THREAD_NAME, methodExecutionInfo.getThreadName())
                .log("Connection Acquired");

            this.connectionSpans.put(connectionId, connectionSpan);
        }
    }

    @Override
    public void afterCloseOnConnection(MethodExecutionInfo methodExecutionInfo) {
        final var connectionInfo = methodExecutionInfo.getConnectionInfo();
        final var connectionId = connectionInfo.getConnectionId();
        final var connectionSpan = this.connectionSpans.remove(connectionId);
        if (connectionSpan != null) {
            final var thrown = methodExecutionInfo.getThrown();
            if (thrown != null) {
                connectionSpan
                    .setTag(Tags.ERROR, true)
                    .log(Map.of(Fields.ERROR_OBJECT, thrown));
            }
            connectionSpan.finish();
        }
    }

    @Override
    public void beforeQuery(QueryExecutionInfo queryExecutionInfo) {
        final var connectionId = queryExecutionInfo.getConnectionInfo().getConnectionId();
        final var parentSpan = transactionSpans.getOrDefault(connectionId, connectionSpans.get(connectionId));
        final var queries = queryExecutionInfo.getQueries().stream()
            .map(QueryInfo::getQuery)
            .collect(joining(", "));

        final var querySpan = GlobalTracer.get()
            .buildSpan("postgresql.query")
            .withTag(Tags.SPAN_KIND, Tags.SPAN_KIND_CLIENT)
            .withTag(Tags.DB_STATEMENT, queries)
            .asChildOf(parentSpan)
            .start();

        queryExecutionInfo.getValueStore().put("ot.querySpan", querySpan);
    }

    @Override
    public void afterQuery(QueryExecutionInfo queryExecutionInfo) {
        final var querySpan = queryExecutionInfo.getValueStore().get("ot.querySpan", Span.class);

        querySpan
            .setTag(TAG_THREAD_ID, String.valueOf(queryExecutionInfo.getThreadId()))
            .setTag(TAG_THREAD_NAME, queryExecutionInfo.getThreadName());

        final var thrown = queryExecutionInfo.getThrowable();
        if (thrown != null) {
            querySpan
                .setTag(Tags.ERROR, true)
                .log(Map.of(Fields.ERROR_OBJECT, thrown));
        }
        querySpan.finish();
    }


    @Override
    public void beforeBeginTransactionOnConnection(MethodExecutionInfo methodExecutionInfo) {
        final var connectionId = methodExecutionInfo.getConnectionInfo().getConnectionId();
        final var connectionSpan = this.connectionSpans.get(connectionId);
        final var transactionSpan = GlobalTracer.get()
            .buildSpan("postgresql.transaction")
            .asChildOf(connectionSpan)
            .start();

        this.transactionSpans.put(connectionId, transactionSpan);
    }

    @Override
    public void afterCommitTransactionOnConnection(MethodExecutionInfo methodExecutionInfo) {
        final var connectionId = methodExecutionInfo.getConnectionInfo().getConnectionId();

        final var transactionSpan = this.transactionSpans.remove(connectionId);
        if (transactionSpan != null) {
            transactionSpan
                .log("commit")
                .setTag(TAG_CONNECTION_ID, connectionId)
                .setTag(TAG_THREAD_ID, String.valueOf(methodExecutionInfo.getThreadId()))
                .setTag(TAG_THREAD_NAME, methodExecutionInfo.getThreadName())
                .finish();
        }

        if (this.connectionSpans.containsKey(connectionId)) {
            final var connectionSpan = this.connectionSpans.get(connectionId);
            connectionSpan.log("Transaction commit");
        }
    }

    @Override
    public void afterRollbackTransactionOnConnection(MethodExecutionInfo methodExecutionInfo) {
        final var connectionId = methodExecutionInfo.getConnectionInfo().getConnectionId();

        final var transactionSpan = this.transactionSpans.remove(connectionId);
        if (transactionSpan != null) {
            transactionSpan
                .log("rollback")
                .setTag(TAG_CONNECTION_ID, connectionId)
                .setTag(TAG_THREAD_ID, String.valueOf(methodExecutionInfo.getThreadId()))
                .setTag(TAG_THREAD_NAME, methodExecutionInfo.getThreadName())
                .finish();
        }

        if (this.connectionSpans.containsKey(connectionId)) {
            final var connectionSpan = this.connectionSpans.get(connectionId);
            connectionSpan.log("Transaction rollback");
        }
    }

    @Override
    public void afterRollbackTransactionToSavepointOnConnection(MethodExecutionInfo methodExecutionInfo) {
        final var connectionId = methodExecutionInfo.getConnectionInfo().getConnectionId();
        final var savepoint = (String) methodExecutionInfo.getMethodArgs()[0];

        final var transactionSpan = this.transactionSpans.remove(connectionId);
        if (transactionSpan != null) {
            transactionSpan
                .log("rollback to savepoint")
                .setTag(TAG_TRANSACTION_SAVEPOINT, savepoint)
                .setTag(TAG_CONNECTION_ID, connectionId)
                .setTag(TAG_THREAD_ID, String.valueOf(methodExecutionInfo.getThreadId()))
                .setTag(TAG_THREAD_NAME, methodExecutionInfo.getThreadName())
                .finish();
        }

        if (this.connectionSpans.containsKey(connectionId)) {
            final var connectionSpan = this.connectionSpans.get(connectionId);
            connectionSpan.log("Transaction rollback to savepoint");
        }
    }
}
