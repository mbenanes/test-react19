package com.adeo.sales.customerorder.tempoorchestrator.handler.psr;

import com.adeo.sales.customerorder.paymentscheduler.v2.execution.domainevent.FirstRankPaymentAgreementWithConfirmationRequired;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.PaymentAgreementApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;


@RequiredArgsConstructor
@Component
@Slf4j
public class FirstRankPaymentAgreementWithConfirmationRequiredHandler implements EventHandler<FirstRankPaymentAgreementWithConfirmationRequired> {
    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final PaymentAgreementApplicationService paymentAgreementApplicationService;

    @Override
    public Mono<Void> handle(FirstRankPaymentAgreementWithConfirmationRequired event, EventMetaData eventMetaData) {
        mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData,
            event.getState().getCustomerOrderId());

        return paymentAgreementApplicationService.apply(event.getState().getOperations(), event.getState().getCustomerOrderId(), eventMetaData.getBuCode());
    }

    @Override
    public Class<?> getManagedEvent() {
        return FirstRankPaymentAgreementWithConfirmationRequired.class;
    }
}
