package com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions;


import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.support.WebExchangeBindException;
import org.springframework.web.server.ServerWebInputException;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@RestControllerAdvice
public class ExceptionHandling {

    @ExceptionHandler(ServerWebInputException.class)
    public ResponseEntity<ErrorResponses> handleInputException(ServerWebInputException exception) {
        final var error = ErrorResponse.builder()
                .status(exception.getStatus().value())
                .code("BAD_REQUEST")
                .detail(exception.getReason())
                .title(exception.getReason())
                .build();

        final var body = ErrorResponses.builder()
            .errors(List.of(error))
            .build();

        return ResponseEntity.badRequest().body(body);
    }

    @ExceptionHandler(WebExchangeBindException.class)
    public ResponseEntity<ErrorResponses> handleValidationError(WebExchangeBindException exception) {
        final var validationException = exception.getAllErrors();

        final var errors = validationException.stream()
                .map(this::convertToErrorResponse)
                .collect(Collectors.toList());

        final var body = ErrorResponses.builder()
            .errors(errors)
            .build();

        return ResponseEntity.badRequest().body(body);
    }

    @ExceptionHandler(HttpConvertibleException.class)
    public ResponseEntity<ErrorResponses> handlerHttpConvertibleException(HttpConvertibleException exception) {
        log.warn("http response error - {}" ,exception.getMessage(), exception);
        final var errors = exception.toErrors();

        return ResponseEntity.status(buildStatus(errors)).body(errors);
    }

    @ExceptionHandler(CallNotPermittedException.class)
    public ResponseEntity<ErrorResponses> handlerCallNotPermittedException(CallNotPermittedException exception) {
        log.error("http response error - circuit breaker is open: {}", exception.getMessage());
        final var error = ErrorResponse.builder()
            .code("DEPENDENT_SERVER_UNREACHABLE")
            .status(500)
            .title("can not contact dependent server because circuit breaker is open")
            .detail(exception.getMessage())
            .build();

        final var body = ErrorResponses.builder()
            .errors(List.of(error))
            .build();

        return ResponseEntity.status(500).body(body);
    }

    private int buildStatus(ErrorResponses errors) {
        final var statusList = errors.getErrors().stream()
                            .map(ErrorResponse::getStatus)
                            .distinct()
                            .collect(Collectors.toList());

        if (statusList.size() == 1) {
            return statusList.get(0);
        } else {
            return 400;
        }
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponses> handleUnknownError(Throwable exception) {
        log.error(exception.getMessage(), exception);
        final var error = ErrorResponse.builder()
            .title("Internal error")
            .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
            .code("INTERNAL_ERROR")
            .build();

        final var body = ErrorResponses.builder()
            .errors(List.of(error))
            .build();

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
    }

    private ErrorResponse convertToErrorResponse(ObjectError objectError) {
        var code = objectError.getCode();
        var message = "";
        var title = "";
        if (objectError instanceof FieldError) {
            message = ((FieldError) objectError).getField() + " " + objectError.getDefaultMessage();
            title = message;
        } else {
            message = objectError.getDefaultMessage();
            title = message;
        }
        try {
            final var source = objectError.unwrap(ConstraintViolationImpl.class);
            final var attributes = source.getConstraintDescriptor().getAttributes();
            if (attributes.containsKey("code")) {
                code = attributes.get("code").toString();
            }
            if (attributes.containsKey("title")) {
                title = attributes.get("title").toString();
            }
        } catch (IllegalArgumentException ie) {
            // do nothing, because this error will append
            // when the source of the object error is not related to our usecase
            // and it's don't mean anything
        }

        return ErrorResponse.builder()
            .title(title)
            .detail(message)
            .code(code)
            .status(HttpStatus.BAD_REQUEST.value())
            .build();
    }
}
