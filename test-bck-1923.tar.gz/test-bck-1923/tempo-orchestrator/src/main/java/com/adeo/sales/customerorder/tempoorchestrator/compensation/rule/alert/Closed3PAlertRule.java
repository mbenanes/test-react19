package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertReason;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.RejectedLinesSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.RejectedPaymentSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.thereIsAtLeastOneCreatedAlert;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Close3PAlert",
    description = "Close promised date alert an reason in (REJECTED_BY_SELLER)",
    priority = 990)
public class Closed3PAlertRule {
    private final AlertMessageService notifier;
    private final Set<String> validPromisedDateReasons = Set.of(AlertReason.REJECTED_BY_SELLER.name());
    private final Set<String> validTransactionReasons = Set.of(AlertReason.REJECTED_PAYMENT.name());

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return thereIsAtLeastOneCreatedAlert(context);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var canceledLineIds = getCanceledLineIds(context);
        final var promisedDateAlertsToClose = getAlertsToClose(context, canceledLineIds, RejectedLinesSpecificData.class, validPromisedDateReasons);
        final var transactionAlertToClose = getAlertsToClose(context, canceledLineIds, RejectedPaymentSpecificData.class, validTransactionReasons);
        final var alertsToClose = Stream.concat(promisedDateAlertsToClose, transactionAlertToClose).collect(Collectors.toList());

        return MonoUtil.infoLog("INTERNAL request close 3P alert for alerts: {}", Alert.joinAlertIds(alertsToClose))
            .then(Mono.when(
                alertsToClose.stream()
                    .map(alert -> notifier.sendCloseAlertMessage(alert, AlertMessageService.ClosingReason.CANCELED))
                    .collect(Collectors.toList())
            ));
    }

    private Stream<Alert> getAlertsToClose(RuleEngineContext context, List<String> canceledLineIds, Class<?> alertType, Set<String> validReasons) {
        return context.getAlertData()
            .getExistingAlerts()
            .stream()
            .filter(alert -> alertType.isAssignableFrom(alert.getSpecificData().getClass()))
            .filter(alert ->
                alert.getStatus() == AlertStatus.CREATED &&
                    alertContainsAllLines(canceledLineIds, alert) &&
                    validReasons.contains(alert.getSpecificData().getReason()));
    }

    private List<String> getCanceledLineIds(RuleEngineContext context) {
        return context.getOrderData()
            .getExistingLineExecutions()
            .stream()
            .filter(lineExecution -> lineExecution.getDelivery().getDeliveryType() == DeliveryType.THIRD_PARTY)
            .filter(lineExecution -> lineExecution.getComposition().getFlags().lastFlagIs(CompositionOrderStatus.CANCELED))
            .map(LineExecution::getLineId)
            .collect(Collectors.toList());
    }

    private boolean alertContainsAllLines(List<String> canceledLineIds, Alert alert) {
        return new HashSet<>(canceledLineIds).containsAll(alert.getImpactedLinesIds());
    }
}
