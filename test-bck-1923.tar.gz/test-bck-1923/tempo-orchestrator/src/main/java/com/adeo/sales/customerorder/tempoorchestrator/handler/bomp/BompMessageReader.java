package com.adeo.sales.customerorder.tempoorchestrator.handler.bomp;

import com.adeo.bomp.order.model.avro.vendororderlines.CustomerOrderLinesState;
import com.adeo.bomp.order.model.avro.vendororderlines.State;
import com.adeo.bomp.order.model.avro.vendororderlines.VendorOrderlines;

import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class BompMessageReader {

    public static List<String> getLineIds(VendorOrderlines orderLines, Predicate<? super CustomerOrderLinesState> filter) {
        return orderLines.getCustomerOrderLines().stream()
            .filter(filter)
            .map(line -> Objects.toString(line.getOrderlineId()))
            .collect(Collectors.toList());
    }


    public static List<String> getLineIds(VendorOrderlines orderLines) {
        return orderLines.getCustomerOrderLines().stream()
            .map(line -> Objects.toString(line.getOrderlineId()))
            .collect(Collectors.toList());
    }

    public static String getExternalOrchestratorId(VendorOrderlines orderLines) {
        return Objects.toString(orderLines.getBompId(), null);
    }

    public static String getCustomerOrderId(VendorOrderlines orderLines) {
        return Objects.toString(orderLines.getCustomerOrderId(), null);
    }

    public static Predicate<CustomerOrderLinesState> withStatus(State lineState) {
        return line -> lineState == line.getStatus();
    }

    public static Predicate<CustomerOrderLinesState> reason(String reason) {
        return line -> Objects.equals(reason, Objects.toString(line.getReasonCode(), null));
    }

    public static Predicate<CustomerOrderLinesState> noReason() {
        return line -> line.getReasonCode() == null;
    }
}
