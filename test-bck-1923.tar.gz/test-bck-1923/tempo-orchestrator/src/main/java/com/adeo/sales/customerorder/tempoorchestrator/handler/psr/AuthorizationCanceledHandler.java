package com.adeo.sales.customerorder.tempoorchestrator.handler.psr;

import com.adeo.sales.customerorder.paymentscheduler.v2.execution.domainevent.AuthorizationCanceled;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.PaymentOperationApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.input.PaymentOperationInput;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationTechnicalStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationType;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

@Component
public class AuthorizationCanceledHandler extends AbstractCancelOperationHandler implements EventHandler<AuthorizationCanceled> {

    public AuthorizationCanceledHandler(MappedDiagnosticContext mappedDiagnosticContext, PaymentOperationApplicationService applicationService) {
        super(mappedDiagnosticContext, applicationService);
    }

    @Override
    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    public Mono<Void> handle(AuthorizationCanceled event, EventMetaData eventMetaData) {
        final var customerOrderId = event.getDelta().getCustomerOrderId();
        this.mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderId);

        final var buCode = eventMetaData.getBuCode();
        return this.applicationService.apply(PaymentOperationInput.builder()
            .inputLineIdsByOperation(this.getImpactedLinesByOperationId(event.getState()))
            .inputLineIdsByOperationKey(this.getImpactedLinesByOperationType(event.getState()))
            .buCode(buCode)
            .customerOrderId(customerOrderId)
            .paymentOperationType(PaymentOperationType.CANCEL_AUTHORIZATION)
            .paymentOperationTechnicalStatus(PaymentOperationTechnicalStatus.SUCCEED)
            .build());
    }

    @Override
    public Class<?> getManagedEvent() {
        return AuthorizationCanceled.class;
    }
}
