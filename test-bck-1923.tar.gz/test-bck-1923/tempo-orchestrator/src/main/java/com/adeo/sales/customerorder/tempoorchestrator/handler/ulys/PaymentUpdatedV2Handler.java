package com.adeo.sales.customerorder.tempoorchestrator.handler.ulys;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.ulys.PaymentApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.postpone.utils.MonoLog;
import com.adeo.ulys.payment.event.kafka.bean.v2.ExternalReference;
import com.adeo.ulys.payment.event.kafka.bean.v2.PaymentUpdatedV2;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.Optional;

@Component
@Slf4j
@RequiredArgsConstructor
public class PaymentUpdatedV2Handler implements EventHandler<PaymentUpdatedV2> {
    private final PaymentApplicationService paymentApplicationService;
    private final MappedDiagnosticContext mappedDiagnosticContext;

    @Override
    public Mono<Void> handle(PaymentUpdatedV2 event, EventMetaData metaData) {
        final var customerOrderID = Optional.ofNullable(event.getExternalReference()).map(ExternalReference::getId).orElse(null);
        final var buCode = metaData.getBusinessUnit();

        if (StringUtils.isEmpty(buCode)) {
            return MonoLog.warn("INTERNAL: PaymentUpdatedV2 event without buCode");
        }

        if (customerOrderID == null) {
            return MonoLog.warn("INTERNAL: PaymentUpdatedV2 event without order");
        }

        this.mappedDiagnosticContext.injectEventMinimalBUData(metaData, customerOrderID, buCode);

        return paymentApplicationService.apply(event, metaData)
            .onErrorResume(throwable -> MonoLog.warn("INTERNAL: Error during PaymentUpdatedV2 event consuming with message {} , stackTrace {}", throwable.getMessage(), Arrays.toString(throwable.getStackTrace())))
            .then();
    }

    @Override
    public Class<?> getManagedEvent() {
        return PaymentUpdatedV2.class;
    }
}
