package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.service;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.service.input.ProjectExecutionRequestAcceptedInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.*;
import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@Slf4j
@Component
@RequiredArgsConstructor
public class ProjectExecutionRequestAcceptedApplicationService {

    private final RuleEngineService ruleEngineService;

    public Mono<Void> apply(ProjectExecutionRequestAcceptedInput input) {
        return this.ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode())
            .doOnNext(
                consumer((customerOrder, lineExecutions, alerts) -> this.updateLines(input, lineExecutions))
            )
            .flatMap(function(this.ruleEngineService.startRuleEngineAndUpdateLines()));
    }

    private void updateLines(ProjectExecutionRequestAcceptedInput input, List<LineExecution> lineExecutions) {
        lineExecutions
            .stream().filter(line -> input.getCustomerOrderLineIds().contains(line.getLineId()))
            .forEach(line -> line.getDelivery().getFlags().raiseFlagIfNot(ACCEPTED)
        );
    }

}
