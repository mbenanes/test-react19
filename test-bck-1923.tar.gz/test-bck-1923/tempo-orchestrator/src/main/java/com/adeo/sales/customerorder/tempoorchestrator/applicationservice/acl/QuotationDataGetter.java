package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.input.CashingStoreAssignerInput;
import lombok.Builder;
import lombok.Getter;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface QuotationDataGetter {

    Mono<Void> applyValidate(CustomerOrder customerOrder);

    enum QuotationStatus{
        SIMULATED, VALIDATED, CANCELED, PROPOSED
    }

    Mono<QuotationData> apply(CashingStoreAssignerInput input);

    @Getter
    @Builder
    class QuotationData {
        private Map<String, LineMetadata> metadataByOfferLineId;
        private List<LoyaltyFee> loyaltyFees;
        private QuotationStatus status;
    }

    @Getter
    @Builder
    class LoyaltyFee {
        private String id;
        private String cashingStore;
        private String refLM;
        private String offerId;
        private BigDecimal amount;
        private String vendorId;
    }

    @Getter
    @Builder
    class LineMetadata {
        private String cashingStore;
    }
}
