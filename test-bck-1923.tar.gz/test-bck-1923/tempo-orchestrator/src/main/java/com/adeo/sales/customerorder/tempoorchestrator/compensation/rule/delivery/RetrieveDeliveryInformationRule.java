package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.DeliveryInformationGetter;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.Clock;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Optional;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_DELIVERY_TYPE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OFFER;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "RetrieveDeliveryInformation",
    description = "retrieve delivery information from DST when version was changed",
    priority = 4)
public class RetrieveDeliveryInformationRule {
    private final DeliveryInformationGetter deliveryInformationGetter;

    private static final Predicate<LineExecution> IS_NOT_CANCELED_OFFER = IS_OFFER
        .and(not(IS_LINE_COMPOSITION_CANCELED));

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        CustomerOrder existingCustomerOrder = context.getOrderData().getExistingCustomerOrder();
        CustomerOrder customerOrder = context.getOrderData().getExistingCustomerOrder();

        boolean compositionDeliveryVersionExists = existingCustomerOrder.getDelivery() != null && existingCustomerOrder.getDelivery().getId() != null;
        boolean compositionDeliveryFromDstVersionExists = existingCustomerOrder.getDeliveryFromDST() != null && existingCustomerOrder.getDeliveryFromDST().getId() != null;

        return (compositionDeliveryVersionExists && !compositionDeliveryFromDstVersionExists && context.hasAtLeastOneLine(IS_OFFER))
            || (context.hasAtLeastOneLine(IS_OFFER.and(not(HAS_DELIVERY_TYPE))) && compositionDeliveryVersionExists)
            || (context.hasAtLeastOneLine(IS_NOT_CANCELED_OFFER) && isDeliveryVersionBetweenTcoAndDSTDifferent(customerOrder));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var lineExecutions = context.getOrderData().getExistingLineExecutions();
        CustomerOrder customerOrder = context.getOrderData().getExistingCustomerOrder();

        return this.deliveryInformationGetter.retrieve(LineExecution.lineIds(context.getOrderData().getExistingLineExecutions()), customerOrder.getBuCode(), customerOrder.getDelivery().getId(), customerOrder.getDelivery().getVersion(), true)
            .doOnNext(deliveryInformationBody -> {
                    deliveryInformationBody.getDeliveryInformationList().forEach(deliveryInformation -> {
                        final var correspondingLineExecutions = LineExecution.getCorrespondingLine(lineExecutions, deliveryInformation.getLineId());
                        updateLineExecutions(deliveryInformation, correspondingLineExecutions, customerOrder);
                    });
                    customerOrder.setDeliveryFromDST(new Clock(deliveryInformationBody.getCode(), deliveryInformationBody.getVersion()));
                }
            ).then();
    }

    private static void updateLineExecutions(DeliveryInformationGetter.DeliveryInformation deliveryInformation, Optional<LineExecution> correspondingLine, CustomerOrder customerOrder) {
        if (correspondingLine.isPresent()) {
            final var line = correspondingLine.get();
            line.getDelivery().setIdDelivery(deliveryInformation.getIdDelivery());
            line.getDelivery().setDeliveryType(deliveryInformation.getDeliveryType());
            if (line.getDelivery().getCustomerKnownDeliveryDate() == null) {
                line.getDelivery().setCustomerKnownDeliveryDate(deliveryInformation.getDeliveryDate());
            }
            line.getDelivery().setAppointmentDate(deliveryInformation.getAppointmentDate());
            if (line.getDelivery().getInitialPromiseDate() == null) {
                line.getDelivery().setInitialPromiseDate(deliveryInformation.getDeliveryDate());
            }
            line.getDelivery().setShippingPoint(deliveryInformation.getShippingPoint());
            line.getComposition().setPromisedDateConfirmed(deliveryInformation.isPromisedDateConfirmed());
            line.getDelivery().setNewDeliveryDate(deliveryInformation.getDeliveryDate());
        } else {
            log.warn("No corresponding dst line id {} in customerOrder {}", deliveryInformation.getLineId(), customerOrder.getId());
        }
    }

    private boolean isDeliveryVersionBetweenTcoAndDSTDifferent(CustomerOrder customerOrder) {
        return customerOrder.getDelivery() != null &&
            customerOrder.getDelivery().getId() != null &&
            customerOrder.getDeliveryFromDST() != null &&
            !customerOrder.getDelivery().getVersion().equals(customerOrder.getDeliveryFromDST().getVersion());
    }
}
