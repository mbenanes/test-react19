package com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions;

import org.springframework.http.HttpStatus;

public class ValidationError extends HttpConvertibleException {
    public final String field;
    public final String code;
    public final String message;

    public ValidationError(String field, String code, String message) {
        super(message);
        this.field = field;
        this.code = code;
        this.message = message;
    }


    @Override
    public ErrorResponse toError() {
        return new ErrorResponse(
            HttpStatus.BAD_REQUEST.value(),
            this.code,
            "validation issue.",
            this.field + " : " + this.message
        );
    }
}
