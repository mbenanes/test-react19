package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.DeliveryInformationGetter;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CONFIRMATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_DATE_CONFIRMED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PROMISED_DATE_CONFIRMATION_ASKED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "ValidateDeliveryDateRuleTpp",
    description = "Validate promise delivery date for an order",
    priority = 1000)
public class ValidateDeliveryDateRuleTpp {
    private final DeliveryInformationGetter deliveryInformationGetter;

    private static final Predicate<LineExecution> OFFER_VALIDATED =
        IS_OFFER
            .and(IS_LINE_COMPOSITION_VALIDATED);
    private static final Predicate<LineExecution> LINE_SHOULD_VALIDATE_DELIVERY_DATE =
        OFFER_VALIDATED
            .and(PAYMENT_ORCHESTRATED_BY_TPP)
            .and(not(IS_DELIVERY_DATE_CONFIRMED))
            .and(not(IS_PROMISED_DATE_CONFIRMATION_ASKED))
            .and(IS_CONFIRMATION_REQUIREMENT_COMPLIANT);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.isCustomerOrderMatches(IS_VALIDATED) && context.hasAtLeastOneLine(LINE_SHOULD_VALIDATE_DELIVERY_DATE);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return MonoUtil.infoLog("INTERNAL request delivery date validation for order: {}", context.getOrderData().getExistingCustomerOrder().getId())
            .then(this.deliveryInformationGetter.applyValidateDate(context.getOrderData().getExistingCustomerOrder().getId(), context.getBuCode())
                .doOnSuccess(unused -> context.getOrderData().getExistingLineExecutions().forEach(lineExecution -> {
                    lineExecution.getComposition().setPromisedDateConfirmationAsked(true);
                    lineExecution.increaseVersion();
                }))
                .onErrorResume(throwable -> MonoUtil.errorLog("INTERNAL: Not able to validate delivery date for order {}", context.getOrderData().getExistingCustomerOrder().getId()))
            );
    }
}
