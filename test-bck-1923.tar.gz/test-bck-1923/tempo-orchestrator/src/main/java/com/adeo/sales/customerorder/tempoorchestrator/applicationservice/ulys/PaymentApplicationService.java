package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.ulys;

import com.adeo.sales.customerorder.tempoorchestrator.converter.PaymentOperationConverter;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperation;
import com.adeo.sales.customerorder.tempoorchestrator.repository.PaymentRepository;
import com.adeo.ulys.payment.event.kafka.bean.v2.PaymentUpdatedV2;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;


@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentApplicationService {

    private final PaymentOperationConverter paymentOperationConverter;
    private final PaymentRepository paymentRepository;

    public Mono<Void> apply(PaymentUpdatedV2 paymentUpdatedV2, EventMetaData eventMetaData) {

        String buCode = eventMetaData.getBusinessUnit();

        List<PaymentOperation> paymentOperations = paymentOperationConverter.convert(paymentUpdatedV2, buCode);

        return paymentRepository.upsert(paymentOperations).then();
    }
}
