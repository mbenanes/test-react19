package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.log;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_ACCEPTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_CREATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_CREATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_REJECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_BOMP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "LogOn3PPartialAcceptance",
    description = "warn log if a vendor partially accepted or refused the order",
    priority = 1000)
public class LogOn3PPartialAcceptanceRule {
    private static final Predicate<LineExecution> BOMP_LINE_NOT_CANCELED = IS_EXTERNAL_SYSTEM_BOMP.and(not(IS_LINE_COMPOSITION_CANCELED));
    private static final Predicate<List<LineExecution>> HAVE_A_LINE_NON_ACCEPTED_OR_REJECTED = lineExecutions -> lineExecutions.stream().anyMatch(IS_DELIVERY_CREATION_REQUESTED.or(IS_DELIVERY_CREATED));
    private static final Predicate<List<LineExecution>> AT_LEAST_ONE_SUBORDER_LINE_IS_ACCEPTED_OR_REJECTED = lineExecutions -> lineExecutions.stream().anyMatch(IS_DELIVERY_ACCEPTED.or(IS_DELIVERY_REJECTED));

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return !this.findBompNotCanceledLines(context).isEmpty();
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return Mono.when(
            this.findBompNotCanceledLines(context)
                .stream()
                .map(lines -> MonoUtil.warnLog(
                    "the sub order with external id {} cannot be captured because some non rejected lines are not accepted.",
                    lines.get(0).getExternalSystem().getId()
                ))
                .collect(Collectors.toList())
        );
    }

    private Collection<List<LineExecution>> findBompNotCanceledLines(RuleEngineContext context) {
        return context.getOrderData().getExistingLineExecutions().stream()
            .filter(BOMP_LINE_NOT_CANCELED)
            .collect(Collectors.groupingBy(l -> l.getExternalSystem().getId()))
            .values().stream()
            .filter(HAVE_A_LINE_NON_ACCEPTED_OR_REJECTED.and(AT_LEAST_ONE_SUBORDER_LINE_IS_ACCEPTED_OR_REJECTED))
            .collect(Collectors.toList());
    }
}
