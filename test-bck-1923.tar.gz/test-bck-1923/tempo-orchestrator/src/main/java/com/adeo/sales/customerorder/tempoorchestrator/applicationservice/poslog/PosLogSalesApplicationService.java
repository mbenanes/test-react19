package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.poslog;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.poslog.input.SoldOrderInput;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderRepository;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.PaymentStatus;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;

import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@Component
@RequiredArgsConstructor
@Slf4j
public class PosLogSalesApplicationService {
    private final CustomerOrderRepository customerOrderRepository;
    private final RuleEngineService ruleEngineService;


    public Mono<Void> apply(SoldOrderInput input) {
        return this.customerOrderRepository.isSelfServiceOrder(input.getCustomerOrderId(), input.getBuCode())
            .flatMap(isSelfServiceOrderedProducts -> {
                if (isSelfServiceOrderedProducts) {
                    return this.ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode())
                        .doOnNext(
                            consumer((customerOrder, lineExecutions, alerts, executionActions, executions) -> this.updateData(input, lineExecutions, executions))
                        )
                        .flatMap(function(ruleEngineService.startRuleEngineAndUpdateLines()));
                } else {
                    return MonoUtil.infoLog("INTERNAL: Order contains not SELF_SERVICE products")
                        .then();
                }
            });
    }

    private void updateData(SoldOrderInput input, List<LineExecution> lineExecutions, List<Execution> executions) {
        input.getReferences().stream()
            .flatMap(soldReference -> lineExecutions.stream()
                .filter(lineExecution -> lineExecution.getComposition().getOffer().getRefLM().equals(soldReference.getReference()))
                .findFirst().stream())
            .forEach(lineExecution ->
                lineExecution.getPayment().getFlags().raiseFlagIfNot(PaymentStatus.OWNERSHIP_TRANSFERRED));

        executions.forEach(execution -> execution.getExecutionStatus().raiseFlagIfNot(ExecutionStatus.CONFIRMED));
        //[TODO] For M4 add COMPLETED flag;
    }
}
