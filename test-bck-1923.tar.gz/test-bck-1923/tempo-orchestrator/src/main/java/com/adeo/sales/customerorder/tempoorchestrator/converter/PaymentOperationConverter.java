package com.adeo.sales.customerorder.tempoorchestrator.converter;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.StateNotManagedException;
import com.adeo.sales.customerorder.tempoorchestrator.handler.ulys.CashingOriginType;
import com.adeo.sales.customerorder.tempoorchestrator.handler.ulys.CashingPaymentStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentLineType;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOrderLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperation;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationType;
import com.adeo.ulys.payment.event.kafka.bean.v2.AuthorizedAmount;
import com.adeo.ulys.payment.event.kafka.bean.v2.Beneficiary;
import com.adeo.ulys.payment.event.kafka.bean.v2.BeneficiaryLine;
import com.adeo.ulys.payment.event.kafka.bean.v2.PaymentUpdatedV2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Component
@Slf4j
public class PaymentOperationConverter implements Converter<PaymentUpdatedV2, List<PaymentOperation>> {

    public static final String PAYMENT_MEAN_MULTIBANCO = "MULTIBANCO";
    public static final String PAYMENT_MEAN_BANK_TRANSFER_WEB = "BANK_TRANSFER_WEB";

    public static final String PAYMENT_MEAN_BIZUM = "BIZUM";
    public static final Set<CashingPaymentStatus> HANDLED_STATUS_FOR_MULTIBANCO = Set.of(CashingPaymentStatus.AUTHORIZATION_REQUESTED, CashingPaymentStatus.REJECTED);

    @Override
    public List<PaymentOperation> convert(PaymentUpdatedV2 paymentUpdatedV2) throws StateNotManagedException {
        final var authorizedAmonts = mapAuthorizedPaymentOperation(paymentUpdatedV2);
        final var capturedAmonts = mapCapturedPaymentOperation(paymentUpdatedV2);
        final var refundedAmonts = mapRefundedPaymentOperation(paymentUpdatedV2);
        final var canceledAmonts = mapCanceledPaymentOperation(paymentUpdatedV2);

        return Stream.of(authorizedAmonts, capturedAmonts, refundedAmonts, canceledAmonts)
            .flatMap(Collection::stream)
            .sorted(Comparator.comparing(PaymentOperation::getOperationDate))
            .toList();
    }

    public List<PaymentOperation> convert(PaymentUpdatedV2 paymentUpdatedV2, String buCode) {
        try {
            return convert(paymentUpdatedV2).stream()
                .peek(paymentOperation -> paymentOperation.setBuCode(buCode))
                .toList();
        } catch (Exception exception) {
            log.warn("Error during payment operation creation for customerOrderId " + paymentUpdatedV2.getExternalReference().getId() + " and buCode " + buCode + " cause by : " + exception.getMessage());
            return Collections.emptyList();
        }
    }

    private static List<PaymentOperation> mapAuthorizedPaymentOperation(PaymentUpdatedV2 paymentUpdatedV2) {
        final CashingOriginType originType = CashingOriginType.fromString(paymentUpdatedV2.getState().getOriginType());
        final var paymentMean = paymentUpdatedV2.getState().getInstrumentType();

        return Optional.ofNullable(paymentUpdatedV2.getState().getAmounts().getAuthorizedAmounts()).orElse(Collections.emptyList()).stream()
            .collect(Collectors.groupingBy(AuthorizedAmount::getStatus))
            .values()
            .stream()
            .filter(authorizedAmounts -> !PaymentOperationStatus.NOT_MANAGED.equals(mapAuthorizedCashingStatus(CashingPaymentStatus.fromString(authorizedAmounts.get(0).getStatus()), originType, paymentMean)))
            .map(authorizedAmounts -> PaymentOperation.builder()
                .id(UUID.randomUUID().toString())
                .customerOrderId(paymentUpdatedV2.getExternalReference().getId())
                .customerOrderVersion(paymentUpdatedV2.getExternalReference().getVersion())
                .transactionId(paymentUpdatedV2.getState().getTransactionId())
                .paymentMean(paymentMean)
                .operation(PaymentOperationType.AUTHORIZATION)
                .operationDate(Instant.ofEpochMilli(authorizedAmounts.get(0).getAuthorizationDate()))
                .status(mapAuthorizedCashingStatus(CashingPaymentStatus.fromString(authorizedAmounts.get(0).getStatus()), originType, paymentMean))
                .amount(authorizedAmounts.stream().map(AuthorizedAmount::getBeneficiary).map(Beneficiary::getLines)
                    .flatMap(Collection::stream).map(BeneficiaryLine::getAmount).map(BigDecimal::valueOf)
                    .reduce(BigDecimal.ZERO, BigDecimal::add))
                .paymentOrderLines(authorizedAmounts.stream().map(AuthorizedAmount::getBeneficiary).map(Beneficiary::getLines).flatMap(Collection::stream).map(beneficiaryLine -> PaymentOrderLine.builder().id(beneficiaryLine.getLineId()).type(mapLineType(beneficiaryLine.getType())).build()).toList())
                .paymentExternalData(mapExternalData(paymentUpdatedV2, paymentMean))
                .build())
            .toList();
    }

    private static Map<String, String> mapExternalData(PaymentUpdatedV2 event, String paymentMean) {
        if (PAYMENT_MEAN_MULTIBANCO.equals(paymentMean) && event.getExternalPaymentReferences().isEmpty()) {
            log.warn("externalPaymentReferences is mandatory for paymentMean " + PAYMENT_MEAN_MULTIBANCO);
        }
        return Objects.requireNonNullElse(event.getExternalPaymentReferences(), Collections.emptyMap());
    }

    private static List<PaymentOperation> mapCapturedPaymentOperation(PaymentUpdatedV2 paymentUpdatedV2) {
        String paymentMean = paymentUpdatedV2.getState().getInstrumentType();
        final var operationStatus =
            CashingOriginType.SYNCHRONOUS == CashingOriginType.fromString(paymentUpdatedV2.getState().getOriginType())
                && !PAYMENT_MEAN_MULTIBANCO.equals(paymentMean)
                ? PaymentOperationStatus.PENDING
                : PaymentOperationStatus.ACCEPTED;

        return Optional.ofNullable(paymentUpdatedV2.getState().getAmounts().getCapturedAmounts()).orElse(Collections.emptyList()).stream()
            .map(capturedAmount -> PaymentOperation.builder()
                .id(UUID.randomUUID().toString())
                .customerOrderId(paymentUpdatedV2.getExternalReference().getId())
                .customerOrderVersion(paymentUpdatedV2.getExternalReference().getVersion())
                .transactionId(capturedAmount.getCaptureId())
                .paymentMean(paymentMean)
                .operation(PaymentOperationType.PAYMENT)
                .operationDate(capturedAmount.getPendingCaptureDate() != null ? Instant.ofEpochMilli(capturedAmount.getPendingCaptureDate()) : Instant.ofEpochMilli(capturedAmount.getCaptureDate()))
                .status(operationStatus)
                .amount(capturedAmount.getBeneficiary().getLines().stream().map(BeneficiaryLine::getAmount).map(BigDecimal::valueOf).reduce(BigDecimal.ZERO, BigDecimal::add))
                .paymentOrderLines(capturedAmount.getBeneficiary().getLines().stream().map(beneficiaryLine -> PaymentOrderLine.builder().id(beneficiaryLine.getLineId()).type(mapLineType(beneficiaryLine.getType())).build()).toList())
                .paymentExternalData(mapExternalData(paymentUpdatedV2, paymentMean))
                .build())
            .toList();
    }

    private static List<PaymentOperation> mapRefundedPaymentOperation(PaymentUpdatedV2 paymentUpdatedV2) {
        String paymentMean = paymentUpdatedV2.getState().getInstrumentType();
        return Optional.ofNullable(paymentUpdatedV2.getState().getAmounts().getRefundedAmounts()).orElse(Collections.emptyList()).stream()
            .map(refundedAmount -> PaymentOperation.builder()
                .id(UUID.randomUUID().toString())
                .customerOrderId(paymentUpdatedV2.getExternalReference().getId())
                .customerOrderVersion(paymentUpdatedV2.getExternalReference().getVersion())
                .transactionId(refundedAmount.getRefundId())
                .paymentMean(paymentMean)
                .operation(PaymentOperationType.REFUND)
                .operationDate(refundedAmount.getPendingRefundDate() != null ? Instant.ofEpochMilli(refundedAmount.getPendingRefundDate()) : null)
                .status(PaymentOperationStatus.ACCEPTED)
                .amount(refundedAmount.getBeneficiary().getLines().stream().map(BeneficiaryLine::getAmount).map(BigDecimal::valueOf).reduce(BigDecimal.ZERO, BigDecimal::add))
                .paymentOrderLines(refundedAmount.getBeneficiary().getLines().stream().map(beneficiaryLine -> PaymentOrderLine.builder().id(beneficiaryLine.getLineId()).type(mapLineType(beneficiaryLine.getType())).build()).toList())
                .paymentExternalData(mapExternalData(paymentUpdatedV2, paymentMean))
                .build())
            .toList();
    }

    private static List<PaymentOperation> mapCanceledPaymentOperation(PaymentUpdatedV2 paymentUpdatedV2) {
        String paymentMean = paymentUpdatedV2.getState().getInstrumentType();
        return Optional.ofNullable(paymentUpdatedV2.getState().getAmounts().getCancelledAmounts()).orElse(Collections.emptyList()).stream()
            .map(cancelledAmount -> PaymentOperation.builder()
                .id(UUID.randomUUID().toString())
                .customerOrderId(paymentUpdatedV2.getExternalReference().getId())
                .customerOrderVersion(paymentUpdatedV2.getExternalReference().getVersion())
                .transactionId(cancelledAmount.getCancelId())
                .paymentMean(paymentMean)
                .operation(PaymentOperationType.CANCEL_AUTHORIZATION)
                .operationDate(cancelledAmount.getPendingCancelDate() != null ? Instant.ofEpochMilli(cancelledAmount.getPendingCancelDate()) : null)
                .status(mapCancelledCashingStatus(cancelledAmount.getStatus()))
                .amount(cancelledAmount.getBeneficiary().getLines().stream().map(BeneficiaryLine::getAmount).map(BigDecimal::valueOf).reduce(BigDecimal.ZERO, BigDecimal::add))
                .paymentOrderLines(cancelledAmount.getBeneficiary().getLines().stream().map(beneficiaryLine -> PaymentOrderLine.builder().id(beneficiaryLine.getLineId()).type(mapLineType(beneficiaryLine.getType())).build()).toList())
                .paymentExternalData(mapExternalData(paymentUpdatedV2, paymentMean))
                .build())
            .toList();
    }

    private static PaymentLineType mapLineType(String lineType) {
        return switch (lineType) {
            case "OFFER" -> PaymentLineType.OFFER_LINE;
            case "DELIVERY" -> PaymentLineType.DELIVERY_LINE;
            case "SERVICE" -> PaymentLineType.SERVICE;
            default -> PaymentLineType.UNKNOWN;
        };
    }

    private static PaymentOperationStatus mapCancelledCashingStatus(String status) {
        CashingPaymentStatus cashingPaymentStatus = CashingPaymentStatus.fromString(status);
        return switch (cashingPaymentStatus) {
            case CANCEL_REQUESTED, CANCELLED -> PaymentOperationStatus.ACCEPTED;
            default -> PaymentOperationStatus.NOT_MANAGED;
        };
    }

    private static PaymentOperationStatus mapAuthorizedCashingStatus(CashingPaymentStatus status, CashingOriginType originType, String paymentMean) throws StateNotManagedException {
        if (PAYMENT_MEAN_MULTIBANCO.equals(paymentMean) && !HANDLED_STATUS_FOR_MULTIBANCO.contains(status)) {
            return PaymentOperationStatus.NOT_MANAGED;
        }

        if (CashingOriginType.SYNCHRONOUS == originType) {
            if (!List.of(PAYMENT_MEAN_BANK_TRANSFER_WEB, PAYMENT_MEAN_BIZUM).contains(paymentMean)) {
                return switch (status) {
                    case PENDING_AUTHORIZATION, PENDING_PSP_APPROVAL, PENDING_CAPTURE -> PaymentOperationStatus.PENDING;
                    default -> PaymentOperationStatus.NOT_MANAGED;
                };
            } else {
                if (status == CashingPaymentStatus.AUTHORIZATION_REQUESTED) {
                    return PaymentOperationStatus.PENDING;
                }
                return PaymentOperationStatus.NOT_MANAGED;
            }
        }
        return switch (status) {
            case PENDING_AUTHORIZATION, AUTHORIZATION_REQUESTED, PENDING_PSP_APPROVAL -> PaymentOperationStatus.PENDING;
            case PENDING_CAPTURE -> PaymentOperationStatus.ACCEPTED;
            case PAYMENT_FAILURE, CANCELLED, PAYMENT_ABORT, REJECTED -> PaymentOperationStatus.REJECTED;
            default -> PaymentOperationStatus.NOT_MANAGED;
        };
    }
}
