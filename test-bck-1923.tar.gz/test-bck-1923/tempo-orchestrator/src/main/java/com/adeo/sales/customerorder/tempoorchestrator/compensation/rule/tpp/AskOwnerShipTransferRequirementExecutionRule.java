package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.tpp;


import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExecutionWithLines;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.service.TppCommandEventService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECTABLE_DELIVERY_TYPE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CURRENT_TPP_VERSION_MISMATCH;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_REQUIREMENT_COMPLETED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_INCOTERM_DDP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_INCOTERM_EXW;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LOYALTY_FEE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OWNERSHIP_TRANSFER_HAS_NOT_BEEN_ASKED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OWNERSHIP_TRANSFER_REQUIREMENT_COMPLETED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OWNERSHIP_TRANSFER_REQUIREMENT_FAILED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OWNERSHIP_TRANSFER_REQUIREMENT_FAILED_CAN_BE_REPLAYED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OWNERSHIP_TRANSFER_REQUIREMENT_REJECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_PARTNER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_STORE_WITH_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_WAREHOUSE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPING_REQUIREMENT_COMPLETED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.NO_TPP_REQUIREMENT_IN_PROGRESS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_PROCESSING;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "AskOwnerShipTransferRequirementExecution",
    description = "Ask to TPP to execute the ownerShipTransfer requirement for 1P lines",
    priority = 1000)
public class AskOwnerShipTransferRequirementExecutionRule {

    private static final Predicate<LineExecution> IS_SHIPPING_OR_DELIVERY_REQUIREMENT_COMPLETED = IS_SHIPPING_REQUIREMENT_COMPLETED.or(IS_DELIVERY_REQUIREMENT_COMPLETED);
    private static final Predicate<LineExecution> IS_SFW_OR_SFS_WITH_REQUIREMENT_COMPLIANT = ((IS_SHIPPED_BY_WAREHOUSE).or(IS_SHIPPED_BY_STORE_WITH_TEMPO)).and(IS_SHIPPING_OR_DELIVERY_REQUIREMENT_COMPLETED);
    public static final Predicate<LineExecution> IS_SFP_WITH_REQUIREMENT_COMPLIANT_AND_RIGHT_INCOTERM = IS_SHIPPED_BY_PARTNER
        .and((IS_INCOTERM_EXW.and(IS_SHIPPING_OR_DELIVERY_REQUIREMENT_COMPLETED))
            .or(IS_DELIVERY_REQUIREMENT_COMPLETED.and(IS_INCOTERM_DDP)));
    private static final Predicate<LineExecution> IS_COLLECTABLE_WITH_DELIVERY_REQUIREMENT_COMPLIANT = IS_COLLECTABLE_DELIVERY_TYPE.and(IS_DELIVERY_REQUIREMENT_COMPLETED);
    private static final Predicate<LineExecution> IS_LOYALTY_FEE_OR_SERVICE_WITH_REQUIREMENTS_COMPLIANT = ((IS_LOYALTY_FEE.or(IS_LINE_SERVICE)).and(IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT));
    private static final Predicate<LineExecution> IS_OWNERSHIP_TRANSFER_REQUIREMENT_FAILED_AND_HAS_TO_BE_REPLAYED = IS_OWNERSHIP_TRANSFER_REQUIREMENT_FAILED_CAN_BE_REPLAYED.and(not(IS_CURRENT_TPP_VERSION_MISMATCH));

    private static final Predicate<LineExecution> LINE_SHOULD_DO_ASK_PAYMENT_REQUIREMENT_OWNERSHIP_TRANSFER =
        PAYMENT_ORCHESTRATED_BY_TPP
            .and(IS_EXTERNAL_SYSTEM_TEMPO)
            .and(IS_LINE_COMPOSITION_VALIDATED)
            .and(IS_OWNERSHIP_TRANSFER_HAS_NOT_BEEN_ASKED)
            .and(NO_TPP_REQUIREMENT_IN_PROGRESS)
            .and(not(IS_OWNERSHIP_TRANSFER_REQUIREMENT_COMPLETED))
            .and(IS_SFW_OR_SFS_WITH_REQUIREMENT_COMPLIANT
                .or(IS_SFP_WITH_REQUIREMENT_COMPLIANT_AND_RIGHT_INCOTERM)
                .or(IS_COLLECTABLE_WITH_DELIVERY_REQUIREMENT_COMPLIANT)
                .or(IS_LOYALTY_FEE_OR_SERVICE_WITH_REQUIREMENTS_COMPLIANT))
            .and(not(IS_OWNERSHIP_TRANSFER_REQUIREMENT_COMPLETED
                .or(IS_OWNERSHIP_TRANSFER_REQUIREMENT_REJECTED)
                .or(IS_OWNERSHIP_TRANSFER_REQUIREMENT_FAILED))
                .or(IS_OWNERSHIP_TRANSFER_REQUIREMENT_FAILED_AND_HAS_TO_BE_REPLAYED));

    public static final Predicate<ExecutionWithLines> IS_LINE_SHOULD_ASK_OWNERSHIP_TRANSFER_REQUIREMENT =
        lineExecutionByIdExecution -> lineExecutionByIdExecution
            .getLineExecutions()
            .stream()
            .allMatch(LINE_SHOULD_DO_ASK_PAYMENT_REQUIREMENT_OWNERSHIP_TRANSFER);


    private final TppCommandEventService tppCommandEventService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        if (!context.hasAtLeastOneExecutionAction(IS_EXECUTION_ACTION_PROCESSING)) {
            return context.getOrderData().getExistingExecutionsWithLines()
                .stream()
                .anyMatch(IS_LINE_SHOULD_ASK_OWNERSHIP_TRANSFER_REQUIREMENT);
        }
        return false;
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        List<ExecutionWithLines> executionsWithLines = context.getOrderData()
            .getExistingExecutionsWithLines()
            .stream()
            .filter(IS_LINE_SHOULD_ASK_OWNERSHIP_TRANSFER_REQUIREMENT)
            .toList();

        return Flux.fromIterable(executionsWithLines)
            .flatMap(executionWithLine -> {
                final Instant statusDate = Instant.now();
                return this.tppCommandEventService.sendActionTypeRequirement(context.getOrderData().getExistingCustomerOrder(), executionWithLine.getExecutionId(), executionWithLine.getLineExecutions(), statusDate, ActionType.OWNERSHIP_TRANSFER)
                    .doOnNext(operationId -> executionWithLine.getLineExecutions().forEach(line -> line.getPaymentRequirements().getOwnerShippedTransfertFlags().raiseFlagIfNot(operationId, RequirementStatus.REQUESTED, statusDate.atOffset(ZoneOffset.UTC))));
            })
            .then();
    }
}
