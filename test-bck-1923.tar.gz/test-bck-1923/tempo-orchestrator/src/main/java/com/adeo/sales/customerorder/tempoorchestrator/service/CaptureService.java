package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import reactor.core.publisher.Mono;

import java.util.List;

public interface CaptureService {
    Mono<Void> sendCommandCaptureOnDeposit(CustomerOrder customerOrder, List<LineExecution> lines);

    Mono<Void> sendCommandCaptureCustomerOrderLines(CustomerOrder customerOrder, List<LineExecution> customerOrderLines);

    Mono<Void> sendCommandCancelCaptureOnDeposit(CustomerOrder updatedCustomerOrder, List<LineExecution> linesLDDOrLEDToCancelCapture);

    Mono<Void> sendCommandCancelCapture(CustomerOrder updatedCustomerOrder, List<LineExecution> thirdPartyLinesToCancelCapture);
}
