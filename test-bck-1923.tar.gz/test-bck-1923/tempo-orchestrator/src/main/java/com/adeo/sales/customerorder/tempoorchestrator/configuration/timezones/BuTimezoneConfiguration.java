package com.adeo.sales.customerorder.tempoorchestrator.configuration.timezones;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BuTimezoneConfiguration {
    private String defaultTimeZone;
    private Map<String, String> specificStoresTimezones = new HashMap<>();
}
