package com.adeo.sales.customerorder.tempoorchestrator.service.alertconverter;

import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.RejectedPaymentSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertToTempoAlertingSpecificDataConverter;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.AlertType;
import org.springframework.stereotype.Component;

@Component
public class RejectedPaymentSpecificDataConverter implements AlertToTempoAlertingSpecificDataConverter<RejectedPaymentSpecificData> {

    @Override
    public AlertType getAlertType() {
        return AlertType.TRANSACTION;
    }

    @Override
    public boolean manageType(Class<? extends AlertSpecificData> aClass) {
        return RejectedPaymentSpecificData.class == aClass;
    }
}
