package com.adeo.sales.customerorder.tempoorchestrator.handler.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.PaymentAdjustmentActionExecutionResponseApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentAdjustmentActionExecutionResponseInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppAllowedStatus;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.tpp.avro.command.PaymentAdjustmentActionExecutionResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppAllowedStatus.FAILED;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppAllowedStatus.REJECTED;


@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentAdjustmentActionExecutionResponseHandler implements EventHandler<PaymentAdjustmentActionExecutionResponse> {

    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final PaymentAdjustmentActionExecutionResponseApplicationService applicationService;

    @Override
    public Mono<Void> handle(PaymentAdjustmentActionExecutionResponse event, EventMetaData eventMetaData) {
        String customerOrderID = event.getCustomerOrderId();
        String buCode = event.getBuId();

        this.mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderID, buCode);

        String status = event.getStatus();
        final TppAllowedStatus tppStatus;
        try {
            tppStatus = TppAllowedStatus.valueOf(status);
        } catch (IllegalArgumentException illegalArgumentException) {
            log.error("PaymentAdjustmentActionExecutionResponse consumes {} - message id: {} - the status {} is not handled by TOR, the message is ignored.", eventMetaData.getTopic(), eventMetaData.getId().orElse("no id"), status);
            return Mono.empty();
        }

        String tppErrorType = this.getTppErrorType(event, tppStatus);

        return Mono.just(event)
            .flatMap(paymentAdjustmentActionExecutionResponse -> this.applicationService.apply(PaymentAdjustmentActionExecutionResponseInput.builder()
                .buCode(event.getBuId())
                .customerOrderId(paymentAdjustmentActionExecutionResponse.getCustomerOrderId())
                .tppVersion(paymentAdjustmentActionExecutionResponse.getPaymentAdjustmentActionExecutionCreationRequest().getCustomerOrderPaymentExecutionPolicyVersion())
                .status(paymentAdjustmentActionExecutionResponse.getStatus())
                .tppErrorType(tppErrorType)
                .paymentAdjustmentActionIds(paymentAdjustmentActionExecutionResponse.getPaymentAdjustmentActionExecutionCreationRequest().getPaymentAdjustmentActionId())
                .rejectedAmount(paymentAdjustmentActionExecutionResponse.getRejectedAmount())
                .build()))
            .then();
    }

    private String getTppErrorType(PaymentAdjustmentActionExecutionResponse event, TppAllowedStatus tppStatus) {
        String tppErrorType = null;
        if (FAILED.equals(tppStatus) && event.getFailedReason() != null) {
            tppErrorType = event.getFailedReason().getValue();
        } else if (REJECTED.equals(tppStatus) && event.getRejectedReason() != null) {
            tppErrorType = event.getRejectedReason().getValue();
        }

        if (tppErrorType != null) {
            log.error("Received an adjustment action execution response with {} error", tppErrorType);
        }

        return tppErrorType;
    }

    @Override
    public Class<?> getManagedEvent() {
        return PaymentAdjustmentActionExecutionResponse.class;
    }
}
