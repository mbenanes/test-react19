package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.backo;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.backo.input.StockValorizedInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CustomerOrderLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderLineRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LineExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple5;
import reactor.util.function.Tuples;

import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.StockValuationStatus.STOCK_VALUATION_FAILED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.StockValuationStatus.STOCK_VALUATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.StockValuationStatus.STOCK_VALUATION_SUCCEED;
import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@RequiredArgsConstructor
@Component
@Slf4j
public class StockValorizedApplicationService {
    private final RuleEngineService ruleEngineService;
    private final LineExecutionRepository lineExecutionRepository;
    private final CustomerOrderLineRepository customerOrderLineRepository;

    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    public Mono<Void> apply(StockValorizedInput stockValorizedInput) {
        return retrieveCustomerOrderId(stockValorizedInput)
            .flatMap(orderId -> processValuationResponse(stockValorizedInput, orderId))
            .onErrorResume(CustomerOrderNotFound.class, error -> {
                log.error("Customer order not found: {}", error.getMessage());
                return Mono.empty();
            });
    }

    private Mono<Void> processValuationResponse(StockValorizedInput input, String orderId) {
        return ruleEngineService.lockAndGetData(orderId, input.getBuCode())
            .flatMap(function(this::updateRefLmIfNecessary))
            .doOnNext(consumer((customerOrder, lineExecutions) -> updateStockValorizedLines(lineExecutions, input)))
            .flatMap(function(ruleEngineService::startRuleEngineAndUpdateLines));
    }

    private Mono<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> updateRefLmIfNecessary(CustomerOrder customerOrder, List<LineExecution> lineExecutions, List<Alert> alerts, List<ExecutionAction> executionActions, List<Execution> executions) {
        if (lineExecutions.stream().anyMatch(line -> line.getComposition().getOffer().getRefLM() == null)) {
            return customerOrderLineRepository.getByCustomerOrderId(customerOrder.getId())
                .doOnNext(customerOrderLine -> updateMissingRefLm(lineExecutions, customerOrderLine))
                .then()
                .thenReturn(Tuples.of(customerOrder, lineExecutions, alerts, executionActions, executions));
        }
        return Mono.just(Tuples.of(customerOrder, lineExecutions, alerts, executionActions, executions));
    }

    private void updateMissingRefLm(List<LineExecution> lineExecutions, CustomerOrderLine customerOrderLine) {
        lineExecutions.stream()
            .filter(line -> line.getLineId().equals(customerOrderLine.getId()))
            .forEach(line -> line.getComposition().getOffer().setRefLM(customerOrderLine.getOffer().getRefLM()));
    }

    private Mono<String> retrieveCustomerOrderId(StockValorizedInput stockValorizedInput) {
        return lineExecutionRepository.getByDeliveryLegacyNumber(stockValorizedInput.getDeliveryLegacyNumber(), stockValorizedInput.getBuCode(), stockValorizedInput.getStoreCode())
            .filter(this::isStockValuationPending)
            .switchIfEmpty(MonoUtil.warnLog("No eligible customer order found for legacyNumber {} buCode {} storeCode {} : " + stockValorizedInput.getDeliveryLegacyNumber(), stockValorizedInput.getBuCode(), stockValorizedInput.getStoreCode()))
            .distinct(LineExecution::getCustomerOrderId)
            .collectList()
            .map(this::validateSingleCustomerOrder)
            .map(lineExecutions -> lineExecutions.get(0).getCustomerOrderId())
            .doOnNext(orderId -> log.info("Found customer order id {} for delivery legacy number {}", orderId, stockValorizedInput.getDeliveryLegacyNumber()));
    }

    private boolean isStockValuationPending(LineExecution line) {
        return line.getDelivery() != null &&
            line.getDelivery().getStockValuationStatus() != null &&
            !STOCK_VALUATION_SUCCEED.equals(line.getDelivery().getStockValuationStatus());
    }

    private List<LineExecution> validateSingleCustomerOrder(List<LineExecution> orderIds) {
        if (orderIds.size() != 1) {
            throw new CustomerOrderNotFound("Expected a single customer order, found: " + orderIds.size());
        }
        return orderIds;
    }

    private void updateStockValorizedLines(List<LineExecution> lineExecutions, StockValorizedInput input) {
        lineExecutions.stream()
            .filter(line -> isEligibleForUpdate(line, input))
            .forEach(line -> updateLineStatus(line, input.isSucceed()));
    }

    private boolean isEligibleForUpdate(LineExecution line, StockValorizedInput input) {
        return input.getDeliveryLegacyNumber().equals(line.getDelivery().getDeliveryLegacyNumber()) &&
            input.getProductReferences().contains(line.getComposition().getOffer().getRefLM()) &&
            (STOCK_VALUATION_REQUESTED == line.getDelivery().getStockValuationStatus() ||
                STOCK_VALUATION_FAILED == line.getDelivery().getStockValuationStatus());
    }

    private void updateLineStatus(LineExecution line, boolean isSucceed) {
        if (isSucceed) {
            line.getDelivery().setStockValuationStatus(STOCK_VALUATION_SUCCEED);
        } else {
            log.warn("Stock valuation failed for line {}", line.getLineId());
            line.getDelivery().setStockValuationStatus(STOCK_VALUATION_FAILED);
        }
    }
}
