package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

import java.util.List;

@Builder
@Getter
public class PaymentExecutionPolicyValidatedInput {

    private String customerOrderId;
    private Integer tppVersion;
    private String buCode;
    private List<Line> lines;

    @Builder
    @Data
    public static class Line {
        private String id;
        private String paymentAdjustmentActionId;
    }
}
