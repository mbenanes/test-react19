package com.adeo.sales.customerorder.tempoorchestrator.service.impl;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.service.CustomerOrderCollectService;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.UpdateLineQuantityCollectDto;
import com.adeo.tempocollect.avro.model.BusinessUnit;
import com.adeo.tempocollect.avro.model.CustomerOrderCollect;
import com.adeo.tempocollect.avro.model.CustomerOrderCollectItem;
import com.adeo.tempocollect.avro.model.CustomerOrderCollectLocation;
import com.adeo.tempocollect.avro.request.CustomerOrderCollectAppointmentCancellation;
import com.adeo.tempocollect.avro.request.CustomerOrderCollectCancellation;
import com.adeo.tempocollect.avro.request.CustomerOrderCollectQuantityUpdateRequested;
import com.adeo.tempocollect.avro.request.CustomerOrderCollectRequested;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.math.RoundingMode;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class CustomerOrderCollectServiceImpl implements CustomerOrderCollectService {
    private final EventProducer eventProducer;
    private final TopicsProperties properties;

    @Override
    public Mono<CustomerOrderCollectRequested> createCustomerOrderCollect(List<LineExecution> linesToCreate, CustomerOrder customerOrder) {
        if (linesToCreate.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask collect creation for following lines: {}", LineExecution.joinLineIds(linesToCreate));

        final var createCustomerOrderCollect = this.buildCustomerOrderCollectRequest(linesToCreate, customerOrder);

        return this.eventProducer.sendEvents(this.properties.getCustomerOrderCollectRequest(), customerOrder.getId(), customerOrder.getBuCode(), createCustomerOrderCollect)
            .thenReturn(createCustomerOrderCollect);
    }

    @Override
    public Mono<CustomerOrderCollectCancellation> cancelCustomerOrderCollect(List<LineExecution> linesToCancel, CustomerOrder customerOrder) {
        if (linesToCancel.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask collect cancellation for following lines: {}", LineExecution.joinLineIds(linesToCancel));

        final var cancelCustomerOrderCollect = this.buildCustomerOrderCancelRequest(linesToCancel, customerOrder);

        return this.eventProducer.sendEvents(this.properties.getCustomerOrderCollectCancellation(), customerOrder.getId(), customerOrder.getBuCode(), cancelCustomerOrderCollect)
            .thenReturn(cancelCustomerOrderCollect);
    }

    @Override
    public Mono<Void> cancelCollectAppointment(String collectId, String customerOrderId, String buCode, String storeId) {
        final CustomerOrderCollectAppointmentCancellation customerOrderCollectAppointmentCancellation = CustomerOrderCollectAppointmentCancellation.newBuilder()
            .setCustomerOrderCollect(CustomerOrderCollect.newBuilder()
                .setBusinessUnit(BusinessUnit.newBuilder()
                    .setBuID(buCode)
                    .build())
                .setLocation(CustomerOrderCollectLocation.newBuilder()
                    .setIdentifier(storeId)
                    .setType("STORE")
                    .build())
                .setCustomerOrderCollectItems(List.of())
                .setIdentifier(collectId).build())
            .build();

        log.info("INTERNAL ask collect cancellation appointment following collect: {} ", collectId);
        return this.eventProducer.sendEvents(this.properties.getCustomerOrderCollectCancellation(), customerOrderId, buCode, customerOrderCollectAppointmentCancellation);
    }

    @Override
    public Mono<CustomerOrderCollectQuantityUpdateRequested> updateCustomerOrderCollect(List<UpdateLineQuantityCollectDto> linesToUpdateQuantities, CustomerOrder existingCustomerOrder) {
        if (linesToUpdateQuantities.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask collect quantity update for following lines: {}", UpdateLineQuantityCollectDto.joinLineIds(linesToUpdateQuantities));

        final var cancelCustomerOrderCollect = this.buildCustomerOrderCollectQuantityUpdateRequested(linesToUpdateQuantities, existingCustomerOrder);

        return this.eventProducer.sendEvents(this.properties.getCustomerOrderCollectQuantityUpdate(), existingCustomerOrder.getId(), existingCustomerOrder.getBuCode(), cancelCustomerOrderCollect)
            .thenReturn(cancelCustomerOrderCollect);
    }

    private CustomerOrderCollectRequested buildCustomerOrderCollectRequest(List<LineExecution> linesToCreate, CustomerOrder existingCustomerOrder) {
        return CustomerOrderCollectRequested.newBuilder()
            .setRequestSourceID(UUID.randomUUID().toString())
            .setCustomerOrderCollect(this.buildCollect(linesToCreate, existingCustomerOrder))
            .build();
    }

    private CustomerOrderCollectCancellation buildCustomerOrderCancelRequest(List<LineExecution> linesToCreate, CustomerOrder existingCustomerOrder) {
        return CustomerOrderCollectCancellation.newBuilder()
            .setCustomerOrderCollect(this.buildCollectCancel(linesToCreate, existingCustomerOrder))
            .build();
    }

    private CustomerOrderCollect buildCollectCancel(List<LineExecution> linesToCreate, CustomerOrder existingCustomerOrder) {
        LineExecution firstLineExecution = linesToCreate.get(0);

        return CustomerOrderCollect.newBuilder()
            .setBusinessUnit(BusinessUnit.newBuilder()
                .setBuID(existingCustomerOrder.getBuCode())
                .build())
            .setCustomerOrderCollectItems(linesToCreate.stream()
                .map(lineExecution -> CustomerOrderCollectItem.newBuilder()
                    .setIdentifier(lineExecution.getDelivery().getCollect().getCollectLineIdentifier())
                    .setStatus(CollectStatus.CANCELLED.name())
                    .setCustomerOrderIdentifier(lineExecution.getCustomerOrderId())
                    .setCustomerOrderCartItemIdentifier(lineExecution.getLineId())
                    .setQuantityToBeCollected(lineExecution.getQuantity().setScale(5, RoundingMode.FLOOR))
                    .setCancellationReason("ORDER_CANCELLATION")
                    .build()
                )
                .collect(Collectors.toList())
            )
            .setIdentifier(firstLineExecution.getDelivery().getCollect().getFlags().getLastFlag().getOperationId())
            .setLocation(CustomerOrderCollectLocation.newBuilder()
                .setIdentifier(firstLineExecution.getPayment().getStoreId())
                .setType("STORE")
                .build())
            .build();
    }

    private CustomerOrderCollect buildCollectUpdate(List<UpdateLineQuantityCollectDto> linesToUpdate, CustomerOrder existingCustomerOrder) {

        final var firstLine = linesToUpdate.get(0);

        return CustomerOrderCollect.newBuilder()
            .setBusinessUnit(BusinessUnit.newBuilder()
                .setBuID(existingCustomerOrder.getBuCode())
                .build())
            .setCustomerOrderCollectItems(linesToUpdate.stream()
                .map(line -> CustomerOrderCollectItem.newBuilder()
                    .setIdentifier(line.getCollectLineIdentifier())
                    .setCustomerOrderIdentifier(existingCustomerOrder.getId())
                    .setCustomerOrderCartItemIdentifier(line.getLineId())
                    .setQuantityToBeCollected(line.getQuantity().setScale(5, RoundingMode.FLOOR))
                    .setCancellationReason(line.getReason() != null ? line.getReason() : "CANCELLATION")
                    .build()
                )
                .collect(Collectors.toList())
            )
            .setIdentifier(firstLine.getCollectIdentifier())
            .setLocation(CustomerOrderCollectLocation.newBuilder()
                .setIdentifier(firstLine.getStoreId())
                .setType("STORE")
                .build())
            .build();
    }

    private CustomerOrderCollectQuantityUpdateRequested buildCustomerOrderCollectQuantityUpdateRequested(List<UpdateLineQuantityCollectDto> linesToUpdateQuantity, CustomerOrder existingCustomerOrder) {
        return CustomerOrderCollectQuantityUpdateRequested.newBuilder()
            .setRequestSourceID(UUID.randomUUID().toString())
            .setCustomerOrderCollect(this.buildCollectUpdate(linesToUpdateQuantity, existingCustomerOrder))
            .build();
    }

    private CustomerOrderCollect buildCollect(List<LineExecution> linesToCreate, CustomerOrder existingCustomerOrder) {

        return CustomerOrderCollect.newBuilder()
            .setAppointmentRequestedDate(linesToCreate.stream()
                .findFirst()
                .map(line -> line.getDelivery().getAppointmentDate())
                .filter(appointmendDate -> appointmendDate.isAfter(OffsetDateTime.now()))
                .map(date -> date.toInstant().toEpochMilli())
                .orElse(null)
            )
            .setBusinessUnit(BusinessUnit.newBuilder()
                .setBuID(existingCustomerOrder.getBuCode())
                .build())
            .setCustomerOrderCollectItems(linesToCreate.stream()
                .map(lineExecution -> CustomerOrderCollectItem.newBuilder()
                    .setClientNumber(existingCustomerOrder.getCustomer().getId())
                    .setCustomerOrderIdentifier(lineExecution.getCustomerOrderId())
                    .setCustomerOrderCartItemIdentifier(lineExecution.getLineId())
                    .setQuantityToBeCollected(lineExecution.getQuantity().setScale(5, RoundingMode.FLOOR))
                    .build()
                )
                .collect(Collectors.toList())
            )
            .setLocation(CustomerOrderCollectLocation.newBuilder()
                .setIdentifier(linesToCreate.get(0).getPayment().getStoreId())
                .setType("STORE")
                .build())
            .build();
    }

}
