package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl;

import com.adeo.sales.customerorder.external.api.client.dst.DeliverySimulationTowerApiClient;
import com.adeo.sales.customerorder.external.api.client.dst.dto.Delivery;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliverySimulation;
import com.adeo.sales.customerorder.external.api.client.dst.dto.FixedDeliveryDate;
import com.adeo.sales.customerorder.external.api.client.dst.dto.OfferCartItem;
import com.adeo.sales.customerorder.external.api.client.dst.dto.RangeDeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.DeliveryVersionsInconsistent;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.LineInvalidDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.ShippingPoint;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Slf4j
@Component
@Primary
public class DeliveryInformationGetterImpl implements DeliveryInformationGetter {
    private final DeliverySimulationTowerApiClient deliverySimulationTowerApiClient;


    @Override
    public Mono<DeliveryInformationBody> retrieve(List<String> customerOrderLinesId,
                                                  String buCode,
                                                  String deliveryId,
                                                  Integer deliveryVersion,
                                                  boolean checkVersion) {
        return this.deliverySimulationTowerApiClient.getDeliveries(deliveryId, buCode)
            .map(result -> stopIfDeliveryVersionIsInconsistent(result, deliveryVersion, checkVersion))
            .map(result -> mapResult(result, customerOrderLinesId));
    }

    private DeliveryInformationBody mapResult(DeliverySimulation result, List<String> customerOrderLinesId) {
        return DeliveryInformationBody.builder()
            .version(result.getVersion())
            .code(result.getCode())
            .deliveryInformationList(result.getDeliveries().stream().flatMap(delivery -> {
                final var linesAssociatedToDelivery = this.extractLineIdsAssociatedToDelivery(delivery);
                final var deliveryDate = this.extractDeliveryDate(delivery);
                return customerOrderLinesId.stream()
                    .filter(linesAssociatedToDelivery::contains)
                    .map(lineId -> this.buildDeliveryInformation(lineId, deliveryDate, delivery))
                    .map(this::checkDeliveryIsIncomplete);
            }).toList())
            .build();
    }

    @Override
    public Mono<Void> applyValidateDate(String customerOrderId, String buCode) {
        return deliverySimulationTowerApiClient.validateDate(customerOrderId, buCode).then();
    }

    private DeliveryInformation buildDeliveryInformation(String lineId, DeliveryDate deliveryDate, Delivery delivery) {
        return DeliveryInformation.builder()
            .deliveryDate(deliveryDate)
            .promisedDateConfirmed(mapPromisedDateConfirmed(delivery, lineId))
            .deliveryType(DeliveryType.mapFromDst(delivery.getDeliveryType()))
            .shippingPoint(ShippingPoint.mapFromDst(delivery.getServiceLevel().getDetails()))
            .lineId(lineId)
            .serviceLevel(delivery.getServiceLevel().getType())
            .idDelivery(delivery.getServiceLevel().getCode())
            .appointmentDate(delivery.getServiceLevel().getAppointmentDate())
            .deliveryMode(delivery.getDeliveryMode().name())
            .build();
    }

    private boolean mapPromisedDateConfirmed(Delivery delivery, String lineId) {
        final var deliveryDateStatus = delivery.getOfferCartItems().stream()
            .filter(offerCartItem -> offerCartItem.getId().equals(lineId))
            .filter(offerCartItem -> offerCartItem.getDeliveryDateStatus() != null)
            .findFirst()
            .map(OfferCartItem::getDeliveryDateStatus);
        return deliveryDateStatus.isEmpty() || "CONFIRMED".equals(deliveryDateStatus.get());
    }

    private DeliverySimulation stopIfDeliveryVersionIsInconsistent(DeliverySimulation simulation, Integer deliveryVersion, boolean checkVersion) {
        if (!simulation.getVersion().equals(deliveryVersion) && checkVersion) {
            throw new DeliveryVersionsInconsistent(deliveryVersion, simulation.getVersion(), simulation.getCode());
        }
        return simulation;
    }

    private List<String> extractLineIdsAssociatedToDelivery(Delivery delivery) {
        return delivery.getOfferCartItems().stream()
            .map(OfferCartItem::getId).collect(Collectors.toList());
    }

    private DeliveryDate extractDeliveryDate(Delivery delivery) {
        if (delivery.getServiceLevel() == null) {
            return null;
        }

        final var deliveryDate = delivery.getServiceLevel().getDeliveryDate();
        if (deliveryDate instanceof RangeDeliveryDate) {
            final var castDeliveryDate = ((RangeDeliveryDate) deliveryDate);
            return new com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.RangeDeliveryDate(
                castDeliveryDate.getStartDate(),
                castDeliveryDate.getEndDate()
            );
        } else if (deliveryDate instanceof FixedDeliveryDate) {
            final var castDeliveryDate = ((FixedDeliveryDate) deliveryDate);
            return new com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.FixedDeliveryDate(
                castDeliveryDate.getFixedDate()
            );
        }

        return null;
    }

    private Mono<DeliveryInformation> stopIfDeliveryIsIncomplete(DeliveryInformation information) {
        if (information.getDeliveryType() == null) {
            log.warn("the customer order lines {} has no delivery type - do nothing", information.getLineId());
            return Mono.error(new LineInvalidDelivery(information.getLineId(), "delivery type empty"));
        }

        if (information.getDeliveryType() == DeliveryType.UNKNOWN) {
            log.warn("the customer order lines {} has a type not managed by tor - do nothing", information.getLineId());
            return Mono.error(new LineInvalidDelivery(information.getLineId(), "delivery type unknown"));
        }

        if (
            information.getDeliveryDate() == null &&
                information.getDeliveryType() != DeliveryType.BACKSTORE_WITHDRAWAL &&
                information.getDeliveryType() != DeliveryType.STORE_SELF_SERVICE
        ) {
            log.warn("the customer order line {} has no delivery date - can cause issue later on order execution", information.getLineId());
        }

        return Mono.just(information);
    }

    private DeliveryInformation checkDeliveryIsIncomplete(DeliveryInformation information) {
        if (information.getDeliveryType() == null) {
            log.warn("the customer order lines {} has no delivery type - do nothing", information.getLineId());
            throw new LineInvalidDelivery(information.getLineId(), "delivery type empty");
        }

        if (information.getDeliveryType() == DeliveryType.UNKNOWN) {
            log.warn("the customer order lines {} has a type not managed by tor - do nothing", information.getLineId());
            throw new LineInvalidDelivery(information.getLineId(), "delivery type unknown");
        }

        if (
            information.getDeliveryDate() == null &&
                information.getDeliveryType() != DeliveryType.BACKSTORE_WITHDRAWAL &&
                information.getDeliveryType() != DeliveryType.STORE_SELF_SERVICE
        ) {
            log.warn("the customer order line {} has no delivery date - can cause issue later on order execution", information.getLineId());
        }

        return information;
    }
}
