package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

public interface CustomerOrderService {
    String POSTPONE_CANCELLATION_FUNCTIONAL_TYPE = "CancelOrder";
    String POSTPONE_SELF_SERVICE_CANCELLATION_FUNCTIONAL_TYPE = "CancelSelfService";

    Mono<Void> sendCancelCustomerOrderLines(CustomerOrder customerOrder, List<LineExecution> lines, String cancelationReason);

    Mono<Void> sendDecreaseQuantity(String customerOrderId, String buCode, Map<String, List<LineExecution>> lineExecutionsById, ExecutionAction executionActions);

    Mono<Void> postponeCancelCustomerOrderLines(CustomerOrder customerOrder, List<LineExecution> lines, String cancelationReason);

}
