package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.service.TppCommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CURRENT_TPP_VERSION_MISMATCH;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_DECREASE_QUANTITY_ACTION_PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTE_ADJUSTMENT_TPP_IS_THE_NEXT_STEP;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "AskPaymentAdjustmentActionExecution",
    description = "Ask to TPP to execute the payment adjustments for 1P lines",
    priority = 900)
public class AskPaymentAdjustmentActionExecutionRule {

    private final TppCommandEventService tppCommandEventService;

    public static final Predicate<ExecutionAction> IS_EXECUTION_ACTION_DECREASE_QUANTITY_PROCESSING_STEP_CALL_ADJUSTMENT = IS_DECREASE_QUANTITY_ACTION_PROCESSING
        .and(IS_EXECUTE_ADJUSTMENT_TPP_IS_THE_NEXT_STEP);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneExecutionAction(IS_EXECUTION_ACTION_DECREASE_QUANTITY_PROCESSING_STEP_CALL_ADJUSTMENT) && context.allLinesMatchs(not(IS_CURRENT_TPP_VERSION_MISMATCH));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return Mono.justOrEmpty(context.getFirstExecutionActionByPredicate(IS_EXECUTION_ACTION_DECREASE_QUANTITY_PROCESSING_STEP_CALL_ADJUSTMENT))
            .flatMap(actionToExecute -> this.processAction(context, actionToExecute).then())
            .then();
    }

    private Mono<Void> processAction(RuleEngineContext context, ExecutionAction actionToExecute) {
        return Flux.fromIterable(actionToExecute.getImpactedExecutions())
            .filter(impactedExecution -> impactedExecution.isNextStepTypeIs(ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP))
            .flatMap(impactedExecution -> {
                List<ImpactedLine> impactedLines = impactedExecution.getImpactedLines()
                    .stream()
                    .filter(impactedLine -> impactedLine.isNextStepIsOfType(ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP))
                    .toList();

                List<ImpactedLine> impactedLinesWithAdjustmentsToExecute = impactedLines
                    .stream()
                    .filter(impactedLine -> StringUtils.isNotEmpty(impactedLine.getPaymentAdjustmentActionId()))
                    .toList();

                List<ImpactedLine> impactedLinesWithoutAdjustments = impactedLines
                    .stream()
                    .filter(impactedLine -> StringUtils.isEmpty(impactedLine.getPaymentAdjustmentActionId()))
                    .toList();

                impactedLinesWithoutAdjustments
                    .forEach(impactedLine -> impactedLine.getNextStep().ifPresent(step -> step.getFlags().raiseFlag(ImpactedLineStep.Status.COMPLETED)));

                return MonoUtil.infoLog("Ask to execute adjustments for execution id {} and lines : {}", impactedExecution.getCurrentExecutionId(), ImpactedLine.joinLineIds(impactedLinesWithAdjustmentsToExecute))
                    .then(this.tppCommandEventService.sendPaymentAdjustmentActionExecutionCreationRequest(context.getOrderData().getExistingCustomerOrder(), impactedLinesWithAdjustmentsToExecute)
                        .doOnNext(operationId -> impactedLinesWithAdjustmentsToExecute
                            .forEach(impactedLine -> impactedLine.getNextStep().ifPresent(step -> step.getFlags().raiseFlag(ImpactedLineStep.Status.PROCESSING)))));
            }).then();
    }
}
