package com.adeo.sales.customerorder.tempoorchestrator.handler.dor;

import com.adeo.featuretoggle.FeatureRepository;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.DeliveryStepUpdatedApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.DeliveryStepUpdatedInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.DORStatus;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.FixedDeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.RangeDeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.ShippingPoint;
import com.adeo.sales.postpone.utils.MonoLog;
import com.adeo.sis.orchestrator.data.state.common.v2.FulfillmentMapExecutionAvro;
import com.adeo.sis.orchestrator.data.state.common.v2.FulfillmentMapExecutionLogisticStepAvro;
import com.adeo.sis.orchestrator.event.common.FulfillmentMapExecutionEventAvro;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.time.ZoneOffset;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.adeo.sales.customerorder.tempoorchestrator.configuration.FeatureToggleConfiguration.MAP_ESTIMATED_DELIVERY_DATE_FROM_FFME;
import static com.adeo.sales.customerorder.tempoorchestrator.handler.dor.DorMessageReader.getCustomerOrderId;
import static com.adeo.sales.customerorder.tempoorchestrator.handler.dor.DorMessageReader.getReferenceValue;

@Slf4j
@Component
@RequiredArgsConstructor
public class FulfillmentMapExecutionEventAvroHandler implements EventHandler<FulfillmentMapExecutionEventAvro> {
    private static final List<String> IGNORED_STATUS = List.of("ERROR");
    private static String LMES_BU_CODE = "002";
    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final DeliveryStepUpdatedApplicationService deliveryStepUpdatedApplicationService;
    private final FeatureRepository featureRepository;

    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    @Override
    public Mono<Void> handle(FulfillmentMapExecutionEventAvro event, EventMetaData metaData) {
        final var customerOrderId = getCustomerOrderId(event);
        this.mappedDiagnosticContext.injectEventMinimalBUData(metaData, customerOrderId, event.getBuCode());
        log.info("FulfillmentMapExecutionAvro consumes {} - message id: {}", metaData.getTopic(), metaData.getId().orElse("no id"));

        if(LMES_BU_CODE.equals(event.getBuCode())) {
            this.stopIfMessageContainsSameLineMultipleTimes(event);
            this.stopIfMessageContainsMultipleCustomerOrder(event);

            return this.updateLineDeliveryInformation(event, customerOrderId);
        } else {
            return MonoLog.info("INTERNAL: Received FFME for BU {}", event.getBuCode());
        }
    }

    private Mono<Void> updateLineDeliveryInformation(FulfillmentMapExecutionEventAvro event, String customerOrderId) {
        return this.featureRepository.getFeature(MAP_ESTIMATED_DELIVERY_DATE_FROM_FFME).isEnabled()
            .flatMap(isEstimatedDeliveryDateMappedFromFFME -> {
                final var lines = this.buildDeliveryLinesUpdateInputLines(event, isEstimatedDeliveryDateMappedFromFFME);

                if (!lines.isEmpty()) {
                    final var input = DeliveryStepUpdatedInput.builder()
                        .buCode(event.getBuCode())
                        .customerOrderId(customerOrderId)
                        .lines(lines)
                        .build();

                    return this.deliveryStepUpdatedApplicationService.apply(input);
                }
                return Mono.empty();
            });
    }

    private List<DeliveryStepUpdatedInput.Line> buildDeliveryLinesUpdateInputLines(FulfillmentMapExecutionEventAvro event, Boolean isEstimatedDeliveryDateMappedFromFFME) {
        return event.getFulfillmentMapExecutions().stream()
            .flatMap(ffme -> this.buildDeliveryLinesUpdateInputLine(ffme, isEstimatedDeliveryDateMappedFromFFME))
            .collect(Collectors.toList());
    }

    private void stopIfMessageContainsMultipleCustomerOrder(FulfillmentMapExecutionEventAvro event) {
        final var numberOfCustomerOrder = event.getFulfillmentMapExecutions().stream()
            .map(FulfillmentMapExecutionAvro::getOrderId)
            .distinct()
            .count();

        if (numberOfCustomerOrder > 1) {
            throw new IllegalArgumentException("the event FulfillmentMapExecutionEventAvro contains two customer order");
        }
    }
    private void stopIfMessageContainsSameLineMultipleTimes(FulfillmentMapExecutionEventAvro event) {
        final var lineIds = event.getFulfillmentMapExecutions().stream()
            .flatMap(execution -> execution.getLogisticSteps().stream())
            .map(FulfillmentMapExecutionLogisticStepAvro::getOrderLineId)
            .collect(Collectors.toList());

        final var distinctLineNumber = lineIds.stream().distinct().count();

        if (lineIds.size() != distinctLineNumber) {
            final var lineIdsDuplicated = lineIds.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet().stream()
                .filter(stringLongEntry -> stringLongEntry.getValue() > 1)
                .map(stringLongEntry -> stringLongEntry.getKey())
                .collect(Collectors.joining());

            throw new IllegalArgumentException("the event FulfillmentMapExecutionEventAvro contains duplicated lines: " + lineIdsDuplicated);
        }
    }

    private Stream<DeliveryStepUpdatedInput.Line> buildDeliveryLinesUpdateInputLine(FulfillmentMapExecutionAvro execution, boolean isEstimatedDeliveryDateMappedFromFFMEFeatureEnabled) {
        return execution.getLogisticSteps().stream()
            .filter(step -> !IGNORED_STATUS.contains(step.getStatus()))
            .map(step -> this.buildDeliveryLineUpdateInputLine(step, execution, isEstimatedDeliveryDateMappedFromFFMEFeatureEnabled))
            .filter(Objects::nonNull);
    }

    private DeliveryStepUpdatedInput.Line buildDeliveryLineUpdateInputLine(FulfillmentMapExecutionLogisticStepAvro step, FulfillmentMapExecutionAvro execution, boolean isEstimatedDeliveryDateMappedFromFFMEFeatureEnabled) {
        final var shippingPoint = getShippingPoint(step);
        final var storeCodeReference = getReferenceValue("STORE_NUMBER", step, execution);
        final var incotermReference = getReferenceValue("INCOTERM", step, execution);
        final var estimatedDeliveryDate = this.getEstimatedDeliveryDate(step, isEstimatedDeliveryDateMappedFromFFMEFeatureEnabled);
        final var deliveryLineStatus = DORStatus.getEnum(step.getStatus());

        if (deliveryLineStatus == DORStatus.UNKNOWN) {
            return null;
        }
        return DeliveryStepUpdatedInput.Line.builder()
            .lineId(step.getOrderLineId())
            .isCancelable(step.getIsModifiableDelivery())
            .legacyOrderNumber(getReferenceValue("LEGACY_ORDER_NUMBER", step, execution).orElse(null))
            .storeCode(storeCodeReference.orElse(null))
            .incoterm(incotermReference.orElse(null))
            .status(deliveryLineStatus)
            .shippingPoint(shippingPoint.orElse(null))
            .estimatedDeliveryDate(estimatedDeliveryDate.orElse(null))
            .build();

    }

    private Optional<DeliveryDate> getEstimatedDeliveryDate(FulfillmentMapExecutionLogisticStepAvro step, boolean isEstimatedDeliveryDateMappedFromFFMEFeatureEnabled) {
        if (step.getDeliveryLocation() == null || step.getDeliveryLocation().getAtpFulfillment() == null) {
            return Optional.empty();
        }
        if (isEstimatedDeliveryDateMappedFromFFMEFeatureEnabled) {
            final var startDate = step.getDeliveryLocation().getAtpFulfillment().getStartDate();
            final var endDate = step.getDeliveryLocation().getAtpFulfillment().getEndDate();
            if (startDate == null && endDate == null) {
                return Optional.empty();
            } else if (startDate == null) {
                return Optional.of(new FixedDeliveryDate(endDate.atOffset(ZoneOffset.UTC)));
            } else if (endDate == null) {
                return Optional.of(new FixedDeliveryDate(startDate.atOffset(ZoneOffset.UTC)));
            } else if (startDate.equals(endDate)) {
                return Optional.of(new FixedDeliveryDate(endDate.atOffset(ZoneOffset.UTC)));
            } else {
                return Optional.of(new RangeDeliveryDate(startDate.atOffset(ZoneOffset.UTC), endDate.atOffset(ZoneOffset.UTC)));
            }
        } else {
            return Optional.empty();
        }
    }

    private Optional<ShippingPoint> getShippingPoint(FulfillmentMapExecutionLogisticStepAvro step) {
        try {
            return Optional.ofNullable(step.getShippingPoint()).map(shippingPoint -> ShippingPoint.valueOf(shippingPoint.getType()));
        } catch (IllegalArgumentException iae) {
            return Optional.empty();
        }
    }


    @Override
    public Class<?> getManagedEvent() {
        return FulfillmentMapExecutionEventAvro.class;
    }
}
