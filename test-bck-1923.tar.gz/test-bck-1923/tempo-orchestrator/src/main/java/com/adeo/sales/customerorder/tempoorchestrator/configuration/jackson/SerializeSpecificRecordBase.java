package com.adeo.sales.customerorder.tempoorchestrator.configuration.jackson;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.apache.avro.specific.SpecificRecordBase;

import java.io.IOException;

public class SerializeSpecificRecordBase extends JsonSerializer<SpecificRecordBase> {

    @Override
    public void serialize(SpecificRecordBase specificRecordBase, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        jsonGenerator.writeStartObject();
        for (final var field: specificRecordBase.getSchema().getFields()) {
            jsonGenerator.writeObjectField(field.name(), specificRecordBase.get(field.name()));
        }
        jsonGenerator.writeEndObject();
    }
}
