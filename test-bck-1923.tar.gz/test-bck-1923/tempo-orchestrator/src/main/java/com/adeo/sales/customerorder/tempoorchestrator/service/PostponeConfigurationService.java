package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.postpone.PostponeConfiguration;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.timezones.TimezonesConfiguration;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import lombok.extern.slf4j.Slf4j;

import java.time.Duration;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.configuration.postpone.PostponeConfiguration.PostponeMethod.BEFORE;

@Slf4j
public final class PostponeConfigurationService {
    private PostponeConfigurationService() {
    }

    public static final DateTimeFormatter ZDT_FORMATTER = DateTimeFormatter.ofPattern("H'h'mm");

    public static List<OffsetDateTime> getDateToSendList(PostponeConfiguration postponeConfiguration, TimezonesConfiguration timezonesConfiguration, CustomerOrder customerOrder, List<LineExecution> lineExecutions, String functionalType) {

        final var storeId = lineExecutions.stream().findFirst().map(lineExecution -> lineExecution.getPayment().getStoreId()).orElse(null);
        final var timeZone = timezonesConfiguration.findTimeZoneForBuAndStore(customerOrder.getBuCode(), storeId);

        final var initialDate = getInitialDate(postponeConfiguration, customerOrder, lineExecutions, timeZone);

        if (initialDate == null) {
            return List.of();
        }

        final var initialDateToSendList = addTimeToStartDate(postponeConfiguration, initialDate);

        var dateIdleFromTime = postponeConfiguration.getHourIdleFrom() != null ? getParsedDate(postponeConfiguration.getHourIdleFrom()) : null;
        var dateIdleToTime = postponeConfiguration.getHourIdleTo() != null ? getParsedDate(postponeConfiguration.getHourIdleTo()) : null;

        return initialDateToSendList.stream().map(initialDateToSend -> {
            if (initialDateToSend != null) {
                if (initialDateToSend.isBefore(OffsetDateTime.now(ZoneId.of(timeZone)))) {
                    log.warn("INTERNAL: Event {} for order {} will be not send because postpone date is in the past", functionalType, customerOrder.getId());
                    return null;
                } else if (dateIdleFromTime == null || dateIdleToTime == null || dateNotInIdlingTimeSlot(dateIdleFromTime, dateIdleToTime, initialDateToSend.toLocalDateTime().toLocalTime())) {
                    return initialDateToSend;
                } else {
                    return getDefaultDateToSendInFunctionOfIdleBounds(postponeConfiguration, initialDateToSend, dateIdleFromTime, dateIdleToTime);
                }
            }
            return null;
        }).filter(Objects::nonNull).collect(Collectors.toList());
    }

    private static List<OffsetDateTime> addTimeToStartDate(PostponeConfiguration postponeConfiguration, OffsetDateTime startDate) {
        return postponeConfiguration.getPostponeValue().stream().map(postponeValue -> {
            Duration parse = Duration.parse(postponeValue);
            return startDate.plus(parse);
        }).collect(Collectors.toList());
    }

    private static OffsetDateTime getDefaultDateToSendInFunctionOfIdleBounds(PostponeConfiguration postponeConfiguration, OffsetDateTime initialDateToSend, LocalTime idleFromTime, LocalTime idleToTime) {
        LocalTime timeToSend = initialDateToSend.toLocalDateTime().toLocalTime();
        boolean isIdleRangeNotOnSameDay = !isIdleRangeOnSameDay(idleFromTime, idleToTime);
        if (BEFORE.equals(postponeConfiguration.getPostponeMethod())) {
            OffsetDateTime fromBoundDateToSend = initialDateToSend.withHour(idleFromTime.getHour()).withMinute(idleFromTime.getMinute());
            if (isIdleRangeNotOnSameDay && needToRetainsOneDay(timeToSend, idleToTime)) {
                return fromBoundDateToSend.minusDays(1);
            }
            return fromBoundDateToSend;
        } else {
            OffsetDateTime toBoundDateToSend = initialDateToSend.withHour(idleToTime.getHour()).withMinute(idleToTime.getMinute());
            if (isIdleRangeNotOnSameDay && needToAddOneDay(timeToSend, idleFromTime)) {
                return toBoundDateToSend.plusDays(1);
            }
            return toBoundDateToSend;
        }
    }

    private static boolean needToRetainsOneDay(LocalTime timeToSend, LocalTime idleToTime) {
        return timeToSend.isBefore(idleToTime);
    }

    private static boolean needToAddOneDay(LocalTime timeToSend, LocalTime idleFromTime) {
        return timeToSend.isAfter(idleFromTime);
    }

    private static LocalTime getParsedDate(String textualDate) {
        return LocalTime.parse(textualDate, ZDT_FORMATTER);
    }

    private static boolean dateNotInIdlingTimeSlot(LocalTime idleFromTime, LocalTime idleToTime, LocalTime timeToSend) {
        if (isIdleRangeOnSameDay(idleFromTime, idleToTime)) {
            return !(timeToSend.isAfter(idleFromTime) && timeToSend.isBefore(idleToTime));
        } else {
            return !(timeToSend.isAfter(idleFromTime) || timeToSend.isBefore(idleToTime));
        }
    }

    private static boolean isIdleRangeOnSameDay(LocalTime idleFromTime, LocalTime idleToTime) {
        return idleFromTime.isBefore(idleToTime);
    }

    private static OffsetDateTime getInitialDate(PostponeConfiguration postponeConfiguration, CustomerOrder customerOrder, List<LineExecution> lineExecutions, String timeZone) {
        ZoneId zoneId = ZoneId.of(timeZone);
        switch (postponeConfiguration.getPostponeStartingDate()) {
            case CREATION:
                return OffsetDateTime.now(zoneId);
            case VALIDATION:
                return customerOrder.getFirstValidatedAt().atZoneSameInstant(zoneId).toOffsetDateTime();
            case APPOINTMENT:
                if (lineExecutions == null) {
                    return null;
                }

                final var deliveries = lineExecutions.stream().map(LineExecution::getDelivery).toList();

                final var deliveryAppointmentDateOption = deliveries.stream()
                    .filter(delivery -> delivery.getAppointmentDate() != null)
                    .findFirst()
                    .map(delivery -> delivery.getAppointmentDate().atZoneSameInstant(zoneId).toOffsetDateTime());

                final var collectAppointmentDateOption = deliveries.stream()
                    .map(LineExecutionDelivery::getCollect)
                    .filter(collect -> collect.getAppointmentDate() != null)
                    .findFirst()
                    .map(collect -> collect.getAppointmentDate().atZoneSameInstant(zoneId).toOffsetDateTime());

                return collectAppointmentDateOption
                    .orElse(deliveryAppointmentDateOption.orElse(null));
            default:
                return null;
        }
    }

}
