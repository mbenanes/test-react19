package com.adeo.sales.customerorder.tempoorchestrator.handler.dor;

import com.adeo.featuretoggle.FeatureRepository;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.alerting.DelayedDeliveryUndeterminedDelayedAlertService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.alerting.DelayedDeliveryLateApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.DeliveryStepUpdatedApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.DelayedLine;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.DeliveryStepUpdatedInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.FulfillmentMapExecutionDelayAlertInput;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.FixedDeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import com.adeo.sis.orchestrator.data.state.common.FulfillmentMapExecutionCustomerOrderLine;
import com.adeo.sis.orchestrator.data.state.common.FulfillmentMapExecutionLogisticDelayAlertStep;
import com.adeo.sis.orchestrator.event.common.FulfillmentMapExecutionDelayAlert;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.configuration.FeatureToggleConfiguration.HANDLE_FULFILLMENT_MAP_EXECUTION_DELAY_ALERT_FOR_CODE_011;
import static com.adeo.sales.customerorder.tempoorchestrator.configuration.FeatureToggleConfiguration.HANDLE_FULFILLMENT_MAP_EXECUTION_DELAY_ALERT_FOR_CODE_012;
import static com.adeo.sales.customerorder.tempoorchestrator.configuration.FeatureToggleConfiguration.HANDLE_FULFILLMENT_MAP_EXECUTION_DELAY_ALERT_FOR_CODE_015;
import static reactor.function.TupleUtils.function;

@Component
@RequiredArgsConstructor
@Slf4j
public class FulfillmentMapExecutionDelayAlertHandler implements EventHandler<FulfillmentMapExecutionDelayAlert> {
    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final DelayedDeliveryLateApplicationService delayedDeliveryLateApplicationService;
    private final DeliveryStepUpdatedApplicationService deliveryStepUpdatedApplicationService;
    private final DelayedDeliveryUndeterminedDelayedAlertService delayedDeliveryUndeterminedDelayedAlertService;
    private final FeatureRepository featureRepository;

    @Override
    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    public Mono<Void> handle(FulfillmentMapExecutionDelayAlert event, EventMetaData metaData) {
        this.mappedDiagnosticContext.injectEventMinimalBUData(metaData, event.getFulfillmentMapExecutionAlert().getCustomerOrderNumber());

        log.info("FulfillmentMapExecutionDelayAlert consumes {} - message id: {}", metaData.getTopic(), metaData.getId().orElse("no id"));


        final var isHandleForCode11Mono = this.featureRepository.getFeature(HANDLE_FULFILLMENT_MAP_EXECUTION_DELAY_ALERT_FOR_CODE_011).isEnabled();
        final var isHandleForCode12Mono = this.featureRepository.getFeature(HANDLE_FULFILLMENT_MAP_EXECUTION_DELAY_ALERT_FOR_CODE_012).isEnabled();
        final var isHandleForCode15Mono = this.featureRepository.getFeature(HANDLE_FULFILLMENT_MAP_EXECUTION_DELAY_ALERT_FOR_CODE_015).isEnabled();

        return stopAllStepsLineAreNotInDelivery(event)
            .then(stopIfAllCodesAreNotSame(event))
            .then(Mono.zip(isHandleForCode12Mono, isHandleForCode15Mono, isHandleForCode11Mono))
            .flatMap(function((isHandleForCode12, isHandleForCode15, isHandleForCode11) -> {
                boolean notHandleBecauseStep12NotActivated = BooleanUtils.isFalse(isHandleForCode12) && eventHasStepWithCode(event, "012");
                boolean notHandleBecauseStep15NotActivated = BooleanUtils.isFalse(isHandleForCode15) && eventHasStepWithCode(event, "015");
                boolean hasForecastedLateLines = eventHasStepWithCode(event, "011");
                boolean notHandleBecauseStep11NotActivated = BooleanUtils.isFalse(isHandleForCode11) && hasForecastedLateLines;

                if (notHandleBecauseStep12NotActivated || notHandleBecauseStep15NotActivated || notHandleBecauseStep11NotActivated) {
                    return MonoUtil.infoLog("INFO handle alert feature is disabled");
                }
                if (hasForecastedLateLines) {
                    return this.deliveryStepUpdatedApplicationService.apply(this.toDeliveryStepUpdatedInput(event));
                }
                if (eventHasStepWithCode(event, "012")) {
                    return this.delayedDeliveryLateApplicationService.apply(this.toInput(event));
                }
                return this.delayedDeliveryUndeterminedDelayedAlertService.apply(this.toInput(event));
            }));
    }

    private Mono<Void> stopIfAllCodesAreNotSame(FulfillmentMapExecutionDelayAlert event) {
        final var allCodes = event.getFulfillmentMapExecutionLogisticDelayAlertSteps().stream()
            .map(FulfillmentMapExecutionLogisticDelayAlertStep::getCode)
            .collect(Collectors.toSet());

        if (allCodes.size() > 1) {
            return Mono.error(new IllegalArgumentException("on a FulfillmentMapExecutionDelayAlert all codes should be same. received " + allCodes));
        }

        return Mono.empty();
    }

    private Mono<Void> stopAllStepsLineAreNotInDelivery(FulfillmentMapExecutionDelayAlert event) {
        final var allLinesOnDeliveryAlert = event.getFulfillmentMapExecutionLogisticDelayAlertSteps().stream()
            .map(line -> line.getCustomerOrderLine().getCustomerOrderLineId())
            .collect(Collectors.toList());

        final var allLinesInGroups = event.getFulfillmentMapExecutionAlert().getCustomerOrderLineGroup().stream()
            .map(FulfillmentMapExecutionCustomerOrderLine::getCustomerOrderLineId)
            .collect(Collectors.toList());

        final var deliveryLinesNotOnGroup = new ArrayList<>(allLinesOnDeliveryAlert);
        deliveryLinesNotOnGroup.removeAll(allLinesInGroups);

        if (!deliveryLinesNotOnGroup.isEmpty()) {
            return Mono.error(new IllegalArgumentException("The DOR event contains lines on steps not on groups. Error lines" + deliveryLinesNotOnGroup));
        }

        return Mono.empty();
    }

    private boolean eventHasStepWithCode(FulfillmentMapExecutionDelayAlert event, String code) {
        return event.getFulfillmentMapExecutionLogisticDelayAlertSteps()
            .stream()
            .anyMatch(step -> code.equals(step.getCode()));
    }

    private DeliveryStepUpdatedInput toDeliveryStepUpdatedInput(FulfillmentMapExecutionDelayAlert event) {
        final var delayedLines = event.getFulfillmentMapExecutionLogisticDelayAlertSteps().stream()
            .map(fulfillmentMapExecutionLogisticDelayAlertStep ->
                DeliveryStepUpdatedInput.Line.builder()
                    .lineId(fulfillmentMapExecutionLogisticDelayAlertStep.getCustomerOrderLine().getCustomerOrderLineId())
                    .estimatedDeliveryDate(
                        fulfillmentMapExecutionLogisticDelayAlertStep.getNewEndStepPromiseDate() != null ?
                            new FixedDeliveryDate(fulfillmentMapExecutionLogisticDelayAlertStep.getNewEndStepPromiseDate().atOffset(ZoneOffset.UTC))
                            : null)
                    .build()
            )
            .collect(Collectors.toList());

        return DeliveryStepUpdatedInput.builder()
            .customerOrderId(event.getFulfillmentMapExecutionAlert().getCustomerOrderNumber())
            .buCode(event.getFulfillmentMapExecutionAlert().getBuId())
            .lines(delayedLines)
            .build();
    }

    private FulfillmentMapExecutionDelayAlertInput toInput(FulfillmentMapExecutionDelayAlert event) {
        final var delayedLines = event.getFulfillmentMapExecutionLogisticDelayAlertSteps().stream()
            .map(fulfillmentMapExecutionLogisticDelayAlertStep -> DelayedLine.builder()
                .lineId(fulfillmentMapExecutionLogisticDelayAlertStep.getCustomerOrderLine().getCustomerOrderLineId())
                .step(fulfillmentMapExecutionLogisticDelayAlertStep.getFulfillmentMapExecutionStep())
                .status(fulfillmentMapExecutionLogisticDelayAlertStep.getFulfillmentMapExecutionStepStatus())
                .code(fulfillmentMapExecutionLogisticDelayAlertStep.getCode())
                .newEndStepPromiseDate(
                    fulfillmentMapExecutionLogisticDelayAlertStep.getNewEndStepPromiseDate() != null ?
                        new FixedDeliveryDate(fulfillmentMapExecutionLogisticDelayAlertStep.getNewEndStepPromiseDate().atOffset(ZoneOffset.UTC))
                        : null)
                .build()
            )
            .collect(Collectors.toMap(DelayedLine::getLineId, Function.identity(), (p, q) -> p))
            .values();

        return FulfillmentMapExecutionDelayAlertInput.builder()
            .customerOrderId(event.getFulfillmentMapExecutionAlert().getCustomerOrderNumber())
            .buCode(event.getFulfillmentMapExecutionAlert().getBuId())
            .delayedLines(List.copyOf(delayedLines))
            .build();
    }

    @Override
    public Class<?> getManagedEvent() {
        return FulfillmentMapExecutionDelayAlert.class;
    }
}
