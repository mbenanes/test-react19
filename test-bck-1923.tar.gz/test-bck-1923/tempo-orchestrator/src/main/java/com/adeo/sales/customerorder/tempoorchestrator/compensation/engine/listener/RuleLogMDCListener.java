package com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.listener;

import com.adeo.sales.customerorder.ruleengine.api.Facts;
import com.adeo.sales.customerorder.ruleengine.api.Rule;
import com.adeo.sales.customerorder.ruleengine.api.RuleListener;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@Slf4j
@AllArgsConstructor
public class RuleLogMDCListener implements RuleListener {
    private final MappedDiagnosticContext mappedDiagnosticContext;

    @Override
    public Mono<Rule> startRule(Rule rule, Facts facts) {
        final var context = getContext(facts);
        mappedDiagnosticContext.enrichCurrentSpan(MappedDiagnosticContext.RULE_ENGINE_CURRENT_RULE_KEY, rule.getClass().getSimpleName());
        log.debug("Starting rule [customerOrder -> {}]  : rule name:{}, rule version:{}, rule priority:{}", context.getCustomerOrderId(), rule.getName(), rule.getVersion(), rule.getPriority());
        return Mono.just(rule);
    }

    @Override
    public boolean beforeEvaluate(Rule rule, Facts facts) {
        final var context = getContext(facts);
        log.debug("Start condition evaluation [customerOrder -> {}]  : rule name:{}, rule version:{}, rule priority:{}", context.getCustomerOrderId(), rule.getName(), rule.getVersion(), rule.getPriority());
        return true;
    }

    @Override
    public Mono<Rule> afterEvaluate(Rule rule, Facts facts, boolean evaluationResult) {
        final var context = getContext(facts);
        log.debug("End condition evaluation({}) [customerOrder -> {}]  : rule name:{}, rule version:{},rule priority:{}", evaluationResult, context.getCustomerOrderId(), rule.getName(), rule.getVersion(), rule.getPriority());
        return Mono.just(rule);
    }

    @Override
    public Mono<Rule> onEvaluationError(Rule rule, Facts facts, Throwable throwable) {
        final var context = getContext(facts);
        log.error("Error on condition evaluation [customerOrder -> {}]  : rule name:{}, rule version:{},rule priority:{}, Error:{} ", context.getCustomerOrderId(), rule.getName(), rule.getVersion(), rule.getPriority(), throwable.getMessage());
        return Mono.just(rule);
    }

    @Override
    public Mono<Rule> beforeExecute(Rule rule, Facts facts) {
        final var context = getContext(facts);
        log.info("Start action execution [customerOrder -> {}]  : rule name:{}, rule version:{},rule priority:{}", context.getCustomerOrderId(), rule.getName(), rule.getVersion(), rule.getPriority());
        return Mono.just(rule);
    }

    @Override
    public Mono<Rule> onSuccess(Rule rule, Facts facts) {
        final var context = getContext(facts);
        log.info("End action execution [customerOrder -> {}]  : rule name:{}, rule version:{},rule priority:{}", context.getCustomerOrderId(), rule.getName(), rule.getVersion(), rule.getPriority());
        return Mono.just(rule);
    }

    @Override
    public Mono<Rule> onFailure(Rule rule, Facts facts, Throwable throwable) {
        final var context = getContext(facts);
        log.error("Error on action execution [customerOrder -> {}]  : rule name:{}, rule version:{},rule priority:{}, Error:{} ", context.getCustomerOrderId(), rule.getName(), rule.getVersion(), rule.getPriority(), throwable.getMessage());
        return Mono.just(rule);
    }

    private RuleEngineContext getContext(Facts facts) {
        return ((RuleEngineContext) (facts.getFact("businessContext").getValue()));
    }
}
