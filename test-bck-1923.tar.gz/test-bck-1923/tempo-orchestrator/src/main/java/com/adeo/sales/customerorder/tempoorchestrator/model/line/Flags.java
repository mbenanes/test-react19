package com.adeo.sales.customerorder.tempoorchestrator.model.line;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.TreeSet;

@Slf4j
@Data
@Builder
public class Flags<T extends Enum<T>> {

    public Flags() {
    }

    public Flags(Flag flag) {
        orderedByDateFlags.add(flag);
    }

    public static final String UNKNOWN_OPERATION_ID = "UNKNOWN_OPERATION_ID";
    private static final Comparator<Flag> FLAG_COMPARATOR_BY_DATE = (Flag o1, Flag o2) -> Objects.compare(o1.getDateTime().toInstant(), o2.getDateTime().toInstant(), Instant::compareTo);
    @Getter
    private final TreeSet<Flag> orderedByDateFlags = new TreeSet<>(FLAG_COMPARATOR_BY_DATE.reversed());

    public void setOrderedByDateFlags(Collection<Flag> flags) {
        this.orderedByDateFlags.addAll(flags);
    }

    public void raiseFlag(T type) {
        this.raiseFlag(type, OffsetDateTime.now());
    }

    public void raiseFlagWithFailedReason(T type, String failedReason) {
        this.raiseFlagWithFailedReason(type, OffsetDateTime.now(), failedReason);
    }

    public void raiseFlag(String operationId, T type) {
        this.raiseFlag(operationId, type, OffsetDateTime.now(), null);
    }

    public void raiseFlag(T type, OffsetDateTime dateTime) {
        raiseFlag(null, type, dateTime, null);
    }

    public void raiseFlagWithFailedReason(T type, OffsetDateTime dateTime, String failedReason) {
        raiseFlag(null, type, dateTime, failedReason);
    }

    public void raiseFlag(String operationId, T type, OffsetDateTime dateTime, String failedReason) {
        final var operation = operationId != null ? operationId : UNKNOWN_OPERATION_ID;
        if (type != null && !this.orderedByDateFlags.add(new Flag(operation, dateTime, type.name(), failedReason))) {
            final var lastFlagDateTimeWithOneNanoMore = this.orderedByDateFlags.last().getDateTime().plusNanos(1);
            this.orderedByDateFlags.add(new Flag(operation, lastFlagDateTimeWithOneNanoMore, type.name(), failedReason));
        }
    }

    public void raiseFlagIfNot(String operationId, T type, OffsetDateTime dateTime) {
        final var operation = operationId != null ? operationId : UNKNOWN_OPERATION_ID;
        if (type != null && !this.lastFlagIs(type)) {
            this.raiseFlag(operation, type, dateTime, null);
        }
    }

    public void raiseFlagIfNotHasOperationId(String operationId, T type, OffsetDateTime dateTime) {
        final var operation = operationId != null ? operationId : UNKNOWN_OPERATION_ID;
        if (type != null && !this.hasOperationId(operationId)) {
            this.raiseFlag(operation, type, dateTime, null);
        }
    }

    public void raiseFlagIfNotSameOperationId(String operationId, T type, OffsetDateTime dateTime) {
        final var operation = operationId != null ? operationId : UNKNOWN_OPERATION_ID;
        boolean sameType = this.lastFlagIs(type);
        if (type != null && (!sameType || (!UNKNOWN_OPERATION_ID.equals(operation) && !operation.equals(getLastFlag().getOperationId())))) {
            this.raiseFlag(operation, type, dateTime, null);
        }
    }

    public void raiseFlagIfNot(T type) {
        if (type != null && !this.hasFlag(type)) {
            this.raiseFlag(type);
        }
    }

    public void raiseFlagIfNotWithReason(T type) {
        if (type != null && !this.hasFlag(type)) {
            this.raiseFlag(type);
        }
    }

    public void raiseFlagIfNotWithFailedReason(T type, String failedReason) {
        if (type != null && !this.hasFlag(type)) {
            this.raiseFlagWithFailedReason(type, failedReason);
        }
    }

    public void raiseFlagIfNotLastWithSameOperationId(String operationId, T type, OffsetDateTime dateTime, String failedReason) {
        final var operation = operationId != null ? operationId : UNKNOWN_OPERATION_ID;
        boolean sameType = this.lastFlagIs(type);
        if (!sameType || (!UNKNOWN_OPERATION_ID.equals(operation) && !operation.equals(getLastFlag().getOperationId()))) {
            raiseFlag(operationId, type, dateTime, failedReason);
        }
    }

    public boolean raiseFlagIfNot(Flag flag) {
        if (flag != null && (getLastFlag() == null || !getLastFlag().getType().equals(flag.getType()))) {
            this.getOrderedByDateFlags().add(flag);
            return true;
        }
        return false;
    }

    public void raiseFlagIfNotLast(T type) {
        if (type != null && !this.lastFlagIs(type)) {
            this.raiseFlag(type);
        }
    }

    public void raiseFlagIfNot(T type, OffsetDateTime dateTime) {
        if (type != null && !this.hasFlag(type)) {
            this.raiseFlag(type, dateTime);
        }
    }

    public boolean hasFlag(T type) {
        return this.orderedByDateFlags.stream()
            .anyMatch(flag -> type.name().equals(flag.getType()));
    }

    public boolean hasOperationId(String operationId) {
        return this.orderedByDateFlags.stream()
            .anyMatch(flag -> operationId.equals(flag.getOperationId()));
    }

    public boolean hasDateTime(OffsetDateTime dateTime) {
        if (dateTime == null) {
            return false;
        }
        return this.orderedByDateFlags.stream()
            .anyMatch(flag -> dateTime.isEqual(flag.getDateTime()));
    }

    public boolean hasNotFlags(List<T> types) {
        final var typeNames = types.stream().map(Enum::name).toList();
        return this.orderedByDateFlags.stream()
            .noneMatch(flag -> typeNames.contains(flag.getType()));
    }

    public boolean hasNoFlags() {
        return this.orderedByDateFlags.isEmpty();
    }

    public boolean hasFlags() {
        return !this.orderedByDateFlags.isEmpty();
    }

    public boolean lastFlagIs(T type) {
        return !this.orderedByDateFlags.isEmpty() && type.name().equals(this.orderedByDateFlags.first().getType());
    }

    public void clearFlags(){
        this.orderedByDateFlags.clear();
    }

    public final boolean lastFlagIsOneOf(Collection<T> types) {
        return types.stream().anyMatch(this::lastFlagIs);
    }

    public final boolean lastFlagIsOneOf(T... types) {
        return Arrays.stream(types).toList().stream().anyMatch(this::lastFlagIs);
    }

    public final boolean hasFlagIsOneOf(Collection<T> types) {
        return types.stream().anyMatch(this::hasFlag);
    }

    @JsonIgnore
    public Flag getLastFlag() {
        if (!this.orderedByDateFlags.isEmpty()) {
            return this.orderedByDateFlags.first();
        }
        return null;
    }
}
