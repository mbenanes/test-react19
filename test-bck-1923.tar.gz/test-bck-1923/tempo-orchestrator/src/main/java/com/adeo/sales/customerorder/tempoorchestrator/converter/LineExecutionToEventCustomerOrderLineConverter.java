package com.adeo.sales.customerorder.tempoorchestrator.converter;

import com.adeo.sales.customerorder.tempoorchestrator.data.Actions;
import com.adeo.sales.customerorder.tempoorchestrator.data.CustomerOrderLineDeliveryInformation;
import com.adeo.sales.customerorder.tempoorchestrator.data.DeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.data.DeliveryDateType;
import com.adeo.sales.customerorder.tempoorchestrator.data.Reference;
import com.adeo.sales.customerorder.tempoorchestrator.data.System;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.FixedDeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.RangeDeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public class LineExecutionToEventCustomerOrderLineConverter implements Converter<LineExecution, com.adeo.sales.customerorder.tempoorchestrator.data.CustomerOrderLine> {

    @Override
    public com.adeo.sales.customerorder.tempoorchestrator.data.CustomerOrderLine convert(LineExecution line) {
        return com.adeo.sales.customerorder.tempoorchestrator.data.CustomerOrderLine.newBuilder()
            .setId(line.getLineId())
            .setConsolidatedStatus(getConsolidatedStatusFrom(line).toString())
            .setVersion(line.getVersion())
            .setExternalOrchestratorId(line.getExternalSystem() != null ? line.getExternalSystem().getId() : null)
            .setCustomerOrderId(line.getCustomerOrderId())
            .setBuCode(line.getBuCode())
            .setReferences(buildReferences(line))
            .setAvailableActions(buildActions(line))
            .setDelivery(buildDeliveryInformation(line))
            .setOrderPartNumber(line.getComposition().getOrderPartNumber())
            .build();
    }

    private CustomerOrderLineDeliveryInformation buildDeliveryInformation(LineExecution line) {
        return CustomerOrderLineDeliveryInformation.newBuilder()
            .setCustomerKnownDeliveryDate(buildDeliveryDate(line.getDelivery().getCustomerKnownDeliveryDate()))
            .setEstimatedDeliveryDate(buildDeliveryDate(line.getDelivery().getEstimatedDeliveryDate()))
            .setInitialPromiseDate(buildDeliveryDate(line.getDelivery().getInitialPromiseDate()))
            .build();
    }

    private DeliveryDate buildDeliveryDate(com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate date) {
        if (date == null) {
            return null;
        }
        if (date instanceof FixedDeliveryDate) {
            return DeliveryDate.newBuilder()
                .setType(DeliveryDateType.FIXED)
                .setFixedDate(((FixedDeliveryDate) date).getFixedDate().toInstant())
                .build();
        }
        if (date instanceof RangeDeliveryDate) {
            return DeliveryDate.newBuilder()
                .setType(DeliveryDateType.RANGE)
                .setMinDate(((RangeDeliveryDate) date).getStartDate().toInstant())
                .setMaxDate(((RangeDeliveryDate) date).getEndDate().toInstant())
                .build();
        }
        throw new IllegalArgumentException("Unsupported delivery date type " + date.getClass().getSimpleName());
    }

    private ArrayList<Reference> buildReferences(LineExecution line) {
        final var references = new ArrayList<Reference>();

        if (line.getExternalSystem() != null && StringUtils.isNotBlank(line.getExternalSystem().getId()) && line.isSoldByAThirdPartyVendor()) {
            references.add(this.buildReference("BOMP_ORDER_NUMBER", line.getExternalSystem().getId()));
        }
        if (StringUtils.isNotBlank(line.getPayment().getStoreId())) {
            references.add(this.buildReference("CASHING_STORE_ID", line.getPayment().getStoreId()));
        }

        if (StringUtils.isNotBlank(line.getComposition().getLegacyNumber())) {
            references.add(this.buildReference("LEGACY_NUMBER", line.getComposition().getLegacyNumber()));
        } else if (StringUtils.isNotBlank(line.getPayment().getDepositLegacyNumber())) {
            references.add(this.buildReference("LEGACY_NUMBER", line.getPayment().getDepositLegacyNumber()));
        } else if (StringUtils.isNotBlank(line.getDelivery().getDeliveryLegacyNumber())) {
            references.add(this.buildReference("LEGACY_NUMBER", line.getDelivery().getDeliveryLegacyNumber()));
        }

        if (StringUtils.isNotBlank(line.getPayment().getDepositLegacyNumber())) {
            references.add(this.buildReference("DEPOSIT_LEGACY_NUMBER", line.getPayment().getDepositLegacyNumber()));
        }
        if (StringUtils.isNotBlank(line.getPayment().getCashierLegacyNumber())) {
            references.add(this.buildReference("CASHIER_LEGACY_NUMBER", line.getPayment().getCashierLegacyNumber()));
        }
        if (StringUtils.isNotBlank(line.getDelivery().getDeliveryLegacyNumber())) {
            references.add(this.buildReference("DELIVERY_LEGACY_NUMBER", line.getDelivery().getDeliveryLegacyNumber()));
        }
        return references;
    }

    private Reference buildReference(String type, String cashingStoreId) {
        return Reference.newBuilder()
            .setType(type)
            .setValue(cashingStoreId)
            .build();
    }

    public CustomerOrderLineConsolidatedStatus getConsolidatedStatusFrom(LineExecution lineExecution) {
        if (!lineExecution.getDelivery().getFlags().hasFlags()) {
            return CustomerOrderLineConsolidatedStatus.UNKNOWN;
        }
        return switch (lineExecution.getDelivery().getLastFlag()) {
            case CREATED, ACCEPTED, HANDOVER_STARTED, RELEASED -> CustomerOrderLineConsolidatedStatus.VALIDATED;
            case REJECTED, ABORTED -> CustomerOrderLineConsolidatedStatus.CANCELLED;
            case SHIPPING_REQUESTED -> CustomerOrderLineConsolidatedStatus.SHIPPING;
            case SHIPPED, RECEIVED, CLOSED -> CustomerOrderLineConsolidatedStatus.SHIPPED;
            default -> CustomerOrderLineConsolidatedStatus.UNKNOWN;
        };
    }

    private Actions buildActions(LineExecution line) {
        return Actions.newBuilder()
            .setIsCancelable(line.getComposition().isCancelable())
            .setIsForceCancelable(line.getDelivery().getForceCancelable())
            .setIsDeliveryDateUpdatable(line.getDelivery().getIsDeliveryDateUpdatable())
            .setIsUpdatable(line.getDelivery().getIsDeliveryDateUpdatable())
            .setSystem(buildSystem(line))
            .build();
    }

    private System buildSystem(LineExecution line) {
        final System system;
        if (line.getExternalSystem() == null
            || line.getExternalSystem().getId() == null
            || line.getExternalSystem().getName() == null
        ) {
            system = null;
        } else {
            system = System.newBuilder()
                .setName(line.getExternalSystem().getName().toString())
                .setReference(line.getExternalSystem().getId())
                .setStoreCode(line.getExternalSystem().getStoreCode())
                .build();
        }
        return system;
    }

    public enum CustomerOrderLineConsolidatedStatus {
        VALIDATED, SHIPPING, SHIPPED, CANCELLED, UNKNOWN
    }
}
