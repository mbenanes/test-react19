package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OwnerRequest {

    private OperatorType operatorType;

    private String identifier;

    public enum OperatorType {
        COLLABORATOR, CUSTOMER, SYSTEM, LDAP;
    }
}
