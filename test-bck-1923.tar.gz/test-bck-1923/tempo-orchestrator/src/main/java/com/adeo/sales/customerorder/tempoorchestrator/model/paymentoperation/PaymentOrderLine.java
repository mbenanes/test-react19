package com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentOrderLine {
    private String id;
    private PaymentLineType type;
}
