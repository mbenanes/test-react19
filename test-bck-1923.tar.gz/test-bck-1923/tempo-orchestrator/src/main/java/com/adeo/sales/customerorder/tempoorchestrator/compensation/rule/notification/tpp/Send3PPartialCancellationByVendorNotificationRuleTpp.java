package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_DECREASE_QUANTITY_ACTION_PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_SEND_CANCELLATION_BY_VENDOR_NOTIFICATION_IS_THE_NEXT_STEP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.SEND_CANCELLATION_BY_VENDOR_NOTIFICATION;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Send3PPartialCancellationByVendorNotificationTpp",
    description = "send a notification CustomerOrderPartialCancellationByVendor",
    priority = 1000)
public class Send3PPartialCancellationByVendorNotificationRuleTpp {
    private static final String MAIL_TEMPLATE = "CustomerOrderPartialCancellationByVendor";

    public static final Predicate<ExecutionAction> IS_ALL_LINE_NEXT_STEP_IS_SEND_NOTIFICATION = executionAction -> executionAction.getAllImpactedLines()
        .stream()
        .filter(impactedLine -> !impactedLine.hasNoMoreSteps() && impactedLine.getStepOfType(SEND_CANCELLATION_BY_VENDOR_NOTIFICATION).isPresent())
        .allMatch(impactedLine -> impactedLine.isNextStepIsOfType(SEND_CANCELLATION_BY_VENDOR_NOTIFICATION));

    public static final Predicate<ExecutionAction> IS_ACTION_EXECUTION_TO_PROCESS = IS_DECREASE_QUANTITY_ACTION_PROCESSING
        .and(IS_ALL_LINE_NEXT_STEP_IS_SEND_NOTIFICATION)
        .and(IS_SEND_CANCELLATION_BY_VENDOR_NOTIFICATION_IS_THE_NEXT_STEP);


    private final OutgoingNotificationService notificationService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneExecutionAction(IS_ACTION_EXECUTION_TO_PROCESS);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        Optional<ExecutionAction> executionActionOptional = context.getFirstExecutionActionByPredicate(IS_ACTION_EXECUTION_TO_PROCESS);
        return Mono.justOrEmpty(executionActionOptional)
            .flatMapIterable(ExecutionAction::getImpactedExecutions)
            .flatMap(impactedExecution -> {
                final var bompSubOrder = impactedExecution.getImpactedLines()
                    .stream()
                    .filter(impactedLine -> impactedLine.isNextStepIsOfType(SEND_CANCELLATION_BY_VENDOR_NOTIFICATION))
                    .flatMap(impactedLine -> context.getOrderData().getLineExecutionByIdAndExecutionId(impactedLine.getLineId(), impactedExecution.getCurrentExecutionId()).stream())
                    .filter(lineExecution -> lineExecution.getExternalSystem() != null && lineExecution.getExternalSystem().getId() != null)
                    .toList();
                return this.sendNotification(bompSubOrder, context.getOrderData().getExistingCustomerOrder(), impactedExecution);
            }).then();
    }

    private Mono<Void> sendNotification(List<LineExecution> bompSubOrder, CustomerOrder customerOrder, ImpactedExecution impactedExecution) {
        final var externalId = bompSubOrder.get(0).getExternalSystem().getId();

        return MonoUtil.infoLog("INTERNAL send notification type {} for lines {}", MAIL_TEMPLATE, LineExecution.joinLineIds(bompSubOrder))
            .then(notificationService.sendPartialCancellationByVendorNotification(customerOrder, externalId))
            .then(Mono.fromRunnable(() -> bompSubOrder.forEach(line -> {
                    line.mailIsSent(MAIL_TEMPLATE);
                    line.increaseVersion();
                    impactedExecution.getImpactedLines()
                        .stream()
                        .filter(impactedLine -> impactedLine.isNextStepIsOfType(SEND_CANCELLATION_BY_VENDOR_NOTIFICATION))
                        .forEach(impactedLine -> impactedLine.raiseFlagStepTypeIfPresent(SEND_CANCELLATION_BY_VENDOR_NOTIFICATION, ImpactedLineStep.Status.COMPLETED));
                })
            ));
    }

}
