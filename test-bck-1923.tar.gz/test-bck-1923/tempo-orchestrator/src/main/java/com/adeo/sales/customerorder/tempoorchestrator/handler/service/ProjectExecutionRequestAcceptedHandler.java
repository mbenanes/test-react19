package com.adeo.sales.customerorder.tempoorchestrator.handler.service;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.service.ProjectExecutionRequestAcceptedApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.service.input.ProjectExecutionRequestAcceptedInput;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.serviceexecution.schemas.ProjectExecutionRequestAccepted;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.util.List;

@RequiredArgsConstructor
@Component
@Slf4j
public class ProjectExecutionRequestAcceptedHandler implements EventHandler<ProjectExecutionRequestAccepted> {

    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final ProjectExecutionRequestAcceptedApplicationService applicationService;

    @Override
    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    public Mono<Void> handle(ProjectExecutionRequestAccepted event, EventMetaData eventMetaData) {

        String customerOrderID = event.getCustomerOrder().getIdentifier();
        String buCode = eventMetaData.getBuCode();

        this.mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderID, buCode);

        List<String> lines = event.getProjectExecutions().stream()
            .flatMap(project -> project.getCustomerOrderCartItemIds().stream())
            .toList();

        var input = ProjectExecutionRequestAcceptedInput.builder()
            .customerOrderId(customerOrderID)
            .buCode(buCode)
            .customerOrderLineIds(lines)
            .build();

        return this.applicationService.apply(input);
    }

    @Override
    public Class<ProjectExecutionRequestAccepted> getManagedEvent() {
        return ProjectExecutionRequestAccepted.class;
    }
}
