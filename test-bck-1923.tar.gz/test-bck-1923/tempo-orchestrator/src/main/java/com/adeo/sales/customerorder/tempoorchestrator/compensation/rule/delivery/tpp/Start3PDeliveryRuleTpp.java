package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.ThirdPartyDeliveryCommandManager;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_ACCEPTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_REJECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_BOMP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_ID_NOT_NULL;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPING_REQUIREMENT_COMPLETED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.NO_TPP_REQUIREMENT_IN_PROGRESS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.SHIPPING_REQUESTED;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Start3PDeliveryTpp",
    description = "Start the 3P delivery when the shipping requirement is completed and the vendor has accepted the customer order. " +
        "The start delivery can happen on a part of a BOMP sub customer order",
    priority = 1000)
public class Start3PDeliveryRuleTpp {
    private static final Predicate<LineExecution> IS_LINE_ACCEPTED_BY_VENDOR_AND_SHIPPING_REQUIREMENT_COMPLETED =
        PAYMENT_ORCHESTRATED_BY_TPP
            .and(IS_DELIVERY_ACCEPTED)
            .and(IS_SHIPPING_REQUIREMENT_COMPLETED)
            .and(NO_TPP_REQUIREMENT_IN_PROGRESS);
    private final ThirdPartyDeliveryCommandManager thirdPartyDeliveryCommandManager;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return this.findBompSubOrdersToStartDelivery(context).findFirst().isPresent()
            && context.getOrderData().getExecutionActions().stream()
            .noneMatch(executionAction -> executionAction.getFlags().lastFlagIs(ExecutionActionStatus.PROCESSING));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return Mono.when(this.findBompSubOrdersToStartDelivery(context)
            .map(subOrder -> this.startDelivery(subOrder, context))
            .collect(Collectors.toList()));
    }

    private Mono<Void> startDelivery(List<LineExecution> bompSubOrderLines, RuleEngineContext context) {
        final var linesToStartDelivery = bompSubOrderLines.stream()
            .filter(IS_LINE_ACCEPTED_BY_VENDOR_AND_SHIPPING_REQUIREMENT_COMPLETED)
            .collect(Collectors.toList());

        return MonoUtil.infoLog("INTERNAL request shipping for 3P lines {}", LineExecution.joinLineIds(linesToStartDelivery))
            .then(this.thirdPartyDeliveryCommandManager.startDelivery(linesToStartDelivery, context.getOrderData().getExistingCustomerOrder()))
            .then(Mono.fromRunnable(() -> linesToStartDelivery.forEach(lineExecution -> {
                lineExecution.getDelivery().getFlags().raiseFlag(SHIPPING_REQUESTED);
                lineExecution.increaseVersion();
            })));
    }

    private Stream<List<LineExecution>> findBompSubOrdersToStartDelivery(RuleEngineContext context) {
        return context.getOrderData().getLineExecutionsByPredicate(IS_EXTERNAL_SYSTEM_BOMP.and(IS_EXTERNAL_SYSTEM_ID_NOT_NULL))
            .stream()
            .collect(Collectors.groupingBy(line -> line.getExternalSystem().getId()))
            .values()
            .stream()
            .filter(this::isAllBompSubOrderAcceptedWithShippingRequirementCompletedOrRejected);
    }

    private boolean isAllBompSubOrderAcceptedWithShippingRequirementCompletedOrRejected(List<LineExecution> bompSubOrderLines) {
        return bompSubOrderLines.stream().allMatch(IS_DELIVERY_REJECTED.or(IS_LINE_ACCEPTED_BY_VENDOR_AND_SHIPPING_REQUIREMENT_COMPLETED));
    }
}
