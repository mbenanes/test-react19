package com.adeo.sales.customerorder.tempoorchestrator.model.customerorder;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;

@Getter
@RequiredArgsConstructor
public enum Bu {
    FRANCE("001"),
    ITALY("005"),
    SPAIN("002"),
    PORTUGAL("003"),
    POLAND("006");

    public static final Bu fromCode(String code){
        return Arrays.stream(Bu.values()).filter(bu -> bu.getCode().equals(code)).findFirst().orElse(null);
    }

    private final String code;
}
