package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.collect;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECTED_LINE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECT_DELIVERED_NOTIFICATION_NOT_SENT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_COMPLETED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_IS_SPLIT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_REASON_IS_REMAINING_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.NotificationStatus.NOTIFICATION_REQUESTED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@AllArgsConstructor
@Rule(name = "SendPickupOrderDeliveredCommunicationRule",
    description = "Send pickup order notification to customer.",
    priority = 1000)
public class SendPickupOrderDeliveredCommunicationRule {

    private final OutgoingNotificationService notificationService;

    private static final Predicate<LineExecution> COLLECTED_LINE_WITHOUT_DELIVERED_NOTIFICATION = IS_COLLECTED_LINE
        .and(IS_COLLECT_DELIVERED_NOTIFICATION_NOT_SENT)
        .and(IS_EXTERNAL_SYSTEM_TEMPO);


    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {

        return context.hasAtLeastOneLine(COLLECTED_LINE_WITHOUT_DELIVERED_NOTIFICATION);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {

        final var reserveAndCollectLines = context.getOrderData().getExistingLineExecutions().stream()
            .filter(COLLECTED_LINE_WITHOUT_DELIVERED_NOTIFICATION)
            .toList();
        final String customerOrderExecutionActionId = getcustomerOrderExecutionActionIdIfExisting(context.getOrderData().getExecutionActions(), reserveAndCollectLines).orElse(null);

        return MonoUtil.infoLog("INTERNAL send notification pickup order {} with executionActionId {} ", context.getOrderData().getExistingCustomerOrder().getId(), customerOrderExecutionActionId != null ? customerOrderExecutionActionId : "absent")
            .then(notificationService.sendPickupInStoreOrderDeliveredNotificationRelatedToExecutionAction(context.getOrderData().getExistingCustomerOrder(), reserveAndCollectLines, customerOrderExecutionActionId))
            .then(Mono.fromRunnable(() -> reserveAndCollectLines.forEach(lineExecution -> {
                lineExecution.getDelivery().getCollect().setPickupDeliveredNotificationStatus(NOTIFICATION_REQUESTED);
                lineExecution.increaseVersion();
            })));
    }

    private Optional<String> getcustomerOrderExecutionActionIdIfExisting(List<ExecutionAction> executionActions, List<LineExecution> lineExecutions) {
        final List<String> executionIds = lineExecutions.stream().map(LineExecution::getExecutionId).distinct().toList();
        final List<String> lineIds = lineExecutions.stream().map(LineExecution::getLineId).toList();

        return executionActions.stream()
            .filter(IS_EXECUTION_ACTION_IS_SPLIT.and(IS_EXECUTION_ACTION_REASON_IS_REMAINING_COLLECT).and(not(IS_EXECUTION_ACTION_COMPLETED)))
            .filter(executionAction -> executionAction.getImpactedExecutions().stream()
                .anyMatch(impactedExecution -> executionIds.contains(impactedExecution.getCurrentExecutionId())))
            .findFirst()
            .map(ExecutionAction::getRequestId);

    }
}
