package com.adeo.sales.customerorder.tempoorchestrator.repository.event;

import org.apache.avro.generic.GenericRecord;
import org.apache.avro.specific.SpecificRecord;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

public interface EventProducer {

    <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord, Map<String, String> headers);

    <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord);


    <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvent(String topic, String customerOrderId, String buCode, T genericRecord);

    <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvent(String topic, String customerOrderId, String buCode, T genericRecord, String sentBy);

    <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvents(List<String> topic, String customerOrderId, String buCode, T genericRecord, boolean useTopicNameStrategy);

    <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord, OffsetDateTime dateToSendEvent, String functionalType);

    <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord, boolean useTopicNameStrategy, OffsetDateTime dateToSendEvent, String functionalType);

}
