package com.adeo.sales.customerorder.tempoorchestrator.model.alert;

public class AlertSpecificDataType {
    public static final String PROMISED_DATE = "promisedDate";
    public static final String REJECTED_LINES = "rejectedLines";
    public static final String REJECTED_PAYMENT = "rejectedPayment";
    public static final String REJECTED_REFUND = "rejectedRefund";

}
