package com.adeo.sales.customerorder.tempoorchestrator.configuration;

import org.springframework.boot.task.TaskSchedulerCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BatchConfiguration {

    @Bean
    TaskSchedulerCustomizer taskSchedulerCustomizer() {
        return taskScheduler -> {
            taskScheduler.setAwaitTerminationSeconds(60);
            taskScheduler.setWaitForTasksToCompleteOnShutdown(true);
        };
    }

}
