package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;

import java.util.List;

public interface UpdateAvailableActionService {
    void apply(List<LineExecution> lineExecutions, LineExecution customerOrderLine, CustomerOrder customerOrder);

    void apply(List<LineExecution> lineExecutions, LineExecution customerOrderLine, CustomerOrder customerOrder, Boolean isCancelable);
}
