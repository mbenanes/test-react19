package com.adeo.sales.customerorder.tempoorchestrator.service.impl;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.ValuateStockBacko;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.ValuateStockBackoOrderLines;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.service.ValuateStockService;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.ValuateStockDto;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class ValuateStockKafkaServiceImpl implements ValuateStockService {

    private final EventProducer eventProducer;
    private final TopicsProperties topicsProperties;

    public Mono<Void> sendValuateStockRequest(@NonNull ValuateStockDto valuateStockDto) {
        final var valuateStockRequestEvent = buildEvent(valuateStockDto);

        return this.eventProducer.sendEvents(this.topicsProperties.getValuateStock(), valuateStockDto.getCustomerOrderNumber(), valuateStockDto.getBuCode(), valuateStockRequestEvent);
    }

    private ValuateStockBacko buildEvent(ValuateStockDto valuateStockDto) {
        if (valuateStockDto == null) {
            return null;
        }
        return ValuateStockBacko.newBuilder()
            .setOrderId(valuateStockDto.getLegacyNumber())
            .setStoreId(valuateStockDto.getStoreCode())
            .setOrderLines(setOrderLines(valuateStockDto))
            .build();
    }

    private List<ValuateStockBackoOrderLines> setOrderLines(ValuateStockDto source) {
        return source.getLines().stream()
            .map(valuateStockLines ->
                ValuateStockBackoOrderLines.newBuilder()
                    .setId(valuateStockLines.getLineId())
                    .setQuantity(valuateStockLines.getQuantity())
                    .setReference(valuateStockLines.getProductCode())
                    .build())
            .collect(Collectors.toList());
    }

}
