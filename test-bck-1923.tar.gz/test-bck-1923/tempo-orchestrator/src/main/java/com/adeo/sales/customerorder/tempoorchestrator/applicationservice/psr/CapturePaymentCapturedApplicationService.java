package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.CreateOrUpdateCustomerOrderApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderAlreadyExists;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.input.CapturePaymentCapturedInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPaymentExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.PaymentOperationType;
import com.adeo.sales.customerorder.tempoorchestrator.repository.impl.LockPosgresRepository;
import com.adeo.sales.customerorder.tempoorchestrator.service.ErrorInformation;
import com.adeo.sales.customerorder.tempoorchestrator.service.impl.DomainEventServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Component;
import org.springframework.transaction.ReactiveTransactionManager;
import org.springframework.transaction.reactive.TransactionalOperator;
import org.springframework.util.CollectionUtils;
import reactor.core.publisher.Mono;

import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.utils.LockUtils.getIdTrimmedUsedToLock;
import static com.adeo.sales.customerorder.tempoorchestrator.utils.LockUtils.getTransactionDefinition;
import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@Component
@RequiredArgsConstructor
@Slf4j
public class CapturePaymentCapturedApplicationService {
    private final RuleEngineService ruleEngineService;
    private final DomainEventServiceImpl domainEventServiceACL;
    private final CreateOrUpdateCustomerOrderApplicationService createOrUpdateCustomerOrderApplicationService;
    private final ReactiveTransactionManager transactionManager;
    private final LockPosgresRepository lockPosgresRepository;


    public Mono<Void> apply(CapturePaymentCapturedInput input) {
        return this.lockAndGetDataThenUpdate(input)
            .onErrorResume(CustomerOrderNotFound.class, error -> this.initCustomerOrder(input)
                .onErrorResume(
                    CustomerOrderAlreadyExists.class,
                    errorCreation -> this.lockAndGetDataThenUpdate(input)
                ))
            .then();
    }

    public Mono<Void> initCustomerOrder(CapturePaymentCapturedInput input) {
        final CustomerOrder customerOrderToCreate = buildCustomerOrder(input);

        final List<LineExecution> linesExecutionToCreate = buildLineExecution(input);

        if (CollectionUtils.isEmpty(linesExecutionToCreate)) {
            final var information = new ErrorInformation(
                "The customer order has not products.",
                "Tempo orchestrator can not manage empty customer order.",
                "EMPTY_CUSTOMER_ORDER"
            );
            return this.domainEventServiceACL.sendCustomerOrderCreationFailed(customerOrderToCreate, information);
        }

        TransactionalOperator rxtx = TransactionalOperator.create(transactionManager, getTransactionDefinition(this));

        return rxtx.transactional(
            this.createOrUpdateCustomerOrderApplicationService.createOrderAndLines(customerOrderToCreate, linesExecutionToCreate)
        ).then(rxtx.transactional(
            ruleEngineService.lockCustomerOrderThenstartRuleEngineAndUpdateLines(customerOrderToCreate.getId(), customerOrderToCreate.getBuCode())
        ));

    }

    private static CustomerOrder buildCustomerOrder(CapturePaymentCapturedInput input) {
        return CustomerOrder.builder()
            .id(input.getCustomerOrderId())
            .buCode(input.getBuCode())
            .version(1)
            .build();
    }

    @NotNull
    private List<LineExecution> buildLineExecution(CapturePaymentCapturedInput input) {
        return input.getCapturedLines().stream().map(inputCapturedLine -> LineExecution.builder()
            .version(1)
            .lineId(inputCapturedLine.getLineId())
            .customerOrderId(input.getCustomerOrderId())
            .lineType(LineType.OFFER)
            .buCode(input.getBuCode())
            .payment(LineExecutionPayment.builder()
                .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.PSR)
                .isCaptureGuarantee(true)
                .isDelayedPayment(false)
                .paymentExecution(LineExecutionPaymentExecution.builder()
                    .flags(this.buildPaymentExecutionFlags())
                    .build())
                .build())
            .build()).toList();
    }

    private Flags<PaymentOperationType> buildPaymentExecutionFlags() {
        Flags<PaymentOperationType> flags = new Flags<>();
        flags.raiseFlag(PaymentOperationType.AUTHORIZED);
        flags.raiseFlag(PaymentOperationType.CAPTURED);
        return flags;
    }


    public Mono<Void> lockAndGetDataThenUpdate(CapturePaymentCapturedInput input) {
        long idToLock = getIdTrimmedUsedToLock(input.getCustomerOrderId());
        TransactionalOperator rxtx = TransactionalOperator.create(transactionManager, getTransactionDefinition(this));
        return rxtx.transactional(lockPosgresRepository.acquireLocks(idToLock)
            .then(this.ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
            .doOnNext(
                consumer((customerOrder, lineExecutions, alerts) -> this.updateLines(input, lineExecutions))
            )
            .flatMap(function(ruleEngineService.startRuleEngineAndUpdateLines())));
    }

    private void updateLines(CapturePaymentCapturedInput input, List<LineExecution> lineExecutions) {
        for (final var capturedLine : input.getCapturedLines()) {
            markV2AsCaptured(lineExecutions, capturedLine);
        }
    }

    private void markV2AsCaptured(List<LineExecution> lineExecutions, CapturePaymentCapturedInput.CapturedLine capturedLine) {
        final var optionalLineExecution = LineExecution.getById(lineExecutions, capturedLine.getLineId());
        optionalLineExecution.ifPresent(lineExecution -> {
            if (optionalLineExecution.get().getPayment().getPaymentExecution().getFlags().hasNoFlags()) {
                optionalLineExecution.get().getPayment().getPaymentExecution().getFlags().raiseFlag(PaymentOperationType.AUTHORIZED);
            }
            optionalLineExecution.get().getPayment().getPaymentExecution().getFlags().raiseFlag(PaymentOperationType.CAPTURED);
        });
    }

}
