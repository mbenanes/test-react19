package com.adeo.sales.customerorder.tempoorchestrator.model.customerorder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Offer {

    private String contextId;
    private String id;
    private String vendorId;
    private Boolean isSoldByAThirdPartyVendor;
    private String adeoKey;
    private String refLM;
    private String type;
}
