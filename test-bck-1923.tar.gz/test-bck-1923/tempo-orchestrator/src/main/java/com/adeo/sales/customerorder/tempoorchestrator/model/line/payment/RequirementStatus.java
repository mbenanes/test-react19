package com.adeo.sales.customerorder.tempoorchestrator.model.line.payment;

public enum RequirementStatus {
    COMPLIANT, NOT_COMPLIANT, REQUESTED, APPROVED, REJECTED, FAILED, UNEXEC_REQUESTED, UNEXEC_APPROVED,UNEXEC_REJECTED, UNEXEC_FAILED;

    public static RequirementStatus getStatusByBoolean(boolean compliant) {
        return compliant ? COMPLIANT : NOT_COMPLIANT;
    }
}
