package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.HAS_ALERT_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_REASON_CUSTOMER_CANCELLATION_FAILURE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_REASON_ORDER_CREATION_FAILURE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_REASON_OUT_OF_STOCK;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_TYPE_PROMISE_DATE_NOT_CLOSED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.buildAlertReason;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.getAlertsContainingAllLinesByPredicate;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_REJECTED;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Close1PAlertForRejectedLines",
    description = "Close promised date alert an reason in (LATE, FORECASTED_LATE, CREATION_FAILURE, OUT_OF_STOCK)",
    priority = 990)
public class Close1PAlertForRejectedLinesRule {
    private final AlertMessageService notifier;
    private static final Predicate<LineExecution> IS_1P_DELIVERY_REJECTED = IS_1P.and(IS_DELIVERY_REJECTED);
    private static final Predicate<Alert> IS_ALERT_CLOSABLE_FOR_REJECTED_LINE =
        HAS_ALERT_ID
            .and(IS_TYPE_PROMISE_DATE_NOT_CLOSED)
            .and(Predicate.not(IS_REASON_OUT_OF_STOCK))
            .and(Predicate.not(IS_REASON_ORDER_CREATION_FAILURE))
            .and(Predicate.not(IS_REASON_CUSTOMER_CANCELLATION_FAILURE));

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(IS_1P_DELIVERY_REJECTED) && context.hasAtLeastOneAlert(IS_ALERT_CLOSABLE_FOR_REJECTED_LINE);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var rejectedLineIds = context.getOrderData().getLineIdsByPredicate(IS_1P_DELIVERY_REJECTED);

        final var closableAlertForRejectedLine = getAlertsContainingAllLinesByPredicate(context, rejectedLineIds, IS_ALERT_CLOSABLE_FOR_REJECTED_LINE);

        return MonoUtil.infoLog("INTERNAL request close 1P alert for alerts: {} because all lines has delivery rejected.", Alert.joinAlertIds(closableAlertForRejectedLine))
            .then(Mono.when(
                closableAlertForRejectedLine.stream()
                    .map(alert -> this.notifier.sendCloseAlertMessage(alert, buildAlertReason(alert, rejectedLineIds, context)))
                    .collect(Collectors.toList())
            ));
    }
}
