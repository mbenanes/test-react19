package com.adeo.sales.customerorder.tempoorchestrator.service;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ErrorInformation {
    private final String title;
    private final String detail;
    private final String code;
}
