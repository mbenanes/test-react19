package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.ApplicationProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.repository.AlertRepository;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.AlertMessageInput;
import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_NOT_CLOSED_PROMISE_DATE_ALERT_PREDICATE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.isMaxCreatedAlertByCustomerOrderReached;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DECLARED_DELIVERED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELAY_TYPE_LATE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELAY_TYPE_UNKNOWN_DELAY;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_COMPLETE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static java.util.function.Predicate.not;

@RequiredArgsConstructor
public class AlertWithoutDateAlertRuleCommon {

    protected final AlertRepository alertRepository;
    protected final AlertMessageService alertMessageService;
    protected final ApplicationProperties applicationProperties;

    public static final Predicate<LineExecution> ALERT_CAN_BE_CREATED_LINES = IS_1P
        .and(IS_EXTERNAL_SYSTEM_TEMPO)
        .and(IS_LINE_COMPOSITION_VALIDATED)
        .and(not(IS_DELIVERY_COMPLETE.or(IS_DECLARED_DELIVERED)));
    protected static final Predicate<LineExecution> IS_UNKNOWN_DELAY_ALERT_CAN_BE_OPENED_LINES = ALERT_CAN_BE_CREATED_LINES.and(IS_DELAY_TYPE_UNKNOWN_DELAY);
    protected static final Predicate<LineExecution> IS_LATE_ALERT_CAN_BE_OPENED_LINES = ALERT_CAN_BE_CREATED_LINES.and(IS_DELAY_TYPE_LATE);

    protected boolean whenCreate(RuleEngineContext context, Predicate<LineExecution> linePredicate) {
        return !isMaxCreatedAlertByCustomerOrderReached(context, applicationProperties.getMaxAlertToCreateByCustomerOrder()) &&
            context.isCustomerOrderMatches(IS_VALIDATED) &&
            !this.getLinesWithoutAlerts(context, linePredicate).isEmpty();
    }

    protected Mono<Void> thenCreate(RuleEngineContext context, Predicate<LineExecution> linePredicate, String reason) {
        List<LineExecution> linesWithoutPromiseDateAlerts = this.getLinesWithoutAlerts(context, linePredicate);
        CustomerOrder customerOrder = context.getOrderData().getExistingCustomerOrder();

        final var serviceConfigurationTypes = context.getServiceCategoryTypes();

        final var alertsToCreate = linesWithoutPromiseDateAlerts
            .stream()
            .map(lineExecution -> this.buildNewAlert(customerOrder, lineExecution, reason, serviceConfigurationTypes))
            .toList();

        return this.sendAlerts(linesWithoutPromiseDateAlerts, alertsToCreate, customerOrder);
    }

    protected Mono<Void> sendAlerts(List<LineExecution> lines, List<Alert> alerts, CustomerOrder customerOrder) {
        return this.alertRepository.upsert(alerts)
            .then(Mono.when(
                alerts.stream()
                    .map(alert -> this.sendAlert(lines, alert, customerOrder))
                    .collect(Collectors.toList()))
            );
    }

    private Mono<Alert> sendAlert(List<LineExecution> lineExecutions, Alert alert, CustomerOrder customerOrder) {
        final var associatedLines = lineExecutions.stream()
            .filter(lineExecution -> alert.getImpactedLinesIds().contains(lineExecution.getLineId()))
            .collect(Collectors.toList());

        if (associatedLines.isEmpty()) {
            return Mono.empty();
        }

        return this.alertMessageService.sendCreateAlertMessage(this.toCreateAlertMessageInput(alert, associatedLines, customerOrder)).thenReturn(alert);
    }

    private AlertMessageInput toCreateAlertMessageInput(Alert alert, List<LineExecution> lines, CustomerOrder customerOrder) {
        return AlertMessageInput.builder()
            .alert(alert)
            .lineExecutions(lines)
            .customerOrder(customerOrder)
            .build();
    }

    protected Alert buildNewAlert(CustomerOrder customerOrder, LineExecution lineExecution, String reason, List<String> serviceConfigurationTypes) {
        final Map<String, List<String>> impactedLineByExecution = Map.of(Optional.ofNullable(lineExecution.getExecutionId()).orElse(lineExecution.getCustomerOrderId()), List.of(lineExecution.getLineId()));
        final var shippingPoint = lineExecution.getDelivery().getShippingPoint();
        final var paymentOrchestratingSystem = lineExecution.getPayment().getPaymentExecutionSystem();

        final var lineMetadataById = Map.of(lineExecution.getLineId(), AlertSpecificData.LineMetadata.fromOrderAndLine(customerOrder, lineExecution));

        return Alert.buildNewAlert(customerOrder.getId(), customerOrder.getBuCode(), impactedLineByExecution, shippingPoint.name(), reason, lineExecution.getDelivery().getInitialPromiseDate(), null, null, lineExecution.getDelivery().getCustomerKnownDeliveryDate(), paymentOrchestratingSystem, serviceConfigurationTypes, lineMetadataById);
    }

    protected List<LineExecution> getLinesWithoutAlerts(RuleEngineContext context, Predicate<LineExecution> impactedLinesPredicate) {
        final var rejectedLines = context.getOrderData().getLineExecutionsByPredicate(impactedLinesPredicate);
        return RuleEngineCompensationAlertsConditions.findLinesWithoutAlertsByPredicate(context, rejectedLines, IS_NOT_CLOSED_PROMISE_DATE_ALERT_PREDICATE);
    }

}
