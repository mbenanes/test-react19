package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.input;

import lombok.Builder;
import lombok.Value;

import java.util.List;
import java.util.Map;

@Value
@Builder
public class DeliveryCanceledInput {
    Map<CancellationReason, List<String>> rejectLineIdByReason;
    List<String> linesIdToClose;
    String externalSystemId;
    String customerOrderId;
    String buCode;
    String updatedBy;

    public enum CancellationReason {
        PAYMENT_ERROR, OPERATOR_CANCEL, CANCELED_BY_VENDOR
    }
}
