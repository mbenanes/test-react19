package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.service.dto.ValuateStockDto;
import reactor.core.publisher.Mono;

public interface ValuateStockService {
    Mono<Void> sendValuateStockRequest(ValuateStockDto valuateStockDto);
}
