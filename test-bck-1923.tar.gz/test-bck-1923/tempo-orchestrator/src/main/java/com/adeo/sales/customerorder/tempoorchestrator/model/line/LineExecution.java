package com.adeo.sales.customerorder.tempoorchestrator.model.line;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.Offer;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDeliveryCollect;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPaymentRequirements;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LineExecution {
    private String executionId;

    //used to update lineexecution when we retrieve deliveryType
    @JsonIgnore
    private String newExecutionId;
    private String lineId;
    private String customerOrderId;
    private LineType lineType;
    private String buCode;
    private boolean isSoldByAThirdPartyVendor;
    private List<String> sentMails;
    private int version;
    private BigDecimal quantity;
    private BigDecimal initialQuantity;

    @JsonIgnore
    private boolean versionIncreased;
    private ExternalSystem externalSystem;
    private LineExecutionPayment payment;
    private LineExecutionDelivery delivery;
    private LineExecutionComposition composition;
    private ConfigurationService configurationService;
    private LineExecutionPaymentRequirements paymentRequirements;

    public void increaseVersion() {
        if (!this.versionIncreased) {
            this.version++;
            this.versionIncreased = true;
        }
    }

    public static String joinLineIds(List<LineExecution> lines) {
        return lines
            .stream()
            .map(LineExecution::getLineId)
            .collect(Collectors.joining(","));
    }

    public static List<String> lineIds(List<LineExecution> lines) {
        return lines
            .stream()
            .map(LineExecution::getLineId)
            .collect(Collectors.toList());
    }

    public static Optional<LineExecution> getById(List<LineExecution> existingLineExecution, String lineId) {
        return existingLineExecution.stream()
            .filter(lineExecution -> lineExecution.getLineId().equals(lineId))
            .findFirst();
    }

    public BigDecimal getQuantity() {
        if (this.quantity != null) {
            return this.quantity;
        } else if (this.getComposition().getQuantity() != null) {
            return this.getComposition().getQuantity();
        }
        return null;
    }

    public BigDecimal getInitialQuantity() {
        if (this.initialQuantity != null) {
            return this.initialQuantity;
        } else if (this.getComposition().getQuantity() != null) {
            return this.getComposition().getQuantity();
        }
        return null;
    }


    public LineExecutionPayment getPayment() {
        if (payment == null) {
            this.payment = new LineExecutionPayment();

        }
        return payment;
    }

    public LineExecutionDelivery getDelivery() {
        if (this.delivery == null) {
            this.delivery = new LineExecutionDelivery();
        }
        return delivery;
    }

    public LineExecutionComposition getComposition() {
        if (this.composition == null) {
            this.composition = new LineExecutionComposition();
        }
        return composition;
    }


    public boolean isMailAlreadySent(String templateType) {
        return sentMails != null && sentMails.contains(templateType);
    }

    public void mailIsSent(String templateType) {
        if (this.sentMails == null) {
            this.sentMails = new ArrayList<>();
        }
        this.sentMails.add(templateType);
    }

    public static Optional<LineExecution> getCorrespondingLine(List<LineExecution> lineExecutions, String lineId) {
        return lineExecutions.stream()
            .filter(lineExecution -> lineExecution.getLineId().equals(lineId))
            .findFirst();
    }

    public static List<LineExecution> getCorrespondingLines(List<LineExecution> lineExecutions, String lineId) {
        return lineExecutions.stream()
            .filter(lineExecution -> lineExecution.getLineId().equals(lineId))
            .toList();
    }

    public static Optional<LineExecution> getCorrespondingLineAndExecution(List<LineExecution> lineExecutions, String lineId, String executionId) {
        return lineExecutions.stream()
            .filter(lineExecution -> lineExecution.getLineId().equals(lineId) && lineExecution.getExecutionId().equals(executionId))
            .findFirst();
    }

    public static List<LineExecution> getLineExecutionsByPredicate(List<LineExecution> lineExecutions, Predicate<LineExecution> predicate) {
        return lineExecutions.stream()
            .filter(predicate)
            .collect(Collectors.toList());
    }

    public void updateExternalSystemId(String externalOrchestratorId) {
        if (this.externalSystem != null && this.externalSystem.isBomp()) {
            this.externalSystem.setId(externalOrchestratorId);
            this.composition.setOrderPartNumber(externalOrchestratorId.substring(4));
        }
    }

    public void fillExternalReferenceFieldsFromDelivery(String storeCode, String systemId) {
        if (this.externalSystem != null && this.externalSystem.isPyxis()) {
            this.getComposition().setOrderPartNumber(systemId);
            this.externalSystem.setId(systemId);
            this.externalSystem.setStoreCode(storeCode);
        }
    }

    public void setUpTempoFlags(String customerOrderNumber) {
        this.getComposition().setOrderPartNumber(customerOrderNumber + "-1");
        this.getComposition().setCancelable(false);
        this.getDelivery().setCancelable(false);
        this.getDelivery().setForceCancelable(false);
        this.getDelivery().setIsDeliveryDateUpdatable(false);
    }

    public LineExecutionPaymentRequirements getPaymentRequirements() {
        if (paymentRequirements == null) {
            paymentRequirements = new LineExecutionPaymentRequirements();
        }
        return paymentRequirements;
    }

    public LineExecution cloneLineExecution() {

        final LineExecutionDelivery lineExecutionDelivery = LineExecutionDelivery.builder()
            .deliveryType(this.getDelivery().getDeliveryType())
            .collect(LineExecutionDeliveryCollect.builder()
                .build())
            .delayType(this.getDelivery().getDelayType())
            .shippingPoint(this.getDelivery().getShippingPoint())
            .deliveryLegacyNumber(this.getDelivery().getDeliveryLegacyNumber())
            .incoterm(this.getDelivery().getIncoterm())
            .cancelable(this.getDelivery().getCancelable())
            .forceCancelable(this.getDelivery().getForceCancelable())
            .customerKnownDeliveryDate(this.getDelivery().getCustomerKnownDeliveryDate())
            .estimatedDeliveryDate(this.getDelivery().getEstimatedDeliveryDate())
            .idDelivery(this.getDelivery().getIdDelivery())
            .estimatedDeliveryDateUpdatedBy(this.getDelivery().getEstimatedDeliveryDateUpdatedBy())
            .newDeliveryDate(this.getDelivery().getNewDeliveryDate())
            .isDeliveryDateUpdatable(this.getDelivery().getIsDeliveryDateUpdatable())
            .initialPromiseDate(this.getDelivery().getInitialPromiseDate())
            .build();

        this.getDelivery().getFlags().getOrderedByDateFlags()
            .forEach(flag -> lineExecutionDelivery.getFlags().raiseFlagIfNot(Flag.builder().dateTime(flag.getDateTime()).type(flag.getType()).operationId(flag.getOperationId()).failedReason(flag.getFailedReason()).build()));

        final LineExecutionComposition lineExecutionComposition = LineExecutionComposition.builder()
            .flags(null)
            .quotationValidationAsked(this.getComposition().isQuotationValidationAsked())
            .quotationValidated(this.getComposition().isQuotationValidated())
            .executionSelector(this.getComposition().getExecutionSelector())
            .orderPartNumber(this.getComposition().getOrderPartNumber())
            .offer(Offer.builder()
                .id(this.getComposition().getOffer().getId())
                .refLM(this.getComposition().getOffer().getRefLM())
                .adeoKey(this.getComposition().getOffer().getAdeoKey())
                .type(this.getComposition().getOffer().getType())
                .isSoldByAThirdPartyVendor(this.getComposition().getOffer().getIsSoldByAThirdPartyVendor())
                .contextId(this.getComposition().getOffer().getContextId())
                .build())
            .quantity(this.getComposition().getQuantity())
            .cancellationReason(this.getComposition().getCancellationReason())
            .createdBy(this.getComposition().getCreatedBy())
            .createdAt(this.getComposition().getCreatedAt())
            .legacyNumber(this.getComposition().getLegacyNumber())
            .promisedDateConfirmed(this.getComposition().isPromisedDateConfirmed())
            .cancelable(this.getComposition().isCancelable())
            .legacyNumber(this.getComposition().getLegacyNumber())
            .build();

        this.getComposition().getFlags().getOrderedByDateFlags()
            .forEach(flag -> lineExecutionComposition.getFlags().raiseFlagIfNot(Flag.builder().dateTime(flag.getDateTime()).type(flag.getType()).operationId(flag.getOperationId()).failedReason(flag.getFailedReason()).build()));

        final ConfigurationService configurationService = this.getConfigurationService() != null ?
            ConfigurationService.builder()
                .associatedLinesId(this.getConfigurationService().getAssociatedLinesId())
                .id(this.getConfigurationService().getId())
                .build()
            : null;

        final ExternalSystem externalSystem = ExternalSystem.builder()
            .name(this.getExternalSystem().getName())
            .origin(this.getExternalSystem().getOrigin())
            .id(this.getExternalSystem().getId())
            .storeCode(this.getExternalSystem().getStoreCode())
            .build();

        final LineExecutionPaymentRequirements lineExecutionPaymentRequirements = LineExecutionPaymentRequirements.builder()
            .validationFlags(null)
            .confirmationFlags(null)
            .amount(this.getPaymentRequirements().getAmount())
            .deliveryAmount(this.getPaymentRequirements().getDeliveryAmount())
            .versionMismatch(this.getPaymentRequirements().isVersionMismatch())
            .build();

        lineExecutionPaymentRequirements.getValidationFlags()
            .getOrderedByDateFlags().add(Flag.builder()
                .type(this.getPaymentRequirements().getValidationFlags().getLastFlag().getType())
                .operationId(this.getPaymentRequirements().getValidationFlags().getLastFlag().getOperationId())
                .dateTime(this.getPaymentRequirements().getValidationFlags().getLastFlag().getDateTime())
                .build());

        lineExecutionPaymentRequirements.getConfirmationFlags()
            .getOrderedByDateFlags().add(Flag.builder()
                .type(this.getPaymentRequirements().getConfirmationFlags().getLastFlag().getType())
                .operationId(this.getPaymentRequirements().getConfirmationFlags().getLastFlag().getOperationId())
                .dateTime(this.getPaymentRequirements().getConfirmationFlags().getLastFlag().getDateTime())
                .build());

        final LineExecutionPayment lineExecutionPayment = LineExecutionPayment.builder()
            .paymentExecutionSystem(this.getPayment().getPaymentExecutionSystem())
            .storeId(this.getPayment().getStoreId())
            .cashierLegacyNumber(this.getPayment().getCashierLegacyNumber())
            .depositLegacyNumber(this.getPayment().getDepositLegacyNumber())
            .legacyNumbersStatus(this.getPayment().getLegacyNumbersStatus())
            .isDepositLegacyNumberNotOwnedByTor(this.getPayment().isDepositLegacyNumberNotOwnedByTor())
            .build();

        return LineExecution.builder()
            .executionId(this.getExecutionId())
            .lineId(this.getLineId())
            .lineType(this.getLineType())
            .buCode(this.getBuCode())
            .composition(lineExecutionComposition)
            .delivery(lineExecutionDelivery)
            .configurationService(configurationService)
            .externalSystem(externalSystem)
            .paymentRequirements(lineExecutionPaymentRequirements)
            .customerOrderId(this.getCustomerOrderId())
            .isSoldByAThirdPartyVendor(this.isSoldByAThirdPartyVendor())
            .payment(lineExecutionPayment)
            .initialQuantity(this.getInitialQuantity())
            .newExecutionId(this.getNewExecutionId())
            .version(this.getVersion())
            .sentMails(this.getSentMails())
            .versionIncreased(this.isVersionIncreased())
            .build();
    }

    public static Map<String, List<LineExecution>> linesIdByExecutionId(List<LineExecution> lineExecutions) {
        return lineExecutions.stream().collect(Collectors.groupingBy(LineExecution::getExecutionId));
    }

}
