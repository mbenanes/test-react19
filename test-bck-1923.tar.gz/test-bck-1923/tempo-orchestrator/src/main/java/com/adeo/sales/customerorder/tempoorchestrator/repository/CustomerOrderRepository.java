package com.adeo.sales.customerorder.tempoorchestrator.repository;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface CustomerOrderRepository {

    Mono<Void> saveCustomerOrder(final CustomerOrder customerOrder);

    Mono<CustomerOrder> getByIdForUpdate(final String id, String buCode);

    Mono<Void> updateCustomerOrder(CustomerOrder updatedCustomerOrder);

    /**
     * insert the customer order to lock it
     * @param customerOrderId the customer order id
     * @param buCode the bu code
     * @return true if the customer order has been inserted, false otherwise
     */
    Mono<Boolean> insertForLock(String customerOrderId, String buCode);

    Flux<CustomerOrder> getTppRequirementToCheckCustomerOrder();

    Mono<Boolean> isSelfServiceOrder(String customerOrderId, String buCode);
}
