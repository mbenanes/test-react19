package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.input.PaymentOperationInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationTechnicalStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.PaymentOperationType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationType.CANCEL_AUTHORIZATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationType.CANCEL_PAYMENT;
import static com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationType.REFUND;
import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@Slf4j
@RequiredArgsConstructor
@Service
public class PaymentOperationApplicationService {
    private final RuleEngineService ruleEngineService;

    public Mono<Void> apply(PaymentOperationInput input) {
        return ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode())
            .doOnNext(
                consumer((customerOrder, lineExecutions, alerts) -> this.updateFlagsAndStatus(input, lineExecutions))
            )
            .flatMap(function(ruleEngineService.startRuleEngineAndUpdateLines()));
    }

    private void updateFlagsAndStatus(PaymentOperationInput input, List<LineExecution> lineExecutions) {
        input.getInputLineIdsByOperationKey().forEach((operationKey, inputLineIds) ->
            inputLineIds.forEach(lineId -> {
                this.updateLineExecution(operationKey, lineExecutions, lineId);
            })
        );
    }

    private void updateLineExecution(PaymentOperationInput.OperationKey operationKey, List<LineExecution> lineExecutions, String lineId) {
        lineExecutions.stream()
            .filter(lineExecution -> lineId.equals(lineExecution.getLineId()))
            .forEach(lineExecution -> this.raisePaymentExecutionFlag(lineExecution, operationKey));
    }


    private void raisePaymentExecutionFlag(LineExecution lineExecution, PaymentOperationInput.OperationKey operationKey) {
        if (operationKey.getType() == CANCEL_PAYMENT) {
            if (operationKey.getStatus() == PaymentOperationTechnicalStatus.SUCCEED) {
                lineExecution.getPayment().getPaymentExecution().getFlags().raiseFlagIfNot(operationKey.getOperationId(), PaymentOperationType.CAPTURE_CANCELED, OffsetDateTime.now());
            } else if (operationKey.getStatus() == PaymentOperationTechnicalStatus.REJECTED) {
                lineExecution.getPayment().getPaymentExecution().getFlags().raiseFlagIfNot(operationKey.getOperationId(), PaymentOperationType.CANCEL_CAPTURE_FAILED, OffsetDateTime.now());
            }
        } else if (operationKey.getType() == CANCEL_AUTHORIZATION) {
            if (operationKey.getStatus() == PaymentOperationTechnicalStatus.SUCCEED) {
                lineExecution.getPayment().getPaymentExecution().getFlags().raiseFlagIfNot(operationKey.getOperationId(), PaymentOperationType.AUTHORIZATION_CANCELED, OffsetDateTime.now());
            } else if (operationKey.getStatus() == PaymentOperationTechnicalStatus.REJECTED) {
                lineExecution.getPayment().getPaymentExecution().getFlags().raiseFlagIfNot(operationKey.getOperationId(), PaymentOperationType.AUTHORIZATION_CANCEL_FAILED, OffsetDateTime.now());
            }
        } else if (operationKey.getType() == REFUND) {
            if (operationKey.getStatus() == PaymentOperationTechnicalStatus.DELAYED) {
                lineExecution.getPayment().getPaymentExecution().getFlags().raiseFlagIfNotSameOperationId(operationKey.getOperationId(), PaymentOperationType.REFUND_DELAYED, OffsetDateTime.now());
            } else if (operationKey.getStatus() == PaymentOperationTechnicalStatus.REJECTED) {
                lineExecution.getPayment().getPaymentExecution().getFlags().raiseFlagIfNotSameOperationId(operationKey.getOperationId(), PaymentOperationType.REFUND_FAILED, OffsetDateTime.now());
            }
        }
    }
}
