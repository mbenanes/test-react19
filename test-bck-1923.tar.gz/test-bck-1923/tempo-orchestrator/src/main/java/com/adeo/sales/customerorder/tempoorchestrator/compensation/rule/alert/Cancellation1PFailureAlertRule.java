package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertReason;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.PromisedDateSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.AlertMessageInput;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate.getMaxCustomerKnownDeliveryDate;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_REASON_CUSTOMER_CANCELLATION_FAILURE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_DELIVERY_ABORT_FAILED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Cancellation1PFailureRule",
    description = "Cancellation order failure.",
    priority = 990)
public class Cancellation1PFailureAlertRule {

    private final AlertMessageService alertMessageService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var allFailedLines = context.getOrderData().getLineExecutionsByPredicate(HAS_DELIVERY_ABORT_FAILED);
        if (allFailedLines.isEmpty()) {
            return false;
        } else {
            return context.getOrderData().hasAtLeastOneExecutionRespectPredicate(PAYMENT_ORCHESTRATED_BY_PSR) && allFailedLines
                .stream()
                .filter(lineExecution -> !lineExecution.getDelivery().isShippedByPartner())
                .anyMatch(lineExecution -> context.getAlertData().getAlertsFor(lineExecution, IS_REASON_CUSTOMER_CANCELLATION_FAILURE).isEmpty());
        }
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var cancellationFailureLinesWithoutAlerts = context.getOrderData().getLineExecutionsByPredicate(HAS_DELIVERY_ABORT_FAILED)
            .stream()
            .filter(lineExecution -> !lineExecution.getDelivery().isShippedByPartner())
            .filter(lineExecution -> context.getAlertData().getAlertsFor(lineExecution, IS_REASON_CUSTOMER_CANCELLATION_FAILURE).isEmpty())
            .collect(Collectors.toList());

        final var customerKnownDeliveryDate = getMaxCustomerKnownDeliveryDate(cancellationFailureLinesWithoutAlerts);
        final var alert = this.buildAlert(context, cancellationFailureLinesWithoutAlerts, DeliveryDate.getMaxDate(customerKnownDeliveryDate));

        return Mono.when(
            this.alertMessageService.sendCreateAlertMessage(this.buildAlertMessageInput(alert, cancellationFailureLinesWithoutAlerts, context.getOrderData().getExistingCustomerOrder()))
        ).then(Mono.fromRunnable(() -> context.getAlertData().addAlert(alert)));
    }


    private Alert buildAlert(RuleEngineContext context, List<LineExecution> linesToCreateAlert, OffsetDateTime customerKnownDeliveryDate) {
        final var alertId = UUID.randomUUID();

        final var lineMetadataByLineId = linesToCreateAlert.stream()
            .collect(Collectors.toMap(
                LineExecution::getLineId,
                line -> AlertSpecificData.LineMetadata.fromOrderAndLine(context.getOrderData().getExistingCustomerOrder(), line)
            ));

        return Alert.builder()
            .id(alertId)
            .specificData(
                PromisedDateSpecificData.builder()
                    .reason(AlertReason.CUSTOMER_CANCELLATION_FAILURE.name())
                    .lineMetadataByLineId(lineMetadataByLineId)
                    .receivedAt(OffsetDateTime.now())
                    .requestId(alertId.toString())
                    .build()
            )
            .impactedLinesIds(LineExecution.lineIds(linesToCreateAlert))
            .customerOrderId(context.getCustomerOrderId())
            .customerKnownDeliveryDate(customerKnownDeliveryDate)
            .buCode(context.getBuCode())
            .status(AlertStatus.CREATION_REQUESTED)
            .build();
    }

    private AlertMessageInput buildAlertMessageInput(Alert alert, List<LineExecution> impactedLines, CustomerOrder customerOrder) {
        return AlertMessageInput.builder()
            .alert(alert)
            .lineExecutions(impactedLines)
            .customerOrder(customerOrder)
            .build();
    }
}
