package com.adeo.sales.customerorder.tempoorchestrator.handler.psr;

import com.adeo.sales.customerorder.paymentscheduler.v2.payment.domainevent.LineRefundDelayed;
import com.adeo.sales.customerorder.paymentscheduler.v2.payment.domainevent.PaymentRefundDelayed;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.PaymentOperationApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.input.PaymentOperationInput;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationTechnicalStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.util.stream.Collectors;


@RequiredArgsConstructor
@Component
public class PaymentRefundDelayedHandler implements EventHandler<PaymentRefundDelayed> {
    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final PaymentOperationApplicationService applicationService;

    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    @Override
    public Mono<Void> handle(PaymentRefundDelayed event, EventMetaData eventMetaData) {
        final var customerOrderId = event.getState().getVectorClock().getCustomerOrder().getId();
        this.mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderId);
        final var buCode = eventMetaData.getBuCode();

        final var inputLineIdsByOperation = event.getDelta().getLines().stream()
            .filter(lineRefundFailed -> lineRefundFailed.getLineType().equals("OFFER_LINE"))
            .collect(Collectors.groupingBy(LineRefundDelayed::getOperationId, Collectors.mapping(LineRefundDelayed::getLineId, Collectors.toList())));

        PaymentOperationInput input = PaymentOperationInput.buildInputFromEvent(event.getState().getRefunds(), inputLineIdsByOperation, customerOrderId, buCode, PaymentOperationTechnicalStatus.DELAYED);
        return this.applicationService.apply(input);
    }

    @Override
    public Class<?> getManagedEvent() {
        return PaymentRefundDelayed.class;
    }
}
