package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.alerting;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.DelayedLine;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.FulfillmentMapExecutionDelayAlertInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DelayType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@RequiredArgsConstructor
@Component
@Slf4j
public class DelayedDeliveryLateApplicationService {

    private final RuleEngineService ruleEngineService;

    public Mono<Void> apply(FulfillmentMapExecutionDelayAlertInput input) {
        return this.ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode())
            .doOnNext(consumer((customerOrder, lineExecutions) -> this.markLinesAsLate(lineExecutions, input.getDelayedLines())))
            .flatMap(function(ruleEngineService.startRuleEngineAndUpdateLines()));
    }

    private void markLinesAsLate(List<LineExecution> lineExecutions, List<DelayedLine> delayedLines) {
        List<String> impactedLines = delayedLines.stream().map(DelayedLine::getLineId).toList();
        lineExecutions
            .stream()
            .filter(lineExecution -> impactedLines.contains(lineExecution.getLineId()))
            .forEach(lineExecution -> Optional.ofNullable(lineExecution.getDelivery().getDelayType())
                .ifPresentOrElse(delayType -> log.warn("line {} is already {}, LATE delay alert will not be taken into account", lineExecution.getLineId(), delayType),
                    () -> lineExecution.getDelivery().setDelayType(DelayType.LATE)));
    }
}
