package com.adeo.sales.customerorder.tempoorchestrator.handler.poslog.dto;

import com.adeo.payment.data.repository.avro.AdeoExternalLink;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.function.Predicate;

@Data
@Builder
public class PosLogDeposit {

    private final String customerOrderId;
    private final String accountNumber;
    private final BigDecimal amount;

    public static final Predicate<AdeoExternalLink> HAS_TEMPO_EXTERNAL_LINK = link -> "tempo-id".equals(link.getTypeCode());

}
