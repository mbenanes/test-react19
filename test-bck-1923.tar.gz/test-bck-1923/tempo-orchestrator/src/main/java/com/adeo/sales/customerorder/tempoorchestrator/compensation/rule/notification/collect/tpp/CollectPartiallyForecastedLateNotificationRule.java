package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.collect.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.NotificationStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExecutionWithLines;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECT_APPOINTMENT_DATE_AFTER_DELIVERY_DATE_OR_NOT_EXISTING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_TPP_COLLECT_IN_PROGRESS;
import static java.util.function.Predicate.not;

@RequiredArgsConstructor
@Slf4j
@Component
@Rule(name = "CollectPartiallyForecastedLateNotificationRule",
    description = "Send communication when partially collect line are on forecasted late regarding appointment date to invite customer to change appointment if he want get all product at the same time",
    priority = 1000)
public class CollectPartiallyForecastedLateNotificationRule {

    public static final Predicate<LineExecution> PARTIAL_DELAYED_COMMUNICATION_ALREADY_SEND = lineExecution -> lineExecution.getDelivery() != null && lineExecution.getDelivery().getCollect() != null && NotificationStatus.NOTIFICATION_REQUESTED.equals(lineExecution.getDelivery().getCollect().getPartialDelayedNotificationStatus());

    private final OutgoingNotificationService outgoingNotificationService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.getOrderData().getExistingExecutionsWithLines()
            .stream()
            .map(ExecutionWithLines::getLineExecutions)
            .anyMatch(lineExecutions -> {
                final List<LineExecution> collectlineExecutionsInProgress = lineExecutions.stream()
                    .filter(IS_TPP_COLLECT_IN_PROGRESS.and(not(PARTIAL_DELAYED_COMMUNICATION_ALREADY_SEND)))
                    .toList();

                return !collectlineExecutionsInProgress.isEmpty() &&
                    !(collectlineExecutionsInProgress.stream()
                        .noneMatch(IS_COLLECT_APPOINTMENT_DATE_AFTER_DELIVERY_DATE_OR_NOT_EXISTING) ||
                    collectlineExecutionsInProgress.stream()
                        .allMatch(IS_COLLECT_APPOINTMENT_DATE_AFTER_DELIVERY_DATE_OR_NOT_EXISTING));
            });
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return Flux.fromIterable(context.getOrderData().getExistingExecutionsWithLines()
            .stream()
            .map(ExecutionWithLines::getLineExecutions)
            .filter(lineExecutions -> {
                final List<LineExecution> collectlineExecutionsInProgress = lineExecutions.stream()
                    .filter(IS_TPP_COLLECT_IN_PROGRESS)
                    .toList();

                return !collectlineExecutionsInProgress.isEmpty() &&
                    !(collectlineExecutionsInProgress.stream()
                        .noneMatch(IS_COLLECT_APPOINTMENT_DATE_AFTER_DELIVERY_DATE_OR_NOT_EXISTING) ||
                        collectlineExecutionsInProgress.stream()
                            .allMatch(IS_COLLECT_APPOINTMENT_DATE_AFTER_DELIVERY_DATE_OR_NOT_EXISTING));
            })
                .toList())
            .flatMap(lineExecutions -> {
                final List<LineExecution> collectableLineDelayedDelivery = lineExecutions.stream().filter(not(IS_COLLECT_APPOINTMENT_DATE_AFTER_DELIVERY_DATE_OR_NOT_EXISTING)).toList();
                return outgoingNotificationService.sendCollectPartiallyForecastedLateNotification(context.getOrderData().getExistingCustomerOrder(), collectableLineDelayedDelivery)
                    .doOnSuccess(unused -> collectableLineDelayedDelivery.stream()
                        .map(lineExecution -> lineExecution.getDelivery().getCollect())
                        .forEach(collect -> collect.setPartialDelayedNotificationStatus(NotificationStatus.NOTIFICATION_REQUESTED)));
            })
            .then();
    }
}
