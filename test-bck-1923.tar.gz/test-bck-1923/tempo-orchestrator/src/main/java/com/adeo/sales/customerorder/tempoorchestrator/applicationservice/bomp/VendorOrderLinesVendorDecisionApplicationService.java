package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.input.VendorOrderLinesVendorDecisionInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertReason;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.ACCEPTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.REJECTED;
import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@RequiredArgsConstructor
@Component
@Slf4j
public class VendorOrderLinesVendorDecisionApplicationService {
    private final RuleEngineService ruleEngineService;

    public Mono<Void> apply(VendorOrderLinesVendorDecisionInput input) {
        return this.ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode())
            .onErrorResume(CustomerOrderNotFound.class, error -> MonoUtil.errorLog("The customer order {} does not exist", input.getCustomerOrderId())
            ).doOnNext(consumer((existingCustomerOrder, existingLineExecution, alerts) -> existingLineExecution
                .stream()
                .filter(line -> line.isSoldByAThirdPartyVendor() && input.getOrderLineids().contains(line.getLineId()))
                .forEach(lineExecution -> this.confirmOrderLines(input, lineExecution))
            ))
            .flatMap(function((customerOrder, lineExecutions, alerts, executionActions, executions) ->
                this.ruleEngineService.startRuleEngineAndUpdateLines(customerOrder, lineExecutions, alerts, executionActions, executions)
                    .thenReturn(customerOrder)
            )).then();
    }

    private void confirmOrderLines(VendorOrderLinesVendorDecisionInput input, LineExecution line) {
        if (input.getAcceptedLineIds().contains(line.getLineId()) && line.getDelivery().canBeConfirmedByVendor()) {
            log.info("INTERNAL the customer order line {} is accepted", line.getLineId());
            line.getDelivery().getFlags().raiseFlagIfNot(ACCEPTED);
            line.updateExternalSystemId(input.getBompId());
        } else if (input.getRefusedLineIds().contains(line.getLineId()) && line.getDelivery().canBeRejectedByVendor()) {
            log.info("INTERNAL the customer order line {} is rejected", line.getLineId());
            line.getDelivery().getFlags().raiseFlagIfNot(REJECTED);
            line.updateExternalSystemId(input.getBompId());
            line.getDelivery().setCancelable(true);
            line.getComposition().setCancellationReason(AlertReason.REJECTED_BY_SELLER.name());
        }
    }

}
