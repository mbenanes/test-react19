package com.adeo.sales.customerorder.tempoorchestrator.model.line.execution;

import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Execution {
    String id;
    String customerOrderId;
    String buCode;
    Flags<ExecutionStatus> executionStatus;

    public Flags<ExecutionStatus> getExecutionStatus() {
        if (this.executionStatus == null) {
            this.executionStatus = new Flags<>();
        }
        return executionStatus;
    }
}
