package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.cancelation;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.PostponedEventStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.CustomerOrderService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_NOT_A_DELAYED_PAYMENT_MEAN;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@AllArgsConstructor
@Rule(name = "PostponeInStoreOrderNotPaidCancellationRule",
    description = "Postpone in store order not paid cancel execution.",
    priority = 1001)
public class PostponeInStoreOrderNotPaidCancellationRule {

    private final CustomerOrderService customerOrderService;
    private static final Predicate<LineExecution> IS_1P_VALIDATED_WITHOUT_REQUIREMENT = IS_LINE_COMPOSITION_VALIDATED
        .and(IS_EXTERNAL_SYSTEM_TEMPO)
        .and(PAYMENT_ORCHESTRATED_BY_TPP)
        .and(not(IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT))
        .and(IS_NOT_A_DELAYED_PAYMENT_MEAN);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var autoCancellationNoTRequested = context.getOrderData().getExistingCustomerOrder().getAutoCancellation() == null;
        return autoCancellationNoTRequested &&
            context.hasAtLeastOneLine(IS_1P_VALIDATED_WITHOUT_REQUIREMENT) &&
            context.isCustomerOrderMatches(IS_VALIDATED.and(IS_PLACE_TYPE_IN_STORE));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return MonoUtil.infoLog("INTERNAL postpone in store order cancellation {}", context.getOrderData().getExistingCustomerOrder().getId())
            .then(this.customerOrderService.postponeCancelCustomerOrderLines(context.getOrderData().getExistingCustomerOrder(), context.getOrderData().getExistingLineExecutions(), "IN_STORE_ORDER_NOT_PAID"))
            .then(Mono.fromRunnable(() -> context.getOrderData().getExistingCustomerOrder().setAutoCancellation(PostponedEventStatus.POSTPONED_REQUESTED)));
    }
}
