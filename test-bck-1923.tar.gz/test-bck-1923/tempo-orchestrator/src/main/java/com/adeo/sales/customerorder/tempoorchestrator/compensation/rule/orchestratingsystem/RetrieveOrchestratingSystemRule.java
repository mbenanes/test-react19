package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.orchestratingsystem;

import com.adeo.sales.customerorder.external.api.client.legacyacl.dto.OrchestratingSystemResponse;
import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.LegacyACL;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.NoSystemDefinedException;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_ORCHESTRATING_SYSTEM;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem.SystemName.TEMPO;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "RetrieveOrchestratingSystem",
    description = "Retrieve the customer order orchestrating system from legacy ACL",
    priority = 1)
public class RetrieveOrchestratingSystemRule {

    private final LegacyACL legacyACL;

    private static final Predicate<LineExecution> IS_DOES_NOT_HAVE_ORCHESTRATING_SYSTEM = not(HAS_ORCHESTRATING_SYSTEM);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(IS_DOES_NOT_HAVE_ORCHESTRATING_SYSTEM) &&
            context.getOrderData().getExistingCustomerOrder().getCustomerOrderNumber() != null;
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var linesWithoutOrchestratingSystem = context.getOrderData().getLineExecutionsByPredicate(IS_DOES_NOT_HAVE_ORCHESTRATING_SYSTEM);
        CustomerOrder customerOrder = context.getOrderData().getExistingCustomerOrder();
        return MonoUtil.infoLog("INTERNAL determine orchestrating system for lines: {}", LineExecution.joinLineIds(linesWithoutOrchestratingSystem))
            .then(this.legacyACL.askOrchestratingSystem(customerOrder.getId(), customerOrder.getBuCode()))
            .doOnNext(orchestratingData -> linesWithoutOrchestratingSystem.forEach(lineExecution -> {
                final var systemName = this.getSystemForLine(orchestratingData, lineExecution.getLineId());
                updateLineExecution(lineExecution, systemName, customerOrder);
            })).then();
    }

    private static void updateLineExecution(LineExecution lineExecution, ExternalSystem.SystemName systemName, CustomerOrder customerOrder) {
        lineExecution.setExternalSystem(ExternalSystem.builder()
            .name(systemName)
            .origin(systemName)
            .id(systemName == TEMPO ? customerOrder.getBuCode() + "-" + customerOrder.getCustomerOrderNumber() + "-" + 1 : null)
            .build());
        if (systemName == TEMPO) {
            lineExecution.setUpTempoFlags(customerOrder.getCustomerOrderNumber());
        }
    }

    private ExternalSystem.SystemName getSystemForLine(OrchestratingSystemResponse response, String lineId) {
        final var systemName = response.getData().stream()
            .filter(orchestratingData -> orchestratingData.getCustomerOrderLinesId().contains(lineId))
            .map(OrchestratingSystemResponse.Data::getOrchestratingSystem).toList();
        if (systemName.isEmpty()) {
            throw new NoSystemDefinedException(lineId);
        } else {
            return ExternalSystem.SystemName.valueOf(systemName.get(0));
        }
    }
}
