package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_A_DELAYED_PAYMENT_MEAN;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR;
import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.NotificationStatus.NOTIFICATION_REQUESTED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "CustomerOrderCanceled",
    description = "notify customer when customer order is canceled.",
    priority = 1000)
public class CustomerOrderCanceledRule {

    private final OutgoingNotificationService outgoingNotificationService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var existingCustomerOrder = context.getOrderData().getExistingCustomerOrder();
        final var customerOrderValidationMailHasNotBeenSent = context.getOrderData().getExistingCustomerOrder().getNotificationStatus() == null;
        final var cancelNotificationHasNotBeenSent = existingCustomerOrder.getCancelNotificationStatus() == null;
        final var customerOrderIsCanceled = existingCustomerOrder.getStatus() == CustomerOrderStatus.CANCELED;
        final var isCancelationReasonIsRejectedPayment = "REJECTED_PAYMENT".equals(existingCustomerOrder.getCancelationReason());
        final var isCancelationReasonIsManualCancelationAndFeatureEnabled = "MANUAL_CANCELATION".equals(existingCustomerOrder.getCancelationReason());
        final var isNotLongPayment = context.hasAtLeastOneLine(not(IS_A_DELAYED_PAYMENT_MEAN));
        return context.hasAtLeastOneLine(PAYMENT_ORCHESTRATED_BY_PSR) &&
            customerOrderValidationMailHasNotBeenSent &&
            cancelNotificationHasNotBeenSent &&
            customerOrderIsCanceled &&
            isNotLongPayment &&
            (isCancelationReasonIsRejectedPayment || isCancelationReasonIsManualCancelationAndFeatureEnabled);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var existingCustomerOrder = context.getOrderData().getExistingCustomerOrder();
        log.info("INTERNAL send customer order canceled communication for order {}", existingCustomerOrder.getId());
        return this.outgoingNotificationService.sendPaymentRefusedNotification(existingCustomerOrder)
            .then(Mono.fromRunnable(() -> {
                existingCustomerOrder.setCancelNotificationStatus(NOTIFICATION_REQUESTED);
                context.getOrderData().getExistingLineExecutions().forEach(LineExecution::increaseVersion);
            }));
    }
}
