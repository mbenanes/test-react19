package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum TppAllowedStatus {
    APPROVED, REJECTED, FAILED;
}
