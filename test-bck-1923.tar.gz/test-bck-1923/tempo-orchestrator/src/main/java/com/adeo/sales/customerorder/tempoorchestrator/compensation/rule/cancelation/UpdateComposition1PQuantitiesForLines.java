package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.cancelation;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineWithExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.CustomerOrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.NO_TPP_REQUIREMENT_IN_PROGRESS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.HAS_LEAST_ONE_IMPACTED_LINE_HAS_NEXT_STEP_DECREASE_QUANTITY_COMPOSITION;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_DECREASE_QUANTITY_ACTION_PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "UpdateComposition1PQuantitiesForLines",
    description = "Decrease quantity for 1P lines on TCO",
    priority = 1000)
public class UpdateComposition1PQuantitiesForLines {

    private static final Predicate<ExecutionAction> IS_PROCESSING_DECREASE_QUANTITY_ACTION_NEXT_STEP_IS_COMPOSITION = IS_DECREASE_QUANTITY_ACTION_PROCESSING.and(HAS_LEAST_ONE_IMPACTED_LINE_HAS_NEXT_STEP_DECREASE_QUANTITY_COMPOSITION);

    private static final Predicate<ExecutionAction> IS_ALL_DECREASE_QUANTITY_COMPOSITION_STEPS_ARE_THE_NEXT_STEP = executionAction -> {
        final List<ImpactedLine> allImpactedLines = executionAction.getAllImpactedLines();
        return !allImpactedLines.isEmpty() && allImpactedLines.stream()
            .filter(impactedLine -> !impactedLine.hasNoMoreSteps() && impactedLine.getStepOfType(DECREASE_QUANTITY_COMPOSITION).isPresent())
            .allMatch(impactedLine -> impactedLine.isNextStepIsOfType(DECREASE_QUANTITY_COMPOSITION));
    };
    private final CustomerOrderService customerOrderService;

    public static final Predicate<ExecutionAction> IS_ACTION_EXECUTION_TO_PROCESS = IS_ALL_DECREASE_QUANTITY_COMPOSITION_STEPS_ARE_THE_NEXT_STEP
        .and(IS_PROCESSING_DECREASE_QUANTITY_ACTION_NEXT_STEP_IS_COMPOSITION);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        boolean hasDecreaseQuantityToProcess = context.getExecutionActionsByPredicate(IS_ACTION_EXECUTION_TO_PROCESS).stream()
            .anyMatch(executionAction -> context.allLineOnExecutionAction(executionAction, NO_TPP_REQUIREMENT_IN_PROGRESS));

        return context.isCustomerOrderMatches(IS_VALIDATED) && hasDecreaseQuantityToProcess;
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {

        Optional<ExecutionAction> currentDecreaseQuantityAction = context.getOrderData().getExecutionActions().stream()
            .filter(IS_PROCESSING_DECREASE_QUANTITY_ACTION_NEXT_STEP_IS_COMPOSITION)
            .findFirst();

        return Mono.justOrEmpty(currentDecreaseQuantityAction)
            .flatMap(actionToExecute -> {

                List<ImpactedLineWithExecution> allImpactedLinesWithExecution = actionToExecute.getAllImpactedLinesWithExecution();

                final Map<String, List<LineExecution>> lineExecutionsById = allImpactedLinesWithExecution
                    .stream()
                    .filter(impactedLineWithExecution -> impactedLineWithExecution.getLine().isNextStepIsOfType(DECREASE_QUANTITY_COMPOSITION))
                    .flatMap(impactedLineWithExecution -> context.getOrderData().getLineExecutionsById(impactedLineWithExecution.getLineId()))
                    .collect(Collectors.groupingBy(LineExecution::getLineId));

                return customerOrderService.sendDecreaseQuantity(context.getCustomerOrderId(), context.getBuCode(), lineExecutionsById, actionToExecute)
                    .then(
                        Mono.fromRunnable(() -> allImpactedLinesWithExecution
                            .forEach(impactedLineWithExecution -> impactedLineWithExecution.getLine().getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION)
                                .ifPresent(step -> step.getFlags().raiseFlag(ImpactedLineStep.Status.PROCESSING))))
                    );
            });
    }

}
