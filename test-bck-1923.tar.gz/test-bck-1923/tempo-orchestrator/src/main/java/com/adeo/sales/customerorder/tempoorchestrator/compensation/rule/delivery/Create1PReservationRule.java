package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.FullfillmentReservationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_PAYMENT_AUTHORIZATION_DELAYED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_A_DELAYED_PAYMENT_MEAN;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_EXECUTION_NOT_STARTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PENDING_VALIDATION_OR_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_ONLINE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.RESERVATION_REQUESTED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Create1PReservation",
    description = "Create the 1P line reservation on the 1P Delivery System",
    priority = 1000)
public class Create1PReservationRule {
    private final FullfillmentReservationService fullfillmentReservationService;
    private static final Predicate<LineExecution> IS_1P_OFFER_TO_RESERVED =
        IS_1P
            .and(PAYMENT_ORCHESTRATED_BY_PSR)
            .and(IS_OFFER)
            .and(IS_LINE_COMPOSITION_VALIDATED);
    private static final Predicate<LineExecution> LINE_SHOULD_BE_RESERVED =
        IS_1P_OFFER_TO_RESERVED
            .and(IS_DELIVERY_EXECUTION_NOT_STARTED)
            .and(HAS_PAYMENT_AUTHORIZATION_DELAYED)
            .and(IS_A_DELAYED_PAYMENT_MEAN);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(LINE_SHOULD_BE_RESERVED) &&
            context.isCustomerOrderMatches(IS_PENDING_VALIDATION_OR_VALIDATED.and(IS_PLACE_TYPE_ONLINE));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var linesToCreate = context.getOrderData().getLineExecutionsByPredicate(LINE_SHOULD_BE_RESERVED);
        return MonoUtil.infoLog("INTERNAL request delivery reservation for 1P lines: {}", LineExecution.joinLineIds(linesToCreate))
            .then(this.fullfillmentReservationService.createOrderReservation(linesToCreate, context.getOrderData().getExistingCustomerOrder()))
            .doOnSuccess(unused -> linesToCreate.forEach(lineExecution -> {
                lineExecution.getDelivery().getFlags().raiseFlag(RESERVATION_REQUESTED);
                lineExecution.increaseVersion();
            }))
            .onErrorResume(throwable -> {
                log.warn(throwable.getMessage(), throwable);
                log.warn("Do not start logistic execution for create the 1P reservation !");
                return Mono.empty();
            });
    }
}
