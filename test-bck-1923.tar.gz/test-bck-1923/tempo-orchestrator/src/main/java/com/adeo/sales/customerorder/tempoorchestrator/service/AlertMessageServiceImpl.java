package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempo.alertreferential.command.CloseAlert;
import com.adeo.sales.customerorder.tempo.alertreferential.command.CloseAlertParameter;
import com.adeo.sales.customerorder.tempo.alertreferential.command.CreateAlert;
import com.adeo.sales.customerorder.tempo.alertreferential.command.CreateAlertParameter;
import com.adeo.sales.customerorder.tempo.alertreferential.state.CustomerOrder;
import com.adeo.sales.customerorder.tempo.alertreferential.state.CustomerOrderLine;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertStatus;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.repository.impl.JsonSerializeException;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.AlertMessageInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertStatus.CREATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate.getMaxCustomerKnownDeliveryDate;

@Component
@Slf4j
@RequiredArgsConstructor
public class AlertMessageServiceImpl implements AlertMessageService {
    private final TopicsProperties topicsProperties;
    private final List<AlertToTempoAlertingSpecificDataConverter<?>> converters;
    private final ObjectMapper objectMapper;
    private final EventProducer eventProducer;

    @Override
    public Mono<Void> sendCreateAlertMessage(AlertMessageInput messageInput) {
        final var involvedLines = messageInput.getLineExecutions().stream()
            .map(customerOrderLine ->
                CustomerOrderLine.newBuilder()
                    .setId(customerOrderLine.getLineId())
                    .setVendorId(messageInput.getCustomerOrder()
                        .getProductOffer()
                        .getOfferLineById(customerOrderLine.getLineId()).map(offer -> offer.getOffer().getVendorId())
                        .orElse(null))
                    .build()
            ).collect(Collectors.toList());

        final CreateAlert alertMessage = this.buildCreateAlertMessage(messageInput.getAlert(), involvedLines);

        return this.eventProducer.sendEvents(topicsProperties.getCreateAlert(),
            messageInput.getAlert().getCustomerOrderId(),
            messageInput.getAlert().getBuCode(), alertMessage);
    }

    @Override
    public Mono<Void> sendCloseAlertMessage(Alert alert, ClosingReason reason) {
        if (alert.getTempoAlertingId() == null) {
            log.error("can not close the alert with tempo orchestrator id {} because the tempo-alerting ack has not been received", alert.getId());
            return Mono.empty();
        }

        final CloseAlert alertMessage = buildCloseAlertMessage(alert, reason);

        return this.eventProducer.sendEvents(topicsProperties.getCreateAlert(), alert.getCustomerOrderId(), alert.getBuCode(), alertMessage)
            .then(Mono.fromRunnable(() -> alert.setStatus(AlertStatus.CLOSE_REQUESTED)));
    }

    @Override
    public Mono<Alert> replaceExistingAlert(
        Alert alert,
        List<LineExecution> linesToRemoveFromAlert,
        List<LineExecution> allLines,
        com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder customerOrder
    ) {

        if (alert.getTempoAlertingId() == null) { // Case of not acknowledged alert creation
            return Mono.empty();
        }

        final var lineIdsToRemoveAlerts = LineExecution.lineIds(linesToRemoveFromAlert);

        final var remainingLines = alert.getImpactedLinesIds().stream()
            .filter(line -> !lineIdsToRemoveAlerts.contains(line))
            .flatMap(lineId -> LineExecution.getCorrespondingLine(allLines, lineId).stream())
            .collect(Collectors.toList());

        Mono<Alert> recreateAlertMono = Mono.empty();
        if (!remainingLines.isEmpty()) {
            recreateAlertMono = reCreateAlertForLines(alert, remainingLines, customerOrder);
        }

        return this.sendCloseAlertMessage(alert, AlertMessageService.ClosingReason.REPLACED)
            .then(recreateAlertMono);
    }

    private Mono<Alert> reCreateAlertForLines(Alert alert, List<LineExecution> remainingLines, com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder customerOrder) {
        final var newAlertId = UUID.randomUUID();
        final var customerKnownDeliveryDate = getMaxCustomerKnownDeliveryDate(remainingLines);
        final var newSpecificData = alert.getSpecificData().copy();
        newSpecificData.setRequestId(newAlertId.toString());

        final Map<String, List<String>> impactedLineByExecution = remainingLines.stream()
            .collect(Collectors.groupingBy(lineExecution -> Optional.ofNullable(lineExecution.getExecutionId()).orElse(lineExecution.getCustomerOrderId()),
                Collectors.mapping(LineExecution::getLineId, Collectors.toList())));

        newSpecificData.setLinesToCancelByExecution(impactedLineByExecution);

        final var newAlert = Alert.builder()
            .id(newAlertId)
            .buCode(alert.getBuCode())
            .customerOrderId(alert.getCustomerOrderId())
            .customerKnownDeliveryDate(DeliveryDate.getMaxDate(customerKnownDeliveryDate))
            .impactedLinesIds(LineExecution.lineIds(remainingLines))
            .specificData(newSpecificData)
            .version(1)
            .status(CREATION_REQUESTED)
            .build();

        return this.sendCreateAlertMessage(new AlertMessageInput(newAlert, remainingLines, customerOrder))
            .thenReturn(newAlert);
    }

    private CloseAlert buildCloseAlertMessage(Alert alert, ClosingReason reason) {
        return CloseAlert.newBuilder()
            .setId(UUID.randomUUID().toString())
            .setType("CloseAlert")
            .setParameter(
                CloseAlertParameter.newBuilder()
                    .setAlertId(alert.getTempoAlertingId())
                    .setClosingReason(reason.name())
                    .build()
            )
            .build();
    }

    private CreateAlert buildCreateAlertMessage(Alert alert, List<CustomerOrderLine> involvedLines) {
        final var converter = getConverter(alert.getSpecificData());

        return CreateAlert.newBuilder()
            .setId(UUID.randomUUID().toString())
            .setType("CreateAlert")
            .setParameter(CreateAlertParameter.newBuilder()
                .setType(converter.getAlertType().toString())
                .setReason(alert.getSpecificData().getReason())
                .setCustomerKnownDeliveryDate(alert.getCustomerKnownDeliveryDate() != null ? alert.getCustomerKnownDeliveryDate().toInstant() : null)
                .setOrder(CustomerOrder.newBuilder()
                    .setId(alert.getCustomerOrderId())
                    .setBuCode(alert.getBuCode())
                    .setInvolvedLines(involvedLines)
                    .build()
                )
                .setDomainSpecificData(this.buildDomainSpecificData(alert))
                .build())
            .build();
    }

    private String buildDomainSpecificData(Alert alert) {
        // This manual serilization is due to a Jackson issue [https://github.com/FasterXML/jackson-databind/issues/3167]
        StringBuilder builder = new StringBuilder("{");
        alert.getSpecificData().getDomainSpecificData().forEach((key, value) ->
        {
            try {
                builder.append("\"").append(key).append("\"")
                    .append(" : ")
                    .append(objectMapper.writeValueAsString(value)).append(", ");
            } catch (JsonProcessingException e) {
                log.error("Unable to process DomainSpecificData", e);
                throw new JsonSerializeException("Unable to process DomainSpecificData");
            }
        });
        return builder.replace(builder.length() - 2, builder.length(), "}").toString();
    }

    private <T extends AlertSpecificData> AlertToTempoAlertingSpecificDataConverter<T> getConverter(T specificData) {
        return (AlertToTempoAlertingSpecificDataConverter<T>) converters.stream()
            .filter(c -> c.manageType(specificData.getClass()))
            .findFirst()
            .orElseThrow();
    }
}
