package com.adeo.sales.customerorder.tempoorchestrator.handler.poslog.dto;


import com.adeo.payment.data.repository.avro.AdeoExternalLink;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType;
import lombok.Builder;
import lombok.Getter;
import org.nrf_arts.ixretail.namespace.avro.LineItemDomainSpecific;

import java.math.BigDecimal;
import java.util.function.Predicate;
import java.util.stream.Stream;

@Builder
@Getter
public class PosLogSale {
    private final String tempoReferenceId;
    private final LineType lineType;
    private final String reflm;
    private final BigDecimal quantity;
    private final BigDecimal amount;
    private final String customerOrderId;
    private final String type;

    public static final Predicate<AdeoExternalLink> HAS_TEMPO_EXTERNAL_LINK = link -> "tempo-id".equals(link.getTypeCode());

    public PosLogSaleBuilder duplicate() {
        return PosLogSale.builder()
            .reflm(this.reflm)
            .quantity(this.quantity)
            .amount(this.amount)
            .customerOrderId(this.customerOrderId)
            .type(this.type)
            .tempoReferenceId(this.tempoReferenceId)
            .lineType(this.lineType);
    }

    public PosLogSale merge(PosLogSale other) {
        return this.duplicate()
            .quantity(this.quantity.add(other.quantity))
            .amount(this.amount.add(other.amount))
            .build();
    }

    public static PosLogSale lineItemToPosLogSale(LineItemDomainSpecific lineItem) {
        final var isAVoidLine = Boolean.TRUE.equals(lineItem.getVoidFlag$1());
        final var quantity = lineItem.getSale().getQuantity().getValue();
        final var amount = lineItem.getSale().getExtendedAmount().getValue();

        final var customerOrderId = Stream.ofNullable(lineItem.getAdeoExternalLink())
            .flatMap(adeoExternalLinks -> adeoExternalLinks.stream()
                .filter(HAS_TEMPO_EXTERNAL_LINK)
                .map(AdeoExternalLink::getID))
            .findFirst()
            .orElse(null);

        return PosLogSale.builder()
            .reflm(lineItem.getSale().getItemID().getValue())
            .quantity(isAVoidLine ? quantity.negate() : quantity)
            .amount(isAVoidLine ? amount.negate() : amount)
            .customerOrderId(customerOrderId)
            .type(lineItem.getSale().getItemType$1())
            .build();
    }

}
