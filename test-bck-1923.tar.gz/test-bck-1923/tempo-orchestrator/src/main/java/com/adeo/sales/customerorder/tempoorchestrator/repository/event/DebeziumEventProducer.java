package com.adeo.sales.customerorder.tempoorchestrator.repository.event;

import brave.propagation.B3SingleFormat;
import com.adeo.pyxis.adapter.avro.creation.CustomerOrderToCreate;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.opentracing.Span;
import io.opentracing.SpanContext;
import io.opentracing.util.GlobalTracer;
import io.r2dbc.spi.Statement;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.specific.SpecificRecord;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.cloud.sleuth.brave.bridge.BraveTraceContext;
import org.springframework.r2dbc.core.ConnectionAccessor;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.CUSTOMER_ORDER_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.FUNCTIONAL_TYPE;

@Component
@Slf4j
public class DebeziumEventProducer implements EventProducer {
    private static final String UNKNOWN_CREATOR = "unknown";
    private final KafkaAvroSerializer kafkaAvroSerializerEventSerializer;
    private final KafkaAvroSerializer kafkaTopicNameStrategyEventSerializer;

    private final Tracer tracer;
    private final ConnectionAccessor connectionAccessor;
    private final MeterRegistry meterRegistry;
    private final String applicationName;
    private final DatabaseClient databaseClient;


    public DebeziumEventProducer(
        KafkaAvroSerializer kafkaAvroSerializerEventSerializer,
        KafkaAvroSerializer kafkaTopicNameStrategyEventSerializer,
        Tracer tracer,
        ConnectionAccessor connectionAccessor,
        MeterRegistry meterRegistry,
        DatabaseClient databaseClient,
        @Value("${spring.application.name}") String applicationName) {
        this.kafkaAvroSerializerEventSerializer = kafkaAvroSerializerEventSerializer;
        this.tracer = tracer;
        this.connectionAccessor = connectionAccessor;
        this.meterRegistry = meterRegistry;
        this.applicationName = applicationName;
        this.kafkaTopicNameStrategyEventSerializer = kafkaTopicNameStrategyEventSerializer;
        this.databaseClient = databaseClient;
    }

    @Override
    public <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord) {
        return this.buildAndSendEvents(topics, customerOrderId, buCode, genericRecord, UNKNOWN_CREATOR, false);
    }

    @Override
    public <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord, Map<String,String> headers) {
        return this.buildAndSendEvents(topics, customerOrderId, buCode, genericRecord, UNKNOWN_CREATOR, false, null, null, headers);
    }

    @Override
    public <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvent(String topic, String customerOrderId, String buCode, T genericRecord) {
        return this.buildAndSendEvents(List.of(topic), customerOrderId, buCode, genericRecord, UNKNOWN_CREATOR, false);
    }

    @Override
    public <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvent(String topic, String customerOrderId, String buCode, T genericRecord, String sentBy) {
        return this.buildAndSendEvents(List.of(topic), customerOrderId, buCode, genericRecord, sentBy, false);
    }

    @Override
    public <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord, boolean useTopicNameStrategy) {
        return this.buildAndSendEvents(topics, customerOrderId, buCode, genericRecord, UNKNOWN_CREATOR, useTopicNameStrategy);
    }

    @Override
    public <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord, OffsetDateTime dateToSendEvent, String functionalType) {
        return this.buildAndSendEvents(topics, customerOrderId, buCode, genericRecord, UNKNOWN_CREATOR, false, dateToSendEvent, functionalType);
    }

    @Override
    public <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord, boolean useTopicNameStrategy, OffsetDateTime dateToSendEvent, String functionalType) {
        return this.buildAndSendEvents(topics, customerOrderId, buCode, genericRecord, UNKNOWN_CREATOR, useTopicNameStrategy, dateToSendEvent, functionalType);
    }

    public Mono<Void> disableEventToSend(String customerOrderId, String functionalType) {
        final var update = "update postponed_event set to_send = false where customer_order_id = :customerOrderId and functional_type= :functionalType";
        return this.databaseClient
            .sql(update)
            .bind(CUSTOMER_ORDER_ID, customerOrderId)
            .bind(FUNCTIONAL_TYPE, functionalType)
            .then();
    }

    public Mono<Boolean> postponedEventExistForOrderAndFunctionalType(String customerOrderId, String functionalType) {
        final var select = "select count(id) from postponed_event where to_send = true and sent = false and customer_order_id = :customerOrderId and functional_type= :functionalType";
        return this.databaseClient
            .sql(select)
            .bind(CUSTOMER_ORDER_ID, customerOrderId)
            .bind(FUNCTIONAL_TYPE, functionalType)
            .map(row -> row.get(0, Integer.class) > 0)
            .one();
    }


    private <T extends GenericRecord> Mono<Void> buildAndSendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord, String createdBy, boolean useTopicNameStrategy) {
        return buildAndSendEvents(topics, customerOrderId, buCode, genericRecord, createdBy, useTopicNameStrategy, null, null);
    }

    private <T extends GenericRecord> Mono<Void> buildAndSendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord, String createdBy, boolean useTopicNameStrategy, OffsetDateTime dateToSendEvent, String functionalType) {
        return buildAndSendEvents(topics, customerOrderId, buCode,  genericRecord, createdBy, useTopicNameStrategy, dateToSendEvent, functionalType, Map.of());
    }

    private <T extends GenericRecord> Mono<Void> buildAndSendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord, String createdBy, boolean useTopicNameStrategy, OffsetDateTime dateToSendEvent, String functionalType, Map<String, String> headers) {
        final var generateId = dateToSendEvent != null;
        final var events = this.buildEvents(customerOrderId, buCode, genericRecord, topics, createdBy, generateId);

        final var currentOpentracingContext = Optional.ofNullable(GlobalTracer.get())
            .map(io.opentracing.Tracer::activeSpan)
            .map(Span::context);

        if (dateToSendEvent == null) {
            return sendEvent(events, useTopicNameStrategy, buCode, currentOpentracingContext, headers);
        } else {
            return postponeEvent(events, useTopicNameStrategy, buCode, currentOpentracingContext, dateToSendEvent, functionalType);
        }
    }

    private Mono<Void> sendEvent(List<TempoOrchestratorEvent<GenericRecord>> events, boolean useTopicNameStrategy, String buCode, Optional<SpanContext> currentOpentracingContext, Map<String, String> headers) {
        final var insert = "insert into tempo_orchestrator_event(id, customer_order_id, event_type, topic, correlation_id, created_at, created_by, event, bu_code, app_source, x_datadog_trace_id, x_datadog_parent_id, x_datadog_sampling_priority, bu_id, canceled_by_type, canceled_by_id, canceled_with)" +
            " values ($1, $2,  $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)";

        return this.connectionAccessor.inConnection(it -> {
            final var statement = it.createStatement(insert);
            events.forEach(event -> {
                log.info("{} Sent to repository - topic {} - event id {}", event.getEventType(), event.getTopic(), event.getId());

                statement
                    .bind(0, event.getId())
                    .bind(1, event.getCustomerOrderId())
                    .bind(2, event.getEventType())
                    .bind(3, event.getTopic())
                    .bind(4, B3SingleFormat.writeB3SingleFormat(BraveTraceContext.toBrave(Objects.requireNonNull(tracer.currentSpan()).context())))
                    .bind(5, event.getCreatedAt())
                    .bind(6, event.getCreatedBy())
                    .bind(7, serializeEvent(event.getTopic(), event.getEvent(), useTopicNameStrategy))
                    .bind(8, event.getBuCode())
                    .bind(9, applicationName)
                    .bind(12, "1")
                    .bind(13, StringUtils.stripStart(buCode, "0"))
                ;

                bindNullable(10, statement, currentOpentracingContext.map(SpanContext::toTraceId).orElse(null));
                bindNullable(11, statement, currentOpentracingContext.map(SpanContext::toSpanId).orElse(null));
                bindNullable(14, statement, headers.get("canceledByType"));
                bindNullable(15, statement, headers.get("canceledById"));
                bindNullable(16, statement, headers.get("canceledWith"));
                statement.add();
            });

            return Flux.from(statement.execute())
                .flatMap(result -> Mono.from(result.getRowsUpdated()))
                .doOnNext(updatedRow -> log.debug("inserting TempoOrchestratorEvent, {} row updated", updatedRow))
                .then();
        }).doOnSuccess(it -> events.forEach(event -> this.addEventCount(event.getEventType(), event.getTopic())));
    }

    private Mono<Void> postponeEvent(List<TempoOrchestratorEvent<GenericRecord>> events, boolean useTopicNameStrategy, String buCode, Optional<SpanContext> currentOpentracingContext, OffsetDateTime dateToSendEvent, String functionalType) {
        final var insert = "insert into postponed_event(id, customer_order_id, event_type, topic, correlation_id, created_at, created_by, event, bu_code, app_source, x_datadog_trace_id, x_datadog_parent_id, x_datadog_sampling_priority, bu_id, date_to_send, to_send, sent, functional_type)" +
            " values ($1, $2,  $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)";

        return this.connectionAccessor.inConnection(it -> {
            final var statement = it.createStatement(insert);
            events.forEach(event -> {
                log.info("{} Sent to repository - topic {} - event id {}", event.getEventType(), event.getTopic(), event.getId());
                statement
                    .bind(0, event.getId())
                    .bind(1, event.getCustomerOrderId())
                    .bind(2, event.getEventType())
                    .bind(3, event.getTopic())
                    .bind(4, B3SingleFormat.writeB3SingleFormat(BraveTraceContext.toBrave(Objects.requireNonNull(tracer.currentSpan()).context())))
                    .bind(5, event.getCreatedAt())
                    .bind(6, event.getCreatedBy())
                    .bind(7, serializeEvent(event.getTopic(), event.getEvent(), useTopicNameStrategy))
                    .bind(8, event.getBuCode())
                    .bind(9, applicationName)
                    .bind(12, "1")
                    .bind(13, StringUtils.stripStart(buCode, "0"))
                    .bind(14, dateToSendEvent)
                    .bind(15, true)
                    .bind(16, false)
                    .bind(17, functionalType)

                ;

                bindNullable(10, statement, currentOpentracingContext.map(SpanContext::toTraceId).orElse(null));
                bindNullable(11, statement, currentOpentracingContext.map(SpanContext::toSpanId).orElse(null));
                statement.add();
            });

            return Flux.from(statement.execute())
                .flatMap(result -> Mono.from(result.getRowsUpdated()))
                .doOnNext(updatedRow -> log.debug("inserting PostponedEvent, {} row updated", updatedRow))
                .then();
        }).doOnSuccess(it -> events.forEach(event -> this.addPostponeEventCount(event.getEventType(), event.getTopic())));
    }

    private byte[] serializeEvent(String topic, GenericRecord event, boolean useTopicNameStrategy) {
        if (useTopicNameStrategy) {
            return this.kafkaTopicNameStrategyEventSerializer.serialize(topic, event);
        }
        return this.kafkaAvroSerializerEventSerializer.serialize(topic, event);
    }

    private void bindNullable(int index, Statement statement, String value) {
        if (value == null) {
            statement.bindNull(index, String.class);
        } else {
            statement.bind(index, value);
        }
    }


    private void addPostponeEventCount(String eventType, String topic) {
        Counter.builder("persisted_postponed_events_to_sent")
            .description("number of postponed events persisted on database")
            .tag("event_type", eventType)
            .tag("topic", topic)
            .register(this.meterRegistry)
            .increment();
    }

    private void addEventCount(String eventType, String topic) {
        Counter.builder("persisted_events_to_sent")
            .description("number of events persisted on database")
            .tag("event_type", eventType)
            .tag("topic", topic)
            .register(this.meterRegistry)
            .increment();
    }

    private List<TempoOrchestratorEvent<GenericRecord>> buildEvents(String customerOrderId, String buCode, GenericRecord genericRecord, List<String> topics, String createdBy, boolean generateId) {
        final UUID eventId;
        if (!generateId && !(genericRecord instanceof CustomerOrderToCreate) && genericRecord.hasField("id") && genericRecord.get("id") != null) {
            eventId = UUID.fromString(genericRecord.get("id").toString());
        } else {
            eventId = UUID.randomUUID();
        }

        return topics.stream()
            .map(topic -> TempoOrchestratorEvent.builder()
                .id(eventId)
                .customerOrderId(customerOrderId)
                .createdAt(OffsetDateTime.now())
                .createdBy(createdBy)
                .topic(topic)
                .event(genericRecord)
                .eventType(genericRecord.getClass().getSimpleName())
                .buCode(buCode)
                .build()).collect(Collectors.toList());
    }

}
