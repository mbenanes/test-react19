package com.adeo.sales.customerorder.tempoorchestrator.controller.dtos;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class CustomerOrderLineResponse {

    private String id;
    private DeliveryResponse delivery;
    private CashingResponse cashing;

}
