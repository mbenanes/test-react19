package com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context;

import com.adeo.sales.customerorder.ruleengine.configuration.GenericRuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.alert.AlertData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import lombok.Data;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_SERVICE;

@Data
public class RuleEngineContext implements GenericRuleEngineContext {
    private OrderData orderData = OrderData.builder().build();
    private AlertData alertData = AlertData.builder().build();

    public String getCustomerOrderId() {
        final var customerOrder = this.orderData.getExistingCustomerOrder();
        return customerOrder != null ? customerOrder.getId() : "empty";
    }

    public String getBuCode() {
        return Optional.ofNullable(this.orderData.getExistingCustomerOrder())
            .map(CustomerOrder::getBuCode)
            .orElseThrow(() -> new IllegalArgumentException("the bu code can not be found on the context"));
    }

    public boolean isCustomerOrderMatches(Predicate<CustomerOrder> predicate) {
        return predicate.test(this.getOrderData().getExistingCustomerOrder());
    }

    public boolean hasAtLeastOneLine(Predicate<LineExecution> predicate) {
        return this.getOrderData().getExistingLineExecutions().stream()
            .anyMatch(predicate);
    }

    public boolean hasAtLeastOneExecutionAction(Predicate<ExecutionAction> predicate) {
        return this.getOrderData().getExecutionActions().stream()
            .anyMatch(predicate);
    }

    public List<ExecutionAction> getExecutionActionsByPredicate(Predicate<ExecutionAction> predicate) {
        return this.getOrderData()
            .getExecutionActions()
            .stream()
            .filter(predicate)
            .toList();
    }

    public Optional<ExecutionAction> getFirstExecutionActionByPredicate(Predicate<ExecutionAction> predicate) {
        return this.getOrderData()
            .getExecutionActions()
            .stream()
            .filter(predicate)
            .findFirst();
    }

    public List<LineExecution> getLineExecutionsByImpactedExecution(ImpactedExecution impactedExecution) {
        return this.orderData
            .getLineExecutionsByPredicate(lineExecution ->
                impactedExecution.getCurrentExecutionId().equals(lineExecution.getExecutionId()) &&
                    impactedExecution.getImpactedLineById(lineExecution.getLineId()).isPresent());
    }

    public boolean allLineOnExecutionAction(ExecutionAction executionAction, Predicate<LineExecution> predicate) {
        return executionAction.getImpactedExecutions().stream()
            .allMatch(impactedExecution -> impactedExecution.getImpactedLines().stream()
                .flatMap(impactedLineAndQuantity -> LineExecution.getCorrespondingLine(this.getOrderData().getExistingLineExecutions(), impactedLineAndQuantity.getLineId()).stream())
                .allMatch(predicate)
            );
    }

    public boolean allLinesMatchs(Predicate<LineExecution> predicate) {
        return !this.getOrderData().getExistingLineExecutions().isEmpty() && this.getOrderData().getExistingLineExecutions().stream()
            .allMatch(predicate);
    }

    public boolean hasAtLeastOneAlert(Predicate<Alert> predicate) {
        return !this.getAlertData().getAlertsFilterBy(predicate).isEmpty();
    }

    public List<String> getServiceCategoryTypes() {
        return this.getOrderData().getExistingLineExecutions()
            .stream()
            .filter(IS_LINE_SERVICE)
            .filter(lineExecution -> lineExecution.getConfigurationService() != null && lineExecution.getConfigurationService().getConfigurationType() != null)
            .map(lineExecution -> lineExecution.getConfigurationService().getConfigurationType())
            .distinct()
            .toList();
    }
}
