package com.adeo.sales.customerorder.tempoorchestrator.handler.ucc;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderCommitmentResponseException;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.ucc.CustomerOrderCommitmentOperationResponseApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.ucc.input.CustomerOrderPaymentCommitmentInput;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.BuReferential;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.ulys.ulyscashingcommitment.avro.beans.CustomerOrderCommitmentOperationResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.ucc.input.CustomerOrderPaymentCommitmentInput.FailedReason.findFailedReasonByValue;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.ucc.input.CustomerOrderPaymentCommitmentInput.RejectedReason.findRejectedReasonByValue;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.ucc.input.CustomerOrderPaymentCommitmentInput.StatusCommitment.findStatusCommitmentByValue;

@Slf4j
@Component
@RequiredArgsConstructor
public class UccHandler implements EventHandler<CustomerOrderCommitmentOperationResponse> {

    private static final List<CustomerOrderPaymentCommitmentInput.StatusCommitment> COMMITMENTS_STATUS_WILL_BE_IGNORED = List.of(CustomerOrderPaymentCommitmentInput.StatusCommitment.CREATED, CustomerOrderPaymentCommitmentInput.StatusCommitment.ACKNOWLEDGED);

    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final CustomerOrderCommitmentOperationResponseApplicationService customerOrderCommitmentOperationResponseApplicationService;
    private final BuReferential buReferential;


    @Transactional
    @Override
    public Mono<Void> handle(CustomerOrderCommitmentOperationResponse event, EventMetaData eventMetaData) {
        String customerOrderID = event.getCustomerOrderId();
        String buCode = buReferential.retrieveBuCodeFromLabel(eventMetaData.getLabelBu());
        this.mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderID, buCode);

        log.info("CustomerOrderCommitmentOperationResponse consumes {} - message id: {}", eventMetaData.getTopic(), eventMetaData.getId().orElse("no id"));

        final CustomerOrderPaymentCommitmentInput.StatusCommitment statusCommitment = findStatusCommitmentByValue(event.getStatus());
        if (COMMITMENTS_STATUS_WILL_BE_IGNORED.contains(statusCommitment)) {
            log.info("CustomerOrderCommitmentOperationResponse will be ignored because this status is not treat by TOR {} ", event.getStatus());
            return Mono.empty();
        }

        final CustomerOrderPaymentCommitmentInput input = CustomerOrderPaymentCommitmentInput.builder()
            .customerOrderId(customerOrderID)
            .buCode(buCode)
            .sourceId(event.getSourceId())
            .statusCommitment(statusCommitment)
            .rejectedReason(findRejectedReasonByValue(event.getRejectedReason()))
            .failedReason(findFailedReasonByValue(event.getFailedReason()))
            .build();

        return customerOrderCommitmentOperationResponseApplicationService.apply(input)
            .onErrorResume(CustomerOrderCommitmentResponseException.class, e -> Mono.empty());

    }

    @Override
    public Class<?> getManagedEvent() {
        return CustomerOrderCommitmentOperationResponse.class;
    }
}
