package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.collect.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDeliveryCollect;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.service.CustomerOrderCollectService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_COLLECT_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_AT_LEAST_DELIVERY_RESERVED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECTABLE_DELIVERY_TYPE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_CREATE_COLLECT_IS_THE_NEXT_STEP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_SPLIT_REMAINING_COLLECT_ACTION_PROCESSING;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "CreateCollectTppRule",
    description = "Create collect for allocated lines in pickup orchestrated by TEMPO and payment orchestrated by TPP",
    priority = 1000)
public class CreateCollectTppRule {

    private final CustomerOrderCollectService collectService;
    private static final Predicate<ExecutionAction> IS_NEXT_STEP_IS_CREATE_COLLECT = IS_SPLIT_REMAINING_COLLECT_ACTION_PROCESSING.and(IS_CREATE_COLLECT_IS_THE_NEXT_STEP);

    private static final Predicate<LineExecution> COULD_CREATE_COLLECT =
        IS_1P
            .and(IS_OFFER)
            .and(IS_LINE_COMPOSITION_VALIDATED)
            .and(IS_EXTERNAL_SYSTEM_TEMPO)
            .and(IS_AT_LEAST_DELIVERY_RESERVED)
            .and(not(HAS_COLLECT_REQUESTED))
            .and(PAYMENT_ORCHESTRATED_BY_TPP);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final Map<String, List<LineExecution>> collectableLineByExecutionOpenToCreateCollect = context.getOrderData().getExistingLineExecutions().stream()
            .filter(IS_COLLECTABLE_DELIVERY_TYPE)
            .collect(Collectors.groupingBy(LineExecution::getExecutionId))
            .entrySet()
            .stream()
            .filter(collectableLineByExecution -> collectableLineByExecution.getValue()
                .stream()
                .allMatch(COULD_CREATE_COLLECT))
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        final boolean shouldCreateCollectForCollectableLineImpactedByAction = context.getExecutionActionsByPredicate(IS_NEXT_STEP_IS_CREATE_COLLECT)
            .stream()
            .map(ExecutionAction::getAllImpactedLines)
            .anyMatch(impactedLines -> collectableLineByExecutionOpenToCreateCollect.entrySet()
                .stream()
                .anyMatch(stringListEntry -> stringListEntry.getValue()
                    .stream()
                    .allMatch(lineExecutions -> {
                        final List<String> actionImpactedLineIds = impactedLines.stream().map(ImpactedLine::getLineId).toList();
                        final List<String> collectableLineExecutionIds = collectableLineByExecutionOpenToCreateCollect.values().stream()
                            .flatMap(Collection::stream)
                            .map(LineExecution::getLineId)
                            .toList();
                        return new HashSet<>(actionImpactedLineIds).containsAll(collectableLineExecutionIds);
                    })));

        return !collectableLineByExecutionOpenToCreateCollect.isEmpty() &&
            context.isCustomerOrderMatches(IS_VALIDATED) &&
            (!context.hasAtLeastOneExecutionAction(IS_EXECUTION_ACTION_PROCESSING) ||
                shouldCreateCollectForCollectableLineImpactedByAction);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        Map<String, List<LineExecution>> collectableLineByExecutionOpenToCreateCollect = context.getOrderData().getExistingLineExecutions().stream()
            .filter(IS_COLLECTABLE_DELIVERY_TYPE)
            .collect(Collectors.groupingBy(LineExecution::getExecutionId))
            .entrySet()
            .stream()
            .filter(collectableLineByExecution -> collectableLineByExecution.getValue()
                .stream()
                .allMatch(COULD_CREATE_COLLECT))
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        return Flux.fromIterable(collectableLineByExecutionOpenToCreateCollect.entrySet())
            .map(Map.Entry::getValue)
            .filter(lineExecutions -> {
                if(context.hasAtLeastOneExecutionAction(IS_EXECUTION_ACTION_PROCESSING)) {
                    return context.getExecutionActionsByPredicate(IS_NEXT_STEP_IS_CREATE_COLLECT)
                        .stream()
                        .map(ExecutionAction::getAllImpactedLines)
                        .allMatch(impactedLines -> {
                            final List<String> actionImpactedLineIds = impactedLines.stream().map(ImpactedLine::getLineId).toList();
                            final List<String> collectableLineExecutionIds = lineExecutions.stream()
                                .map(LineExecution::getLineId)
                                .toList();
                            return new HashSet<>(actionImpactedLineIds).containsAll(collectableLineExecutionIds);
                        });
                }
                return true;
            })
            .flatMap(linesToCreate -> MonoUtil.infoLog("INTERNAL request collect creation for lines: {}", LineExecution.joinLineIds(linesToCreate))
                .then(this.collectService.createCustomerOrderCollect(linesToCreate, context.getOrderData().getExistingCustomerOrder()))
                .doOnNext(customerOrderCollectRequest -> linesToCreate.forEach(lineExecution -> {
                    final OffsetDateTime offsetDateTime = linesToCreate.stream()
                        .findFirst()
                        .map(line -> line.getDelivery().getAppointmentDate())
                        .map(date -> date.toInstant().toEpochMilli())
                        .map(aLong -> OffsetDateTime.ofInstant(Instant.ofEpochMilli(aLong), ZoneId.systemDefault()))
                        .orElse(null);
                    final var collect = LineExecutionDeliveryCollect.builder()
                        .globalCollectStatus(CollectStatus.REQUESTED)
                        .appointmentDate(offsetDateTime)
                        .build();
                    collect.getFlags().raiseFlag(customerOrderCollectRequest.getRequestSourceID(), CollectStatus.REQUESTED);
                    lineExecution.getDelivery().setCollect(collect);
                    lineExecution.increaseVersion();
                    context.getFirstExecutionActionByPredicate(IS_NEXT_STEP_IS_CREATE_COLLECT)
                        .ifPresent(executionAction -> executionAction.raiseFlagsOnImpactedLineStepByType(ImpactedLineStep.Type.CREATE_COLLECT, ImpactedLineStep.Status.PROCESSING));
                }))
            ).then();
    }
}
