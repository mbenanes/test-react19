package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.ThirdPartyDeliveryCommandManager;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.UpdateAvailableActionService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_3P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_ACCEPTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_CREATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_CREATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Abort3PDelivery",
    description = "Abort third party line delivery.",
    priority = 1000)
public class Abort3PDeliveryRule {

    private final UpdateAvailableActionService updateAvailableActionService;


    public static final Predicate<LineExecution> IS_DELIVERY_STATUS_ACCEPT_CANCELLATION = IS_DELIVERY_CREATED
        .or(IS_DELIVERY_CREATION_REQUESTED)
        .or(IS_DELIVERY_ACCEPTED);

    public static final Predicate<LineExecution> SHOULD_ABORT_DELIVERY = IS_3P
        .and(PAYMENT_ORCHESTRATED_BY_PSR)
        .and(IS_LINE_COMPOSITION_CANCELED)
        .and(IS_DELIVERY_STATUS_ACCEPT_CANCELLATION);

    private final ThirdPartyDeliveryCommandManager thirdPartyDeliveryCommandManager;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(SHOULD_ABORT_DELIVERY);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var lines = context.getOrderData().getLineExecutionsByPredicate(SHOULD_ABORT_DELIVERY);

        if (lines.isEmpty()) {
            log.info("INTERNAL all lines are already canceled on BOMP. nothing to do.");
            return Mono.empty();
        }

        return MonoUtil.infoLog("INTERNAL request delivery abort for 3P lines: {}", LineExecution.joinLineIds(lines))
            .then(this.thirdPartyDeliveryCommandManager.abortCustomerOrderLines(lines, context.getOrderData().getExistingCustomerOrder()))
            .then(Mono.fromRunnable(() -> lines.forEach(lineExecution -> {
                final var delivery = lineExecution.getDelivery();
                delivery.getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.ABORT_REQUESTED);
                this.updateAvailableActionService.apply(context.getOrderData().getExistingLineExecutions(), lineExecution, context.getOrderData().getExistingCustomerOrder(), false);
                lineExecution.increaseVersion();
            })));
    }
}
