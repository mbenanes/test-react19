package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception;

public class CustomerOrderCommitmentResponseException extends RuntimeException {

    public CustomerOrderCommitmentResponseException() {
        super();
    }
}
