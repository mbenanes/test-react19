package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_ALREADY_SENT_MAIL_FOR_LONG_PAYMENT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_A_DELAYED_PAYMENT_MEAN;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_RESERVATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.service.impl.OutcomingNotificationServiceImpl.NotificationType.IN_STORE_LONG_PAYMENT;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "OrderInStoreToPaidWithLongPaymentRule",
    description = "Send notification to Notify to inform that the order is paid with a long payment in store",
    priority = 1000)
public class OrderInStoreToPaidWithLongPaymentRule {

    private final OutgoingNotificationService outgoingNotificationService;

    private static final Predicate<LineExecution> IS_LINES_HAS_TO_BE_NOTIFIED =
        IS_OFFER
            .and(PAYMENT_ORCHESTRATED_BY_TPP)
            .and(IS_RESERVATION_REQUIREMENT_COMPLIANT)
            .and(IS_LINE_COMPOSITION_VALIDATED)
            .and(not(IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT))
            .and(not(IS_ALREADY_SENT_MAIL_FOR_LONG_PAYMENT))
            .and(IS_A_DELAYED_PAYMENT_MEAN);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.isCustomerOrderMatches(IS_VALIDATED.and(IS_PLACE_TYPE_IN_STORE)) &&
            context.hasAtLeastOneLine(IS_LINES_HAS_TO_BE_NOTIFIED);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var longPaymentLinesToNotify = context.getOrderData().getLineExecutionsByPredicate(IS_LINES_HAS_TO_BE_NOTIFIED);
        final var existingCustomerOrder = context.getOrderData().getExistingCustomerOrder();
        return MonoUtil.infoLog("INTERNAL send long payment communication for order {}", existingCustomerOrder)
            .then(outgoingNotificationService.sendLongPaymentNotification(context.getOrderData().getExistingCustomerOrder()))
            .then(Mono.fromRunnable(() -> longPaymentLinesToNotify
                .forEach(line -> {
                    line.mailIsSent(IN_STORE_LONG_PAYMENT.getTemplateType());
                    line.increaseVersion();
                })));
    }

}
