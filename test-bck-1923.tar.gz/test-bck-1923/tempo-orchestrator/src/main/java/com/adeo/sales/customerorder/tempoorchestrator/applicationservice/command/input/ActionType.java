package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input;

public enum ActionType {
    DECREASE_QUANTITY
}
