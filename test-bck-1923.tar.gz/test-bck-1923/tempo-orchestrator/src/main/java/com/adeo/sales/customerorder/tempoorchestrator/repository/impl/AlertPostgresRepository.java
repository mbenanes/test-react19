package com.adeo.sales.customerorder.tempoorchestrator.repository.impl;

import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.repository.AlertRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.r2dbc.spi.Result;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.r2dbc.core.ConnectionAccessor;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.BU_CODE;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.CREATED_AT;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.CUSTOMER_ORDER_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.DATA;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.ID;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.LAST_MODIFIED_AT;

@Slf4j
@Component
@RequiredArgsConstructor
public class AlertPostgresRepository implements AlertRepository {
    private final DatabaseClient databaseClient;
    private final ObjectMapper objectMapper;
    private final ConnectionAccessor connectionAccessor;

    @Override
    public Mono<Alert> getByTempoAlertingId(String id, String buCode) {
        final var select = "select data, alert.created_at from alert where data->>'tempoAlertingId' = :id and data->>'buCode' = :buCode";
        return this.databaseClient
            .sql(select)
            .bind(ID, id)
            .bind(BU_CODE, buCode)
            .map(row -> deserialize(
                row.get("data", String.class),
                row.get("created_at", LocalDateTime.class)
            ))
            .one();
    }

    @Override
    public Mono<Alert> upsert(Alert alert) {
        final var sql = "insert into alert(id, customer_order_id, data, created_at, last_modified_at) values(:id, :customerOrderId, CAST(:data as jsonb), :created_at, :last_modified_at)" +
            " on conflict(id) do update set data = CAST(:data as jsonb), last_modified_at = :last_modified_at";

        final var now = OffsetDateTime.now().atZoneSameInstant(ZoneOffset.UTC);

        return this.databaseClient.sql(sql)
            .bind(ID, alert.getId())
            .bind(CUSTOMER_ORDER_ID, alert.getCustomerOrderId())
            .bind(DATA, serialize(alert))
            .bind(CREATED_AT, now)
            .bind(LAST_MODIFIED_AT, now)
            .then()
            .thenReturn(alert);
    }

    @Override
    public Mono<List<Alert>> upsert(List<Alert> alerts) {
        if (alerts.isEmpty()) {
            return Mono.empty();
        }
        final var sql = "insert into alert(id, customer_order_id, data, created_at, last_modified_at) values($1, $2, CAST($3 as jsonb), $4, $4)" +
            " on conflict(id) do update set data = CAST($3 as jsonb), last_modified_at = $4";

        return connectionAccessor.inConnection(connection -> {
            final var statement = connection.createStatement(sql);
            for (final var alert : alerts) {
                statement.bind(0, alert.getId())
                    .bind(1, alert.getCustomerOrderId())
                    .bind(2, serialize(alert))
                    .bind(3, OffsetDateTime.now().atZoneSameInstant(ZoneOffset.UTC))
                    .add();
            }

            return Flux.from(statement.execute())
                .flatMap(Result::getRowsUpdated)
                .doOnNext(result -> log.debug(" {} upserted alerts", result))
                .collectList()
                .thenReturn(alerts);
        });
    }

    @Override
    public Flux<Alert> listAlertsByCustomerOrderId(String customerOrderId, String buCode) {
        String select = "select distinct(alert.id), alert.data, alert.created_at from alert " +
            "where alert.customer_order_id = :customerOrderId and alert.data->>'buCode' = :buCode";

        return this.databaseClient
            .sql(select)
            .bind(BU_CODE, buCode)
            .bind(CUSTOMER_ORDER_ID, customerOrderId)
            .map(row -> deserialize(
                row.get("data", String.class),
                row.get("created_at", LocalDateTime.class)
            ))
            .all();
    }

    private Alert deserialize(String data, LocalDateTime createdAt) {
        try {
            final var alert = objectMapper.readValue(data, Alert.class);
            alert.setCreatedAt(createdAt.atOffset(ZoneOffset.UTC));
            return alert;
        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }

    private String serialize(Alert alert) {
        try {
            return this.objectMapper.writeValueAsString(alert);
        } catch (JsonProcessingException e) {
            throw new JsonSerializeException(e);
        }
    }
}
