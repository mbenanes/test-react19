package com.adeo.sales.customerorder.tempoorchestrator.handler.poslog.dto;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Builder
public class PosLogOperation {

    private final String customerOrderId;

    private final String transactionId;

    private final String storeCode;

    @Setter
    private List<PosLogSale> sales;
    private List<PosLogDeposit> deposits;

    public PosLogOperationBuilder copy() {
        return PosLogOperation.builder()
            .customerOrderId(this.customerOrderId)
            .transactionId(this.transactionId)
            .storeCode(this.storeCode)
            .sales(this.sales)
            .deposits(this.deposits);
    }

}
