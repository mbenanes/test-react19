package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.execution;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertReason;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.AppSource;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.TreeSet;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_A_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_NO_REQUIREMENT_OR_REQUIREMENT_FAILED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_3P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECTABLE_DELIVERY_TYPE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECT_REJECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CONFIRMATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_ACCEPTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_CREATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_CREATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_EXECUTION_STARTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COLLECT_REJECTED_OR_CANCELED_OR_CANCELED_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PAYMENT_OWNERSHIP_TRANSFERED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_ONLINE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_PARTNER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPING_REQUIREMENT_FAILED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_TO_EXECUTE;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.CREATION_FAILED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction.isExecutionActionReasonMatches;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionReasonEnum.CANCELLATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionReasonEnum.REMAINING_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.ABORT_DELIVERY_3P;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.ASK_GENERATE_DEPOSIT_LEGACY_NUMBER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.ASK_PREPARATION_REQUIREMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.CANCEL_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.CREATE_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.READ_ADJUSTMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.SEND_CANCELLATION_BY_VENDOR_NOTIFICATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.SEND_CANCELLATION_NOTIFICATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.SEND_PAYMENT_REFUSED_NOTIFICATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.SPLIT_LINE_EXECUTION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.initializeFlags;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "InitializeExecutionActionWorkflowRule",
    description = "Initialize all possible workflows for ExecutionAction",
    priority = 11)
public class InitializeExecutionActionWorkflowRuleStart {

    public static final Predicate<LineExecution> IS_DELIVERY_STATUS_ACCEPT_CANCELLATION = IS_DELIVERY_CREATED
        .or(IS_DELIVERY_CREATION_REQUESTED)
        .or(IS_DELIVERY_ACCEPTED);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneExecutionAction(IS_EXECUTION_ACTION_TO_EXECUTE) &&
            context.getOrderData().getExecutionActions().stream().noneMatch(IS_EXECUTION_ACTION_PROCESSING);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        context.getExecutionActionsByPredicate(IS_EXECUTION_ACTION_TO_EXECUTE)
            .stream()
            .min(Comparator.comparing(ExecutionAction::getCreatedAt))
            .ifPresent(executionAction -> {
                executionAction.getFlags().raiseFlagIfNot(ExecutionActionStatus.PROCESSING);
                executionAction.getImpactedExecutions()
                    .forEach(impactedExecution -> impactedExecution.getImpactedLines()
                        .forEach(impactedLine -> {
                            Optional<LineExecution> lineExecutionOption = context.getOrderData().getLineExecutionByIdAndExecutionId(impactedLine.getLineId(), impactedExecution.getCurrentExecutionId());
                            switch (executionAction.getActionType()) {
                                case DECREASE_QUANTITY ->
                                    this.buildDecreaseQuantityWorkflow(executionAction, impactedLine, lineExecutionOption, context);
                                case SPLIT ->
                                    this.buildSplitWorkflow(executionAction, impactedLine, lineExecutionOption);
                            }
                        }));
            });

        return Mono.empty();
    }

    private void buildSplitWorkflow(ExecutionAction executionAction, ImpactedLine impactedLine, Optional<LineExecution> lineExecutionOption) {
        if (isExecutionActionReasonMatches(executionAction, CANCELLATION.name())) {
            addStep(impactedLine.getSteps(), SPLIT_LINE_EXECUTION, true);
        } else if (isExecutionActionReasonMatches(executionAction, REMAINING_COLLECT.name())) {
            boolean hasRequirementIssues = lineExecutionOption.stream().anyMatch(not(HAS_NO_REQUIREMENT_OR_REQUIREMENT_FAILED));

            if (hasRequirementIssues) {
                addStep(impactedLine.getSteps(), UNEXEC_REQUIREMENT_TPP, true);
            }
            addStep(impactedLine.getSteps(), SPLIT_LINE_EXECUTION, true);
            addStep(impactedLine.getSteps(), ASK_PREPARATION_REQUIREMENT_TPP, true);
            addStep(impactedLine.getSteps(), CREATE_COLLECT, true);
        }
    }

    private void buildDecreaseQuantityWorkflow(ExecutionAction executionAction, ImpactedLine impactedLine, Optional<LineExecution> lineExecutionOption, RuleEngineContext context) {
        lineExecutionOption.ifPresent(lineExecution -> {
            if (!PAYMENT_ORCHESTRATED_BY_TPP.and(IS_LINE_COMPOSITION_VALIDATED).test(lineExecution)) return;

            boolean isCollectInProgress = HAS_A_COLLECT
                .and(not(IS_LINE_COLLECT_REJECTED_OR_CANCELED_OR_CANCELED_REQUESTED))
                .and(not(IS_COLLECT_REJECTED))
                .and(IS_COLLECTABLE_DELIVERY_TYPE).test(lineExecution);

            final boolean isDecreaseByCOC = AppSource.COC.equals(executionAction.getAppSource());
            final boolean isOffer1P = IS_OFFER.and(IS_1P).and(IS_DELIVERY_EXECUTION_STARTED).and(not(IS_SHIPPED_BY_PARTNER)).test(lineExecution);
            final boolean isOffer3P = IS_OFFER.and(IS_3P).and(IS_DELIVERY_STATUS_ACCEPT_CANCELLATION).test(lineExecution);
            final boolean isPaidOnLineOrder = IS_CONFIRMATION_REQUIREMENT_COMPLIANT.test(lineExecution) && context.isCustomerOrderMatches(IS_PLACE_TYPE_ONLINE);

	          if(AlertReason.ORDER_CREATION_FAILURE.name().equals(impactedLine.getReason()) && lineExecution.getExternalSystem().isOriginPyxis()) {
	                addStep(impactedLine.getSteps(), ASK_GENERATE_DEPOSIT_LEGACY_NUMBER, true);
	            }
                
            if (isOffer1P) {
                boolean isBlocking = !(isCollectInProgress && isDecreaseByCOC);
                addStep(impactedLine.getSteps(), DECREASE_QUANTITY_DELIVERY, isBlocking);
            } else if (isOffer3P) {
                addStep(impactedLine.getSteps(), ABORT_DELIVERY_3P, true);
            }

            if (IS_LINE_SERVICE.test(lineExecution)) {
                addStep(impactedLine.getSteps(), CANCEL_SERVICE, false);
            }

            if (isCollectInProgress && !isDecreaseByCOC) {
                addStep(impactedLine.getSteps(), DECREASE_QUANTITY_COLLECT, true);
            }

            if (not(HAS_NO_REQUIREMENT_OR_REQUIREMENT_FAILED).test(lineExecution)) {
                addStep(impactedLine.getSteps(), UNEXEC_REQUIREMENT_TPP, true);
            }

            addStep(impactedLine.getSteps(), DECREASE_QUANTITY_COMPOSITION, true);

            if (isPaidOnLineOrder) {
                addStep(impactedLine.getSteps(), READ_ADJUSTMENT_TPP, true);
                addStep(impactedLine.getSteps(), EXECUTE_ADJUSTMENT_TPP, true);
            }

            boolean isTriggeredByTORForUnPaid = isDecreaseTriggeredByTORForUnPaidInStoreOrder(executionAction.getAppSource(), context, lineExecution);
            if (IS_1P.test(lineExecution) && !isTriggeredByTORForUnPaid) {
                addStep(impactedLine.getSteps(), SEND_CANCELLATION_NOTIFICATION, true);
            } else {
                if (IS_SHIPPING_REQUIREMENT_FAILED.test(lineExecution)) {
                    addStep(impactedLine.getSteps(), SEND_PAYMENT_REFUSED_NOTIFICATION, true);
                } else {
                    addStep(impactedLine.getSteps(), SEND_CANCELLATION_BY_VENDOR_NOTIFICATION, true);
                }
            }

        });
    }

    public static void addStep(TreeSet<ImpactedLineStep> steps, ImpactedLineStep.Type type, boolean isBlocking) {
        int nextPosition = steps.isEmpty() ? 1 : steps.last().getPosition() + 1;
        steps.add(ImpactedLineStep.builder()
            .position(nextPosition)
            .type(type)
            .isBlocking(isBlocking)
            .flags(initializeFlags())
            .build());
    }

    private boolean isDecreaseTriggeredByTORForUnPaidInStoreOrder(String appSource, RuleEngineContext context, LineExecution lineExecution) {
        return AppSource.TOR.equals(appSource)
            && context.isCustomerOrderMatches(IS_PLACE_TYPE_IN_STORE)
            && (not(IS_CONFIRMATION_REQUIREMENT_COMPLIANT).test(lineExecution)
            || not(IS_PAYMENT_OWNERSHIP_TRANSFERED).test(lineExecution));
    }

}
