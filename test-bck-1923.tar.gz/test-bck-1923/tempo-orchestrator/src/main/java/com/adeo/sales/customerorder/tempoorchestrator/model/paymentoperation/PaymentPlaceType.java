package com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation;

public enum PaymentPlaceType {
    ONLINE,
    IN_STORE;
}
