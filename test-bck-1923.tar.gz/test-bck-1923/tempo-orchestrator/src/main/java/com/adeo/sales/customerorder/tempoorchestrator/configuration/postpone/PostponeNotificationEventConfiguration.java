package com.adeo.sales.customerorder.tempoorchestrator.configuration.postpone;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "postpone.events.notification")
@Slf4j
public class PostponeNotificationEventConfiguration {
    private Map<String, PostponeConfiguration> postponeNotificationTemplateConfigurations;

    public PostponeConfiguration getPostponeConfiguration(String templateName, String buCode){

        final PostponeConfiguration postponeConfiguration = postponeNotificationTemplateConfigurations.get(templateName);
        return postponeConfiguration != null && postponeConfiguration.getApplyForBu().contains(buCode) ? postponeConfiguration : null;
    }

}
