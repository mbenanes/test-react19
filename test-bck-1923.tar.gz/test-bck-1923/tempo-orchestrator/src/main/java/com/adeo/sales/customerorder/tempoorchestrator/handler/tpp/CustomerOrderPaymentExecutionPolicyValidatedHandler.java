package com.adeo.sales.customerorder.tempoorchestrator.handler.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.CustomerOrderPaymentExecutionPolicyValidatedApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentExecutionPolicyValidatedInput;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.tpp.avro.event.CustomerOrderPaymentExecutionPolicyValidated;
import com.adeo.sales.tpp.avro.model.PaymentAdjustmentAction;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;

@Slf4j
@Component
@RequiredArgsConstructor
public class CustomerOrderPaymentExecutionPolicyValidatedHandler implements EventHandler<CustomerOrderPaymentExecutionPolicyValidated> {

    public static List<String> TPP_AJDUSTMENT_ALLOWED_REASONS = List.of("ITEM_CANCELATION", "QUANTITY_DECREASE", "LOWER_PRICE");
    public static final Predicate<PaymentAdjustmentAction> IS_DECREASE_QUANTITY_PAYMENT_ADJUSTMENT_ACTION_TO_EXECUTE = paymentAdjustmentAction -> CollectionUtils.isEmpty(paymentAdjustmentAction.getExecution()) &&
        TPP_AJDUSTMENT_ALLOWED_REASONS.contains(paymentAdjustmentAction.getReason());
    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final CustomerOrderPaymentExecutionPolicyValidatedApplicationService customerOrderPaymentExecutionPolicyValidatedApplicationService;

    @Override
    public Mono<Void> handle(CustomerOrderPaymentExecutionPolicyValidated event, EventMetaData eventMetaData) {
        String customerOrderID = event.getState().getDependency().getCustomerOrder().getId();
        String buCode = event.getState().getBuId();

        this.mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderID, buCode);

        final var lines = event.getState()
            .getItemPaymentExecutionPolicy()
            .stream()
            .filter(itemPaymentExecutionPolicy -> !CollectionUtils.isEmpty(itemPaymentExecutionPolicy.getPaymentAdjustmentAction()) &&
                itemPaymentExecutionPolicy.getPaymentAdjustmentAction()
                    .stream()
                    .anyMatch(IS_DECREASE_QUANTITY_PAYMENT_ADJUSTMENT_ACTION_TO_EXECUTE))
            .map(itemPaymentExecutionPolicy -> PaymentExecutionPolicyValidatedInput.Line
                .builder()
                .id(itemPaymentExecutionPolicy.getCustomerOrderCartItem().getId())
                .paymentAdjustmentActionId(itemPaymentExecutionPolicy.getPaymentAdjustmentAction()
                    .stream()
                    .filter(IS_DECREASE_QUANTITY_PAYMENT_ADJUSTMENT_ACTION_TO_EXECUTE)
                    .map(PaymentAdjustmentAction::getId)
                    .findFirst()
                    .orElse(null))
                .build())
            .toList();

        return Mono.just(event)
            .filter(customerOrderPaymentExecutionPolicyValidated -> "VALIDATED".equals(customerOrderPaymentExecutionPolicyValidated.getState().getStatus()))
            .flatMap(customerOrderPaymentExecutionPolicyValidated -> this.customerOrderPaymentExecutionPolicyValidatedApplicationService.apply(PaymentExecutionPolicyValidatedInput.builder()
                .customerOrderId(customerOrderID)
                .buCode(buCode)
                .lines(lines)
                .tppVersion(customerOrderPaymentExecutionPolicyValidated.getState().getVersion())
                .build()));
    }

    @Override
    public Class<?> getManagedEvent() {
        return CustomerOrderPaymentExecutionPolicyValidated.class;
    }
}
