package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception;


public class ExecutionAndLineNotFoundError extends RuntimeException {
    public ExecutionAndLineNotFoundError(String error) {
        super(error);
    }

}
