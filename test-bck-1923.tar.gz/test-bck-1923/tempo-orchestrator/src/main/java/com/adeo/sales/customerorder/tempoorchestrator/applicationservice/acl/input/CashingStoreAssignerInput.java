package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.input;

import lombok.Builder;
import lombok.Value;

@Builder
@Value
public class CashingStoreAssignerInput {
    String quotationId;
    Integer quotationVersion;
    String buCode;
}
