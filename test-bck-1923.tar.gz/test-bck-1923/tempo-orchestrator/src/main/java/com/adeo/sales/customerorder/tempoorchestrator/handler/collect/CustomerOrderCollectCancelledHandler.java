package com.adeo.sales.customerorder.tempoorchestrator.handler.collect;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.collect.CustomerOrderCollectApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.tempocollect.avro.event.CustomerOrderCollectCancelled;
import com.adeo.tempocollect.avro.model.CustomerOrderCollectItem;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.util.List;

@Component
@Slf4j
public class CustomerOrderCollectCancelledHandler extends CustomerOrderCollectCommon implements EventHandler<CustomerOrderCollectCancelled> {


    public CustomerOrderCollectCancelledHandler(MappedDiagnosticContext mappedDiagnosticContext, CustomerOrderCollectApplicationService customerOrderCollectApplicationService) {
        super(mappedDiagnosticContext, customerOrderCollectApplicationService);
    }

    @Override
    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    public Mono<Void> handle(CustomerOrderCollectCancelled event, EventMetaData eventMetaData) {
        List<CustomerOrderCollectItem> customerOrderCollectItems = event.getState().getCustomerOrderCollectItems();
        return this.handleCollectEvent(event.getState().getStatus(), event.getState().getIdentifier(),event.getState(), eventMetaData, customerOrderCollectItems, this.getManagedEvent().getSimpleName());
    }

    @Override
    public Class<?> getManagedEvent() {
        return CustomerOrderCollectCancelled.class;
    }
}
