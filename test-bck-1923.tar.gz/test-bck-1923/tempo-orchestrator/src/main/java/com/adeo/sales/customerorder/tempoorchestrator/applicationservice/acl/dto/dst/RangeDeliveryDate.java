package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst;

import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@NoArgsConstructor
@Data
@JsonTypeName("RANGE")
public class RangeDeliveryDate implements DeliveryDate {
    private OffsetDateTime startDate;
    private OffsetDateTime endDate;

    public RangeDeliveryDate(OffsetDateTime startDate, OffsetDateTime endDate){
        this.startDate = startDate;
        this.endDate = endDate;
    }
}
