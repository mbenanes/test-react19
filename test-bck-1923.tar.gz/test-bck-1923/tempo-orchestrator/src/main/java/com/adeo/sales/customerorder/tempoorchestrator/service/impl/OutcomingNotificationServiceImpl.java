package com.adeo.sales.customerorder.tempoorchestrator.service.impl;

import com.adeo.sales.customerorder.notify.command.sendcustomerordernotification.SendCustomerOrderNotification;
import com.adeo.sales.customerorder.notify.command.sendcustomerordernotification.SendCustomerOrderNotificationParameter;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.postpone.PostponeNotificationEventConfiguration;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.timezones.TimezonesConfiguration;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.configuration.ApplicationProperties.TEMPO_SYSTEM_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment.PaymentExecutionSystem.TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.service.PostponeConfigurationService.getDateToSendList;

@Slf4j
@Component
@RequiredArgsConstructor
public class OutcomingNotificationServiceImpl implements OutgoingNotificationService {

    private final TopicsProperties properties;
    private final PostponeNotificationEventConfiguration postponeNotificationEventConfiguration;
    private final TimezonesConfiguration timezonesConfiguration;
    private final EventProducer eventProducer;

    @Override
    public Mono<Void> sendValidationNotification(CustomerOrder customerOrder) {
        if (customerOrder.getOrderPlaceType() == CustomerOrderPlaceType.ONLINE) {
            return this.sendCommandNotification(customerOrder, List.of(), NotificationType.VALIDATION, null, List.of());
        } else {
            return this.sendCommandNotification(customerOrder, List.of(), NotificationType.VALIDATION_IN_STORE, null, List.of());
        }
    }

    @Override
    public Mono<Void> sendOrderInStoreToPaidNotification(CustomerOrder customerOrder) {
        return this.sendCommandNotification(customerOrder, List.of(), NotificationType.ORDER_IN_STORE_TO_PAID, null, List.of());
    }

    @Override
    public Mono<Void> sendOrderInStoreToPaidReminder1Notification(CustomerOrder customerOrder) {
        return this.sendCommandNotification(customerOrder, List.of(), NotificationType.ORDER_IN_STORE_TO_PAID_REMINDER1, null, List.of());
    }

    @Override
    public Mono<Void> sendOrderInStoreToPaidReminder2Notification(CustomerOrder customerOrder) {
        return this.sendCommandNotification(customerOrder, List.of(), NotificationType.ORDER_IN_STORE_TO_PAID_REMINDER2, null, List.of());
    }

    @Override
    public Mono<Void> sendOrderInStoreNotPaidAutoCancel(CustomerOrder customerOrder) {
        return this.sendCommandNotification(customerOrder, List.of(), NotificationType.ORDER_IN_STORE_NOT_PAID_AUTO_CANCEL, null, List.of());
    }

    @Override
    public Mono<Void> sendWaitingForPaymentNotification(CustomerOrder customerOrder) {
        return this.sendCommandNotification(customerOrder, List.of(), NotificationType.WAITING_FOR_PAYMENT, null, List.of());
    }

    @Override
    public Mono<Void> sendWaitingForPaymentReminderNotification(CustomerOrder customerOrder) {
        return this.sendCommandNotification(customerOrder, List.of(), NotificationType.WAITING_FOR_PAYMENT_REMINDER, null, List.of());
    }


    @Override
    public Mono<Void> sendLongPaymentCanceledNotification(CustomerOrder customerOrder) {
        return this.sendCommandNotification(customerOrder, List.of(), NotificationType.LONG_PAYMENT_CANCELED, null, List.of());
    }

    @Override
    public Mono<Void> sendLongPaymentNotification(CustomerOrder customerOrder) {
        return this.sendCommandNotification(customerOrder, List.of(), NotificationType.IN_STORE_LONG_PAYMENT, null, List.of());
    }

    @Override
    public Mono<Void> sendPartialCancellationByVendorNotification(CustomerOrder customerOrder, String externalOrchestratorId) {
        return this.sendCommandNotification(customerOrder, List.of(), NotificationType.PARTIAL_CANCELLATION_BY_VENDOR, externalOrchestratorId, List.of());
    }

    @Override
    public Mono<Void> sendPaymentRefusedNotification(CustomerOrder customerOrder) {
        return this.sendCommandNotification(customerOrder, List.of(), NotificationType.PAYMENT_REFUSED, null, List.of());
    }

    @Override
    public Mono<Void> sendAppointmentReminderDayBeforeNotification(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        return this.sendCommandNotification(customerOrder, lineExecutions, NotificationType.APPOINTMENT_REMINDER_DAY_BEFORE, null, List.of());
    }

    @Override
    public Mono<Void> sendAppointmentReminderHoursBeforeNotification(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        return this.sendCommandNotification(customerOrder, lineExecutions, NotificationType.APPOINTMENT_REMINDER_HOURS_BEFORE, null, List.of());
    }

    @Override
    public Mono<Void> sendPickupInStoreOrderDeliveredNotificationRelatedToExecutionAction(CustomerOrder customerOrder, List<LineExecution> lineExecutions, final String customerOrderExecutionActionId) {
        return this.sendCommandNotification(customerOrder, lineExecutions, NotificationType.PICKUP_ORDER_DELIVERED, null, List.of(), customerOrderExecutionActionId);
    }

    @Override
    public Mono<Void> sendPickupInStoreOrderDeliveredNotification(CustomerOrder customerOrder, List<LineExecution> lineExecutions ) {
        return this.sendCommandNotification(customerOrder, lineExecutions, NotificationType.PICKUP_ORDER_DELIVERED, null, List.of());
    }

    @Override
    public Mono<Void> sendPickupInStoreAppointmentUpdatingNotification(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        return this.sendCommandNotification(customerOrder, lineExecutions, NotificationType.PICKUP_APPOINTMENT_UPDATING, null, LineExecution.lineIds(lineExecutions));
    }

    @Override
    public Mono<Void> sendPickupInStoreAppointmentExpiredNotification(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        return this.sendCommandNotification(customerOrder, lineExecutions, NotificationType.PICKUP_APPOINTMENT_EXPIRED, null, LineExecution.lineIds(lineExecutions));
    }

    @Override
    public Mono<Void> sendCollectForecastedLateNotification(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        return this.sendCommandNotification(customerOrder, lineExecutions, NotificationType.COLLECT_FORECASTED_LATE, null, LineExecution.lineIds(lineExecutions));
    }

    @Override
    public Mono<Void> sendCollectPartiallyForecastedLateNotification(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        return this.sendCommandNotification(customerOrder, lineExecutions, NotificationType.COLLECT_PARTIALLY_FORECASTED_LATE, null, LineExecution.lineIds(lineExecutions));
    }

    @Override
    public Mono<Void> sendMailForLines(List<LineExecution> lines, String mailType, CustomerOrder customerOrder) {
        final var command = buildNotificationCommand(this.buildNotificationParameterBuilder(lines, mailType, customerOrder));

        return this.eventProducer.sendEvents(this.properties.getOutComingNotification(), customerOrder.getId(), customerOrder.getBuCode(), command);
    }

    @Override
    public Mono<Void> sendMailForExecutionAction(String executionActionId, String mailType, CustomerOrder customerOrder) {
        final var command = buildNotificationCommand(this.buildNotificationParameterBuilder(executionActionId, mailType, customerOrder));

        return this.eventProducer.sendEvents(this.properties.getOutComingNotification(), customerOrder.getId(), customerOrder.getBuCode(), command);
    }

    private Mono<Void> sendCommandNotification(
        final CustomerOrder customerOrder,
        List<LineExecution> lineExecutions,
        final NotificationType notificationType,
        final String externalOrchestratorId,
        final List<String> linesId) {
        return sendCommandNotification(
        customerOrder,
        lineExecutions,
        notificationType,
        externalOrchestratorId,
        linesId, null);
    }

    private Mono<Void> sendCommandNotification(
        final CustomerOrder customerOrder,
        List<LineExecution> lineExecutions,
        final NotificationType notificationType,
        final String externalOrchestratorId,
        final List<String> linesId,
        final String customerOrderExecutionActionId) {
        final var postponeConfiguration = postponeNotificationEventConfiguration.getPostponeConfiguration(notificationType.getTemplateType(), customerOrder.getBuCode());
        final var command = executionPlanIdIfNeeded(lineExecutions, notificationType)
            ? buildNotificationCommand(this.buildNotificationParameterBuilder(customerOrder, notificationType.templateType, externalOrchestratorId, linesId, customerOrderExecutionActionId,
            lineExecutions.stream()
                .findFirst()
                .map(LineExecution::getExecutionId)
                .orElse(null)))
            : buildNotificationCommand(this.buildNotificationParameterBuilder(customerOrder, notificationType.templateType, externalOrchestratorId, linesId, customerOrderExecutionActionId));

        if (postponeConfiguration != null) {
            final var dateToSendEventList = getDateToSendList(postponeConfiguration, timezonesConfiguration, customerOrder, lineExecutions, notificationType.templateType);
            return Flux.fromIterable(dateToSendEventList).flatMap(dateToSendEvent -> {
                if (dateToSendEvent != null) {
                    return this.eventProducer.sendEvents(this.properties.getOutComingNotification(), customerOrder.getId(), customerOrder.getBuCode(), command, dateToSendEvent, notificationType.getTemplateType());
                } else {
                    return MonoUtil.warnLog("INTERNAL: No postponed date could be found for event {} and order {}", notificationType.getTemplateType(), customerOrder.getId()).then();
                }
            }).collectList().then();
        }
        return this.eventProducer.sendEvents(this.properties.getOutComingNotification(), customerOrder.getId(), customerOrder.getBuCode(), command);
    }

    private SendCustomerOrderNotification buildNotificationCommand(SendCustomerOrderNotificationParameter.Builder parameterBuilder) {
        return SendCustomerOrderNotification.newBuilder()
            .setId(UUID.randomUUID().toString())
            .setType("SendCustomerOrderNotification")
            .setParameterBuilder(parameterBuilder)
            .setCommandResponseTopicName(this.properties.getOutcomingNotificationResponse())
            .build();
    }

    private SendCustomerOrderNotificationParameter.Builder buildNotificationParameterBuilder(CustomerOrder customerOrder, String templateType, String externalOrchestratorId, List<String> linesId) {
        return buildNotificationParameterBuilder(customerOrder, templateType, externalOrchestratorId,  linesId, null);
    }

    private SendCustomerOrderNotificationParameter.Builder buildNotificationParameterBuilder(CustomerOrder customerOrder, String templateType, String externalOrchestratorId, List<String> linesId, final String customerOrderExecutionActionId) {
        return buildNotificationParameterBuilder(customerOrder, templateType, externalOrchestratorId, linesId, customerOrderExecutionActionId, null);
    }

    private SendCustomerOrderNotificationParameter.Builder buildNotificationParameterBuilder(CustomerOrder customerOrder, String templateType, String externalOrchestratorId, List<String> linesId, final String customerOrderExecutionActionId, final String executionPlanId) {
        return SendCustomerOrderNotificationParameter.newBuilder()
            .setBuCode(customerOrder.getBuCode())
            .setCustomerSaleNumber(customerOrder.getId())
            .setCustomerSaleVersion(customerOrder.getVersion())
            .setExternalOrchestratorId(externalOrchestratorId)
            .setCustomerSaleProvider(TEMPO_SYSTEM_NAME)
            .setCustomerSaleType("CustomerOrder")
            .setCustomerSaleInvolvedLines(linesId)
            .setCustomerOrderExecutionActionId(customerOrderExecutionActionId)
            .setCustomerOrderExecutionPlanId(executionPlanId)
            .setType(templateType)
            .setRequestDate(Instant.now());
    }

    private boolean executionPlanIdIfNeeded(List<LineExecution> lineExecutions, NotificationType notificationType) {
        boolean isTpp = lineExecutions.stream().anyMatch(lineExecution -> TPP == lineExecution.getPayment().getPaymentExecutionSystem());
        return isTpp && (NotificationType.PICKUP_APPOINTMENT_UPDATING.equals(notificationType) ||
            NotificationType.APPOINTMENT_REMINDER_DAY_BEFORE.equals(notificationType) ||
            NotificationType.APPOINTMENT_REMINDER_HOURS_BEFORE.equals(notificationType) ||
            NotificationType.PICKUP_APPOINTMENT_EXPIRED.equals(notificationType));
    }

    private SendCustomerOrderNotificationParameter.Builder buildNotificationParameterBuilder(List<LineExecution> lines, String mailType, CustomerOrder customerOrder) {
        final var linesId = LineExecution.lineIds(lines);

        return SendCustomerOrderNotificationParameter.newBuilder()
            .setBuCode(customerOrder.getBuCode())
            .setCustomerSaleNumber(customerOrder.getId())
            .setCustomerSaleVersion(customerOrder.getVersion())
            .setCustomerSaleProvider(TEMPO_SYSTEM_NAME)
            .setCustomerSaleType("CustomerOrder")
            .setCustomerSaleInvolvedLines(linesId)
            .setType(mailType)
            .setRequestDate(Instant.now());
    }

    private SendCustomerOrderNotificationParameter.Builder buildNotificationParameterBuilder(String executionActionId, String mailType, CustomerOrder customerOrder) {
        return SendCustomerOrderNotificationParameter.newBuilder()
            .setBuCode(customerOrder.getBuCode())
            .setCustomerSaleNumber(customerOrder.getId())
            .setCustomerSaleVersion(customerOrder.getVersion())
            .setCustomerSaleProvider(TEMPO_SYSTEM_NAME)
            .setCustomerSaleType("CustomerOrder")
            .setCustomerOrderExecutionActionId(executionActionId)
            .setType(mailType)
            .setRequestDate(Instant.now());
    }

    @Getter
    public enum NotificationType {

        PARTIAL_CANCELLATION_BY_VENDOR("CustomerOrderPartialCancellationByVendor"),

        VALIDATION("CustomerOrderValidationTempo"),
        VALIDATION_IN_STORE("CustomerOrderValidationTempoInStore"),
        ORDER_IN_STORE_TO_PAID("OrderInStoreToPayLevel1"),
        ORDER_IN_STORE_TO_PAID_REMINDER1("OrderInStoreToPayLevel2"),
        ORDER_IN_STORE_TO_PAID_REMINDER2("OrderInStoreToPayLevel3"),
        ORDER_IN_STORE_NOT_PAID_AUTO_CANCEL("OrderInStoreUnpaidAutoCancel"),
        WAITING_FOR_PAYMENT("CustomerOrderLongPaymentWaiting"),

        WAITING_FOR_PAYMENT_REMINDER("CustomerOrderLongPaymentWaitingReminder"),

        LONG_PAYMENT_CANCELED("CustomerOrderLongPaymentWaitingAutoCancel"),
        IN_STORE_LONG_PAYMENT("OrderInStoreToPayWithLongPayment"),

        PAYMENT_REFUSED("CustomerOrderPaymentCorrupted"),

        APPOINTMENT_REMINDER_DAY_BEFORE("PickUpInStoreAppointmentReminderDayBefore"),

        APPOINTMENT_REMINDER_HOURS_BEFORE("PickUpInStoreAppointmentReminderHoursBefore"),
        PICKUP_ORDER_DELIVERED("PickUpInStoreOrderDelivered"),
        PICKUP_APPOINTMENT_UPDATING("PickupInStoreAppointmentUpdating"),
        COLLECT_FORECASTED_LATE("PickupInStoreTotalDelayed"),
            COLLECT_PARTIALLY_FORECASTED_LATE("PickupInStorePartialDelayed"),
        PICKUP_APPOINTMENT_EXPIRED("PickUpInStoreOrderExpiredAppointment");

        private final String templateType;

        NotificationType(String templateType) {
            this.templateType = templateType;
        }

    }

    public enum NotificationMedia {
        EMAIL, SMS;
    }
}
