package com.adeo.sales.customerorder.tempoorchestrator.service.impl;

import com.adeo.sales.customerorder.external.api.client.cpr.ConfiguredProductRepositoryApiClient;
import com.adeo.sales.customerorder.external.api.client.csr.ConfiguratorSimulationsRepositoryApiClient;
import com.adeo.sales.customerorder.external.api.client.dst.DeliverySimulationTowerWebClient;
import com.adeo.sales.customerorder.external.api.client.dst.dto.Delivery;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliveryAddress;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliveryDate;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliveryPlace;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliverySimulation;
import com.adeo.sales.customerorder.external.api.client.dst.dto.HomeDelivery1PDetails;
import com.adeo.sales.customerorder.external.api.client.dst.dto.NoDeliveryPlace;
import com.adeo.sales.customerorder.external.api.client.dst.dto.OfferCartItem;
import com.adeo.sales.customerorder.external.api.client.dst.dto.RelayPoint;
import com.adeo.sales.customerorder.external.api.client.dst.dto.RelayPoint1PDetails;
import com.adeo.sales.customerorder.external.api.client.dst.dto.ServiceLevel;
import com.adeo.sales.customerorder.external.api.client.dst.dto.ServiceLevelDetails;
import com.adeo.sales.customerorder.external.api.client.dst.dto.ShippingPoint;
import com.adeo.sales.customerorder.external.api.client.dst.dto.ShippingPointType;
import com.adeo.sales.customerorder.external.api.client.dst.dto.StoreDeliveryPlace;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.service.FullfillmentReservationService;
import com.adeo.sis.dor.avro.business.fulfillmentorder.ChannelTypeEnumAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.CustomerDeliveryLocationAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.CustomerOrderCartItemAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.FulfillmentOrderLineReservationAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.FulfillmentOrderReservationAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.InvoicingLocationAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.LocationTypeEnumAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.LockFlagEnum;
import com.adeo.sis.dor.avro.business.fulfillmentorder.ProductAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.ShippingLocationAvro;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.Nullable;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment.PaymentExecutionSystem.TPP;


@Service
@Slf4j
public class FulfillmentReservationServiceImpl extends AbstractFulfillmentOrderService implements FullfillmentReservationService {
    private final EventProducer eventProducer;
    private final DeliverySimulationTowerWebClient dstClient;

    private final TopicsProperties properties;

    public FulfillmentReservationServiceImpl(ConfiguredProductRepositoryApiClient configuredProductRepositoryApiClient, ConfiguratorSimulationsRepositoryApiClient configuratorSimulationsRepositoryApiClient, EventProducer eventProducer, DeliverySimulationTowerWebClient dstClient, TopicsProperties properties) {
        super(configuredProductRepositoryApiClient, configuratorSimulationsRepositoryApiClient);
        this.eventProducer = eventProducer;
        this.dstClient = dstClient;
        this.properties = properties;
    }

    @Override
    public Mono<Void> createOrderReservation(List<LineExecution> lines, CustomerOrder customerOrder) {
        if (lines.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask to reservce the customer order on the 1P orchestrator system: {}", LineExecution.joinLineIds(lines));

        return dstClient.getDeliveries(customerOrder.getDelivery().getId(), customerOrder.getBuCode())
            .map(deliverySimulation ->
                FulfillmentOrderReservationAvro.newBuilder()
                    .setChannel(customerOrder.getOrderPlaceType() == CustomerOrderPlaceType.IN_STORE ? ChannelTypeEnumAvro.STORE : ChannelTypeEnumAvro.WEB)
                    .setCustomerOrderIdentifier(customerOrder.getId())
                    .setCustomerOrderNumber(customerOrder.getCustomerOrderNumber())
                    .setCustomerOrderCreatedDate(customerOrder.getMetadata().getCreationDate())
                    .setClientNumber(customerOrder.getCustomer().getId())
                    .setBusinessUnitIdentifier(customerOrder.getBuCode())
                    .setUserContextStoreIdentifier(Optional.ofNullable(deliverySimulation.getDeliveryContext().getUserStoreCode()).orElse(deliverySimulation.getDeliveryContext().getDefaultStoreCode()))
                    .setFulfillmentOrderLines(this.buildReservationLines(customerOrder, lines, deliverySimulation))
                    .build()
            )
                .flatMap(fulfillmentOrderReservationAvro -> {
                    boolean isTpp = lines.stream().anyMatch(lineExecution -> TPP == lineExecution.getPayment().getPaymentExecutionSystem());
                    if(isTpp){
                        return this.getSimulations(customerOrder, lines).collectList().defaultIfEmpty(List.of())
                            .zipWhen(simulations -> this.getConfiguredProducts(customerOrder, lines).collectList().defaultIfEmpty(List.of()))
                            .flatMap(tuple ->
                                Flux.fromIterable(fulfillmentOrderReservationAvro.getFulfillmentOrderLines())
                                    .flatMap(fulfillmentOrderLineExecutionAvro -> Flux.fromIterable(fulfillmentOrderLineExecutionAvro.getCustomerOrderCartItems()))
                                    .flatMap(customerOrderCartItemAvro ->
                                        Mono.justOrEmpty(this.buildFulfillmentOrderLineConfiguredProduct(customerOrder, lines, customerOrderCartItemAvro.getCustomerOrderCartItemIdentifier(), tuple)
                                            .map(fulfillmentOrderLineConfiguredProductAvro -> {
                                                customerOrderCartItemAvro.setFulfillmentOrderLineConfiguredProduct(fulfillmentOrderLineConfiguredProductAvro);
                                                return fulfillmentOrderReservationAvro;
                                            }))
                                     )
                                     .then(Mono.just(fulfillmentOrderReservationAvro))
                            );
                    } else {
                        return Mono.just(fulfillmentOrderReservationAvro);
                    }
                })
                .log()
            .flatMap(orderReservationRequest ->
                this.eventProducer.sendEvents(this.properties.getCreateDeliveryV2(customerOrder.getBuCode()), customerOrder.getId(), customerOrder.getBuCode(), orderReservationRequest)
            );
    }

    private List<FulfillmentOrderLineReservationAvro> buildReservationLines(CustomerOrder customerOrder, List<LineExecution> lines, DeliverySimulation deliverySimulation) {

        final var lineIds = LineExecution.lineIds(lines);
        return deliverySimulation.getDeliveries().stream()
            .filter(delivery -> delivery.getOfferCartItems()
                .stream()
                .anyMatch(offerCartItem -> lineIds.contains(offerCartItem.getId())))
            .map(delivery -> {
                final var deliveryPlace = deliverySimulation.getDeliveryPlace().getDeliveryPlace(delivery.getDeliveryMode(), delivery.getDeliveryPlaceReference());
                final var serviceLevel = delivery.getServiceLevel();
                final var shippingPoint = this.mapShippingPointToAvro(serviceLevel.getDetails(), deliveryPlace, customerOrder.getBuCode());
                final var cartIds = delivery.getOfferCartItems().stream().map(OfferCartItem::getId).collect(Collectors.toList());
                final var deliveryLineExecutions = lines.stream().filter(lineExecution -> cartIds.contains(lineExecution.getLineId())).collect(Collectors.toList());
                return FulfillmentOrderLineReservationAvro.newBuilder()
                    .setCustomerDeliveryServiceDeliveryMode(delivery.getDeliveryMode().name())
                    .setFulfillmentOrderLockFlags(shippingPoint != null ? this.getLockFlagForShippingPointAndDeliveryMode(shippingPoint.getType()) : List.of())
                    .setCustomerDeliveryLocation(this.buildDeliveryLocation(deliveryPlace, delivery))
                    .setDeliverySlotManagementIdentifier(serviceLevel.getDeliverySlotManagementId())
                    .setDeliveryServiceLevelIdentifier(serviceLevel.getType())
                    .setAvailableToPromiseMinDeliveryDate(DeliveryDate.getMinDate(serviceLevel.getDeliveryDate()).toInstant())
                    .setAvailableToPromiseMaxDeliveryDate(DeliveryDate.getMaxDate(serviceLevel.getDeliveryDate()).toInstant())
                    .setFulfillmentOrderAppointmentDate((serviceLevel.getAppointmentDate() != null) ? serviceLevel.getAppointmentDate().toInstant() : null)
                    .setCustomerDeliveryServiceIdentifier(this.getCarrierServiceCode(serviceLevel))
                    .setDeliveryCategoryTransportType(this.getCarrierType(serviceLevel))
                    .setExtraDeliveryServiceIdentifiers(serviceLevel.getExtraDeliveryServices() != null ? serviceLevel.getExtraDeliveryServices() : List.of())
                    .setShippingLocation(this.buildShippingLocation(shippingPoint))
                    .setInvoicingLocation(this.buildInvoicingLocation(customerOrder, deliveryLineExecutions))
                    .setCustomerOrderCartItems(this.buildCartItems(delivery, lines, customerOrder))
                    .build();
            }).collect(Collectors.toList());

    }

    private InvoicingLocationAvro buildInvoicingLocation(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        return InvoicingLocationAvro.newBuilder()
            .setInvoicingLocationIdentifier(lineExecutions.get(0).getPayment().getStoreId())
            .setInvoicingLocationType(LocationTypeEnumAvro.STORE)
            .setBusinessUnitIdentifier(customerOrder.getBuCode())
            .build();
    }

    private ShippingLocationAvro buildShippingLocation(ShippingPoint shippingPoint) {
        if (shippingPoint == null) {
            return null;
        }
        return ShippingLocationAvro.newBuilder()
            .setShippingLocationType(this.mapShippingPointTypeToAvro(shippingPoint.getType()))
            .setShippingLocationIdentifier(shippingPoint.getId())
            .setBusinessUnitIdentifier(shippingPoint.getBu())
            .build();
    }

    private LocationTypeEnumAvro mapShippingPointTypeToAvro(ShippingPointType type) {
        switch (type) {
            case STORE:
                return LocationTypeEnumAvro.STORE;
            case SUPPLIER:
                return LocationTypeEnumAvro.SUPPLIER;
            case WAREHOUSE:
                return LocationTypeEnumAvro.WAREHOUSE;
            default:
                return null;
        }
    }

    private String getCarrierServiceCode(ServiceLevel serviceLevel) {
        final var detail = serviceLevel.getDetails();
        if (detail instanceof RelayPoint1PDetails) {
            return ((RelayPoint1PDetails) serviceLevel.getDetails()).getCarrierServiceCode();
        } else if (detail instanceof HomeDelivery1PDetails) {
            return ((HomeDelivery1PDetails) serviceLevel.getDetails()).getCarrierServiceCode();
        }
        return null;
    }

    private String getCarrierType(ServiceLevel serviceLevel) {
        final var detail = serviceLevel.getDetails();
        if (detail instanceof RelayPoint1PDetails) {
            return ((RelayPoint1PDetails) serviceLevel.getDetails()).getCarrierType();
        } else if (detail instanceof HomeDelivery1PDetails) {
            return ((HomeDelivery1PDetails) serviceLevel.getDetails()).getCarrierType();
        }
        return null;
    }

    private ShippingPoint mapShippingPointToAvro(ServiceLevelDetails details, DeliveryPlace deliveryPlace, String buCode) {
        if (details instanceof RelayPoint1PDetails) {
            return ((RelayPoint1PDetails) details).getShippingPoint();
        } else if (details instanceof HomeDelivery1PDetails) {
            return ((HomeDelivery1PDetails) details).getShippingPoint();
        } else {
            if (deliveryPlace instanceof StoreDeliveryPlace) {
                return ShippingPoint.builder()
                    .bu(buCode)
                    .type(ShippingPointType.STORE)
                    .id(((StoreDeliveryPlace) deliveryPlace).getStoreCode())
                    .build();
            }
        }
        log.error("No delivery point founded in DST response.");
        return null;
    }

    private List<LockFlagEnum> getLockFlagForShippingPointAndDeliveryMode(ShippingPointType type) {
        switch (type) {
            case STORE:
                return List.of(LockFlagEnum.LOCKED_SHIPPING_POINT_ID);
            case SUPPLIER:
            case WAREHOUSE:
                return List.of(LockFlagEnum.LOCKED_SHIPPING_POINT_TYPE);
            default:
                return List.of();
        }
    }


    private CustomerDeliveryLocationAvro buildDeliveryLocation(DeliveryPlace deliveryPlace, Delivery delivery) {
        if (deliveryPlace instanceof NoDeliveryPlace) {
            return null;
        } else if (deliveryPlace instanceof StoreDeliveryPlace) {
            final var store = (StoreDeliveryPlace) deliveryPlace;
            return CustomerDeliveryLocationAvro.newBuilder()
                .setType(this.mapDeliveryType(delivery))
                .setIdentifier(store.getStoreCode())
                .build();
        } else if (deliveryPlace instanceof DeliveryAddress) {
            final var deliveryAddress = (DeliveryAddress) deliveryPlace;
            return CustomerDeliveryLocationAvro.newBuilder()
                .setType(this.mapDeliveryType(delivery))
                .setIdentifier(deliveryAddress.getId().toString())
                .setCountryCode(deliveryAddress.getCountryCode())
                .setPostalCode(deliveryAddress.getPostalCode())
                .setCityName(deliveryAddress.getCity())
                .build();
        } else if (deliveryPlace instanceof RelayPoint) {
            final var relayPoint = (RelayPoint) deliveryPlace;
            return CustomerDeliveryLocationAvro.newBuilder()
                .setType(this.mapDeliveryType(delivery))
                .setIdentifier(relayPoint.getProvider())
                .setCountryCode(relayPoint.getAddress().getCountryCode())
                .setPartnerCategoryName(relayPoint.getPartnerCategory())
                .setPostalCode(relayPoint.getAddress().getPostalCode())
                .setCityName(relayPoint.getAddress().getCity())
                .build();
        } else {
            log.warn("Unknown delivery place type: " + deliveryPlace.getClass().getName() + ". send null delivery place to DOR.");
            return null;
        }
    }


    private LocationTypeEnumAvro mapDeliveryType(Delivery delivery) {
        switch (delivery.getDeliveryMode()) {
            case HOME_DELIVERY:
            case RELAY_POINT_DELIVERY:
                return LocationTypeEnumAvro.ADDRESS;
            default:
                return LocationTypeEnumAvro.STORE;
        }
    }

    private List<CustomerOrderCartItemAvro> buildCartItems(com.adeo.sales.customerorder.external.api.client.dst.dto.Delivery delivery, List<LineExecution> lines, CustomerOrder customerOrder) {
        return delivery.getOfferCartItems()
            .stream()
            .filter(offerCartItem -> LineExecution.lineIds(lines).contains(offerCartItem.getId()))
            .map(offerCartItem -> {
                final var lineExecutionOption = LineExecution.getById(lines, offerCartItem.getId());
                final var offerLineOption = customerOrder.getProductOffer().getOfferLineById(offerCartItem.getId());
                if (lineExecutionOption.isEmpty() || offerLineOption.isEmpty()) {
                    log.warn("a line or an offer is not found in fulfillment mapping");
                    return null;
                }
                return CustomerOrderCartItemAvro.newBuilder()
                    .setCustomerOrderCartItemIdentifier(offerCartItem.getId())
                    .setIsSalesFloorStockIgnored(offerCartItem.isIgnoreStockOnHandleImmediateQuantity())
                    .setIsTargetOrchestrationRequested(lineExecutionOption.get().getExternalSystem().isTempo())
                    .setFulfillmentOrderInitialQuantity(offerLineOption.get().getInitialOrderedQuantity())
                    .setProduct(ProductAvro.newBuilder()
                        .setProductAdeoReference(offerLineOption.get().getOffer().getAdeoKey())
                        .setProductBuReference(offerLineOption.get().getOffer().getRefLM())
                        .build())
                    .build();
            })
            .filter(Objects::nonNull)
            .collect(Collectors.toList());
    }

}
