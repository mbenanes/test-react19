package com.adeo.sales.customerorder.tempoorchestrator.service.dor;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sis.dor.avro.business.fulfillmentorder.CustomerOrderCartItemCancellationAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.FulfillmentOrderLinesCancellationRequestAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.ProductAvro;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class FulfillmentCancelLineServiceImpl implements FulfillmentCancelLineService {
    private final EventProducer eventProducer;
    private final TopicsProperties properties;

    @Override
    public Mono<Void> decreaseQuantity(List<LineExecution> lines, ExecutionAction action, CustomerOrder customerOrder) {
        if (lines.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask to decrease quantity on delivery for following lines: {}", LineExecution.joinLineIds(lines));
        final var deceaseQuantityRequest = this.buildDeceaseQuantityRequest(lines, action, customerOrder);
        return this.eventProducer.sendEvents(this.properties.getDeliveryDecreaseQuantity(), customerOrder.getId(), customerOrder.getBuCode(), deceaseQuantityRequest);
    }

    private FulfillmentOrderLinesCancellationRequestAvro buildDeceaseQuantityRequest(List<LineExecution> lines, ExecutionAction action, CustomerOrder customerOrder) {
        return FulfillmentOrderLinesCancellationRequestAvro.newBuilder()
            .setCustomerOrderIdentifier(customerOrder.getId())
            .setBusinessUnitIdentifier(customerOrder.getBuCode())
            .setCancelledCustomerOrderCartItems(lines.stream()
                .map(lineExecution -> {
                    final var quantityToDecrease = action.getImpactedExecutions().stream()
                        .flatMap(impactedExecution -> impactedExecution.getImpactedLines().stream()
                            .filter(impactedLineAndQuantity -> impactedLineAndQuantity.getLineId().equals(lineExecution.getLineId()))
                            .map(ImpactedLine::getQuantity)
                        )
                        .reduce(BigDecimal.ZERO, BigDecimal::add);

                    return CustomerOrderCartItemCancellationAvro.newBuilder()
                        .setCustomerOrderCartItemIdentifier(lineExecution.getLineId())
                        .setFulfillmentOrderLineInitialQuantity(lineExecution.getInitialQuantity())
                        .setFulfillmentOrderLineCancelledQuantity(quantityToDecrease)
                        .setFulfillmentOrderLineExecutedQuantity(lineExecution.getQuantity().subtract(quantityToDecrease))
                        .setProduct(ProductAvro.newBuilder()
                            .setProductAdeoReference(lineExecution.getComposition().getOffer().getAdeoKey())
                            .setProductBuReference(lineExecution.getComposition().getOffer().getRefLM())
                            .build())
                        .build();
                })
                .collect(Collectors.toList()))
            .build();
    }
}
