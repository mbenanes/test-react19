package com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation;

public enum PaymentOperationTechnicalStatus {
    SUCCEED,
    REJECTED,
    TECHNICALLY_FAILED,
    DELAYED,
    PENDING;

    public static PaymentOperationTechnicalStatus mapFromString(String value) {
        if("ACCEPTED".equals(value)) {
            return SUCCEED;
        } else {
            return PaymentOperationTechnicalStatus.valueOf(value);
        }
    }
}
