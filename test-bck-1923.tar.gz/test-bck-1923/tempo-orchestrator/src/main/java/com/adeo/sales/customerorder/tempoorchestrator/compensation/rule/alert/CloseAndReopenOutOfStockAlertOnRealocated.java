package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.HAS_ALERT_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_TYPE_PROMISE_DATE_OUT_OF_STOCK_CREATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_STATUS_ALLOCATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "CloseAndReopenOutOfStockAlertOnRealocated",
    description = "Close and reopen alert OUT_OF_STOCK if necessary when DOR sends an FFME ALLOCATION_VALIDATED after an ALLOCATION_FAILED or a BusinessError",
    priority = 990)
public class CloseAndReopenOutOfStockAlertOnRealocated {

    private final AlertMessageService alertMessageService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var customerOrderLinesConcernedByRealloc = context.getOrderData().getLineExecutionsByPredicate(IS_1P.and((IS_DELIVERY_STATUS_ALLOCATED).or(IS_LINE_COMPOSITION_CANCELED)));

        return context.getAlertData().getExistingAlerts().stream()
            .filter(IS_TYPE_PROMISE_DATE_OUT_OF_STOCK_CREATED.and(HAS_ALERT_ID))
            .anyMatch(alert -> RuleEngineCompensationAlertsConditions.hasAtLeastOneCommonLineExecution(alert, customerOrderLinesConcernedByRealloc));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var allLineExecutions = context.getOrderData().getExistingLineExecutions();
        final var customerOrderLinesConcernedAllocated = context.getOrderData().getLineExecutionsByPredicate(IS_1P.and((IS_DELIVERY_STATUS_ALLOCATED).or(IS_LINE_COMPOSITION_CANCELED)));

        final var outOfStockAlerts = context.getAlertData().getExistingAlerts().stream()
            .filter(IS_TYPE_PROMISE_DATE_OUT_OF_STOCK_CREATED)
            .filter(alert -> RuleEngineCompensationAlertsConditions.hasAtLeastOneCommonLineExecution(alert, customerOrderLinesConcernedAllocated))
            .collect(Collectors.toList());

        return Flux.fromIterable(outOfStockAlerts)
            .flatMap(alertToClose -> alertMessageService.replaceExistingAlert(alertToClose, customerOrderLinesConcernedAllocated, allLineExecutions, context.getOrderData().getExistingCustomerOrder())
                .doOnNext(recreatedAlert -> context.getAlertData().addAlert(recreatedAlert)))
            .then();
    }

}
