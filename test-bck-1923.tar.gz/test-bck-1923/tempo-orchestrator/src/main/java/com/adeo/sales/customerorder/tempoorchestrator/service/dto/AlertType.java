package com.adeo.sales.customerorder.tempoorchestrator.service.dto;

public enum AlertType {
    PROMISED_DATE,
    TRANSACTION
}
