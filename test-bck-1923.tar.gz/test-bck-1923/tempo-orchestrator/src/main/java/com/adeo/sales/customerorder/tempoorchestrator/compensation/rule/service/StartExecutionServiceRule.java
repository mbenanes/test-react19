package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.service;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.ahs.AhsCommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_CASHING_STORE_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_DELIVERY_CREATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.CREATION_REQUESTED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "StartExecutionServiceRule",
    description = "Ask to AHS to execute service",
    priority = 1000)
public class StartExecutionServiceRule {

    private final AhsCommandEventService ahsCommandEventService;

    private static final Predicate<LineExecution> IS_SERVICE_LINE_TO_CREATE =
        PAYMENT_ORCHESTRATED_BY_TPP
            .and(IS_EXTERNAL_SYSTEM_TEMPO)
            .and(IS_LINE_COMPOSITION_VALIDATED)
            .and(IS_VALIDATION_REQUIREMENT_COMPLIANT)
            .and(IS_LINE_SERVICE)
            .and(HAS_CASHING_STORE_ID)
            .and(not(HAS_DELIVERY_CREATION_REQUESTED));

    private static final Predicate<LineExecution> IS_ASSOCIATED_PRODUCT_LINE_TO_CREATE =
        PAYMENT_ORCHESTRATED_BY_TPP
            .and(IS_EXTERNAL_SYSTEM_TEMPO)
            .and(IS_LINE_COMPOSITION_VALIDATED)
            .and(IS_VALIDATION_REQUIREMENT_COMPLIANT)
            .and(IS_OFFER);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        List<LineExecution> serviceLines = context.getOrderData().getLineExecutionsByPredicate(IS_SERVICE_LINE_TO_CREATE);
        return serviceLines.stream().anyMatch(serviceLine -> {
            List<LineExecution> associatedLines = serviceLine.getConfigurationService()
                .getAssociatedLinesId()
                .stream()
                .flatMap(lineId -> context.getOrderData().getFirstFindedLineExecutionById(lineId).stream())
                .toList();

            return associatedLines.isEmpty() || associatedLines.stream().allMatch(IS_ASSOCIATED_PRODUCT_LINE_TO_CREATE.or(IS_LINE_COMPOSITION_CANCELED));
        });
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        List<LineExecution> serviceLines = context.getOrderData().getLineExecutionsByPredicate(IS_SERVICE_LINE_TO_CREATE);

        List<LineExecution> associatedProducts = serviceLines.stream().flatMap(serviceLine -> serviceLine
                .getConfigurationService()
                .getAssociatedLinesId()
                .stream()
                .flatMap(lineId -> context.getOrderData().getFirstFindedLineExecutionById(lineId).stream())
                .filter(IS_ASSOCIATED_PRODUCT_LINE_TO_CREATE))
            .toList();

        List<LineExecution> allLines = Stream.concat(associatedProducts.stream(), serviceLines.stream()).distinct().toList();

        return MonoUtil.infoLog("INTERNAL request execution of service for 1P service lines : {} with associated products lines : {}", LineExecution.joinLineIds(serviceLines), LineExecution.joinLineIds(associatedProducts))
            .then(this.ahsCommandEventService.sendCustomerOrderValidatedWithInstallation(context.getOrderData().getExistingCustomerOrder(), allLines))
            .doOnSuccess(unused -> serviceLines.forEach(serviceLine -> serviceLine.getDelivery().getFlags().raiseFlag(CREATION_REQUESTED)))
            .onErrorResume(throwable -> {
                log.warn(throwable.getMessage(), throwable);
                log.warn("Do not start service lines ids : {} execution", LineExecution.joinLineIds(serviceLines));
                return Mono.empty();
            });
    }

}
