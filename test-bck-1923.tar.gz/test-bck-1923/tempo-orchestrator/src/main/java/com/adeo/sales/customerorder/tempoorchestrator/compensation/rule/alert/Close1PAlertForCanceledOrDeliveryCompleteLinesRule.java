package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.HAS_ALERT_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_REASON_CUSTOMER_CANCELLATION_FAILURE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_REASON_FORECASTED_LATE_ON_SHIPPED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_TYPE_PROMISE_DATE_NOT_CLOSED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.buildAlertReason;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.getAlertsContainingAllLinesByPredicate;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DECLARED_DELIVERED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_COMPLETE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Close1PAlert",
    description = "Close promised date alert an reason in (LATE, FORECASTED_LATE, CREATION_FAILURE, OUT_OF_STOCK)",
    priority = 990)
public class Close1PAlertForCanceledOrDeliveryCompleteLinesRule {
    private final AlertMessageService notifier;

    private static final Predicate<LineExecution> IS_1P_CANCELED_OR_DELIVERY_COMPLETE_OR_DECLARED_DELIVERED = IS_1P
        .and(IS_LINE_COMPOSITION_CANCELED.or(IS_DELIVERY_COMPLETE).or(IS_DECLARED_DELIVERED));
    private static final Predicate<Alert> IS_ALERT_CLOSABLE_FOR_CONSIDERED_DELIVERED_LINE =
        HAS_ALERT_ID
            .and(IS_TYPE_PROMISE_DATE_NOT_CLOSED)
            .and(not(IS_REASON_FORECASTED_LATE_ON_SHIPPED))
            .and(not(IS_REASON_CUSTOMER_CANCELLATION_FAILURE));

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(IS_1P_CANCELED_OR_DELIVERY_COMPLETE_OR_DECLARED_DELIVERED) && context.hasAtLeastOneAlert(IS_ALERT_CLOSABLE_FOR_CONSIDERED_DELIVERED_LINE);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {

        final var consideredDeliveredLineIds = context.getOrderData().getLineIdsByPredicate(IS_1P_CANCELED_OR_DELIVERY_COMPLETE_OR_DECLARED_DELIVERED);

        final var closableAlertForConsideredDeliveredLines = getAlertsContainingAllLinesByPredicate(context, consideredDeliveredLineIds, IS_ALERT_CLOSABLE_FOR_CONSIDERED_DELIVERED_LINE);

        return MonoUtil.infoLog("INTERNAL request close 1P alert for alerts: {} because all lines are canceled or delivered", Alert.joinAlertIds(closableAlertForConsideredDeliveredLines))
            .then(Mono.when(
                closableAlertForConsideredDeliveredLines.stream()
                    .map(alert -> this.notifier.sendCloseAlertMessage(alert, buildAlertReason(alert, consideredDeliveredLineIds, context)))
                    .collect(Collectors.toList())
            ));
    }
}
