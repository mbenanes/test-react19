package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import reactor.core.publisher.Mono;

public interface DomainEventService {
    Mono<Void> sendCustomerOrderCreationFailed(CustomerOrder customerOrder, ErrorInformation errorInfo);
}
