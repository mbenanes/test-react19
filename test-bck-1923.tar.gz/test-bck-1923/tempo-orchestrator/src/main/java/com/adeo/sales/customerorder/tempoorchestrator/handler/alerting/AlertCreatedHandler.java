package com.adeo.sales.customerorder.tempoorchestrator.handler.alerting;

import com.adeo.sales.customerorder.tempo.alertreferential.event.AlertCreated;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple5;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static reactor.function.TupleUtils.function;

@RequiredArgsConstructor
@Component
@Slf4j
public class AlertCreatedHandler implements EventHandler<AlertCreated> {
    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final ObjectMapper objectMapper;
    private final RuleEngineService ruleEngineService;

    @Override
    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    public Mono<Void> handle(AlertCreated event, EventMetaData eventMetaData) {
        final var customerOrderId = event.getDelta().getOrder().getId();
        final var buCode = eventMetaData.getBuCode();

        mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderId);
        log.info("AlertCreated consumes {} - message id: {}", eventMetaData.getTopic(), eventMetaData.getId().orElse("no id"));

        return ruleEngineService.lockAndGetData(customerOrderId, buCode)
            .flatMap(data -> acknowledgeAlertCreation(event, data))
            .flatMap(function(ruleEngineService.startRuleEngineAndUpdateLines()));
    }

    private Mono<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> acknowledgeAlertCreation(AlertCreated event, Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>> rulesEngineData) {
        final var alerts = rulesEngineData.getT3();

        return readRequestId(event)
            .flatMap(requestId -> {
                final var alertOpt = alerts.stream()
                    .filter(alert -> alert.getId().equals(requestId))
                    .findFirst();

                if (alertOpt.isEmpty()) {
                    return Mono.error(() -> new IllegalArgumentException("Can not find the alert with tempo orchestrator id " + requestId));
                }

                final var alert = alertOpt.get();
                if (alert.getTempoAlertingId() != null && !alert.getTempoAlertingId().equals(event.getDelta().getId())) {
                    log.warn(
                        "tempo alerting has sent a new AlertCreated on a already acknowledged alert. alert request id = {}, previous tempo alerting id = {}, new tempo alerting id = {}",
                        alert.getId(), alert.getTempoAlertingId(), event.getDelta().getId()
                    );
                }
                alert.setTempoAlertingId(event.getDelta().getId());
                alert.setStatus(AlertStatus.CREATED);

                return Mono.just(rulesEngineData);
            });
    }

    private Mono<UUID> readRequestId(AlertCreated event) {
        try {
            final var specificDataString = event.getDelta().getDomainSpecificData();
            if (specificDataString == null || specificDataString.isBlank()) {
                log.info("INTERNAL there are no specific data, can not link the tempo-alerting alert with a tempo-orchestrator alert");
                return Mono.empty();
            }
            final var specificData = objectMapper.readValue(specificDataString, Map.class);
            final var requestId = specificData.get("request-id");
            if (requestId == null) {
                log.info("INTERNAL there are no request id, can not link the tempo-alerting alert with a tempo-orchestrator alert");
                return Mono.empty();
            } else if (requestId instanceof String) {
                return Mono.just(UUID.fromString((String) requestId));
            } else {
                return Mono.error(new IllegalArgumentException("the request-id is not a string"));
            }
        } catch (JsonProcessingException e) {
            return Mono.error(new IllegalArgumentException("the domain specific data is not a well formed JSON", e));
        }
    }

    @Override
    public Class<?> getManagedEvent() {
        return AlertCreated.class;
    }
}
