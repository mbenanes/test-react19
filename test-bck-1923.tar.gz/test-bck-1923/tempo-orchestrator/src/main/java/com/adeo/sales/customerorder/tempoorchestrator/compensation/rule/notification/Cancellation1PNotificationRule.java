package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_EXECUTION_NOT_STARTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXECUTION_CANCELABLE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OWNERSHIP_TRANSFER_OR_VALUATE_STOCK_STARTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_PARTNER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR;
import static com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService.NotificationType.CUSTOMER_ORDER_PARTIAL_CANCELLATION;
import static com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService.NotificationType.CUSTOMER_ORDER_TOTAL_CANCELLATION;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Cancellation1PNotification",
    description = "Send cancellation notification for 1p cancelled lines.",
    priority = 950)
public class Cancellation1PNotificationRule {
    private static final List<String> NO_MAIL_TO_SEND_CANCELLATION_REASON = List.of("IN_STORE_ORDER_NOT_PAID");
    private static final Predicate<LineExecution> TCO_LINE_CANCELLATION_REASON_ALLOW_SEND_MAIL =
        line -> line.getComposition().getCancellationReason() == null || (line.getComposition().getCancellationReason() != null && !NO_MAIL_TO_SEND_CANCELLATION_REASON.contains(line.getComposition().getCancellationReason()));
    private static final Predicate<LineExecution> LINE_CANCELLATION_MAIL_NOT_ALREADY_SENT =
        line -> !line.isMailAlreadySent(CUSTOMER_ORDER_TOTAL_CANCELLATION.templateType) && !line.isMailAlreadySent(CUSTOMER_ORDER_PARTIAL_CANCELLATION.templateType);
    private static final Predicate<LineExecution> LINE_SHOULD_SEND_CANCELLATION_MAIL = IS_EXTERNAL_SYSTEM_TEMPO
        .and(PAYMENT_ORCHESTRATED_BY_PSR)
        .and(IS_LINE_COMPOSITION_CANCELED)
        .and(IS_DELIVERY_CANCELED.or(IS_SHIPPED_BY_PARTNER.or(IS_DELIVERY_EXECUTION_NOT_STARTED.and(IS_EXECUTION_CANCELABLE))))
        .and(LINE_CANCELLATION_MAIL_NOT_ALREADY_SENT)
        .and(TCO_LINE_CANCELLATION_REASON_ALLOW_SEND_MAIL)
        .and(not(IS_OWNERSHIP_TRANSFER_OR_VALUATE_STOCK_STARTED));
    private final OutgoingNotificationService notificationService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var customerOrderValidationMailHasBeenSent = context.getOrderData().getExistingCustomerOrder().getNotificationStatus() != null;

        return customerOrderValidationMailHasBeenSent && context.hasAtLeastOneLine(LINE_SHOULD_SEND_CANCELLATION_MAIL);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var canceledLinesToNotify = context.getOrderData().getLineExecutionsByPredicate(LINE_SHOULD_SEND_CANCELLATION_MAIL);

        final var areAllTempoLineCanceled = context.getOrderData().getExistingLineExecutions().stream()
            .filter(IS_EXTERNAL_SYSTEM_TEMPO)
            .allMatch(IS_LINE_COMPOSITION_CANCELED);

        final var mailType = areAllTempoLineCanceled ? CUSTOMER_ORDER_TOTAL_CANCELLATION : CUSTOMER_ORDER_PARTIAL_CANCELLATION;

        return MonoUtil.infoLog("INTERNAL send notification type {} for lines {}", mailType, LineExecution.joinLineIds(canceledLinesToNotify))
            .then(notificationService.sendMailForLines(canceledLinesToNotify, mailType.templateType, context.getOrderData().getExistingCustomerOrder()))
            .then(Mono.fromRunnable(() -> {
                canceledLinesToNotify.forEach(line -> {
                    line.mailIsSent(mailType.templateType);
                    line.increaseVersion();
                });
            }));
    }
}
