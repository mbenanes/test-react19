package com.adeo.sales.customerorder.tempoorchestrator.compensation.engine;

import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction.isExecutionActionReasonMatches;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionReasonEnum.CANCELLATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionReasonEnum.REMAINING_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Status.CREATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Status.PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.ABORT_DELIVERY_3P;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.ASK_GENERATE_DEPOSIT_LEGACY_NUMBER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.ASK_PREPARATION_REQUIREMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.CANCEL_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.CREATE_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.SEND_CANCELLATION_BY_VENDOR_NOTIFICATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.SEND_CANCELLATION_NOTIFICATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.SEND_PAYMENT_REFUSED_NOTIFICATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.SPLIT_LINE_EXECUTION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP;

@NoArgsConstructor
@Slf4j
public class RuleEngineCompensationExecutionActionConditions {

    public static final Predicate<ExecutionAction> IS_EXECUTION_ACTION_IS_DECREASE_QUANTITY = executionAction -> executionAction.getActionType() == ExecutionActionType.DECREASE_QUANTITY;
    public static final Predicate<ExecutionAction> IS_EXECUTION_ACTION_IS_SPLIT = executionAction -> executionAction.getActionType() == ExecutionActionType.SPLIT;

    public static final Predicate<ExecutionAction> IS_EXECUTION_ACTION_TO_EXECUTE = executionAction -> executionAction.getFlags().lastFlagIs(ExecutionActionStatus.CREATED);
    public static final Predicate<ExecutionAction> IS_EXECUTION_ACTION_PROCESSING = executionAction -> executionAction.getFlags().lastFlagIs(ExecutionActionStatus.PROCESSING);
    public static final Predicate<ExecutionAction> IS_EXECUTION_ACTION_COMPLETED = executionAction -> executionAction.getFlags().lastFlagIs(ExecutionActionStatus.COMPLETED);
    public static final Predicate<ExecutionAction> IS_EXECUTION_ACTION_FAILED = executionAction -> executionAction.getFlags().lastFlagIs(ExecutionActionStatus.FAILED);

    public static final Predicate<ExecutionAction> IS_DECREASE_QUANTITY_ACTION_PROCESSING = IS_EXECUTION_ACTION_PROCESSING.and(IS_EXECUTION_ACTION_IS_DECREASE_QUANTITY);
    public static final Predicate<ExecutionAction> IS_SPLIT_ACTION_PROCESSING = IS_EXECUTION_ACTION_PROCESSING.and(IS_EXECUTION_ACTION_IS_SPLIT);

    public static final Predicate<ExecutionAction> IS_EXECUTION_ACTION_REASON_IS_CANCELLATION = executionAction -> isExecutionActionReasonMatches(executionAction, CANCELLATION.name());
    public static final Predicate<ExecutionAction> IS_EXECUTION_ACTION_REASON_IS_REMAINING_COLLECT = executionAction -> isExecutionActionReasonMatches(executionAction, REMAINING_COLLECT.name());

    public static final Predicate<ExecutionAction> IS_SPLIT_REMAINING_COLLECT_ACTION_PROCESSING = IS_SPLIT_ACTION_PROCESSING.and(IS_EXECUTION_ACTION_REASON_IS_REMAINING_COLLECT);

    public static final Predicate<ExecutionAction> IS_DECREASE_QUANTITY_DELIVERY_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(DECREASE_QUANTITY_DELIVERY).isEmpty();
    public static final Predicate<ExecutionAction> ASK_GENERATE_DEPOSIT_LEGACY_NUMBER_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(ASK_GENERATE_DEPOSIT_LEGACY_NUMBER).isEmpty();
    public static final Predicate<ExecutionAction> IS_CANCEL_SERVICE_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(CANCEL_SERVICE).isEmpty();
    public static final Predicate<ExecutionAction> IS_ABORT_DELIVERY_3P_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(ABORT_DELIVERY_3P).isEmpty();
    public static final Predicate<ExecutionAction> IS_DECREASE_QUANTITY_COLLECT_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(DECREASE_QUANTITY_COLLECT).isEmpty();
    public static final Predicate<ExecutionAction> IS_UNEXEC_REQUIREMENT_TPP_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(UNEXEC_REQUIREMENT_TPP).isEmpty();
    public static final Predicate<ExecutionAction> IS_EXECUTE_ADJUSTMENT_TPP_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(EXECUTE_ADJUSTMENT_TPP).isEmpty();
    public static final Predicate<ExecutionAction> IS_SPLIT_LINE_EXECUTION_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(SPLIT_LINE_EXECUTION).isEmpty();
    public static final Predicate<ExecutionAction> IS_ASK_PREPARATION_REQUIREMENT_TPP_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(ASK_PREPARATION_REQUIREMENT_TPP).isEmpty();
    public static final Predicate<ExecutionAction> IS_CREATE_COLLECT_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(CREATE_COLLECT).isEmpty();
    public static final Predicate<ExecutionAction> IS_SEND_CANCELLATION_NOTIFICATION_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(SEND_CANCELLATION_NOTIFICATION).isEmpty();
    public static final Predicate<ExecutionAction> IS_SEND_CANCELLATION_BY_VENDOR_NOTIFICATION_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(SEND_CANCELLATION_BY_VENDOR_NOTIFICATION).isEmpty();
    public static final Predicate<ExecutionAction> IS_SEND_PAYMENT_REFUSED_NOTIFICATION_IS_THE_NEXT_STEP = executionAction -> !executionAction.getImpactedExecutionsNextStepType(SEND_PAYMENT_REFUSED_NOTIFICATION).isEmpty();
    public static final Predicate<ExecutionAction> HAS_LEAST_ONE_IMPACTED_LINE_HAS_NEXT_STEP_DECREASE_QUANTITY_COMPOSITION = executionAction -> !executionAction.getImpactedExecutionsNextStepType(DECREASE_QUANTITY_COMPOSITION).isEmpty();
    public static final Predicate<ExecutionAction> IS_ALL_STEP_ARE_DONE = executionAction -> executionAction.getAllImpactedLines()
        .stream()
        .flatMap(impactedLine -> impactedLine.getSteps().stream())
        .noneMatch(step -> step.getFlags().lastFlagIsOneOf(CREATED, PROCESSING));

}
