package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr;

import com.adeo.sales.customerorder.paymentscheduler.v2.execution.Operation;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.CreateOrUpdateCustomerOrderApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderAlreadyExists;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPaymentExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.PaymentOperationType;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.LinePaymentOperationHistory;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationTechnicalStatus;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LinePaymentOperationRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.impl.LockPosgresRepository;
import com.adeo.sales.postpone.utils.MonoLog;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.ReactiveTransactionManager;
import org.springframework.transaction.reactive.TransactionalOperator;
import org.springframework.util.CollectionUtils;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationType.AUTHORIZATION;
import static com.adeo.sales.customerorder.tempoorchestrator.utils.LockUtils.getIdTrimmedUsedToLock;
import static com.adeo.sales.customerorder.tempoorchestrator.utils.LockUtils.getTransactionDefinition;
import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@RequiredArgsConstructor
@Component
@Slf4j
public class PaymentAgreementApplicationService {
    private final RuleEngineService ruleEngineService;
    private final CreateOrUpdateCustomerOrderApplicationService createOrUpdateCustomerOrderApplicationService;
    private final LinePaymentOperationRepository linePaymentOperationRepository;
    private final LockPosgresRepository lockPosgresRepository;
    private final ReactiveTransactionManager transactionManager;


    public static final List<String> DELAYED_PAYMENT_MEANS = List.of("MULTIBANCO");
    public static final List<String> PAYMENT_MEANS_WICH_DEPOSIT_LEGACY_NUMBER_NOT_OWNED_BY_TOR = List.of("BANK_TRANSFER_WEB", "BIZUM", "MULTIBANCO");

    public static final List<PaymentOperationType> AUTHORIZED_STATUS = List.of(PaymentOperationType.AUTHORIZATION_DELAYED, PaymentOperationType.AUTHORIZATION_PENDING, PaymentOperationType.AUTHORIZATION_REJECTED);


    public Mono<Void> apply(List<Operation> operations, String customerOrderId, String buCode) {
        final var authorizationOperations = mapOperationToLineAuthorization(operations, customerOrderId, buCode);

        return this.lockAndGetDataThenUpdate(authorizationOperations, customerOrderId, buCode)
            .onErrorResume(CustomerOrderNotFound.class, error -> this.initCustomerOrder(authorizationOperations, customerOrderId, buCode)
                .onErrorResume(
                    CustomerOrderAlreadyExists.class,
                    errorCreation -> this.lockAndGetDataThenUpdate(authorizationOperations, customerOrderId, buCode)
                ))
            .then();
    }

    public Mono<Void> lockAndGetDataThenUpdate(List<LinePaymentOperationHistory> input, String customerOrderId, String buCode) {
        long idToLock = getIdTrimmedUsedToLock(customerOrderId);
        TransactionalOperator rxtx = TransactionalOperator.create(transactionManager, getTransactionDefinition(this));
        return rxtx.transactional(
            lockPosgresRepository.acquireLocks(idToLock)
                .then(MonoLog.info("update customer order payment"))
                .then(this.ruleEngineService.lockAndGetData(customerOrderId, buCode))
                .doOnNext(
                    consumer((customerOrder, lineExecutions, alerts) -> this.updateLinePayment(input, lineExecutions))
                )
                .flatMap(function(ruleEngineService.startRuleEngineAndUpdateLines()))
                .then(linePaymentOperationRepository.saveLinesOperation(input)));
    }

    private void updateLinePayment(List<LinePaymentOperationHistory> inputLinePaymentOperationHistories, List<LineExecution> lineExecutions) {
        lineExecutions.forEach(lineExecution -> {
            final var linePaymentOperationHistoriesByLineId = this.getLinePaymentOperationHistoriesByLineId(inputLinePaymentOperationHistories, lineExecution.getLineId());
            mapPaymentExecutionFlags(linePaymentOperationHistoriesByLineId, lineExecution.getPayment().getPaymentExecution().getFlags());

            inputLinePaymentOperationHistories.stream().findFirst()
                .filter(linePaymentOperationHistory -> AUTHORIZATION.equals(linePaymentOperationHistory.getOperationType()))
                .ifPresent(linePaymentOperationHistory -> {
                    lineExecution.getPayment().setCaptureAllowedBefore(linePaymentOperationHistory.getCaptureAllowedBefore());
                    lineExecution.getPayment().setIsCaptureGuarantee(linePaymentOperationHistory.getIsCaptureGuarantee());
                    lineExecution.getPayment().setIsDelayedPayment(DELAYED_PAYMENT_MEANS.contains(linePaymentOperationHistory.getPaymentMean()));
                    lineExecution.getPayment().setDepositLegacyNumberNotOwnedByTor(PAYMENT_MEANS_WICH_DEPOSIT_LEGACY_NUMBER_NOT_OWNED_BY_TOR.contains(linePaymentOperationHistory.getPaymentMean()));
                });
        });
    }

    private List<LinePaymentOperationHistory> getLinePaymentOperationHistoriesByLineId(List<LinePaymentOperationHistory> linePaymentOperationHistories, String customerOrderLineId) {
        return linePaymentOperationHistories.stream()
            .filter(operation -> operation.getLineId().equals(customerOrderLineId) &&
                operation.getOperationType() == com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationType.AUTHORIZATION)
            .collect(Collectors.toList());
    }


    public Mono<Void> initCustomerOrder(List<LinePaymentOperationHistory> inputPaymentOperations, String customerOrderId, String buCode) {
        final String customerOrderNumberTrimmed = customerOrderId.replaceAll("[^0-9]", "");

        CustomerOrder customerOrderToCreate = buildCustomerOrder(customerOrderId, buCode);

        final List<LineExecution> linesExecutionToCreate = buildLineExecution(inputPaymentOperations, customerOrderId, buCode);

        if (CollectionUtils.isEmpty(linesExecutionToCreate)) {
            log.error("The customer order has not products.");
            return Mono.empty();
        }

        TransactionalOperator rxtx = TransactionalOperator.create(transactionManager, getTransactionDefinition(this));

        long id = Long.parseLong(customerOrderNumberTrimmed.substring(0, Math.min(customerOrderNumberTrimmed.length(), 10)));
        return rxtx.transactional(lockPosgresRepository.acquireLocks(id)
            .then(MonoLog.info("create customer order payment"))
            .then(
                createOrUpdateCustomerOrderApplicationService.createOrderAndLines(customerOrderToCreate, linesExecutionToCreate)
            )).then(rxtx.transactional(
            lockPosgresRepository.acquireLocks(id)
                .then(ruleEngineService.lockCustomerOrderThenstartRuleEngineAndUpdateLines(customerOrderToCreate.getId(), customerOrderToCreate.getBuCode()))));
    }

    private List<LineExecution> buildLineExecution(List<LinePaymentOperationHistory> inputPaymentOperations, String customerOrderId, String buCode) {
        final var operationsByLineId = inputPaymentOperations.stream().collect(Collectors.groupingBy(LinePaymentOperationHistory::getLineId));
        return operationsByLineId.entrySet().stream().map(entry -> {
            Optional<LinePaymentOperationHistory> newerOperationOption = entry.getValue().stream().max(Comparator.comparing(LinePaymentOperationHistory::getCreatedAt));
            String paymentMean = newerOperationOption.map(LinePaymentOperationHistory::getPaymentMean).orElse("UNKNOWN");
            return LineExecution.builder()
                .version(1)
                .lineId(entry.getKey())
                .customerOrderId(customerOrderId)
                .lineType(LineType.OFFER)
                .buCode(buCode)
                .payment(LineExecutionPayment.builder()
                    .captureAllowedBefore(newerOperationOption.map(LinePaymentOperationHistory::getCaptureAllowedBefore).orElse(null))
                    .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.PSR)
                    .isCaptureGuarantee(newerOperationOption.map(LinePaymentOperationHistory::getIsCaptureGuarantee).orElse(null))
                    .isDelayedPayment(DELAYED_PAYMENT_MEANS.contains(paymentMean))
                    .isDepositLegacyNumberNotOwnedByTor(PAYMENT_MEANS_WICH_DEPOSIT_LEGACY_NUMBER_NOT_OWNED_BY_TOR.contains(paymentMean))
                    .paymentExecution(LineExecutionPaymentExecution.builder()
                        .flags(this.buildPaymentExecutionFlags(entry.getValue()))
                        .build())
                    .build())
                .build();
        }).toList();
    }

    private static CustomerOrder buildCustomerOrder(String customerOrderId, String buCode) {
        return CustomerOrder.builder()
            .id(customerOrderId)
            .buCode(buCode)
            .version(1)
            .build();
    }

    private List<LinePaymentOperationHistory> mapOperationToLineAuthorization(List<Operation> operations, String customerOrderId, String buCode) {
        return operations.stream()
            .flatMap(operation -> operation.getLines().stream()
                .filter(line -> line.getType().equals("OFFER_LINE") || line.getType().equals("LOYALTY_LINE"))
                .map(line -> LinePaymentOperationHistory.builder()
                    .operationId(operation.getId())
                    .operationType(AUTHORIZATION)
                    .status(mapPaymentOperationStatus(operation.getStatus()))
                    .customerOrderId(customerOrderId)
                    .lineId(line.getId())
                    .transactionId(operation.getTransactionId())
                    .isCaptureGuarantee(operation.getAdditionalInformation() == null || operation.getAdditionalInformation().getIsCaptureGarantee())
                    .captureAllowedBefore(operation.getAdditionalInformation() != null ? operation.getAdditionalInformation().getCaptureAllowedBefore().atOffset(ZoneOffset.UTC) : null)
                    .buCode(buCode)
                    .paymentMean(operation.getInstrumentType())
                    .alertRequested(false)
                    .createdAt(LocalDateTime.now(ZoneId.of("UTC")))
                    .build()
                )
            ).collect(Collectors.toList());
    }

    private PaymentOperationTechnicalStatus mapPaymentOperationStatus(String operationStatus) {
        if (operationStatus.equals("PENDING")) {
            return PaymentOperationTechnicalStatus.DELAYED;
        } else if (operationStatus.equals("ACCEPTED")) {
            return PaymentOperationTechnicalStatus.SUCCEED;
        } else {
            return PaymentOperationTechnicalStatus.REJECTED;
        }
    }

    private Flags<PaymentOperationType> buildPaymentExecutionFlags(List<LinePaymentOperationHistory> authorizationOperations) {
        Flags<PaymentOperationType> flags = new Flags<>();
        mapPaymentExecutionFlags(authorizationOperations, flags);
        return flags;
    }

    private static void mapPaymentExecutionFlags(List<LinePaymentOperationHistory> authorizationOperations, Flags<PaymentOperationType> flags) {
        if (flags.hasNoFlags() || flags.lastFlagIsOneOf(AUTHORIZED_STATUS)) {
            authorizationOperations
                .stream()
                .sorted(Comparator.comparing(LinePaymentOperationHistory::getCreatedAt))
                .forEach(operation -> {
                    final var creationDateWithOffset = operation.getCreatedAt().atOffset(OffsetDateTime.now().getOffset());
                    switch (operation.getStatus()) {
                        case SUCCEED ->
                            flags.raiseFlagIfNot(operation.getOperationId(), PaymentOperationType.AUTHORIZED, creationDateWithOffset);
                        case DELAYED ->
                            flags.raiseFlagIfNot(operation.getOperationId(), PaymentOperationType.AUTHORIZATION_DELAYED, creationDateWithOffset);
                        case PENDING ->
                            flags.raiseFlagIfNot(operation.getOperationId(), PaymentOperationType.AUTHORIZATION_PENDING, creationDateWithOffset);
                        case REJECTED ->
                            flags.raiseFlagIfNot(operation.getOperationId(), PaymentOperationType.AUTHORIZATION_REJECTED, creationDateWithOffset);
                        default -> {
                        }
                    }
                });
        }
    }

}

