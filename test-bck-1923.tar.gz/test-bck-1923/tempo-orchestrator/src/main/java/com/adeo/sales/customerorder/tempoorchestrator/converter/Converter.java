package com.adeo.sales.customerorder.tempoorchestrator.converter;

public interface Converter<From, To> {

    To convert(From from);
}
