package com.adeo.sales.customerorder.tempoorchestrator.service.impl;

import com.adeo.sales.customerorder.external.api.client.dst.DeliverySimulationTowerWebClient;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliveryAddress;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliveryDate;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliveryMode;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliveryPlace;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliverySimulation;
import com.adeo.sales.customerorder.external.api.client.dst.dto.HomeDelivery1PDetails;
import com.adeo.sales.customerorder.external.api.client.dst.dto.NoDeliveryPlace;
import com.adeo.sales.customerorder.external.api.client.dst.dto.OfferCartItem;
import com.adeo.sales.customerorder.external.api.client.dst.dto.RelayPoint;
import com.adeo.sales.customerorder.external.api.client.dst.dto.RelayPoint1PDetails;
import com.adeo.sales.customerorder.external.api.client.dst.dto.ServiceLevel;
import com.adeo.sales.customerorder.external.api.client.dst.dto.ServiceLevelDetails;
import com.adeo.sales.customerorder.external.api.client.dst.dto.ShippingPoint;
import com.adeo.sales.customerorder.external.api.client.dst.dto.ShippingPointType;
import com.adeo.sales.customerorder.external.api.client.dst.dto.StoreDeliveryPlace;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.service.CommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sis.orchestrator.command.orderexecution.CancelCustomerOrderLinesRequest;
import com.adeo.sis.orchestrator.command.orderexecution.CancelCustomerOrderLinesRequestParameter;
import com.adeo.sis.orchestrator.command.orderexecution.OrderExecutionRequest;
import com.adeo.sis.orchestrator.command.orderexecution.OrderExecutionRequestParameter;
import com.adeo.sis.orchestrator.command.updateavailabletopromiserequest.UpdateAvailableToPromiseRequest;
import com.adeo.sis.orchestrator.data.Customer;
import com.adeo.sis.orchestrator.data.CustomerOrderDelivery;
import com.adeo.sis.orchestrator.data.Delivery;
import com.adeo.sis.orchestrator.data.DeliveryContext;
import com.adeo.sis.orchestrator.data.DeliveryModeTypeEnum;
import com.adeo.sis.orchestrator.data.LocationTypeEnum;
import com.adeo.sis.orchestrator.data.LockFlagEnum;
import com.adeo.sis.orchestrator.data.OrderLine;
import com.adeo.sis.orchestrator.data.Quotation;
import com.adeo.sis.orchestrator.data.dor.Offer;
import com.adeo.sis.orchestrator.data.dor.ProductOffer;
import com.adeo.sis.orchestrator.data.dor.ProductOfferLine;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.math.RoundingMode;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate.getMaxDate;

@RequiredArgsConstructor
@Slf4j
@Component
public class FirstPartyCommandServiceImpl implements CommandEventService {

    private final TopicsProperties properties;
    private final EventProducer eventProducer;
    private final DeliverySimulationTowerWebClient dstClient;

    @Override
    public Mono<Void> createOrderExecution(List<LineExecution> lines, CustomerOrder customerOrder) {
        if (lines.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask to create the customer order on the 1P orchestrator system: {}", LineExecution.joinLineIds(lines));

        return dstClient.getDeliveries(customerOrder.getDelivery().getId(), customerOrder.getBuCode())
            .map(deliverySimulation ->
                OrderExecutionRequest.newBuilder()
                    .setId(UUID.randomUUID().toString())
                    .setType("OrderExecutionRequest")
                    .setCommandResponseTopicName(this.properties.getProductExecutionResponse())
                    .setData(buildDORCustomerOrder(customerOrder, lines, deliverySimulation))
                    .setParameterBuilder(
                        OrderExecutionRequestParameter.newBuilder()
                            .setCustomerOrderId(customerOrder.getId())
                            .setRetry(0)
                    )
                    .build()
            )
            .flatMap(orderExecutionRequest ->
                this.eventProducer.sendEvents(this.properties.getCreateDeliveryV2(customerOrder.getBuCode()), customerOrder.getId(), customerOrder.getBuCode(), orderExecutionRequest)
            );
    }

    @Override
    public Mono<Void> cancelCustomerOrderLines(List<LineExecution> lines, CustomerOrder customerOrder) {
        if (lines.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask to cancel the delivery for following lines: {}", LineExecution.joinLineIds(lines));

        final var cancelCustomerOrderLinesRequest = this.buildCancelCustomerOrderLinesRequest(lines, customerOrder);

        return this.eventProducer.sendEvents(this.properties.getCancelCustomerOrderLines(customerOrder.getBuCode()), customerOrder.getId(), customerOrder.getBuCode(), cancelCustomerOrderLinesRequest);
    }

    @Override
    public Mono<Void> sendUpdateDeliveryDate(List<LineExecution> lines, CustomerOrder customerOrder) {
        if (lines.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask to update the delivery for following lines: {}", LineExecution.joinLineIds(lines));

        final var updateAvailableToPromiseRequest = this.buildUpdateAvailableToPromiseRequestRequest(lines, customerOrder);

        return this.eventProducer.sendEvents(this.properties.getUpdateAvailableToPromise(customerOrder.getBuCode()), customerOrder.getId(), customerOrder.getBuCode(), updateAvailableToPromiseRequest);
    }

    private Instant extractMinDeliveryDateFromLine(com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate deliveryDate) {
        return deliveryDate != null ? getMaxDate(deliveryDate).toInstant() : null;
    }

    private UpdateAvailableToPromiseRequest buildUpdateAvailableToPromiseRequestRequest(List<LineExecution> lines, CustomerOrder customerOrder) {
        final var dorLines = lines.stream()
            .map(line ->
                OrderLine.newBuilder()
                    .setTempoLineId(line.getLineId())
                    .setId(line.getLineId())
                    .setBuId(line.getBuCode())
                    .setFulfillmentPO(null)
                    .setQuantity(null)
                    .setFulfillmentPOLine(null)
                    .setQuantity(null)
                    .setProductReference(null)
                    .setMinDeliveryDate(extractMinDeliveryDateFromLine(line.getDelivery().getNewDeliveryDate()))
                    .setRelayPoint(null)
                    .setShippingAddress(null)
                    .setShipvia(null)
                    .setToCancel(null)
                    .setOrderLineNumber(null)
                    .setSourcingLocation(null)
                    .build()
            )
            .collect(Collectors.toList());

        return UpdateAvailableToPromiseRequest.newBuilder()
            .setId(UUID.randomUUID().toString())
            .setType("UpdateAvailableToPromiseRequest")
            .setBuCode(customerOrder.getBuCode())
            .setOrderId(customerOrder.getId())
            .setOrderLineIds(dorLines)
            .setOrderLines(dorLines)
            .build();
    }

    private CancelCustomerOrderLinesRequest buildCancelCustomerOrderLinesRequest(List<LineExecution> lines, CustomerOrder customerOrder) {
        final var reason = lines.stream()
            .map(lineExecution -> lineExecution.getComposition().getCancellationReason())
            .filter(Objects::nonNull)
            .findFirst()
            .orElse("NO_REASON_PROVIDED");

        return CancelCustomerOrderLinesRequest.newBuilder()
            .setId(UUID.randomUUID().toString())
            .setType("CancelCustomerOrderLinesRequest")
            .setCommandResponseTopicName(this.properties.getProductExecutionResponse())
            .setData(buildDORCustomerOrder(customerOrder, lines))
            .setParameterBuilder(
                CancelCustomerOrderLinesRequestParameter.newBuilder()
                    .setCancelCustomerOrder(false)
                    .setCustomerOrderId(customerOrder.getId())
                    .setReason(reason)
            )
            .build();
    }

    private com.adeo.sis.orchestrator.data.dor.CustomerOrder buildDORCustomerOrder(CustomerOrder customerOrder, List<LineExecution> lines) {
        return buildDORCustomerOrder(customerOrder, lines, null);
    }

    private com.adeo.sis.orchestrator.data.dor.CustomerOrder buildDORCustomerOrder(CustomerOrder customerOrder, List<LineExecution> lines, DeliverySimulation deliverySimulation) {
        final var builder = com.adeo.sis.orchestrator.data.dor.CustomerOrder.newBuilder()
            .setId(customerOrder.getId())
            .setVersion(customerOrder.getVersion())
            .setCustomerOrderNumber(customerOrder.getCustomerOrderNumber())
            .setBuCode(customerOrder.getBuCode())
            // to remove when dor will correct their avros
            .setPyxisNumber(null)
            .setProductOfferBuilder(
                ProductOffer.newBuilder()
                    .setId(customerOrder.getProductOffer().getId())
                    .setVersion(customerOrder.getProductOffer().getVersion())
                    .setItems(
                        lines.stream().map(line -> this.buildCancelCustomerOrderLinesRequestDataProductOfferItem(line, customerOrder)).collect(Collectors.toList())
                    )
            )
            .setDeliveryBuilder(
                Delivery.newBuilder()
                    .setId(customerOrder.getDelivery().getId())
                    .setVersion(customerOrder.getDelivery().getVersion())
            )
            .setQuotation(null)
            .setDeliveryContextBuilder(
                DeliveryContext.newBuilder()
                    .setDeliveries(this.buildDeliveries(deliverySimulation, lines, customerOrder.getBuCode()))
                    .setContextStore(
                        Optional.ofNullable(deliverySimulation)
                            .map(DeliverySimulation::getDeliveryContext)
                            .map(context -> Optional.ofNullable(context.getUserStoreCode()).orElse(context.getDefaultStoreCode()))
                            .orElse(null)
                    )
            )
            .setQuotationBuilder(
                Quotation.newBuilder()
                    .setId(customerOrder.getQuotation().getId())
                    .setVersion(customerOrder.getQuotation().getVersion())
            );

        if (customerOrder.getCustomer() != null) {
            builder.setCustomerBuilder(
                Customer.newBuilder()
                    .setId(customerOrder.getCustomer().getId())
            );
        }
        return builder.build();
    }

    private List<CustomerOrderDelivery> buildDeliveries(DeliverySimulation deliverySimulation, List<LineExecution> lines, String buCode) {
        if (deliverySimulation == null) {
            return null;
        }

        final var lineIds = LineExecution.lineIds(lines);
        return deliverySimulation.getDeliveries().stream()
            .filter(delivery -> this.mapDeliveryModeToAvro(delivery.getDeliveryMode()) != null)
            .filter(delivery -> delivery.getOfferCartItems().stream().anyMatch(offerCartItem -> lineIds.contains(offerCartItem.getId())))
            .map(delivery -> {
                final var deliveryPlace = deliverySimulation.getDeliveryPlace().getDeliveryPlace(delivery.getDeliveryMode(), delivery.getDeliveryPlaceReference());
                return CustomerOrderDelivery.newBuilder()
                    .setDeliveryMode(this.mapDeliveryModeToAvro(delivery.getDeliveryMode()))
                    .setDeliveryPlace(
                        mapDeliveryPlaceToAvro(deliveryPlace)
                    )
                    .setServiceLevel(
                        mapServiceLevelToAvro(delivery, deliveryPlace, buCode)
                    )
                    .setOfferCartItems(
                        mapOfferCartItemsToAvro(delivery.getOfferCartItems(), lines)
                    )
                    .build();
            })
            .collect(Collectors.toList());
    }

    private List<com.adeo.sis.orchestrator.data.OfferCartItem> mapOfferCartItemsToAvro(List<OfferCartItem> offerCartItems, List<LineExecution> lineExecutions) {
        if (offerCartItems == null) {
            return null;
        }
        final var lineIds = LineExecution.lineIds(lineExecutions);
        return offerCartItems.stream()
            .filter(item -> lineIds.contains(item.getId()))
            .map(item ->
                com.adeo.sis.orchestrator.data.OfferCartItem.newBuilder()
                    .setId(item.getId())
                    .setIsTargetOrchestrationRequested(isTempoExternalSystem(lineExecutions, item.getId()))
                    .setQuantity(item.getQuantity().setScale(5, RoundingMode.UNNECESSARY))
                    .setProductId(item.getProductId())
                    .setCashingStore(LineExecution.getCorrespondingLine(lineExecutions, item.getId())
                        .map(lineExecution -> lineExecution.getPayment().getStoreId())
                        .orElse(null))
                    .build()
            )
            .collect(Collectors.toList());
    }

    private boolean isTempoExternalSystem(List<LineExecution> lineExecutions, String offerCartItemId) {
        final Optional<LineExecution> lineExecution = LineExecution.getById(lineExecutions, offerCartItemId);
        return lineExecution.isPresent() && ExternalSystem.SystemName.TEMPO == lineExecution.get().getExternalSystem().getName();
    }

    private com.adeo.sis.orchestrator.data.ServiceLevel mapServiceLevelToAvro(com.adeo.sales.customerorder.external.api.client.dst.dto.Delivery delivery, DeliveryPlace deliveryPlace, String buCode) {
        final var serviceLevel = delivery.getServiceLevel();
        if (serviceLevel == null) {
            return null;
        }

        com.adeo.sis.orchestrator.data.ShippingPoint shippingPoint = mapShippingPointToAvro(serviceLevel.getDetails(), deliveryPlace, buCode);
        final var lockFlags = getLockFlagForShippingPointAndDeliveryMode(shippingPoint);

        return com.adeo.sis.orchestrator.data.ServiceLevel.newBuilder()
            .setType(serviceLevel.getType())
            .setAppointmentDate((serviceLevel.getAppointmentDate() != null) ? serviceLevel.getAppointmentDate().toInstant() : null)
            .setMinDeliveryDate(DeliveryDate.getMinDate(serviceLevel.getDeliveryDate()).toInstant())
            .setMaxDeliveryDate(DeliveryDate.getMaxDate(serviceLevel.getDeliveryDate()).toInstant())
            .setCarrierServiceCode(getCarrierServiceCode(serviceLevel))
            .setCarrierType(getCarrierType(serviceLevel))
            .setDeliverySlotManagementId(serviceLevel.getDeliverySlotManagementId())
            .setExtraDeliveryServices(serviceLevel.getExtraDeliveryServices())
            .setLockFlags(lockFlags)
            .setShippingPoint(shippingPoint)
            .build();
    }

    private List<LockFlagEnum> getLockFlagForShippingPointAndDeliveryMode(com.adeo.sis.orchestrator.data.ShippingPoint shippingPoint) {
        if (shippingPoint == null) {
            return List.of();
        }

        return switch (shippingPoint.getType()) {
            case STORE -> List.of(LockFlagEnum.LOCKED_SHIPPING_POINT_ID);
            case SUPPLIER, WAREHOUSE -> List.of(LockFlagEnum.LOCKED_SHIPPING_POINT_TYPE);
            default -> List.of();
        };
    }

    private String getCarrierType(ServiceLevel serviceLevel) {
        final var detail = serviceLevel.getDetails();
        if (detail instanceof RelayPoint1PDetails) {
            return ((RelayPoint1PDetails) serviceLevel.getDetails()).getCarrierType();
        } else if (detail instanceof HomeDelivery1PDetails) {
            return ((HomeDelivery1PDetails) serviceLevel.getDetails()).getCarrierType();
        }
        return null;
    }

    private String getCarrierServiceCode(ServiceLevel serviceLevel) {
        final var detail = serviceLevel.getDetails();
        if (detail instanceof RelayPoint1PDetails) {
            return ((RelayPoint1PDetails) serviceLevel.getDetails()).getCarrierServiceCode();
        } else if (detail instanceof HomeDelivery1PDetails) {
            return ((HomeDelivery1PDetails) serviceLevel.getDetails()).getCarrierServiceCode();
        }
        return null;
    }

    private com.adeo.sis.orchestrator.data.ShippingPoint mapShippingPointToAvro(ServiceLevelDetails details, DeliveryPlace deliveryPlace, String buCode) {
        final ShippingPoint shippingPoint;
        if (details instanceof RelayPoint1PDetails) {
            shippingPoint = ((RelayPoint1PDetails) details).getShippingPoint();
        } else if (details instanceof HomeDelivery1PDetails) {
            shippingPoint = ((HomeDelivery1PDetails) details).getShippingPoint();
        } else {
            if (deliveryPlace instanceof StoreDeliveryPlace) {
                shippingPoint = ShippingPoint.builder()
                    .bu(buCode)
                    .type(ShippingPointType.STORE)
                    .id(((StoreDeliveryPlace) deliveryPlace).getStoreCode())
                    .build();
            } else {
                return null;
            }
        }
        return com.adeo.sis.orchestrator.data.ShippingPoint.newBuilder()
            .setBuCode(shippingPoint.getBu())
            .setId(shippingPoint.getId())
            .setType(mapShippingPointTypeToAvro(shippingPoint.getType()))
            .build();
    }

    private LocationTypeEnum mapShippingPointTypeToAvro(ShippingPointType type) {
        return switch (type) {
            case STORE -> LocationTypeEnum.STORE;
            case SUPPLIER -> LocationTypeEnum.SUPPLIER;
            case WAREHOUSE -> LocationTypeEnum.WAREHOUSE;
        };
    }

    private com.adeo.sis.orchestrator.data.DeliveryPlace mapDeliveryPlaceToAvro(DeliveryPlace deliveryPlace) {
        if (deliveryPlace instanceof NoDeliveryPlace) {
            return null;
        } else if (deliveryPlace instanceof StoreDeliveryPlace) {
            return com.adeo.sis.orchestrator.data.DeliveryPlace.newBuilder()
                .setStoreCode(((StoreDeliveryPlace) deliveryPlace).getStoreCode())
                .build();
        } else if (deliveryPlace instanceof DeliveryAddress deliveryAddress) {
            return com.adeo.sis.orchestrator.data.DeliveryPlace.newBuilder()
                .setDeliveryAddressBuilder(mapDeliveryAddressToAvro(deliveryAddress))
                .build();
        } else if (deliveryPlace instanceof RelayPoint relayPoint) {
            return com.adeo.sis.orchestrator.data.DeliveryPlace.newBuilder()
                .setPartnerCategory(relayPoint.getPartnerCategory())
                .setProviderId(relayPoint.getProvider())
                .setDeliveryAddressBuilder(mapDeliveryAddressToAvro(relayPoint.getAddress()))
                .build();
        } else {
            log.warn("Unknown delivery place type: " + deliveryPlace.getClass().getName() + ". send null delivery place to DOR.");
            return null;
        }
    }

    private com.adeo.sis.orchestrator.data.DeliveryAddress.Builder mapDeliveryAddressToAvro(DeliveryAddress
                                                                                                deliveryAddress) {
        return com.adeo.sis.orchestrator.data.DeliveryAddress.newBuilder()
            .setCityName(deliveryAddress.getCity())
            .setCountryCode(deliveryAddress.getCountryCode())
            .setPostalCode(deliveryAddress.getPostalCode())
            .setProvinceName(deliveryAddress.getProvince());
    }

    private DeliveryModeTypeEnum mapDeliveryModeToAvro(DeliveryMode deliveryMode) {
        return switch (deliveryMode) {
            case PICKUP_IN_STORE -> DeliveryModeTypeEnum.PICKUP_IN_STORE;
            case HOME_DELIVERY -> DeliveryModeTypeEnum.HOME_DELIVERY;
            case RELAY_POINT_DELIVERY -> DeliveryModeTypeEnum.RELAY_POINT_DELIVERY;
            default -> null;
        };
    }

    private ProductOfferLine buildCancelCustomerOrderLinesRequestDataProductOfferItem(LineExecution line, CustomerOrder customerOrder) {
        final var offerOption = customerOrder.getProductOffer().getOfferLineById(line.getLineId());
        if (offerOption.isEmpty()) {
            log.warn("The corresponding offer is not found for the line {}", line.getLineId());
        }
        return offerOption.map(offer -> ProductOfferLine.newBuilder()
            .setId(line.getLineId())
            .setOfferBuilder(
                Offer.newBuilder()
                    .setId(offer.getOffer().getId())
                    .setVendorId(offer.getOffer().getVendorId())
                    .setAdeoKey(offer.getOffer().getAdeoKey())
                    .setRefLM(offer.getOffer().getRefLM())
            )
            .setPyxisNumber(null)
            .setQuantity(offer.getQuantity().setScale(5, RoundingMode.UNNECESSARY))
            .setCashingStore(line.getPayment().getStoreId())
            .build()).orElse(null);
    }
}
