package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.ShippingPoint;
import lombok.Builder;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Builder
@Getter
public class DeliveryStepUpdatedInput {
    private final String messageId;
    private final List<Line> lines;
    private final String customerOrderId;
    private final String buCode;

    @Builder
    @Getter
    public static class Line {
        private final String lineId;
        private final Boolean isCancelable;
        private final DORStatus status;
        private final String storeCode;
        private final String incoterm;
        private final FoQuantities foQuantities;
        private final ShippingPoint shippingPoint;
        private final DeliveryDate estimatedDeliveryDate;
        private final String legacyOrderNumber;

        @Builder
        @Getter
        public static class FoQuantities{
            private final BigDecimal initialQuantity;
            private final BigDecimal executedQuantity;
            private final BigDecimal cancelledQuantity;
        }
    }

    public Optional<Line> getLine(String lineId) {
        return lines.stream()
            .filter(line -> line.lineId.equals(lineId))
            .findFirst();
    }

    public List<String> lineIds() {
        return this.lines.stream()
            .map(line -> line.lineId)
            .collect(Collectors.toList());
    }

}
