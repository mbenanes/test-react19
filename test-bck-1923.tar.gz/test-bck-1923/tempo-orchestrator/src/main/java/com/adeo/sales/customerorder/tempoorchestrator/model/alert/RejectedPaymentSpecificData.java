package com.adeo.sales.customerorder.tempoorchestrator.model.alert;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Getter
@SuperBuilder
@NoArgsConstructor
public class RejectedPaymentSpecificData extends AlertSpecificData {

    private RejectedPaymentSpecificData(RejectedPaymentSpecificData from) {
        super(from);
    }

    @Override
    public AlertSpecificData copy() {
        return new RejectedPaymentSpecificData(this);
    }
}
