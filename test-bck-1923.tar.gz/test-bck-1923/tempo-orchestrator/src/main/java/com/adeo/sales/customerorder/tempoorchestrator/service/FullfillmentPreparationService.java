package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import reactor.core.publisher.Mono;

import java.util.List;

public interface FullfillmentPreparationService {
    Mono<Void> createOrderPreparation(List<LineExecution> lines, CustomerOrder customerOrder);

    Mono<Void> createOrderAnticipatedPreparation(List<LineExecution> lines, CustomerOrder customerOrder);
}
