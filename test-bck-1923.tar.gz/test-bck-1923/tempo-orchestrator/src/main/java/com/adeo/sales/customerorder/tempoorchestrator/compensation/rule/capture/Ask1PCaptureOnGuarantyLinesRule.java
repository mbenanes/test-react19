package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.capture;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.CaptureService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_PAYMENT_AUTHORIZED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CAPTURE_GUARANTEE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_EXECUTION_NOT_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_RECEIVED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_REJECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_SHIPPED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DEPOSIT_LEGACY_NUMBER_NULL;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LOYALTY_FEE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PAYMENT_STATUS_ALLOWS_ASK_CAPTURE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_RESERVE_AND_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_PARTNER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_STORE_WITH_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_WAREHOUSE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.PaymentOperationType.CAPTURE_REQUESTED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Ask1PCaptureOnGuarantyLines",
    description = "Ask first party line capture when the payment is guaranty.",
    priority = 1000)
public class Ask1PCaptureOnGuarantyLinesRule {

    public static final Predicate<LineExecution> IS_SHIPPED_BY_WAREHOUSE_OR_PARTNER = IS_SHIPPED_BY_PARTNER.or(IS_SHIPPED_BY_WAREHOUSE);
    public static final Predicate<LineExecution> IS_SHIPPED_OR_DELIVERED = IS_DELIVERY_SHIPPED.or(IS_DELIVERY_RECEIVED);
    public static final Predicate<LineExecution> IS_A_SHIPPED_OR_DELIVERED_OFFER = IS_OFFER.and(IS_SHIPPED_BY_WAREHOUSE_OR_PARTNER.or(IS_SHIPPED_BY_STORE_WITH_TEMPO)).and(IS_SHIPPED_OR_DELIVERED);
    public static final Predicate<LineExecution> IS_A_VALIDATED_LOYALTY_FEE = IS_LOYALTY_FEE.and(IS_LINE_COMPOSITION_VALIDATED);
    public static final Predicate<LineExecution> FIRST_PARTY_LINE_SFP_SFW_TO_CAPTURE =
        IS_A_SHIPPED_OR_DELIVERED_OFFER
            .or(IS_A_VALIDATED_LOYALTY_FEE)
            .and(IS_PAYMENT_STATUS_ALLOWS_ASK_CAPTURE)
            .and(HAS_PAYMENT_AUTHORIZED)
            .and(IS_CAPTURE_GUARANTEE);
    public static final Predicate<LineExecution> RESERVE_AND_COLLECT_ORCHESTRATED_TEMPO_TO_CAPTURE = IS_RESERVE_AND_COLLECT.and(IS_EXTERNAL_SYSTEM_TEMPO).and(HAS_PAYMENT_AUTHORIZED).and(IS_PAYMENT_STATUS_ALLOWS_ASK_CAPTURE).and(IS_DELIVERY_EXECUTION_NOT_CANCELED.and(not(IS_DELIVERY_REJECTED)));
    public static final Predicate<LineExecution> LINES_SHOULD_ASK_CAPTURE = not(IS_LINE_COMPOSITION_CANCELED)
        .and(FIRST_PARTY_LINE_SFP_SFW_TO_CAPTURE.or(RESERVE_AND_COLLECT_ORCHESTRATED_TEMPO_TO_CAPTURE))
        .and(PAYMENT_ORCHESTRATED_BY_PSR)
        .and(not(IS_DEPOSIT_LEGACY_NUMBER_NULL));

    private final CaptureService captureService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.isCustomerOrderMatches(IS_VALIDATED) && context.hasAtLeastOneLine(LINES_SHOULD_ASK_CAPTURE);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        var lineToCapture = context.getOrderData().getLineExecutionsByPredicate(LINES_SHOULD_ASK_CAPTURE);

        return MonoUtil.infoLog("INTERNAL request capture for 1P lines: {}", LineExecution.joinLineIds(lineToCapture))
            .then(this.captureService.sendCommandCaptureOnDeposit(context.getOrderData().getExistingCustomerOrder(), lineToCapture))
            .then(Mono.fromRunnable(() -> lineToCapture.forEach(lineExecution -> {
                lineExecution.getPayment().getPaymentExecution().getFlags().raiseFlag(CAPTURE_REQUESTED);
                lineExecution.increaseVersion();
            })));
    }
}
