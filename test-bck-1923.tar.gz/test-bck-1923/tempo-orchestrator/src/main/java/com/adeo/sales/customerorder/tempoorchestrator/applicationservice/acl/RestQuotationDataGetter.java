package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl;

import com.adeo.sales.customerorder.external.api.client.quotation.QuotationApiClient;
import com.adeo.sales.customerorder.external.api.client.quotation.dto.OfferLineItem;
import com.adeo.sales.customerorder.external.api.client.quotation.dto.Transaction;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.input.CashingStoreAssignerInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.QuotationVersionsInconsistent;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
@Component
public class RestQuotationDataGetter implements QuotationDataGetter {
    private final QuotationApiClient client;

    @Override
    public Mono<QuotationData> apply(CashingStoreAssignerInput input) {
        return client.getQuotation(input.getQuotationId(), input.getBuCode())
            .map(transaction -> stopIfInconsistentVersions(transaction, input.getQuotationVersion(), input.getQuotationId()))
            .map(this::buildQuotationData);
    }

    @Override
    public Mono<Void> applyValidate(CustomerOrder customerOrder) {
        return client.validateQuotation(customerOrder.getQuotation().getId(), customerOrder.getQuotation().getVersion(), customerOrder.getBuCode()).then();
    }

    private QuotationData buildQuotationData(Transaction transaction) {
        return QuotationData.builder()
            .status(QuotationStatus.valueOf(transaction.getStatus()))
            .loyaltyFees(mapLoyaltyFee(transaction.getLoyaltyFees()))
            .metadataByOfferLineId(
                transaction.getOfferLineItems().stream()
                    .collect(Collectors.toMap(OfferLineItem::getId, it -> LineMetadata.builder().cashingStore(it.getCashingStore()).build()))
            )
            .build();
    }

    private List<LoyaltyFee> mapLoyaltyFee(List<com.adeo.sales.customerorder.external.api.client.quotation.dto.LoyaltyFee> loyaltyFees) {
        if (loyaltyFees == null) {
            return List.of();
        }
        return loyaltyFees.stream()
            .map(loyaltyFee -> LoyaltyFee.builder()
                .id(loyaltyFee.getId())
                .amount(loyaltyFee.getAmount())
                .cashingStore(loyaltyFee.getCashingStore())
                .offerId(loyaltyFee.getOffer().getId())
                .refLM(loyaltyFee.getBuReference())
                .vendorId(loyaltyFee.getVendor().getCode())
                .build()
            )
            .collect(Collectors.toList());
    }

    private Transaction stopIfInconsistentVersions(Transaction transaction, Integer expectedVersion, String quotationId) {
        if (!transaction.getVersion().equals(expectedVersion)) {
            throw new QuotationVersionsInconsistent(expectedVersion, transaction.getVersion(), quotationId);
        }
        return transaction;
    }
}
