package com.adeo.sales.customerorder.tempoorchestrator.repository;

import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.List;

@Repository
public interface LineExecutionRepository {
    Mono<Void> save(List<LineExecution> lineExecutions);

    Mono<Void> upsert(List<LineExecution> lineExecutions);

    Mono<Void> updateExecutionId(List<LineExecution> lineExecutions);

    Flux<LineExecution> getSFWorSFPLinesWhereAuthorizationWillExpireBefore(OffsetDateTime limitExpirationDate);

    Flux<LineExecution> getByCustomerOrderIdForUpdate(String customerOrderId, String buCode);

    Flux<LineExecution> getByDeliveryLegacyNumber(String deliveryLegacyNumber, String buCode, String storeId);

    class NoLineExecutionInsertedException extends RuntimeException {
        public NoLineExecutionInsertedException() {
            super("No customer order line has been inserted");
        }
    }
}
