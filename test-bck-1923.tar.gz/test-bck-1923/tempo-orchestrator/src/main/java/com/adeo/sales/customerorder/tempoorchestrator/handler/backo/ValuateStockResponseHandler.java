package com.adeo.sales.customerorder.tempoorchestrator.handler.backo;

import com.adeo.sales.customerorder.tempoorchestrator.event.command.ValuateStockBackoResponse;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.ValuateStockBackoResponseOrderLines;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.backo.input.StockValorizedInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.backo.StockValorizedApplicationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.stream.Collectors;

@RequiredArgsConstructor
@Component
@Slf4j
public class ValuateStockResponseHandler implements EventHandler<ValuateStockBackoResponse> {

    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final StockValorizedApplicationService stockValorizedApplicationService;

    @Override
    public Mono<Void> handle(ValuateStockBackoResponse event, EventMetaData eventMetaData) {
        final var deliveryLegacyNumber = event.getOrderId();
        final var buCode = eventMetaData.getBuCode();
        mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, deliveryLegacyNumber);
        log.info("ValuateStockBackoResponse consumes {} - delivery legacy number: {}", eventMetaData.getTopic(), deliveryLegacyNumber);

        final var input = StockValorizedInput.builder()
            .buCode(buCode)
            .deliveryLegacyNumber(deliveryLegacyNumber)
            .storeCode(event.getStoreId())
            .succeed(event.getSuccess())
            .productReferences(event.getOrderLines().stream()
                .map(ValuateStockBackoResponseOrderLines::getReference)
                .collect(Collectors.toList()))
            .build();

        return stockValorizedApplicationService.apply(input);
    }

    @Override
    public Class<?> getManagedEvent() {
        return ValuateStockBackoResponse.class;
    }
}
