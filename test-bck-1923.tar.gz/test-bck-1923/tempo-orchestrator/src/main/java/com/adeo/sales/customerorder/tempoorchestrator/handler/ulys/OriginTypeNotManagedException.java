package com.adeo.sales.customerorder.tempoorchestrator.handler.ulys;

public class OriginTypeNotManagedException extends RuntimeException {

    public static final String ERROR_MESSAGE = "the cashing origin type %s is not managed on an authorization feedback.";

    public OriginTypeNotManagedException(String status) {
        super(String.format(ERROR_MESSAGE, status));
    }
}
