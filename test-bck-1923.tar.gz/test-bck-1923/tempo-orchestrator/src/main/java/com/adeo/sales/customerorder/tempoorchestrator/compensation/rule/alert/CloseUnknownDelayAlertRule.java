package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.ApplicationProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.repository.AlertRepository;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.HAS_ALERT_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_ALERT_CREATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_REASON_FORECASTED_EARLY;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_REASON_FORECASTED_LATE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_REASON_LATE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_TYPE_PROMISE_DATE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.getAlertsContainingAllLinesByPredicate;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.getAlertsContainingLineByPredicate;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService.ClosingReason.REPLACED;

@Component
@Slf4j
@Rule(name = "CloseUnknownDelayAlert",
    description = "Close alert with UNKNOWN_DELAY reason",
    priority = 998)
public class CloseUnknownDelayAlertRule extends AlertWithoutDateAlertRuleCommon {

    private static final Predicate<Alert> IS_ALERT_CLOSABLE =
        HAS_ALERT_ID
            .and(IS_ALERT_CREATED)
            .and(IS_TYPE_PROMISE_DATE)
            .and(IS_REASON_LATE.or(IS_REASON_FORECASTED_LATE).or(IS_REASON_FORECASTED_EARLY));

    public CloseUnknownDelayAlertRule(AlertRepository alertRepository, AlertMessageService alertMessageService, ApplicationProperties applicationProperties) {
        super(alertRepository, alertMessageService, applicationProperties);
    }

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        List<LineExecution> lineExecutionWithAlertToCreate = context.getOrderData().getLineExecutionsByPredicate(IS_UNKNOWN_DELAY_ALERT_CAN_BE_OPENED_LINES);
        List<String> lineIdsWithAlertToCreate = LineExecution.lineIds(lineExecutionWithAlertToCreate);
        return context.isCustomerOrderMatches(IS_VALIDATED) &&
            !getAlertsContainingAllLinesByPredicate(context, lineIdsWithAlertToCreate, IS_ALERT_CLOSABLE).isEmpty();
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        List<LineExecution> lineExecutionWithAlertToCreate = context.getOrderData().getLineExecutionsByPredicate(IS_UNKNOWN_DELAY_ALERT_CAN_BE_OPENED_LINES);
        List<String> lineIdsWithAlertToCreate = LineExecution.lineIds(lineExecutionWithAlertToCreate);
        List<Alert> alertsToClose = getAlertsContainingLineByPredicate(context, lineIdsWithAlertToCreate, IS_ALERT_CLOSABLE);
        return this.closeAlerts(alertsToClose);
    }

    private Mono<Void> closeAlerts(List<Alert> alertsToClose) {
        alertsToClose.forEach(alert -> alert.setStatus(AlertStatus.CLOSE_REQUESTED));

        final var closeAlertsMono = Flux.fromIterable(alertsToClose)
            .flatMap(alert -> alertMessageService.sendCloseAlertMessage(alert, REPLACED))
            .then();

        return Mono.when(
            closeAlertsMono,
            this.alertRepository.upsert(alertsToClose)
        );
    }

}
