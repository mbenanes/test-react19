package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertReason;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.PromisedDateSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.AlertMessageInput;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate.getMaxCustomerKnownDeliveryDate;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.IS_REASON_CUSTOMER_CANCELLATION_FAILURE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_TPP_UNEXEC_REQUIREMENT_IN_PROGRESS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_FAILED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_IS_DECREASE_QUANTITY;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Cancellation1PFailureAlertTPPRule",
    description = "Cancellation order failure for TPP order.",
    priority = 990)
public class Cancellation1PFailureAlertTPPRule {

    private final AlertMessageService alertMessageService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var allFailedLines = this.getLinesToAlert(context);
        if (allFailedLines.isEmpty()) {
            return false;
        } else {
            return context.getOrderData().hasAtLeastOneExecutionRespectPredicate(PAYMENT_ORCHESTRATED_BY_TPP
                .and(not(RuleEngineCompensationConditions.IS_CURRENT_TPP_VERSION_MISMATCH))
                .and(not(IS_TPP_UNEXEC_REQUIREMENT_IN_PROGRESS))) &&
            allFailedLines
                .stream()
                .filter(lineExecution -> !lineExecution.getDelivery().isShippedByPartner())
                .anyMatch(lineExecution -> context.getAlertData().getAlertsForExecutionAndLine(lineExecution, IS_REASON_CUSTOMER_CANCELLATION_FAILURE).isEmpty() ||
                    context.getAlertData().getAlertsFor(lineExecution, IS_REASON_CUSTOMER_CANCELLATION_FAILURE).isEmpty());
        }
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var cancellationFailureLinesWithoutAlerts = this.getLinesToAlert(context)
            .stream()
            .filter(lineExecution -> !lineExecution.getDelivery().isShippedByPartner())
            .filter(lineExecution -> context.getAlertData().getAlertsFor(lineExecution, IS_REASON_CUSTOMER_CANCELLATION_FAILURE).isEmpty())
            .collect(Collectors.toList());

        return Flux.fromIterable(cancellationFailureLinesWithoutAlerts.stream()
            .collect(Collectors.groupingBy(LineExecution::getExecutionId))
            .entrySet())
            .flatMap(lineExecutionByExecution -> {
                final var customerKnownDeliveryDate = getMaxCustomerKnownDeliveryDate(lineExecutionByExecution.getValue());

                final var alert = this.buildAlert(context, lineExecutionByExecution.getValue(), DeliveryDate.getMaxDate(customerKnownDeliveryDate));

                return this.alertMessageService.sendCreateAlertMessage(this.buildAlertMessageInput(alert, cancellationFailureLinesWithoutAlerts, context.getOrderData().getExistingCustomerOrder()))
                    .doOnSuccess(unused -> context.getAlertData().addAlert(alert));
            })
            .then();
    }

    private List<LineExecution> getLinesToAlert(RuleEngineContext context) {
        final var lastDecreaseQuantityExecutionAction = context.getExecutionActionsByPredicate(IS_EXECUTION_ACTION_IS_DECREASE_QUANTITY.and(IS_EXECUTION_ACTION_FAILED))
            .stream()
            .max(Comparator.comparing(ExecutionAction::getCreatedAt));

        return lastDecreaseQuantityExecutionAction
            .stream()
            .flatMap(executionAction -> executionAction.getImpactedExecutions().stream())
            .flatMap(impactedExecution -> impactedExecution.getImpactedLines()
                .stream()
                .filter(impactedLine -> impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY).stream()
                    .filter(ImpactedLineStep::isBlocking)
                    .anyMatch(step -> step.getFlags().lastFlagIs(ImpactedLineStep.Status.FAILED)))
                .flatMap(impactedLine -> context.getOrderData().getLineExecutionByIdAndExecutionId(impactedLine.getLineId(), impactedExecution.getCurrentExecutionId()).stream())
            ).toList();
    }

    private Alert buildAlert(RuleEngineContext context, List<LineExecution> linesIdToCreateAlert, OffsetDateTime customerKnownDeliveryDate) {
        final Map<String, List<String>> impactedLineByExecution = linesIdToCreateAlert.stream()
            .collect(Collectors.groupingBy(lineExecution -> Optional.ofNullable(lineExecution.getExecutionId()).orElse(lineExecution.getCustomerOrderId()),
                Collectors.mapping(LineExecution::getLineId, Collectors.toList())));

        final var lineMetadataByLineId = linesIdToCreateAlert.stream()
            .collect(Collectors.toMap(
                LineExecution::getLineId,
                line -> AlertSpecificData.LineMetadata.fromOrderAndLine(context.getOrderData().getExistingCustomerOrder(), line)
            ));

        final var alertId = UUID.randomUUID();
        return Alert.builder()
            .id(alertId)
            .specificData(
                PromisedDateSpecificData.builder()
                    .reason(AlertReason.CUSTOMER_CANCELLATION_FAILURE.name())
                    .receivedAt(OffsetDateTime.now())
                    .requestId(alertId.toString())
                    .lineMetadataByLineId(lineMetadataByLineId)
                    .linesToCancelByExecution(impactedLineByExecution)
                    .build()
            )
            .impactedLinesIds(linesIdToCreateAlert.stream().map(LineExecution::getLineId).collect(Collectors.toList()))
            .customerOrderId(context.getCustomerOrderId())
            .customerKnownDeliveryDate(customerKnownDeliveryDate)
            .buCode(context.getBuCode())
            .status(AlertStatus.CREATION_REQUESTED)
            .build();
    }

    private AlertMessageInput buildAlertMessageInput(Alert alert, List<LineExecution> impactedLines, CustomerOrder customerOrder) {
        return AlertMessageInput.builder()
            .alert(alert)
            .lineExecutions(impactedLines)
            .customerOrder(customerOrder)
            .build();
    }
}
