package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineWithExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.service.TppCommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.NO_TPP_REQUIREMENT_IN_PROGRESS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_IS_DECREASE_QUANTITY;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_IS_SPLIT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_REASON_IS_REMAINING_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_UNEXEC_REQUIREMENT_TPP_IS_THE_NEXT_STEP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Status.PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "AskUnexecLastRequirementExecution",
    description = "Ask to TPP to unexecute the last requirement",
    priority = 13)
public class AskUnexecLastRequirementExecutionRule {

    public static final Predicate<ExecutionAction> IS_EXECUTION_ACTION_PROCESSING_IS_DECREASE_QUANTITY_OR_SPLIT_WITH_REMAINING_COLLECT_REASON = IS_EXECUTION_ACTION_PROCESSING
        .and(IS_EXECUTION_ACTION_IS_DECREASE_QUANTITY
            .or(IS_EXECUTION_ACTION_IS_SPLIT.and(IS_EXECUTION_ACTION_REASON_IS_REMAINING_COLLECT)))
        .and(IS_UNEXEC_REQUIREMENT_TPP_IS_THE_NEXT_STEP);

    private final TppCommandEventService tppCommandEventService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneExecutionAction(IS_EXECUTION_ACTION_PROCESSING_IS_DECREASE_QUANTITY_OR_SPLIT_WITH_REMAINING_COLLECT_REASON)
            && context.isCustomerOrderMatches(IS_VALIDATED);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return Mono.justOrEmpty(context.getFirstExecutionActionByPredicate(IS_EXECUTION_ACTION_PROCESSING_IS_DECREASE_QUANTITY_OR_SPLIT_WITH_REMAINING_COLLECT_REASON))
            .flatMap(actionToExecute -> this.processAction(context, actionToExecute).then(Mono.fromRunnable(() -> actionToExecute.getFlags().raiseFlagIfNot(ExecutionActionStatus.PROCESSING)))).then();
    }

    private Flux<String> processAction(RuleEngineContext context, ExecutionAction actionToExecute) {
        return Flux.fromIterable(actionToExecute.getImpactedExecutions())
            .filter(impactedExecution -> impactedExecution.isNextStepTypeIs(UNEXEC_REQUIREMENT_TPP))
            .flatMap(impactedExecution -> {
                final var impactedLinesToProcess = impactedExecution
                    .getImpactedLinesWithExecution()
                    .stream()
                    .filter(impactedLineWithExecution -> impactedLineWithExecution.getLine().isNextStepIsOfType(UNEXEC_REQUIREMENT_TPP))
                    .toList();

                final var impactedLineExecutions = impactedLinesToProcess
                    .stream()
                    .flatMap(impactedLineWithExecution -> context.getOrderData().getLineExecutionByIdAndExecutionId(impactedLineWithExecution.getLineId(), impactedLineWithExecution.getExecutionId()).stream())
                    .toList();

                final boolean allImpactedLineWithUnexecStepIsTheNextStep = impactedExecution.getImpactedLines()
                    .stream()
                    .filter(impactedLine -> impactedLine.getStepOfType(UNEXEC_REQUIREMENT_TPP).isPresent())
                    .count() == (long) impactedLineExecutions.size();

                if(!allImpactedLineWithUnexecStepIsTheNextStep) {
                    return MonoUtil.infoLog("All impacted line with unexec requirement step are at this step");
                }

                final var linesByLastApprovedRequirement = impactedLineExecutions.stream()
                    .filter(lineExecution -> getLastApprovedOrUnexecApprovedRequirement(lineExecution) != null)
                    .collect(Collectors.groupingBy(AskUnexecLastRequirementExecutionRule::getLastApprovedOrUnexecApprovedRequirement));

                if (linesByLastApprovedRequirement.isEmpty()) {
                    return MonoUtil.infoLog("No requirement for lines, nothing to do");
                }

                if (!impactedLineExecutions.stream().allMatch(NO_TPP_REQUIREMENT_IN_PROGRESS)) {
                    return MonoUtil.infoLog("A requirement is currently processing, impossible to unexec");
                }

                if (linesByLastApprovedRequirement.size() > 1) {
                    return MonoUtil.errorLog("Decrease quantity impacted execution lines have not the same last approved requirement")
                        .doOnNext(o -> actionToExecute.getFlags().raiseFlagIfNotWithFailedReason(ExecutionActionStatus.FAILED, "Multiple last approved requirement on impacted lines for execution: " + impactedExecution.getCurrentExecutionId()))
                        .then(Mono.error(new Throwable("Multiple last approved requirement on impacted lines for execution: " + impactedExecution.getCurrentExecutionId())));
                }

                ActionType actionType = linesByLastApprovedRequirement.keySet().stream().findFirst().get();

                return MonoUtil.infoLog("Request unexec {} requirement for 1P lines: {} and execution : {}", actionType, LineExecution.joinLineIds(impactedLineExecutions), impactedExecution.getCurrentExecutionId())
                    .then(this.tppCommandEventService.sendUnexecActionTypeRequirement(context.getOrderData().getExistingCustomerOrder(), impactedExecution.getCurrentExecutionId(), ImpactedLineWithExecution.mapToImpactedLines(impactedLinesToProcess), Instant.now(), actionType)
                        .doOnNext(operationId -> {
                            final List<String> lineIdProcesseed = ImpactedLineWithExecution.getAllImpactedLineId(impactedLinesToProcess);
                            impactedLineExecutions.forEach(line -> flagUnexecOnLine(line, actionType, operationId));
                            impactedExecution.setUnexecRequirementOperationId(operationId);
                            impactedExecution.getImpactedLines()
                                .stream()
                                .filter(impactedLine ->  lineIdProcesseed.contains(impactedLine.getLineId()))
                                .forEach(impactedLine -> impactedLine.raiseFlagStepTypeIfPresent(UNEXEC_REQUIREMENT_TPP, PROCESSING));
                        }));
            });
    }

    private static void flagUnexecOnLine(LineExecution line, ActionType actionType, String operationId) {
        switch (actionType) {
            case PREPARATION ->
                line.getPaymentRequirements().getPreparationFlags().raiseFlag(operationId, RequirementStatus.UNEXEC_REQUESTED);
            case SHIPPING ->
                line.getPaymentRequirements().getShippingFlags().raiseFlag(operationId, RequirementStatus.UNEXEC_REQUESTED);
            case DELIVERY ->
                line.getPaymentRequirements().getDeliveryFlags().raiseFlag(operationId, RequirementStatus.UNEXEC_REQUESTED);
            case OWNERSHIP_TRANSFER ->
                line.getPaymentRequirements().getOwnerShippedTransfertFlags().raiseFlag(operationId, RequirementStatus.UNEXEC_REQUESTED);
            default -> log.info("No action needed for action type: {}", actionType);
        }
    }

    private static ActionType getLastApprovedOrUnexecApprovedRequirement(LineExecution lineExecution) {
        var mapApprovedDate = new HashMap<ActionType, OffsetDateTime>();

        mapApprovedDate.computeIfAbsent(ActionType.PREPARATION, key -> getCompletedOrUnexecDate(lineExecution.getPaymentRequirements().getPreparationFlags().getLastFlag()));
        mapApprovedDate.computeIfAbsent(ActionType.SHIPPING, key -> getCompletedOrUnexecDate(lineExecution.getPaymentRequirements().getShippingFlags().getLastFlag()));
        mapApprovedDate.computeIfAbsent(ActionType.DELIVERY, key -> getCompletedOrUnexecDate(lineExecution.getPaymentRequirements().getDeliveryFlags().getLastFlag()));
        mapApprovedDate.computeIfAbsent(ActionType.OWNERSHIP_TRANSFER, key -> getCompletedOrUnexecDate(lineExecution.getPaymentRequirements().getOwnerShippedTransfertFlags().getLastFlag()));

        return mapApprovedDate.entrySet().stream()
            .filter(entry -> entry.getValue() != null)
            .max(Map.Entry.comparingByValue())
            .map(Map.Entry::getKey).orElse(null);
    }

    private static OffsetDateTime getCompletedOrUnexecDate(Flag flag) {
        return flag != null && List.of(RequirementStatus.APPROVED.name(), RequirementStatus.UNEXEC_APPROVED.name()).contains(flag.getType()) ? flag.getDateTime() : null;
    }

}
