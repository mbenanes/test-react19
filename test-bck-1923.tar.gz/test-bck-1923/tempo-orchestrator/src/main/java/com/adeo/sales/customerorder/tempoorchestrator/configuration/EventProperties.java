package com.adeo.sales.customerorder.tempoorchestrator.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@Data
@ConfigurationProperties(prefix = "events")
public class EventProperties {
    OutputEvents output;
}
