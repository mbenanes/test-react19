package com.adeo.sales.customerorder.tempoorchestrator.model.line;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@Slf4j
public class CustomerOrderLine {

    private String id;

    @JsonIgnore
    private CustomerOrder customerOrder;

    private Offer offer;
}
