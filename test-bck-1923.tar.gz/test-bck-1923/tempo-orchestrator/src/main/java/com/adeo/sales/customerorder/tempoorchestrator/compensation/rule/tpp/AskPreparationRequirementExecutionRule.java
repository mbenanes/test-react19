package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.service.TppCommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_PREPARATION_REQUIREMENT_COMPLETED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CURRENT_TPP_VERSION_MISMATCH;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_DATE_CONFIRMED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_PYXIS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_NOT_SERVICE_ALONE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_ONLINE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PREPARATION_REQUIREMENT_FAILED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PREPARATION_REQUIREMENT_FAILED_CAN_BE_REPLAYED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PREPARATION_REQUIREMENT_REJECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_QUOTATION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_STORE_SELF_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.NO_TPP_REQUIREMENT_IN_PROGRESS;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_ASK_PREPARATION_REQUIREMENT_TPP_IS_THE_NEXT_STEP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_PROCESSING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_SPLIT_REMAINING_COLLECT_ACTION_PROCESSING;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "AskPreparationRequirementExecution",
    description = "Ask to TPP to execute the preparation requirement for 1P lines",
    priority = 1000)
public class AskPreparationRequirementExecutionRule {

    private static final Predicate<LineExecution> LINE_SHOULD_DO_ASK_PREPARATION_REQUIREMENT = IS_1P
        .and(PAYMENT_ORCHESTRATED_BY_TPP)
        .and((IS_OFFER.and(IS_DELIVERY_DATE_CONFIRMED))
            .or(IS_NOT_SERVICE_ALONE))
        .and(IS_LINE_COMPOSITION_VALIDATED)
        .and(IS_QUOTATION_VALIDATED)
        .and(NO_TPP_REQUIREMENT_IN_PROGRESS)
        .and(not(IS_STORE_SELF_SERVICE))
        .and(IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT)
        .and(not(HAS_PREPARATION_REQUIREMENT_COMPLETED.or(IS_PREPARATION_REQUIREMENT_REJECTED).or(IS_PREPARATION_REQUIREMENT_FAILED))
            .or(IS_PREPARATION_REQUIREMENT_FAILED_CAN_BE_REPLAYED.and(not(IS_CURRENT_TPP_VERSION_MISMATCH))));

    private static final Predicate<ExecutionAction> IS_ASK_PREPARATION_TPP_IS_THE_NEXT_STEP = IS_SPLIT_REMAINING_COLLECT_ACTION_PROCESSING.and(IS_ASK_PREPARATION_REQUIREMENT_TPP_IS_THE_NEXT_STEP);


    private final TppCommandEventService tppCommandEventService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return ((context.isCustomerOrderMatches(IS_PLACE_TYPE_ONLINE) && context.hasAtLeastOneLine(IS_EXTERNAL_SYSTEM_PYXIS)) || context.hasAtLeastOneLine(IS_EXTERNAL_SYSTEM_TEMPO)) &&
            context.getOrderData()
                    .getExistingExecutionsWithLines()
                        .stream()
                            .anyMatch(executionWithLines -> executionWithLines.getLineExecutions()
                                .stream()
                                .allMatch(LINE_SHOULD_DO_ASK_PREPARATION_REQUIREMENT)
                            ) &&
            (!context.hasAtLeastOneExecutionAction(IS_EXECUTION_ACTION_PROCESSING) ||
                context.hasAtLeastOneExecutionAction(IS_ASK_PREPARATION_TPP_IS_THE_NEXT_STEP));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        List<LineExecution> linesToRequest = getLinesToRequestPreparation(context);
        CustomerOrder customerOrder = context.getOrderData().getExistingCustomerOrder();
        Instant statusDate = Instant.now();

        return MonoUtil.infoLog("INTERNAL request preparation requirement execution for lines: {}",
                LineExecution.joinLineIds(linesToRequest))
            .thenReturn(linesToRequest.stream()
                .collect(Collectors.groupingBy(LineExecution::getExecutionId)))
            .flatMapIterable(Map::entrySet)
            .flatMap(entry -> sendRequestAndUpdateContext(context, customerOrder, statusDate, entry))
            .then();
    }

    private List<LineExecution> getLinesToRequestPreparation(RuleEngineContext context) {
        return context.getOrderData()
            .getExistingLineExecutions().stream()
            .collect(Collectors.groupingBy(LineExecution::getExecutionId))
            .entrySet().stream()
            .filter(entry -> areAllLinesEligible(entry.getValue(), context))
            .flatMap(entry -> entry.getValue().stream())
            .toList();
    }

    private Mono<Void> sendRequestAndUpdateContext(
        RuleEngineContext context,
        CustomerOrder customerOrder,
        Instant statusDate,
        Map.Entry<String, List<LineExecution>> entry
    ) {
        String executionId = entry.getKey();
        List<LineExecution> lines = entry.getValue();

        return tppCommandEventService.sendActionTypeRequirement(customerOrder, executionId, lines, statusDate, ActionType.PREPARATION)
            .doOnNext(operationId -> updatePreparationFlags(context, operationId, lines, statusDate))
            .then();
    }

    private void updatePreparationFlags(
        RuleEngineContext context,
        String operationId,
        List<LineExecution> lines,
        Instant statusDate
    ) {
        lines.forEach(line ->
            line.getPaymentRequirements()
                .getPreparationFlags()
                .raiseFlagIfNot(operationId, RequirementStatus.REQUESTED, statusDate.atOffset(ZoneOffset.UTC))
        );

        context.getFirstExecutionActionByPredicate(IS_ASK_PREPARATION_TPP_IS_THE_NEXT_STEP)
            .ifPresent(executionAction ->
                executionAction.raiseFlagsOnImpactedLineStepByType(
                    ImpactedLineStep.Type.ASK_PREPARATION_REQUIREMENT_TPP,
                    ImpactedLineStep.Status.PROCESSING
                )
            );
    }

    private boolean areAllLinesEligible(List<LineExecution> lineExecutions, RuleEngineContext context) {
        Predicate<LineExecution> predicate = getPreparationRequirementPredicate(context);
        return lineExecutions.stream().allMatch(predicate);
    }

    private Predicate<LineExecution> getPreparationRequirementPredicate(RuleEngineContext context) {
        return context.isCustomerOrderMatches(IS_PLACE_TYPE_IN_STORE)
            ? LINE_SHOULD_DO_ASK_PREPARATION_REQUIREMENT.and(IS_EXTERNAL_SYSTEM_TEMPO)
            : LINE_SHOULD_DO_ASK_PREPARATION_REQUIREMENT;
    }

}
