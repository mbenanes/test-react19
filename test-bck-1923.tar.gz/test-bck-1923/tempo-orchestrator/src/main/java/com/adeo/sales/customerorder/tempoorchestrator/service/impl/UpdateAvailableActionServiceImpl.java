package com.adeo.sales.customerorder.tempoorchestrator.service.impl;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecutionComposition;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.PaymentStatus;
import com.adeo.sales.customerorder.tempoorchestrator.service.UpdateAvailableActionService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CONFIRMATION_REQUIREMENT_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_EXECUTION_NOT_STARTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_STORE_SELF_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus.PENDING_VALIDATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.DELIVERY_CANCEL_IN_PROGRESS_STATUS;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.DELIVERY_STATUS_NOT_CANCELABLE;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.DELIVERY_STATUS_ORDER_CREATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.SHIPPED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType.STORE_SELF_SERVICE;
import static java.util.function.Predicate.not;

@Slf4j
@Service
public class UpdateAvailableActionServiceImpl implements UpdateAvailableActionService {

    public void apply(List<LineExecution> lineExecutions, LineExecution lineExecution, CustomerOrder customerOrder) {

        var executionSelector = Optional.of(lineExecution.getComposition())
            .map(LineExecutionComposition::getExecutionSelector)
            .stream()
            .filter(StringUtils::isNotEmpty)
            .findFirst();

        if(PAYMENT_ORCHESTRATED_BY_TPP.and(not(IS_CONFIRMATION_REQUIREMENT_COMPLIANT)).test(lineExecution)){
            lineExecution.increaseVersion();
            lineExecution.getComposition().setCancelable(false);
            lineExecution.getDelivery().setForceCancelable(false);
        } else if (hasTPPServiceOrchestratedByTempo(lineExecutions) && isOwnershipTransferNotStarted(lineExecution)) {
            lineExecution.increaseVersion();
            lineExecution.getDelivery().setForceCancelable(IS_CONFIRMATION_REQUIREMENT_COMPLIANT.test(lineExecution));
            lineExecution.getComposition().setCancelable(false);
        } else if (lineExecution.getComposition().getFlags().lastFlagIs(CompositionOrderStatus.CANCELED) ) {
            lineExecution.increaseVersion();
            lineExecution.getComposition().setCancelable(false);
            lineExecution.getDelivery().setForceCancelable(false);
        } else if ((lineExecution.getDelivery().getDeliveryType() != null && STORE_SELF_SERVICE.equals(lineExecution.getDelivery().getDeliveryType())) || executionSelector.isPresent()) {
                lineExecution.increaseVersion();
                lineExecution.getComposition().setCancelable(false);
                lineExecution.getDelivery().setForceCancelable(true);
        } else if (
            IS_VALIDATED.and(IS_PLACE_TYPE_IN_STORE).test(customerOrder) &&
                PAYMENT_ORCHESTRATED_BY_TPP
                    .and(not(IS_CONFIRMATION_REQUIREMENT_COMPLIANT))
                    .and(IS_DELIVERY_EXECUTION_NOT_STARTED)
                    .and(not(IS_STORE_SELF_SERVICE)).test(lineExecution)
        ) {
            lineExecution.increaseVersion();
            lineExecution.getComposition().setCancelable(true);
            lineExecution.getDelivery().setForceCancelable(false);
        } else {
            ExternalSystem externalSystem = lineExecution.getExternalSystem();
            Boolean isCancelable = lineExecution.getDelivery().getCancelable();
            DeliveryType deliveryType = lineExecution.getDelivery().getDeliveryType();
            boolean ownershipTransferNotStarted = this.isOwnershipTransferNotStarted(lineExecution);

            if (externalSystem != null && not(IS_DELIVERY_CANCELED).test(lineExecution)) {
                boolean isAlreadyCompositionCancelledOrInCancellationProgress = lineExecution.getComposition().getFlags().lastFlagIs(CompositionOrderStatus.CANCELED) || lineExecution.getComposition().getFlags().lastFlagIs(CompositionOrderStatus.CANCELED_REQUESTED);
                boolean cancellationIsPossibleByTempo = isCancellationIsPossibleByTempo(customerOrder.getStatus(), lineExecution.getDelivery().getLastFlag(), externalSystem, ownershipTransferNotStarted, deliveryType);
                boolean isCompositionCancelable = BooleanUtils.isTrue(isCancelable) && cancellationIsPossibleByTempo;
                if (isCompositionCancelable != lineExecution.getComposition().isCancelable()) {
                    lineExecution.getComposition().setCancelable(isCompositionCancelable);
                    lineExecution.increaseVersion();
                }
                boolean forceCancelable = deliveryType == DeliveryType.SFP
                    && !isCompositionCancelable
                    && cancellationIsPossibleByTempo
                    && !isAlreadyCompositionCancelledOrInCancellationProgress;
                if (lineExecution.getDelivery().getForceCancelable() == null || forceCancelable != lineExecution.getDelivery().getForceCancelable()) {
                    lineExecution.getDelivery().setForceCancelable(forceCancelable);
                    lineExecution.increaseVersion();
                }
            }
        }

    }


    private static boolean hasTPPServiceOrchestratedByTempo(List<LineExecution> lineExecutions) {
        return lineExecutions.stream().anyMatch(PAYMENT_ORCHESTRATED_BY_TPP.and(IS_EXTERNAL_SYSTEM_TEMPO).and(IS_LINE_SERVICE));
    }

    @Override
    public void apply(List<LineExecution> lineExecutions, LineExecution lineExecution, CustomerOrder customerOrder, Boolean isCancelable) {
        lineExecution.getDelivery().setCancelable(isCancelable);
        this.apply(lineExecutions, lineExecution, customerOrder);
    }

    private static boolean isCancellationIsPossibleByTempo(CustomerOrderStatus customerOrderStatus, CustomerOrderLineDeliveryStatus deliveryStatus, ExternalSystem externalSystem, boolean ownershipTransferNotStarted, DeliveryType deliveryType) {
        boolean isDeliveryCancellationInProgress = deliveryStatus != null && DELIVERY_CANCEL_IN_PROGRESS_STATUS.contains(deliveryStatus);
        boolean isCustomerOrderCompositionStatusNotPendingValidation = customerOrderStatus != PENDING_VALIDATION;
        boolean deliveryStatusNotInCreation = deliveryStatus != null && !DELIVERY_STATUS_ORDER_CREATION_REQUESTED.contains(deliveryStatus);
        boolean deliveryStatusNotCancellable = deliveryStatus != null && (!DELIVERY_STATUS_NOT_CANCELABLE.contains(deliveryStatus) || (deliveryType == DeliveryType.SFP && deliveryStatus == SHIPPED && ownershipTransferNotStarted));
        boolean isNotPyxis = !externalSystem.isPyxis();
        return deliveryStatusNotInCreation
            && ownershipTransferNotStarted
            && deliveryStatusNotCancellable
            && isCustomerOrderCompositionStatusNotPendingValidation
            && !isDeliveryCancellationInProgress
            && isNotPyxis;
    }

    public boolean isOwnershipTransferNotStarted(LineExecution lineExecution) {
        return lineExecution.getDelivery().getStockValuationStatus() == null &&
            (lineExecution.getPayment().getFlags().hasNoFlags() ||
                lineExecution.getPayment().getFlags().lastFlagIs(PaymentStatus.NONE));
    }

}
