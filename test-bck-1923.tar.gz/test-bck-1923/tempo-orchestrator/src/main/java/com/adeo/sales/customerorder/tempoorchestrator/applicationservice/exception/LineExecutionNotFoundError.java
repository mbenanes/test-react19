package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception;


public class LineExecutionNotFoundError extends RuntimeException {
    public LineExecutionNotFoundError(String error) {
        super(error);
    }

}
