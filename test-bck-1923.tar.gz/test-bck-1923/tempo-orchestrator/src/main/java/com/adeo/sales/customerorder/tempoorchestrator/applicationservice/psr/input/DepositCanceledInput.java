package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.input;

import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
public class DepositCanceledInput {
    private final List<String> depositCanceledLineIds;
    private final String updatedBy;
    private final String customerOrderId;
    private final String buCode;
}
