package com.adeo.sales.customerorder.tempoorchestrator.handler.psr;

import com.adeo.sales.customerorder.paymentscheduler.v2.execution.domainevent.CapturePaymentCaptureFailed;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.domainevent.LineCapturePaymentCaptureFailed;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.PaymentCaptureFailedApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.input.PaymentCaptureFailedInput;
import com.adeo.sales.customerorder.tempoorchestrator.handler.BuCodeKafkaHeader;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.util.stream.Collectors;


@Slf4j
@Component
@AllArgsConstructor
public class CapturePaymentCaptureFailedHandler implements EventHandler<CapturePaymentCaptureFailed> {
	private final PaymentCaptureFailedApplicationService paymentCaptureFailed;
	private final MappedDiagnosticContext mappedDiagnosticContext;

	@Transactional(transactionManager = "connectionFactoryTransactionManager")
	@Override
	public Mono<Void> handle(CapturePaymentCaptureFailed event, EventMetaData metaData) {
        final var delta = event.getDelta();
        final var vectorClock = event.getState().getVectorClock();
        final var orderVersion = vectorClock.getCustomerOrder() != null ? vectorClock.getCustomerOrder().getVersion() : null;
        mappedDiagnosticContext.injectEventMinimalVersionedData(metaData, delta.getCustomerOrderId(), orderVersion);
        log.info("CustomerOrderLinesPaymentCaptureFailed consumes {} - message id: {}", metaData.getTopic(), metaData.getId().orElse("no id"));

        final var rejectedLineIds = delta.getLines().stream()
                .map(LineCapturePaymentCaptureFailed::getId)
                .collect(Collectors.toList());
        final var input = PaymentCaptureFailedInput.builder()
                .rejectedLineIds(rejectedLineIds)
                .buCode(BuCodeKafkaHeader.getTempoBuCode(metaData))
                .customerOrderId(event.getDelta().getCustomerOrderId())
                .build();

        return this.paymentCaptureFailed.apply(input);
	}

	@Override
	public Class<?> getManagedEvent() {
		return CapturePaymentCaptureFailed.class;
	}
}
