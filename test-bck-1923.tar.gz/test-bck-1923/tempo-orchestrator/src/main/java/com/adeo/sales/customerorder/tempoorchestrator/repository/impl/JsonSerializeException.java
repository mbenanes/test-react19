package com.adeo.sales.customerorder.tempoorchestrator.repository.impl;

public class JsonSerializeException extends RuntimeException {

    public JsonSerializeException(Throwable cause) {
        super("Error serializing entity to json for database persist.", cause);
    }

    public JsonSerializeException(String message) {
        super(message);
    }
}
