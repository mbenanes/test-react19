package com.adeo.sales.customerorder.tempoorchestrator.repository.impl;

import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.r2dbc.spi.Result;
import io.r2dbc.spi.Row;
import io.r2dbc.spi.RowMetadata;
import io.r2dbc.spi.Statement;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.r2dbc.core.ConnectionAccessor;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class ExecutionPostgresRepository implements ExecutionRepository {
    private final ObjectMapper objectMapper;
    private final ConnectionAccessor connectionAccessor;
    private final DatabaseClient databaseClient;

    @Override
    public Flux<Execution> getExecutionFromOrder(String customerOrderId, String buCode) {
        var select = "select id, customer_order_id, bu_code, execution_status" +
            " from execution" +
            " where customer_order_id = :customerOrderId" +
            " and  bu_code = :buCode";

        return this.databaseClient
            .sql(select)
            .bind("customerOrderId", customerOrderId)
            .bind("buCode", buCode)
            .map(this::deserializeExecution)
            .all();
    }

    @Override
    public Mono<Void> delete(String customerOrderId, String idExecution) {
        return databaseClient.sql("DELETE FROM execution WHERE id = :idExecution and customer_order_id = :customerOrderId")
            .bind("idExecution", idExecution)
            .bind("customerOrderId", customerOrderId)
            .fetch()
            .rowsUpdated()
            .doOnNext(updatedRow -> log.debug("Deleting execution, {} row updated", updatedRow))
            .then();
    }

    @Override
    public Mono<Void> save(List<Execution> executions) {
        if (executions == null || executions.isEmpty()) {
            return Mono.empty();
        }
        final var insert =
            "insert into execution(id, customer_order_id, bu_code, execution_status)" +
                " values ($1,$2, $3, CAST($4 as jsonb))";

        return this.connectionAccessor.inConnection(it -> {
            final Statement statement = it.createStatement(insert);
            executions.forEach(execution -> statement.bind(0, execution.getId())
                .bind(1, execution.getCustomerOrderId())
                .bind(2, execution.getBuCode())
                .bind(3, serialize(execution.getExecutionStatus()))
                .add());

            return Flux.from(statement.execute())
                .flatMap(Result::getRowsUpdated)
                .flatMap(numberOfInsertedLines -> {
                    if (numberOfInsertedLines == 0) {
                        return Mono.error(new NoExecutionUpsertedException());
                    } else {
                        return Mono.just(numberOfInsertedLines);
                    }
                })
                .then();
        }).then();
    }

    @Override
    public Mono<Void> update(List<Execution> executions) {
        if (executions == null || executions.isEmpty()) {
            return Mono.empty();
        }
        final var insert =
            "UPDATE execution set execution_status= CAST($1 as jsonb) where id=$2";

        return this.connectionAccessor.inConnection(it -> {
            final Statement statement = it.createStatement(insert);
            executions.forEach(execution -> statement.bind(0, serialize(execution.getExecutionStatus())).bind(1, execution.getId()).add());

            return Flux.from(statement.execute())
                .flatMap(Result::getRowsUpdated)
                .flatMap(numberOfInsertedLines -> {
                    if (numberOfInsertedLines == 0) {
                        return Mono.error(new NoExecutionUpsertedException());
                    } else {
                        return Mono.just(numberOfInsertedLines);
                    }
                })
                .then();
        }).then();
    }

    private Execution deserializeExecution(Row row, RowMetadata rowMetadata) {
        try {
            return Execution.builder()
                .id(row.get("id", String.class))
                .customerOrderId(row.get("customer_order_id", String.class))
                .buCode(row.get("bu_code", String.class))
                .executionStatus(deserialize(row.get("execution_status", String.class), Flags.class))
                .build();

        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }

    private <T> T deserialize(String json, Class<T> clazz) {
        if (json == null) {
            return null;
        }
        try {
            return objectMapper.readValue(json, clazz);
        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }

    private String serialize(final Object object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (Exception exception) {
            throw new JsonSerializeException(exception);
        }
    }
}
