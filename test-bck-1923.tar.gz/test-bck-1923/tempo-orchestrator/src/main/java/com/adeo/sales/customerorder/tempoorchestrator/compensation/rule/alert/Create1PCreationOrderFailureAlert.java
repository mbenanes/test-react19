package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.service.UpdateAvailableActionService;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertReason.ORDER_CREATION_FAILURE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_CREATION_FAILED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@Rule(name = "Create1PCreationOrderFailureAlert",
    description = "Create alert ORDER_CREATION_FAILURE for CREATION_FAILURE line.",
    priority = 980)
public class Create1PCreationOrderFailureAlert extends AbstractRejectLinesAlertRule {
    private static final Predicate<LineExecution> HAS_CREATION_ORDER_FAILURE_ALERT_TO_BE_CREATED = IS_DELIVERY_CREATION_FAILED.and(IS_1P).and(not(IS_LINE_COMPOSITION_CANCELED));

    public Create1PCreationOrderFailureAlert(AlertMessageService alertMessageService, UpdateAvailableActionService updateAvailableActionService) {
        super(alertMessageService, updateAvailableActionService);
    }

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.isCustomerOrderMatches(IS_VALIDATED) && this.isRuleShouldBeTriggered(context, HAS_CREATION_ORDER_FAILURE_ALERT_TO_BE_CREATED);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return this.createAlertForRejectedLines(context, HAS_CREATION_ORDER_FAILURE_ALERT_TO_BE_CREATED, ORDER_CREATION_FAILURE.name());
    }

}
