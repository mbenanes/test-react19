package com.adeo.sales.customerorder.tempoorchestrator.model.line.execution;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.OwnerRequest;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@Builder
@AllArgsConstructor
@Data
@NoArgsConstructor
public class ExecutionAction {
    private String requestId;
    private String appSourceRequestId;
    private String customerOrderId;
    private String buCode;
    private String appSource;
    private ExecutionActionType actionType;
    private OwnerRequest ownerRequest;
    private List<ImpactedExecution> impactedExecutions;
    private Flags<ExecutionActionStatus> flags;
    private List<RefundResult> refundResults;

    private Instant createdAt;

    public List<RefundResult> getRefundResults() {
        if (this.refundResults == null) {
            this.refundResults = new ArrayList<>();
        }
        return this.refundResults;
    }

    public List<ImpactedExecution> getImpactedExecutionsNextStepType(ImpactedLineStep.Type stepType) {
        return this.impactedExecutions.stream().filter(impactedExecution -> impactedExecution.isNextStepTypeIs(stepType)).toList();
    }

    public Optional<ImpactedExecution> getImpactedExecutionByExecutionId(String executionId) {
        return this.impactedExecutions.stream().filter(impactedExecution -> impactedExecution.getCurrentExecutionId().equals(executionId)).findFirst();
    }

    public Optional<ImpactedLine> getImpactedLineByExecutionIdAndLineId(String executionId, String lineId) {
        Optional<ImpactedLine> lineExecution = this.impactedExecutions
            .stream()
            .filter(impactedExecution -> impactedExecution.getCurrentExecutionId().equals(executionId))
            .flatMap(impactedExecution -> impactedExecution.getImpactedLineById(lineId).stream())
            .findFirst();

        if (lineExecution.isEmpty()) {
            log.debug("Unable to find line execution with executionId : {} and lineId {}", executionId, lineId);
        }

        return lineExecution;
    }

    @JsonIgnoreProperties
    @JsonIgnore
    public List<ImpactedLine> getAllImpactedLines() {
        return this.impactedExecutions.stream()
            .flatMap(impactedExecution -> impactedExecution.getImpactedLines().stream())
            .toList();
    }

    public List<ImpactedLineWithExecution> getAllImpactedLinesWithExecution() {
        return this.impactedExecutions.stream()
            .flatMap(impactedExecution -> impactedExecution.getImpactedLinesWithExecution().stream())
            .toList();
    }
    public Optional<ImpactedLine> getImpactedLineByLineId(String lineId) {
        Optional<ImpactedLine> lineExecution = this.impactedExecutions
            .stream()
            .flatMap(impactedExecution -> impactedExecution.getImpactedLineById(lineId).stream())
            .findFirst();

        if (lineExecution.isEmpty()) {
            log.error("Unable to find line with lineId {}", lineId);
        }

        return lineExecution;
    }

    public void raiseFlagsOnImpactedLineStepByType(ImpactedLineStep.Type type, ImpactedLineStep.Status status) {
        this.impactedExecutions.forEach(impactedExecution -> impactedExecution.getImpactedLines()
            .forEach(impactedLine -> impactedLine.getStepOfType(type)
                .ifPresent(step -> step.getFlags().raiseFlag(status))));
    }

    public ExecutionActionStatus getLastFlag() {
        Flag lastFlag = this.getFlags().getLastFlag();
        if (lastFlag != null) {
            final var lastFlagType = lastFlag.getType();
            return ExecutionActionStatus.valueOf(lastFlagType);
        }
        return null;
    }

    public Flags<ExecutionActionStatus> getFlags() {
        if (this.flags == null) {
            this.flags = new Flags<>();
        }
        return flags;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExecutionAction that = (ExecutionAction) o;
        return Objects.equals(requestId, that.requestId) && actionType == that.actionType;
    }

    public static Optional<String> getActionExecutionReason(ExecutionAction executionAction) {
        return executionAction.getImpactedExecutions().stream()
            .map(ImpactedExecution::getImpactedLines)
            .findFirst()
            .flatMap(impactedLines -> impactedLines.stream().findFirst().map(ImpactedLine::getReason));
    }

    public static boolean isExecutionActionReasonMatches(ExecutionAction executionAction, String reasonToCompare) {
        return getActionExecutionReason(executionAction).stream().anyMatch(reason -> reason.equals(reasonToCompare));
    }


    public static ExecutionAction buildExecutionAction(String customerOrderId, String buCode,
                                                       List<ImpactedExecution> impactedExecutions,
                                                       String appSource,
                                                       ExecutionActionType executionActionType,
                                                       OwnerRequest ownerRequest
    ) {
        final var intiFlags = new Flags<ExecutionActionStatus>();
        intiFlags.raiseFlag(ExecutionActionStatus.CREATED);
        return ExecutionAction.builder()
            .requestId(UUID.randomUUID().toString())
            .customerOrderId(customerOrderId)
            .buCode(buCode)
            .appSource(appSource)
            .actionType(executionActionType)
            .createdAt(Instant.now())
            .ownerRequest(ownerRequest)
            .impactedExecutions(impactedExecutions)
            .flags(intiFlags)
            .build();
    }

    public static ExecutionAction buildExecutionAction(String customerOrderId, String buCode,
                                                       List<ImpactedExecution> impactedExecutions,
                                                       String appSource,
                                                       String appSourceRequestId,
                                                       ExecutionActionType executionActionType,
                                                       OwnerRequest ownerRequest
    ) {
        final var intiFlags = new Flags<ExecutionActionStatus>();
        intiFlags.raiseFlag(ExecutionActionStatus.CREATED);
        return ExecutionAction.builder()
            .requestId(UUID.randomUUID().toString())
            .customerOrderId(customerOrderId)
            .buCode(buCode)
            .appSource(appSource)
            .appSourceRequestId(appSourceRequestId)
            .actionType(executionActionType)
            .createdAt(Instant.now())
            .ownerRequest(ownerRequest)
            .impactedExecutions(impactedExecutions)
            .flags(intiFlags)
            .build();
    }

    public boolean executionIsDone(){
        return this.impactedExecutions.stream()
            .flatMap(impactedExecution -> impactedExecution.getImpactedLines().stream())
            .allMatch(ImpactedLine::getLastStepIsDone);
    }

}
