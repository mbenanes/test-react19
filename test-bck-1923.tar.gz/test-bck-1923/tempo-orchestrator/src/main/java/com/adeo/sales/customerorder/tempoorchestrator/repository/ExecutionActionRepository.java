package com.adeo.sales.customerorder.tempoorchestrator.repository;

import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Repository
public interface ExecutionActionRepository {
    Mono<Void> upsert(List<ExecutionAction> executionActions);

    Flux<ExecutionAction> getExecutionActionsFromOrder(String customerOrderId, String buCode);

    class NoExecutionActionInsertedException extends RuntimeException {
        public NoExecutionActionInsertedException() {
            super("No execution action has been inserted");
        }
    }
}
