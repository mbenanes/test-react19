package com.adeo.sales.customerorder.tempoorchestrator.model.alert;

public enum AlertStatus {
    PENDING,
    CREATION_REQUESTED,
    CREATED,
    CLOSE_REQUESTED,
    CLOSED
}
