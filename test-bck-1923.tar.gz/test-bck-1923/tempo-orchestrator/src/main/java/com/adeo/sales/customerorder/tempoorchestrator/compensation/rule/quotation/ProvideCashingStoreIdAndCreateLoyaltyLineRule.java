package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.quotation;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.QuotationDataGetter;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.input.CashingStoreAssignerInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.QuotationVersionsInconsistent;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.Offer;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecutionComposition;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_CASHING_STORE_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_AUTHORIZATION_REJECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PENDING_VALIDATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineCompositionOrderStatus.VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem.SystemName.TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags.UNKNOWN_OPERATION_ID;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "ProvideCashingStoreIdAndCreateLoyaltyLine",
    description = "Call quotation to retrieve the cashing store id and create loyalty fee line",
    priority = 2)
public class ProvideCashingStoreIdAndCreateLoyaltyLineRule {

    private final QuotationDataGetter quotationDataGetter;


    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        CustomerOrder existingCustomerOrder = context.getOrderData().getExistingCustomerOrder();
        return !(context.isCustomerOrderMatches(IS_PENDING_VALIDATION) && context.hasAtLeastOneLine(IS_AUTHORIZATION_REJECTED)) &&
            context.hasAtLeastOneLine(not(HAS_CASHING_STORE_ID)) &&
            existingCustomerOrder.getQuotation() != null &&
            existingCustomerOrder.getQuotation().getId() != null;
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var linesToEhance = context.getOrderData().getLineExecutionsByPredicate(not(HAS_CASHING_STORE_ID));
        CustomerOrder customerOrder = context.getOrderData().getExistingCustomerOrder();
        return MonoUtil.infoLog("INTERNAL enhance with quotation datas lines: {}", LineExecution.joinLineIds(linesToEhance))
            .then(this.quotationDataGetter.apply(this.toInput(customerOrder)))
            .doOnNext(quotationData -> {
                this.associateCashingStoreId(linesToEhance, quotationData.getMetadataByOfferLineId());
                if (quotationData.getStatus() == QuotationDataGetter.QuotationStatus.VALIDATED) {
                    linesToEhance.forEach(line -> line.getComposition().setQuotationValidated(true));
                }
                quotationData.getLoyaltyFees().forEach(loyaltyFee -> {
                    this.createLoyaltyFeeLineExecutions(loyaltyFee, context);
                });
            })
            .doOnNext(quotationData ->
                quotationData.getLoyaltyFees().forEach(loyaltyFee -> {
                    this.createLoyaltyFeeLineExecutions(loyaltyFee, context);
                })
            )
            .onErrorResume(throwable -> {
                if(throwable instanceof QuotationVersionsInconsistent) {
                    return MonoUtil.infoLog("INTERNAL: {}", throwable.getMessage());
                } else {
                    return MonoUtil.errorLog("INTERNAL: Get quotation information failure on order {} for reason", customerOrder.getId(), throwable.getMessage());
                }
            })
            .then();
    }

    private void createLoyaltyFeeLineExecutions(QuotationDataGetter.LoyaltyFee loyaltyFee, RuleEngineContext context) {
        Optional<LineExecution> existingLoyaltyFeeLineOption = context.getOrderData().getFirstFindedLineExecutionById(loyaltyFee.getId());
        final var customerOrder = context.getOrderData().getExistingCustomerOrder();
        ExternalSystem externalSystem = ExternalSystem.builder()
            .name(TEMPO)
            .id(customerOrder.getBuCode() + "-" + customerOrder.getCustomerOrderNumber() + "-" + 1)
            .origin(TEMPO)
            .build();

        existingLoyaltyFeeLineOption.ifPresentOrElse(existingLoyaltyFeeLine -> {
            existingLoyaltyFeeLine.getComposition().getFlags().raiseFlag(CompositionOrderStatus.VALIDATED);
            existingLoyaltyFeeLine.setVersion(1);
            existingLoyaltyFeeLine.setLineType(LineType.LOYALTY_FEE);
            existingLoyaltyFeeLine.setLineId(loyaltyFee.getId());
            existingLoyaltyFeeLine.setCustomerOrderId(customerOrder.getId());
            existingLoyaltyFeeLine.setExecutionId(existingLoyaltyFeeLine.getExecutionId());
            existingLoyaltyFeeLine.setQuantity(BigDecimal.ONE);
            existingLoyaltyFeeLine.setInitialQuantity(BigDecimal.ONE);
            existingLoyaltyFeeLine.setBuCode(customerOrder.getBuCode());
            existingLoyaltyFeeLine.getPayment().setStoreId(loyaltyFee.getCashingStore());
            existingLoyaltyFeeLine.getComposition().setQuantity(BigDecimal.ONE);
            existingLoyaltyFeeLine.getComposition().setCreatedAt(customerOrder.getMetadata().getCreatedAt());
            existingLoyaltyFeeLine.getComposition().setCreatedBy(customerOrder.getMetadata().getCreatedBy().getReference());
            existingLoyaltyFeeLine.getComposition().setOffer(Offer.builder()
                .id(loyaltyFee.getOfferId())
                .isSoldByAThirdPartyVendor(false)
                .vendorId(loyaltyFee.getVendorId())
                .adeoKey(loyaltyFee.getRefLM())
                .refLM(loyaltyFee.getRefLM())
                .build());
            existingLoyaltyFeeLine.setExternalSystem(externalSystem);
        }, () -> context.getOrderData().getExistingLineExecutions().add(LineExecution.builder()
            .version(1)
            .lineType(LineType.LOYALTY_FEE)
            .lineId(loyaltyFee.getId())
            .customerOrderId(customerOrder.getId())
            .executionId(UUID.randomUUID().toString())
            .buCode(customerOrder.getBuCode())
            .payment(LineExecutionPayment.builder()
                .storeId(loyaltyFee.getCashingStore())
                .build())
            .composition(LineExecutionComposition.builder()
                .quantity(BigDecimal.ONE)
                .createdAt(customerOrder.getMetadata().getCreatedAt())
                .createdBy(customerOrder.getMetadata().getCreatedBy().getReference())
                .offer(Offer.builder()
                    .id(loyaltyFee.getOfferId())
                    .isSoldByAThirdPartyVendor(false)
                    .vendorId(loyaltyFee.getVendorId())
                    .adeoKey(loyaltyFee.getRefLM())
                    .refLM(loyaltyFee.getRefLM())
                    .build())
                .flags(new Flags<>(new Flag(UNKNOWN_OPERATION_ID, OffsetDateTime.now(), VALIDATED.name(), null)))
                .build())
            .externalSystem(externalSystem)
            .build()));
    }

    private void associateCashingStoreId(List<LineExecution> lines, Map<String, QuotationDataGetter.LineMetadata> lineMetadataByOfferLineId) {
        log.info("Assign cashing store");
        updateLineExecution(lines, lineMetadataByOfferLineId);
    }

    private static void updateLineExecution(List<LineExecution> lines, Map<String, QuotationDataGetter.LineMetadata> lineMetadataByOfferLineId) {
        lines.forEach(lineExecution -> {
            final var quotationOfferLine = lineMetadataByOfferLineId.get(lineExecution.getLineId());
            if (quotationOfferLine != null) {
                lineExecution.getPayment().setStoreId(quotationOfferLine.getCashingStore());
            } else {
                log.warn("can not find the offer customerOrderLine {} on quotation", lineExecution.getLineId());
            }
        });
    }

    private CashingStoreAssignerInput toInput(CustomerOrder customerOrder) {
        return CashingStoreAssignerInput.builder()
            .buCode(customerOrder.getBuCode())
            .quotationId(customerOrder.getQuotation().getId())
            .quotationVersion(customerOrder.getQuotation().getVersion())
            .build();
    }

}
