package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.service.input;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@AllArgsConstructor
@Builder
public class ProjectExecutionRequestAcceptedInput {
    private String customerOrderId;
    private String buCode;
    private List<String> customerOrderLineIds;
}
