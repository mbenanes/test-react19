package com.adeo.sales.customerorder.tempoorchestrator.model.alert;

public enum AlertShippingType {
    WAREHOUSE,
    SUPPLIER,
    STORE,
    VENDOR
}
