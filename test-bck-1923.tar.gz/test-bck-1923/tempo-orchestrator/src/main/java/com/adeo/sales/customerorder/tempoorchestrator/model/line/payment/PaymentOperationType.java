package com.adeo.sales.customerorder.tempoorchestrator.model.line.payment;

import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.EnumSet;
import java.util.Set;

@NoArgsConstructor
@Getter
public enum PaymentOperationType {
    CANCEL_AUTHORIZATION_REQUESTED,
    AUTHORIZATION_PENDING,
    AUTHORIZATION_DELAYED,
    AUTHORIZATION_REJECTED,
    AUTHORIZED,
    AUTHORIZATION_CANCELED,
    AUTHORIZATION_CANCEL_FAILED,
    CAPTURED,
    CAPTURE_REQUESTED,
    CAPTURE_FAILED,
    CANCEL_CAPTURE_REQUESTED,
    CANCEL_CAPTURE_FAILED,
    REFUND_DELAYED,
    REFUND_FAILED,
    CAPTURE_CANCELED;

    public static final Set<PaymentOperationType> STATUS_ACCEPTING_CAPTURE = EnumSet.of(
        AUTHORIZED, AUTHORIZATION_CANCEL_FAILED, CAPTURE_FAILED
    );

}
