package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.collect.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExecutionWithLines;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.PostponedEventService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_APPOINTMENT_EXPIRED_NOTIFICATION_POSTPONED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_APPOINTMENT_REMINDER_NOTIFICATION_POSTPONED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECTABLE_DELIVERY_TYPE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECT_APPOINTMENT_DATE_AFTER_DELIVERY_DATE_OR_NOT_EXISTING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_GLOBAL_COLLECT_EXECUTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.NotificationStatus.NOTIFICATION_POSTPONED_NOT_SENT;
import static com.adeo.sales.customerorder.tempoorchestrator.service.impl.OutcomingNotificationServiceImpl.NotificationType.APPOINTMENT_REMINDER_DAY_BEFORE;
import static com.adeo.sales.customerorder.tempoorchestrator.service.impl.OutcomingNotificationServiceImpl.NotificationType.APPOINTMENT_REMINDER_HOURS_BEFORE;
import static com.adeo.sales.customerorder.tempoorchestrator.service.impl.OutcomingNotificationServiceImpl.NotificationType.PICKUP_APPOINTMENT_EXPIRED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@AllArgsConstructor
@Rule(name = "RemovePostponedAppointmentCommunicationTPPRule",
    description = "Remove postponed appointment notification.",
    priority = 999)
public class RemovePostponedAppointmentCommunicationTPPRule {

    private final List<String> emailTypesAppointmentNotification = new ArrayList<>(List.of(APPOINTMENT_REMINDER_DAY_BEFORE.getTemplateType(), APPOINTMENT_REMINDER_HOURS_BEFORE.getTemplateType(), PICKUP_APPOINTMENT_EXPIRED.getTemplateType()));

    public static final Predicate<LineExecution> IS_TPP_COLLECTABLE_LINE_BY_TEMPO_WITH_EXISTING_POSPONED_APPOINTMENT_NOTIFICATION = PAYMENT_ORCHESTRATED_BY_TPP.and(IS_COLLECTABLE_DELIVERY_TYPE).and(IS_EXTERNAL_SYSTEM_TEMPO).and(IS_APPOINTMENT_REMINDER_NOTIFICATION_POSTPONED.or(IS_APPOINTMENT_EXPIRED_NOTIFICATION_POSTPONED));
    private final PostponedEventService postponedEventService;

    private static final Predicate<LineExecution> IS_CANCELED_OR_EXECUTED = IS_LINE_COMPOSITION_CANCELED.or(IS_GLOBAL_COLLECT_EXECUTED);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.getOrderData().getExistingExecutionsWithLines()
            .stream()
            .map(ExecutionWithLines::getLineExecutions)
            .anyMatch(lineExecutions -> {
                final List<LineExecution> collectableLines = lineExecutions.stream()
                    .filter(IS_TPP_COLLECTABLE_LINE_BY_TEMPO_WITH_EXISTING_POSPONED_APPOINTMENT_NOTIFICATION)
                    .toList();

                return !collectableLines.isEmpty() &&
                    collectableLines.stream()
                        .allMatch(IS_CANCELED_OR_EXECUTED.or(not(IS_COLLECT_APPOINTMENT_DATE_AFTER_DELIVERY_DATE_OR_NOT_EXISTING)));
            });
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return Flux.fromIterable(emailTypesAppointmentNotification)
            .flatMap(emailType -> postponedEventService.postponedEventExistForOrderAndFunctionalType(context.getCustomerOrderId(), emailType)
                .filter(eventExists -> eventExists)
                .thenReturn(emailType))
            .flatMap(emailType -> postponedEventService.markEventAsNotToSend(context.getCustomerOrderId(), emailType)
                .then(Mono.fromRunnable(() ->
                    context.getOrderData().getExistingExecutionsWithLines()
                        .stream()
                        .map(ExecutionWithLines::getLineExecutions)
                        .filter(lineExecutions -> {
                            final List<LineExecution> collectableLines = lineExecutions.stream()
                                .filter(IS_TPP_COLLECTABLE_LINE_BY_TEMPO_WITH_EXISTING_POSPONED_APPOINTMENT_NOTIFICATION)
                                .toList();

                            return !collectableLines.isEmpty() &&
                                collectableLines.stream()
                                    .allMatch(IS_CANCELED_OR_EXECUTED.or(not(IS_COLLECT_APPOINTMENT_DATE_AFTER_DELIVERY_DATE_OR_NOT_EXISTING)));
                        })
                        .flatMap(Collection::stream)
                    .forEach(lineExecution -> {
                        lineExecution.getDelivery().getCollect().setAppointmentReminderNotificationStatus(NOTIFICATION_POSTPONED_NOT_SENT);
                        lineExecution.getDelivery().getCollect().setAppointmentExpiredNotificationStatus(NOTIFICATION_POSTPONED_NOT_SENT);
                        lineExecution.increaseVersion();
                    })
                )))
            .then();
    }
}
