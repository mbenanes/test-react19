package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.legacynumber.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.LegacyACL;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.LegacyNumbersStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PAYMENT_OWNERSHIP_TRANSFERED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT;

@Component
@Slf4j
@AllArgsConstructor
@Rule(name = "ReleaseDematCodeRuleTpp",
    description = "Remove demat code when order is paid or canceled.",
    priority = 9)
public class ReleaseDematCodeRuleTpp {
    private final LegacyACL legacyACL;
    private static final Predicate<LineExecution> NEED_REMOVE_DEMAT_CODE = IS_LINE_COMPOSITION_VALIDATED
        .and(IS_EXTERNAL_SYSTEM_TEMPO)
        .and(IS_VALIDATION_AND_CONFIRMATION_REQUIREMENT_COMPLIANT.or(IS_PAYMENT_OWNERSHIP_TRANSFERED));

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return (context.hasAtLeastOneLine(NEED_REMOVE_DEMAT_CODE) || context.allLinesMatchs(IS_LINE_COMPOSITION_CANCELED))
            && context.getOrderData().getExistingCustomerOrder().getDematCode() != null
            && context.getOrderData().getExistingCustomerOrder().getDematCodeStatus() != LegacyNumbersStatus.RELEASED
            && context.isCustomerOrderMatches(IS_PLACE_TYPE_IN_STORE);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var storeId = context.getOrderData().getExistingLineExecutions().get(0).getPayment().getStoreId();

        return this.legacyACL.releaseDematCode(context.getOrderData().getExistingCustomerOrder().getId(), storeId, context.getBuCode())
            .then(Mono.fromRunnable(() -> {
                context.getOrderData().getExistingCustomerOrder().setDematCodeStatus(LegacyNumbersStatus.RELEASED);
                context.getOrderData().getExistingLineExecutions().forEach(LineExecution::increaseVersion);
            }));
    }
}
