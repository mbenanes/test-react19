package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.paymentscheduler.command.cancelcustomerorderlinespayment.CancelCustomerOrderLinesPayment;
import com.adeo.sales.customerorder.paymentscheduler.command.cancelcustomerorderlinespayment.CancelCustomerOrderLinesPaymentParameter;
import com.adeo.sales.customerorder.paymentscheduler.v2.payment.command.AskOwnershipTransferCustomerOrderLine;
import com.adeo.sales.customerorder.paymentscheduler.v2.payment.command.AskOwnershipTransferFromDeposit;
import com.adeo.sales.customerorder.paymentscheduler.v2.payment.command.AskOwnershipTransferFromDepositParameter;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.specific.SpecificRecord;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;


@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentSchedulerServiceImpl implements PaymentSchedulerService {

    private final TopicsProperties properties;
    private final EventProducer eventProducer;

    @Override
    public Mono<Void> sendCommandCancelCustomerOrderLine(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        if (!lineExecutions.isEmpty()) {
            log.info("INTERNAL ask to cancel authorization for the following lines {}", LineExecution.joinLineIds(lineExecutions));
            final var customerOrderId = customerOrder.getId();
            final var command = this.buildPaymentCancelCommand(customerOrder, lineExecutions);
            final var buCode = customerOrder.getBuCode();
            return this.sendCommand(customerOrderId, buCode, command);
        }
        return Mono.empty();
    }

    @Override
    public Mono<Void> sendCommandAskOwnershipTransferFromDeposit(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        if (!lineExecutions.isEmpty()) {
            log.info("INTERNAL ask an ownership transfer for the following lines {}", LineExecution.joinLineIds(lineExecutions));
            final var customerOrderId = customerOrder.getId();
            final var buCode = customerOrder.getBuCode();
            final var command = buildAskOwnershipTransferFromDepositCommand(customerOrder, lineExecutions);
            return sendCommand(customerOrderId, buCode, command);
        }
        return Mono.empty();
    }

    private AskOwnershipTransferFromDeposit buildAskOwnershipTransferFromDepositCommand(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        final var customerOrderId = customerOrder.getId();
        final var paymentScheduleId = customerOrder.getPaymentSchedule().getId();
        final var lines = lineExecutions.stream().map(this::buildAskOwnershipTransferCustomerOrderLines).collect(Collectors.toList());
        final var parameter = AskOwnershipTransferFromDepositParameter.newBuilder()
            .setCustomerOrderId(customerOrderId)
            .setPaymentScheduleId(paymentScheduleId)
            .setCustomerOrderLines(lines)
            .build();

        return AskOwnershipTransferFromDeposit.newBuilder()
            .setCommandResponseTopicName(this.properties.getPaymentSchedulerResponse())
            .setParameter(parameter)
            .setType("AskOwnershipTransferFromDeposit")
            .setId(UUID.randomUUID().toString())
            .build();
    }

    private CancelCustomerOrderLinesPayment buildPaymentCancelCommand(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        final var lines = lineExecutions.stream().map(lineExecution -> this.buildCustomerOrderLines(customerOrder, lineExecution)).collect(Collectors.toList());
        final var parameter = CancelCustomerOrderLinesPaymentParameter.newBuilder()
            .setLines(lines)
            .setPaymentScheduleId(customerOrder.getPaymentSchedule().getId())
            .setPaymentScheduleVersion(customerOrder.getPaymentSchedule().getVersion());

        return CancelCustomerOrderLinesPayment.newBuilder()
            .setParameterBuilder(parameter)
            .setId(UUID.randomUUID().toString())
            .setCommandResponseTopicName(this.properties.getPaymentSchedulerResponse())
            .setType("CancelCustomerOrderLinesPayment")
            .build();
    }

    private AskOwnershipTransferCustomerOrderLine buildAskOwnershipTransferCustomerOrderLines(LineExecution lineExecution) {
        return AskOwnershipTransferCustomerOrderLine.newBuilder()
            .setCustomerOrderLineId(lineExecution.getLineId())
            .setDepositId(lineExecution.getPayment().getDepositLegacyNumber())
            .build();
    }

    private com.adeo.sales.customerorder.paymentscheduler.state.CustomerOrderLine buildCustomerOrderLines(CustomerOrder customerOrder, LineExecution lineExecution) {
        final var offerOption = customerOrder.getProductOffer().getOfferLineById(lineExecution.getLineId());
        return com.adeo.sales.customerorder.paymentscheduler.state.CustomerOrderLine
            .newBuilder()
            .setId(lineExecution.getLineId())
            .setCustomerOrderId(customerOrder.getId())
            .setVendorId(offerOption.stream().map(offer -> offer.getOffer().getVendorId()).findFirst().orElse(null))
            .build();
    }

    private <T extends SpecificRecord & GenericRecord> Mono<Void> sendCommand(String customerOrderId, String buCode, T command) {
        return this.eventProducer.sendEvents(this.properties.getPaymentScheduler(), customerOrderId, buCode, command);
    }
}
