package com.adeo.sales.customerorder.tempoorchestrator.handler.ulys;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum CashingPaymentStatus {
    PENDING_AUTHORIZATION,
    CAPTURE_REQUESTED,
    CAPTURED,
    REFUND_REQUESTED,
    REFUNDED,
    AUTHORIZATION_REQUESTED,
    PENDING_PSP_APPROVAL,
    PENDING_CAPTURE,
    PAYMENT_FAILURE,
    CANCELLED,
    CANCELLED_BY_CUSTOMER,
    CANCEL_REQUESTED,
    PAYMENT_ABORT,
    REJECTED,
    REJECTED_CAPTURE,
    CREATED,
    CREATED_DELAY_EXPIRED,
    REDIRECTED,
    PAID,
    UNKNOWN;

    public static CashingPaymentStatus fromString(String value) {
        try {
            return CashingPaymentStatus.valueOf(value);
        } catch (IllegalArgumentException e) {
            log.warn("Cashing payment status {} is unknown", value, e);
            return UNKNOWN;
        }
    }
}
