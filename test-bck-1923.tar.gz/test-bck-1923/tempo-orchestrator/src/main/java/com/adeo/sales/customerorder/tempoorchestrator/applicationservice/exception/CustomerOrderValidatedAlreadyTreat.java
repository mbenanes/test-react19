package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception;

public class CustomerOrderValidatedAlreadyTreat extends RuntimeException {

    public CustomerOrderValidatedAlreadyTreat() {
        super("the customer order validate has already treated. COPV is ignored");
    }
}
