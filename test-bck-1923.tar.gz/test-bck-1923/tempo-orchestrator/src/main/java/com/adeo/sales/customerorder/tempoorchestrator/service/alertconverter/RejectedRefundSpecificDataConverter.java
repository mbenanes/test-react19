package com.adeo.sales.customerorder.tempoorchestrator.service.alertconverter;

import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationFailedSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertToTempoAlertingSpecificDataConverter;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.AlertType;
import org.springframework.stereotype.Component;

@Component
public class RejectedRefundSpecificDataConverter implements AlertToTempoAlertingSpecificDataConverter<PaymentOperationFailedSpecificData> {

    @Override
    public AlertType getAlertType() {
        return AlertType.TRANSACTION;
    }

    @Override
    public boolean manageType(Class<? extends AlertSpecificData> aClass) {
        return PaymentOperationFailedSpecificData.class == aClass;
    }
}
