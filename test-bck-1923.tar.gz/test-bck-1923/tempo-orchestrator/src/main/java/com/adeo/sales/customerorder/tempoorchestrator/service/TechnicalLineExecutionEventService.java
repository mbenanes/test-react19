package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.converter.Converter;
import com.adeo.sales.customerorder.tempoorchestrator.event.delta.CustomerOrderLineUpdatedDelta;
import com.adeo.sales.customerorder.tempoorchestrator.event.technical.CustomerOrderLinesUpdated;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class TechnicalLineExecutionEventService {

    private final EventProducer eventProducer;
    private final String technicalEventTopic;
    private final Converter<LineExecution, com.adeo.sales.customerorder.tempoorchestrator.data.CustomerOrderLine> lineExecutionToEventCustomerOrderLine;

    public TechnicalLineExecutionEventService(
        EventProducer eventProducer,
        TopicsProperties topicsProperties,
        Converter<LineExecution, com.adeo.sales.customerorder.tempoorchestrator.data.CustomerOrderLine> lineExecutionToEventCustomerOrderLine
    ) {
        this.eventProducer = eventProducer;
        this.technicalEventTopic = topicsProperties.getTechnicalEvent();
        this.lineExecutionToEventCustomerOrderLine = lineExecutionToEventCustomerOrderLine;
    }

    public Mono<Void> sendCustomerOrderLinesUpdated(List<LineExecution> lineExecutions) {
        if (lineExecutions.isEmpty()) {
            return Mono.empty();
        }
        final var event = this.customerOrderLinesToUpdatedEvent(lineExecutions);

        final var customerOrderId = lineExecutions.get(0).getCustomerOrderId();
        final var buCode = lineExecutions.get(0).getBuCode();

        return this.eventProducer.sendEvent(technicalEventTopic, customerOrderId, buCode, event);
    }

    private CustomerOrderLinesUpdated customerOrderLinesToUpdatedEvent(List<LineExecution> lineExecutions) {
        final var eventId = UUID.randomUUID();
        final var state = lineExecutions.stream()
            .map(this.lineExecutionToEventCustomerOrderLine::convert)
            .collect(Collectors.toList());
        final var delta = lineExecutions.stream()
            .map(line ->
                CustomerOrderLineUpdatedDelta.newBuilder()
                    .setId(line.getLineId())
                    .setVersion(line.getVersion())
                    .build()
            )
            .collect(Collectors.toList());

        return CustomerOrderLinesUpdated.newBuilder()
            .setId(eventId.toString())
            .setType("CustomerOrderLinesUpdated")
            .setState(state)
            .setDelta(delta)
            .build();
    }

}
