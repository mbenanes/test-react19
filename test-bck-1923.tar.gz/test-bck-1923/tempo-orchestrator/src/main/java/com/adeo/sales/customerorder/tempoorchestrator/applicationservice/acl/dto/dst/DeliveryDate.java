package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst;


import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import java.time.Duration;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Comparator;
import java.util.List;

@JsonTypeInfo(
    use = JsonTypeInfo.Id.NAME,
    property = "type",
    visible = true)
@JsonSubTypes({
    @JsonSubTypes.Type(value = FixedDeliveryDate.class, name = "FIXED"),
    @JsonSubTypes.Type(value = RangeDeliveryDate.class, name = "RANGE")
})
public interface DeliveryDate {
    Comparator<? super DeliveryDate> BY_MAX_DATE_COMPARATOR = Comparator.comparing(DeliveryDate::getMaxDate);

    static OffsetDateTime getMaxDate(DeliveryDate date) {
        if(date == null) {
            return null;
        }
        if (date instanceof FixedDeliveryDate) {
            return ((FixedDeliveryDate) date).getFixedDate();
        }
        return ((RangeDeliveryDate) date).getEndDate();
    }

    static DeliveryDate getMaxCustomerKnownDeliveryDate(List<LineExecution> lines){
        return lines
            .stream()
            .map(lineExecution -> lineExecution.getDelivery().getCustomerKnownDeliveryDate())
            .max(BY_MAX_DATE_COMPARATOR)
            .orElse(null);
    }

    default long nbDayBetween(DeliveryDate other) {
        final var thisMaxDate = getMaxDate(this);
        final var otherMaxDate = getMaxDate(other);

        return Duration.between(thisMaxDate.toLocalDate().atStartOfDay(), otherMaxDate.toLocalDate().atStartOfDay()).toDays();
    }

    default long nbDayBetweenAbs(DeliveryDate other) {
        final var thisMaxDate = getMaxDate(this);
        final var otherMaxDate = getMaxDate(other);
        final var nbDayBetween = Duration.between(thisMaxDate.toLocalDate().atStartOfDay(), otherMaxDate.toLocalDate().atStartOfDay()).toDays();
        return Math.abs(nbDayBetween);
    }

    default Duration durationBetween(DeliveryDate other) {
        final var thisMaxDate = getMaxDate(this);
        final var otherMaxDate = getMaxDate(other);

        return Duration.between(thisMaxDate, otherMaxDate);
    }

    @JsonIgnore
    default boolean isInPast() {
        return Duration.between(LocalDate.now().atStartOfDay(), getMaxDate(this).toLocalDate().atStartOfDay()).toDays() < 0;
    }
}
