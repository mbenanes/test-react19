package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.log;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.Incoterm;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_NOT_ASKED_STOCK_VALUATION;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CAPTURE_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_SHIPPED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_INCOTERM_INELIGIBLE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_PARTNER;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "LogOnUnhandledIncortermAtShipped",
    description = "Log error when received unhandled incoterm at shipped",
    priority = 1100)
public class LogOnUnhandledIncortermAtShippedRule {

    private static final Predicate<LineExecution> ASK_STOCK_VALORIZATION_REQUESTED = IS_CAPTURE_REQUESTED
        .and(IS_SHIPPED_BY_PARTNER)
        .and(IS_DELIVERY_SHIPPED)
        .and(IS_INCOTERM_INELIGIBLE)
        .and(HAS_NOT_ASKED_STOCK_VALUATION);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(ASK_STOCK_VALORIZATION_REQUESTED);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var shippedLinesToStockValorize = context.getOrderData().getExistingLineExecutions().stream()
            .filter(ASK_STOCK_VALORIZATION_REQUESTED)
            .filter(line -> line.getDelivery().getDeliveryLegacyNumber() != null)
            .collect(Collectors.groupingBy(lineExecution -> lineExecution.getDelivery().getDeliveryLegacyNumber()));

        shippedLinesToStockValorize.values().forEach(lines -> {
            LineExecution firstLine = lines.get(0);
            String rawIncoterm = firstLine.getDelivery().getIncoterm();
            try {
                final var incoterm = Incoterm.valueOf(rawIncoterm);
                log.error("this incoterm {} is unmanaged", incoterm);
            } catch (IllegalArgumentException e) {
                log.error("this incoterm {} is unknown", rawIncoterm);
            }
        });

        return Mono.empty();
    }
}
