package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert;

import com.adeo.featuretoggle.FeatureRepository;
import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.BiPredicateHelper;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.FeatureToggleConfiguration;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertReason;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.RejectedPaymentSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.service.UpdateAvailableActionService;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.AlertMessageInput;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.DeliveryDate.getMaxCustomerKnownDeliveryDate;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "CreateAlertWhen3PPaymentIsRejected",
    description = "create an alert when a payment capture is failed on a third party customer order line",
    priority = 1000)
public class CreateAlertWhen3PPaymentIsRejectedRule {
    public static final String ALERT_REASON = AlertReason.REJECTED_PAYMENT.name();
    public static final Predicate<LineExecution> THIRD_PARTY_LINE_HAVE_CAPTURE_FAILED =
        RuleEngineCompensationConditions.IS_3P
            .and(RuleEngineCompensationConditions.IS_CAPTURE_FAILED)
            .and(RuleEngineCompensationConditions.IS_NOT_COMPOSITION_CANCELED_AND_NOT_CANCEL_REQUESTED)
            .and(RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR);

    private final FeatureRepository featureRepository;
    private final AlertMessageService alertMessageService;
    private final UpdateAvailableActionService updateAvailableActionService;

    @Condition
    public Mono<Boolean> when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return BiPredicateHelper.and(
            FeatureToggleConfiguration.isRejectedCaptureAlertingFeatureEnabled(context.getBuCode(), this.featureRepository),
            Mono.just(context.hasAtLeastOneLine(THIRD_PARTY_LINE_HAVE_CAPTURE_FAILED))
        );
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var linesToCancel = context.getOrderData().getLineExecutionsByPredicate(THIRD_PARTY_LINE_HAVE_CAPTURE_FAILED).stream()
            .filter(line -> RuleEngineCompensationConditions.hasNoAlertOn(context, line, ALERT_REASON))
            .collect(Collectors.toList());

        if (linesToCancel.isEmpty()) {
            return MonoUtil.infoLog("All lines with capture failed have already a {} alert. No new alert created.", ALERT_REASON);
        }
        final var customerKnownDeliveryDate = getMaxCustomerKnownDeliveryDate(linesToCancel);

        final var alert = this.buildAlert(context, linesToCancel, DeliveryDate.getMaxDate(customerKnownDeliveryDate));

        return MonoUtil.infoLog("INTERNAL request alert {} creation for payment refused 3P lines: {}", alert.getId(), LineExecution.joinLineIds(linesToCancel))
            .then(alertMessageService.sendCreateAlertMessage(this.buildAlertMessageInput(linesToCancel, alert, context.getOrderData().getExistingCustomerOrder())))
            .then(Mono.fromRunnable(() -> {
                context.getAlertData().getExistingAlerts().add(alert);
                linesToCancel.forEach(line -> this.updateAvailableActionService.apply(context.getOrderData().getExistingLineExecutions(), line, context.getOrderData().getExistingCustomerOrder(), true));
            }));
    }

    private Alert buildAlert(RuleEngineContext context, List<LineExecution> linesToCancel, OffsetDateTime customerKnownDeliveryDate) {

        final Map<String, List<String>> impactedLineByExecution = linesToCancel.stream()
            .collect(Collectors.groupingBy(lineExecution -> Optional.ofNullable(lineExecution.getExecutionId()).orElse(lineExecution.getCustomerOrderId()),
                Collectors.mapping(LineExecution::getLineId, Collectors.toList())));

        final var lineMetadataByLineId = linesToCancel.stream()
            .collect(Collectors.toMap(
                LineExecution::getLineId,
                line -> AlertSpecificData.LineMetadata.fromOrderAndLine(context.getOrderData().getExistingCustomerOrder(), line)
            ));

        final var alertId = UUID.randomUUID();
        return Alert.builder()
            .id(alertId)
            .specificData(RejectedPaymentSpecificData.builder()
                .linesToCancelByExecution(impactedLineByExecution)
                .lineMetadataByLineId(lineMetadataByLineId)
                .reason(ALERT_REASON)
                .receivedAt(OffsetDateTime.now())
                .paymentOrchestratingSystem(linesToCancel.get(0).getPayment().getPaymentExecutionSystem().name())
                .requestId(alertId.toString())
                .build()
            )
            .impactedLinesIds(linesToCancel.stream().map(LineExecution::getLineId).collect(Collectors.toList()))
            .customerOrderId(context.getCustomerOrderId())
            .customerKnownDeliveryDate(customerKnownDeliveryDate)
            .buCode(context.getBuCode())
            .status(AlertStatus.CREATION_REQUESTED)
            .build();
    }

    private AlertMessageInput buildAlertMessageInput(List<LineExecution> linesToCreateAlert, Alert alert, CustomerOrder existingCustomerOrder) {
        return AlertMessageInput.builder()
            .alert(alert)
            .lineExecutions(linesToCreateAlert)
            .customerOrder(existingCustomerOrder)
            .build();
    }
}
