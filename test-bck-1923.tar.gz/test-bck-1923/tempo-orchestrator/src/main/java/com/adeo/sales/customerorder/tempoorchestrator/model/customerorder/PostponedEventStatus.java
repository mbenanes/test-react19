package com.adeo.sales.customerorder.tempoorchestrator.model.customerorder;

public enum PostponedEventStatus {
    POSTPONED_REQUESTED, POSTPONED_NOT_SENT
}
