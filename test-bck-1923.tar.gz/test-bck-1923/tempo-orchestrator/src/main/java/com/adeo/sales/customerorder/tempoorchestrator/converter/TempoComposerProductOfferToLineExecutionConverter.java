package com.adeo.sales.customerorder.tempoorchestrator.converter;

import com.adeo.sales.customerorder.ProductOfferLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.Offer;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ConfigurationService;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Slf4j
@Component
public class TempoComposerProductOfferToLineExecutionConverter implements Converter<ProductOfferLine, LineExecution> {

    @Override
    public LineExecution convert(ProductOfferLine productOfferLine) {
        final var result = new LineExecution();

        result.setVersion(1);
        result.setLineId(productOfferLine.getId());
        result.setLineType("SERVICE".equals(productOfferLine.getItemType()) ? LineType.SERVICE : LineType.OFFER);
        result.getComposition().getFlags().raiseFlag(CompositionOrderStatus.valueOf(productOfferLine.getStatus()));
        result.getComposition().setQuantity(productOfferLine.getQuantity());
        result.setQuantity(productOfferLine.getQuantity());
        result.setInitialQuantity(productOfferLine.getInitialOrderedQuantity());
        result.getComposition().setCancellationReason(productOfferLine.getCancelationReason());
        result.getComposition().setPosition(productOfferLine.getPosition());

        if (productOfferLine.getConfiguration() != null && productOfferLine.getConfiguration().getConfigurationId() != null) {
            final String configurationId = productOfferLine.getConfiguration().getConfigurationId();
            final ConfigurationService configurationService = ConfigurationService.builder().id(configurationId).associatedLinesId(new ArrayList<>()).build();
            result.setConfigurationService(configurationService);
        }

        final var tempoComposerOffer = productOfferLine.getOffer();
        final var offer = Offer.builder()
            .contextId(tempoComposerOffer.getContextId())
            .id(tempoComposerOffer.getId())
            .vendorId(tempoComposerOffer.getVendorId())
            .isSoldByAThirdPartyVendor(tempoComposerOffer.getIsSoldByAThirdPartyVendor())
            .adeoKey(tempoComposerOffer.getAdeoKey())
            .refLM(tempoComposerOffer.getRefLM())
            .build();

        result.getComposition().setOffer(offer);
        result.setSoldByAThirdPartyVendor(tempoComposerOffer.getIsSoldByAThirdPartyVendor());

        return result;
    }
}
