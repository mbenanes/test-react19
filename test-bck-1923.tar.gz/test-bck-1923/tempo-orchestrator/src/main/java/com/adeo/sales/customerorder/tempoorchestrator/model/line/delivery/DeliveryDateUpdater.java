package com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery;

public enum DeliveryDateUpdater {
    DELIVERY,
    CALL_CENTER
}
