package com.adeo.sales.customerorder.tempoorchestrator.model.line;

import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.Offer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LineExecutionComposition {
    private OffsetDateTime createdAt;
    private String createdBy;
    private String cancellationReason;
    private String orderPartNumber;
    private boolean promisedDateConfirmed;
    private boolean promisedDateConfirmationAsked;
    private boolean quotationValidated;
    private boolean quotationValidationAsked;
    private boolean cancelable;
    private BigDecimal quantity;
    private Integer position;
    private String legacyNumber;
    private String executionSelector;

    private Offer offer;
    private Flags<CompositionOrderStatus> flags;

    public Flags<CompositionOrderStatus> getFlags() {
        if (this.flags == null) {
            this.flags = new Flags<>();
        }
        return flags;
    }

    public Offer getOffer() {
        if (this.offer == null) {
            this.offer = new Offer();
        }
        return offer;
    }

    public CompositionOrderStatus getLastFlag() {
        Flag lastFlag = this.getFlags().getLastFlag();
        if (lastFlag != null) {
            final var lastFlagType = lastFlag.getType();
            return CompositionOrderStatus.valueOf(lastFlagType);
        }
        return null;
    }
}
