package com.adeo.sales.customerorder.tempoorchestrator.configuration.postpone;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PostponeNotificationTemplateConfiguration extends PostponeConfiguration {
    private String template;
}
