package com.adeo.sales.customerorder.tempoorchestrator.service.impl;

import com.adeo.sales.customerorder.external.api.client.cpr.ConfiguredProductRepositoryApiClient;
import com.adeo.sales.customerorder.external.api.client.csr.ConfiguratorSimulationsRepositoryApiClient;
import com.adeo.sales.customerorder.external.api.client.dst.DeliverySimulationTowerWebClient;
import com.adeo.sales.customerorder.external.api.client.dst.dto.Delivery;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliveryAddress;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliveryDate;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliveryPlace;
import com.adeo.sales.customerorder.external.api.client.dst.dto.DeliverySimulation;
import com.adeo.sales.customerorder.external.api.client.dst.dto.HomeDelivery1PDetails;
import com.adeo.sales.customerorder.external.api.client.dst.dto.NoDeliveryPlace;
import com.adeo.sales.customerorder.external.api.client.dst.dto.OfferCartItem;
import com.adeo.sales.customerorder.external.api.client.dst.dto.RelayPoint;
import com.adeo.sales.customerorder.external.api.client.dst.dto.RelayPoint1PDetails;
import com.adeo.sales.customerorder.external.api.client.dst.dto.ServiceLevel;
import com.adeo.sales.customerorder.external.api.client.dst.dto.ServiceLevelDetails;
import com.adeo.sales.customerorder.external.api.client.dst.dto.ShippingPoint;
import com.adeo.sales.customerorder.external.api.client.dst.dto.ShippingPointType;
import com.adeo.sales.customerorder.external.api.client.dst.dto.StoreDeliveryPlace;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.service.FulfillmentOrderExecutionService;
import com.adeo.sis.dor.avro.business.fulfillmentorder.ChannelTypeEnumAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.CustomerDeliveryLocationAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.CustomerOrderCartItemAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.FulfillmentOrderExecutionAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.FulfillmentOrderLineExecutionAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.LocationTypeEnumAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.LockFlagEnum;
import com.adeo.sis.dor.avro.business.fulfillmentorder.ProductAvro;
import com.adeo.supply.avro.common.locations.v1.InvoicingLocation;
import com.adeo.supply.avro.common.locations.v1.ShippingLocation;
import com.adeo.supply.avro.common.types.v1.LocationType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Component
public class FulfillmentOrderExecutionServiceImpl extends AbstractFulfillmentOrderService implements FulfillmentOrderExecutionService {
    private final TopicsProperties properties;
    private final EventProducer eventProducer;
    private final DeliverySimulationTowerWebClient dstClient;

    public FulfillmentOrderExecutionServiceImpl(ConfiguredProductRepositoryApiClient configuredProductRepositoryApiClient, ConfiguratorSimulationsRepositoryApiClient configuratorSimulationsRepositoryApiClient, TopicsProperties properties, EventProducer eventProducer, DeliverySimulationTowerWebClient dstClient) {
        super(configuredProductRepositoryApiClient, configuratorSimulationsRepositoryApiClient);
        this.properties = properties;
        this.eventProducer = eventProducer;
        this.dstClient = dstClient;
    }

    @Override
    public Mono<Void> createOrderExecution(List<LineExecution> lines, CustomerOrder customerOrder) {
        if (lines.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask to create the customer order on the 1P orchestrator system: {}", LineExecution.joinLineIds(lines));

        return dstClient.getDeliveries(customerOrder.getDelivery().getId(), customerOrder.getBuCode())
            .map(deliverySimulation ->
                FulfillmentOrderExecutionAvro.newBuilder()
                    .setChannel(customerOrder.getOrderPlaceType() == CustomerOrderPlaceType.IN_STORE ? ChannelTypeEnumAvro.STORE : ChannelTypeEnumAvro.WEB)
                    .setCustomerOrderIdentifier(customerOrder.getId())
                    .setCustomerOrderNumber(customerOrder.getCustomerOrderNumber())
                    .setCustomerOrderCreatedDate(customerOrder.getMetadata().getCreationDate())
                    .setClientNumber(customerOrder.getCustomer().getId())
                    .setBusinessUnitIdentifier(customerOrder.getBuCode())
                    .setUserContextStoreIdentifier(Optional.ofNullable(deliverySimulation.getDeliveryContext().getUserStoreCode()).orElse(deliverySimulation.getDeliveryContext().getDefaultStoreCode()))
                    .setFulfillmentOrderLines(this.buildReservationLines(customerOrder, lines, deliverySimulation))
                    .build()
            )
            .flatMap(fulfillmentOrderExecutionAvro -> this.getSimulations(customerOrder, lines)
                .collectList().defaultIfEmpty(List.of())
                .zipWhen(simulations -> this.getConfiguredProducts(customerOrder, lines)
                    .collectList().defaultIfEmpty(List.of()))
                .flatMap(tuple ->
                    Flux.fromIterable(fulfillmentOrderExecutionAvro.getFulfillmentOrderLines())
                        .flatMap(fulfillmentOrderLineExecutionAvro -> Flux.fromIterable(fulfillmentOrderLineExecutionAvro.getCustomerOrderCartItems()))
                        .flatMap(customerOrderCartItemAvro ->
                            Mono.justOrEmpty(this.buildFulfillmentOrderLineConfiguredProduct(customerOrder, lines, customerOrderCartItemAvro.getCustomerOrderCartItemIdentifier(), tuple)
                                .map(fulfillmentOrderLineConfiguredProductAvro -> {
                                    customerOrderCartItemAvro.setFulfillmentOrderLineConfiguredProduct(fulfillmentOrderLineConfiguredProductAvro);
                                    return fulfillmentOrderExecutionAvro;
                                }))
                        )
                        .then(Mono.just(fulfillmentOrderExecutionAvro))
                ))
            .log()
            .flatMap(fulfillmentOrderExecutionAvro ->
                this.eventProducer.sendEvents(this.properties.getCreateDeliveryV2(customerOrder.getBuCode()), customerOrder.getId(), customerOrder.getBuCode(), fulfillmentOrderExecutionAvro)
            );
    }

    private List<FulfillmentOrderLineExecutionAvro> buildReservationLines(CustomerOrder customerOrder, List<LineExecution> lines, DeliverySimulation deliverySimulation) {

        final var lineIds = LineExecution.lineIds(lines);
        return deliverySimulation.getDeliveries().stream()
            .filter(delivery -> delivery.getOfferCartItems()
                .stream()
                .anyMatch(offerCartItem -> lineIds.contains(offerCartItem.getId())))
            .map(delivery -> {
                final var deliveryPlace = deliverySimulation.getDeliveryPlace().getDeliveryPlace(delivery.getDeliveryMode(), delivery.getDeliveryPlaceReference());
                final var serviceLevel = delivery.getServiceLevel();
                final var shippingPoint = this.mapShippingPointToAvro(serviceLevel.getDetails(), deliveryPlace, customerOrder.getBuCode());
                final var cartIds = delivery.getOfferCartItems().stream().map(OfferCartItem::getId).toList();
                final var deliveryLineExecutions = lines.stream().filter(lineExecution -> cartIds.contains(lineExecution.getLineId())).collect(Collectors.toList());
                return FulfillmentOrderLineExecutionAvro.newBuilder()
                    .setCustomerDeliveryServiceDeliveryMode(delivery.getDeliveryMode().name())
                    .setFulfillmentOrderLockFlags(shippingPoint != null ? this.getLockFlagForShippingPointAndDeliveryMode(shippingPoint.getType()) : List.of())
                    .setCustomerDeliveryLocation(this.buildDeliveryLocation(deliveryPlace, delivery))
                    .setDeliverySlotManagementIdentifier(serviceLevel.getDeliverySlotManagementId())
                    .setDeliveryServiceLevelIdentifier(serviceLevel.getType())
                    .setAvailableToPromiseMinDeliveryDate(DeliveryDate.getMinDate(serviceLevel.getDeliveryDate()).toInstant())
                    .setAvailableToPromiseMaxDeliveryDate(DeliveryDate.getMaxDate(serviceLevel.getDeliveryDate()).toInstant())
                    .setFulfillmentOrderAppointmentDate((serviceLevel.getAppointmentDate() != null) ? serviceLevel.getAppointmentDate().toInstant() : null)
                    .setCustomerDeliveryServiceIdentifier(this.getCarrierServiceCode(serviceLevel))
                    .setDeliveryCategoryTransportType(this.getCarrierType(serviceLevel))
                    .setExtraDeliveryServiceIdentifiers(serviceLevel.getExtraDeliveryServices() != null ? serviceLevel.getExtraDeliveryServices() : List.of())
                    .setShippingLocation(this.buildShippingLocation(shippingPoint))
                    .setInvoicingLocation(this.buildInvoicingLocation(customerOrder, deliveryLineExecutions))
                    .setCustomerOrderCartItems(this.buildCartItems(delivery, lines, customerOrder))
                    .build();
            }).collect(Collectors.toList());
    }

    private InvoicingLocation buildInvoicingLocation(CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        return InvoicingLocation.newBuilder()
            .setInvoicingLocationIdentifier(lineExecutions.get(0).getPayment().getStoreId())
            .setInvoicingLocationType(LocationType.STORE)
            .setBusinessUnitIdentifier(customerOrder.getBuCode())
            .build();
    }

    private ShippingLocation buildShippingLocation(ShippingPoint shippingPoint) {
        if (shippingPoint == null) {
            return null;
        }
        return ShippingLocation.newBuilder()
            .setShippingLocationType(this.mapShippingPointTypeToAvro(shippingPoint.getType()))
            .setShippingLocationIdentifier(shippingPoint.getId())
            .setBusinessUnitIdentifier(shippingPoint.getBu())
            .build();
    }

    private LocationType mapShippingPointTypeToAvro(ShippingPointType type) {
        return switch (type) {
            case STORE -> LocationType.STORE;
            case SUPPLIER -> LocationType.SUPPLIER;
            case WAREHOUSE -> LocationType.WAREHOUSE;
        };
    }

    private String getCarrierServiceCode(ServiceLevel serviceLevel) {
        final var detail = serviceLevel.getDetails();
        if (detail instanceof RelayPoint1PDetails) {
            return ((RelayPoint1PDetails) serviceLevel.getDetails()).getCarrierServiceCode();
        } else if (detail instanceof HomeDelivery1PDetails) {
            return ((HomeDelivery1PDetails) serviceLevel.getDetails()).getCarrierServiceCode();
        }
        return null;
    }

    private String getCarrierType(ServiceLevel serviceLevel) {
        final var detail = serviceLevel.getDetails();
        if (detail instanceof RelayPoint1PDetails) {
            return ((RelayPoint1PDetails) serviceLevel.getDetails()).getCarrierType();
        } else if (detail instanceof HomeDelivery1PDetails) {
            return ((HomeDelivery1PDetails) serviceLevel.getDetails()).getCarrierType();
        }
        return null;
    }

    private ShippingPoint mapShippingPointToAvro(ServiceLevelDetails details, DeliveryPlace deliveryPlace, String buCode) {
        if (details instanceof RelayPoint1PDetails relayPoint1PDetails) {
            return relayPoint1PDetails.getShippingPoint();
        } else if (details instanceof HomeDelivery1PDetails homeDelivery1PDetails) {
            return homeDelivery1PDetails.getShippingPoint();
        } else {
            if (deliveryPlace instanceof StoreDeliveryPlace storeDeliveryPlace) {
                return ShippingPoint.builder()
                    .bu(buCode)
                    .type(ShippingPointType.STORE)
                    .id(storeDeliveryPlace.getStoreCode())
                    .build();
            }
        }
        log.error("No delivery point founded in DST response.");
        return null;
    }

    private List<LockFlagEnum> getLockFlagForShippingPointAndDeliveryMode(ShippingPointType type) {
        return switch (type) {
            case STORE -> List.of(LockFlagEnum.LOCKED_SHIPPING_POINT_ID);
            case SUPPLIER, WAREHOUSE -> List.of(LockFlagEnum.LOCKED_SHIPPING_POINT_TYPE);
        };
    }


    private CustomerDeliveryLocationAvro buildDeliveryLocation(DeliveryPlace deliveryPlace, Delivery delivery) {
        if (deliveryPlace instanceof NoDeliveryPlace) {
            return null;
        } else if (deliveryPlace instanceof StoreDeliveryPlace storeDeliveryPlace) {
            return CustomerDeliveryLocationAvro.newBuilder()
                .setType(this.mapDeliveryType(delivery))
                .setIdentifier(storeDeliveryPlace.getStoreCode())
                .build();
        } else if (deliveryPlace instanceof DeliveryAddress deliveryAddress) {
            return CustomerDeliveryLocationAvro.newBuilder()
                .setType(this.mapDeliveryType(delivery))
                .setIdentifier(deliveryAddress.getId().toString())
                .setCountryCode(deliveryAddress.getCountryCode())
                .setPostalCode(deliveryAddress.getPostalCode())
                .setCityName(deliveryAddress.getCity())
                .build();
        } else if (deliveryPlace instanceof RelayPoint relayPoint) {
            return CustomerDeliveryLocationAvro.newBuilder()
                .setType(this.mapDeliveryType(delivery))
                .setIdentifier(relayPoint.getProvider())
                .setCountryCode(relayPoint.getAddress().getCountryCode())
                .setPartnerCategoryName(relayPoint.getPartnerCategory())
                .setPostalCode(relayPoint.getAddress().getPostalCode())
                .setCityName(relayPoint.getAddress().getCity())
                .build();
        } else {
            log.warn("Unknown delivery place type: {}. send null delivery place to DOR.", deliveryPlace.getClass().getName());
            return null;
        }
    }


    private LocationTypeEnumAvro mapDeliveryType(Delivery delivery) {
        return switch (delivery.getDeliveryMode()) {
            case HOME_DELIVERY, RELAY_POINT_DELIVERY -> LocationTypeEnumAvro.ADDRESS;
            default -> LocationTypeEnumAvro.STORE;
        };
    }

    private List<CustomerOrderCartItemAvro> buildCartItems(com.adeo.sales.customerorder.external.api.client.dst.dto.Delivery delivery, List<LineExecution> lines, CustomerOrder customerOrder) {
        return delivery.getOfferCartItems()
            .stream()
            .filter(offerCartItem -> LineExecution.lineIds(lines).contains(offerCartItem.getId()))
            .map(offerCartItem -> {
                final var lineExecutionOption = LineExecution.getById(lines, offerCartItem.getId());
                final var offerLineOption = customerOrder.getProductOffer().getOfferLineById(offerCartItem.getId());
                if (lineExecutionOption.isEmpty() || offerLineOption.isEmpty()) {
                    log.warn("a line or an offer is not found in fulfillment mapping");
                    return null;
                }
                return CustomerOrderCartItemAvro.newBuilder()
                    .setCustomerOrderCartItemIdentifier(offerCartItem.getId())
                    .setIsTargetOrchestrationRequested(lineExecutionOption.get().getExternalSystem().isTempo())
                    .setFulfillmentOrderInitialQuantity(offerLineOption.get().getInitialOrderedQuantity())
                    .setIsSalesFloorStockIgnored(offerCartItem.isIgnoreStockOnHandleImmediateQuantity())
                    .setProduct(ProductAvro.newBuilder()
                        .setProductAdeoReference(offerLineOption.get().getOffer().getAdeoKey())
                        .setProductBuReference(offerLineOption.get().getOffer().getRefLM())
                        .build())
                    .build();
            })
            .filter(Objects::nonNull)
            .toList();
    }

}
