package com.adeo.sales.customerorder.tempoorchestrator.handler;

public class ApiNames {
    public static final String BOMP = "bomp";
    public static final String DOR = "delivery-orchestrator";
    public static final String PAYMENT_SCHEDULER = "payment-scheduler";
    public static final String TEMPO_PAYMENT_REQUIREMENT_POLICY = "tempo-payment-requirement-policy";
    public static final String TEMPO_ALERTING = "tempo-alerting";
    public static final String TEMPO_COMPOSER = "tempo-composer";
    public static final String PYXIS_ADAPTER = "pyxis-adapter";
    public static final String BACKO = "backo";
    public static final String TOR = "tempo-orchestrator";
    public static final String UCC = "ucc";
    public static final String POSLOG = "poslog";

}
