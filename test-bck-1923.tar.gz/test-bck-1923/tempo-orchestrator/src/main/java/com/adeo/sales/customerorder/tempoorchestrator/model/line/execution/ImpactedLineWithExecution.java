package com.adeo.sales.customerorder.tempoorchestrator.model.line.execution;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@AllArgsConstructor
@Data
@NoArgsConstructor
public class ImpactedLineWithExecution {
    private ImpactedLine line;
    private ImpactedExecution execution;

    public String getExecutionId() {
        return this.execution.getCurrentExecutionId();
    }

    public String getLineId() {
        return this.line.getLineId();
    }

    public static List<ImpactedLine> mapToImpactedLines(List<ImpactedLineWithExecution> impactedLinesWithExecution) {
        return impactedLinesWithExecution.stream().map(ImpactedLineWithExecution::getLine).toList();
    }

    public static List<String> getAllImpactedLineId(List<ImpactedLineWithExecution> impactedLineWithExecutions) {
        return impactedLineWithExecutions.stream().map(ImpactedLineWithExecution::getLineId).toList();
    }
}
