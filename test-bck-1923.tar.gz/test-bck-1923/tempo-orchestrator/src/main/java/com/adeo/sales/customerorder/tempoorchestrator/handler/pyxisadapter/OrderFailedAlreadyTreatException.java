package com.adeo.sales.customerorder.tempoorchestrator.handler.pyxisadapter;

public class OrderFailedAlreadyTreatException extends  RuntimeException{

    public OrderFailedAlreadyTreatException(String customerOrderId) {
        super(String.format("Allocation Or Creation Failed already Treated for order %s ", customerOrderId));
    }
}
