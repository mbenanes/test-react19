package com.adeo.sales.customerorder.tempoorchestrator.repository.impl;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.OwnerRequest;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionActionRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.r2dbc.spi.Result;
import io.r2dbc.spi.Row;
import io.r2dbc.spi.Statement;
import lombok.extern.slf4j.Slf4j;
import org.springframework.r2dbc.core.ConnectionAccessor;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.OwnerRequest.OperatorType.COLLABORATOR;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.OwnerRequest.OperatorType.CUSTOMER;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.OwnerRequest.OperatorType.LDAP;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.OwnerRequest.OperatorType.SYSTEM;

@Slf4j
@Component
public class ExecutionActionPostgresRepository implements ExecutionActionRepository {

    private final ObjectMapper objectMapper;
    private final ConnectionAccessor connectionAccessor;
    private final DatabaseClient databaseClient;

    public ExecutionActionPostgresRepository(
        DatabaseClient databaseClient,
        ObjectMapper objectMapper,
        ConnectionAccessor connectionAccessor
    ) {
        this.objectMapper = objectMapper;
        this.connectionAccessor = connectionAccessor;
        this.databaseClient = databaseClient;
    }

    @Override
    public Mono<Void> upsert(List<ExecutionAction> executionActions) {
        if (executionActions == null || executionActions.isEmpty()) {
            return Mono.empty();
        }
        final var insert =
            "insert into execution_action(id, customer_order_id, bu_code, action_type, last_flag, flags, impacted_executions, created_at, app_source, app_source_request_id, operator_type, identifier)" +
                " values ($1,$2, $3, $4, $5, CAST($6 as jsonb), CAST($7 as jsonb), $8 at time zone 'utc', $9, $10, $11, $12)" +
                " ON CONFLICT (id) DO UPDATE set last_flag = $5, flags = CAST($6 as jsonb), impacted_executions = CAST($7 as jsonb)";

        return this.connectionAccessor.inConnection(it -> {
            final Statement statement = it.createStatement(insert);
            executionActions.forEach(executionAction -> {

                String requestOwnerOperatorType = null;
                String identifier = null;
                if(executionAction.getOwnerRequest() != null) {
                    requestOwnerOperatorType = executionAction.getOwnerRequest().getOperatorType().name();
                    identifier = executionAction.getOwnerRequest().getIdentifier();
                }

                bindNullable(statement, 9, executionAction.getAppSourceRequestId(), String.class);
                bindNullable(statement, 10, requestOwnerOperatorType, String.class);
                bindNullable(statement, 11, identifier, String.class);
                statement.bind(0, executionAction.getRequestId())
                    .bind(1, executionAction.getCustomerOrderId())
                    .bind(2, executionAction.getBuCode())
                    .bind(3, executionAction.getActionType().name())
                    .bind(4, executionAction.getLastFlag().name())
                    .bind(5, serialize(executionAction.getFlags()))
                    .bind(6, serialize(executionAction.getImpactedExecutions()))
                    .bind(7, executionAction.getCreatedAt())
                    .bind(8, executionAction.getAppSource())
                    .add();
            });

            return Flux.from(statement.execute())
                .flatMap(Result::getRowsUpdated)
                .flatMap(numberOfInsertedLines -> {
                    if (numberOfInsertedLines == 0) {
                        return Mono.error(new NoExecutionActionInsertedException());
                    } else {
                        return Mono.just(numberOfInsertedLines);
                    }
                })
                .then();
        });
    }

    @Override
    public Flux<ExecutionAction> getExecutionActionsFromOrder(String customerOrderId, String buCode) {
        var select = "select id, customer_order_id, bu_code, action_type, user_id, ldap, flags, impacted_executions, created_at, app_source, app_source_request_id, operator_type, identifier" +
            " from execution_action" +
            " where customer_order_id = :customerOrderId" +
            " and  bu_code = :buCode" +
            " and last_flag <> 'CANCELED'" +
            " order by created_at desc FOR UPDATE ";

        return this.databaseClient
            .sql(select)
            .bind("customerOrderId", customerOrderId)
            .bind("buCode", buCode)
            .map(this::deserializeExecutionAction)
            .all();
    }

    private ExecutionAction deserializeExecutionAction(Row row) {
        try {

            //deal with deprecated field in database
            String ldap = row.get("ldap", String.class);
            String userId = row.get("user_id", String.class);
            String operatorType = row.get("operator_type", String.class);
            String identifier = Optional.ofNullable(ldap).orElse(userId);

            OwnerRequest.OperatorType operatorTypeEnum = Optional.ofNullable(operatorType)
                .map(OwnerRequest.OperatorType::valueOf)
                .orElseGet(() -> {
                    if (ldap != null && ldap.isEmpty()) {
                        return COLLABORATOR;
                    } else if (userId != null && userId.isEmpty()) {
                        return CUSTOMER;
                    }
                    return SYSTEM;
                });

            if (operatorType != null) {
                identifier = row.get("identifier", String.class);
            }

            return ExecutionAction.builder()
                .requestId(row.get("id", String.class))
                .customerOrderId(row.get("customer_order_id", String.class))
                .buCode(row.get("bu_code", String.class))
                .actionType(ExecutionActionType.valueOf(row.get("action_type", String.class)))
                .createdAt(row.get("created_at", Instant.class))
                .ownerRequest(OwnerRequest.builder()
                    .identifier(identifier)
                    .operatorType(operatorTypeEnum)
                    .build())
                .appSource(row.get("app_source", String.class))
                .appSourceRequestId(row.get("app_source_request_id", String.class))
                .impactedExecutions(deserialize(row.get("impacted_executions", String.class), new TypeReference<>() {}))
                .flags(deserialize(row.get("flags", String.class), Flags.class))
                .build();

        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }

    private void bindNullable(Statement statement, int index, Object value, Class<?> type) {
        if (value != null) {
            statement.bind(index, value);
        } else {
            statement.bindNull(index, type);
        }
    }

    private <T> T deserialize(String json, Class<T> clazz) {
        if (json == null) {
            return null;
        }
        try {
            return objectMapper.readValue(json, clazz);
        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }

    private <T> T deserialize(String json, TypeReference<T> type) {
        if (json == null) {
            return null;
        }
        try {
            return objectMapper.readValue(json, type);
        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }

    private String serialize(final Object object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (Exception exception) {
            throw new JsonSerializeException(exception);
        }
    }

}
