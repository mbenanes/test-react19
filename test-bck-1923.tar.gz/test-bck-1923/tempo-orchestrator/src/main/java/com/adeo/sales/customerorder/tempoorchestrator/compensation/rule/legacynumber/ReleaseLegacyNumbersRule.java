package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.legacynumber;


import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.LegacyACL;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.LegacyNumbersStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_CAPTURED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_CAPTURE_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_ORDER_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PAYMENT_DEPOSIT_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PAYMENT_OWNERSHIP_TRANSFERED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "ReleaseLegacyNumberV2",
    description = "release the legacy number with legacy acl endpoint",
    priority = 1000)
public class ReleaseLegacyNumbersRule {
    private final LegacyACL legacyACL;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.isCustomerOrderMatches(IS_VALIDATED.or(IS_ORDER_CANCELED)) && !this.getLinesWithLegacyNumberToRelease(context).isEmpty();
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var customerOrderId = context.getCustomerOrderId();
        final var buCode = context.getBuCode();
        final var linesNotReleased = this.getLinesWithLegacyNumberToRelease(context);

        return MonoUtil.infoLog("INTERNAL release legacyNumber for lines: {}", LineExecution.joinLineIds(linesNotReleased))
            .then(this.legacyACL.releaseLegacyNumbersV2(linesNotReleased, customerOrderId, buCode)
                .onErrorResume(error -> MonoUtil.errorLog("an error occurs during release legacy number", error))
                .then(Mono.fromRunnable(() -> {
                        linesNotReleased.forEach(line -> {
                            line.getPayment().setLegacyNumbersStatus(LegacyNumbersStatus.RELEASED);
                            line.increaseVersion();
                        });
                    }
                )));
    }

    private List<LineExecution> getLinesWithLegacyNumberToRelease(RuleEngineContext context) {
        final var lines = context.getOrderData().getExistingLineExecutions();
        return lines.stream()
            .filter(IS_1P)
            .filter(line -> line.getPayment().getLegacyNumbersStatus() != LegacyNumbersStatus.RELEASED)
            .filter(
                IS_PAYMENT_OWNERSHIP_TRANSFERED.or
                    (IS_LINE_COMPOSITION_CANCELED.and(HAS_CAPTURED).and(IS_PAYMENT_DEPOSIT_CANCELED)).or
                    (IS_LINE_COMPOSITION_CANCELED.and(not(HAS_CAPTURED)).and(not(IS_CAPTURE_REQUESTED)))
            )
            .collect(Collectors.toList());
    }
}
