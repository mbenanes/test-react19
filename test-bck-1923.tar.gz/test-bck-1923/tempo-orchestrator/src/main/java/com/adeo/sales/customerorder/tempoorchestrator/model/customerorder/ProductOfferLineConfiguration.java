package com.adeo.sales.customerorder.tempoorchestrator.model.customerorder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class ProductOfferLineConfiguration {
    private String configurationId;
}
