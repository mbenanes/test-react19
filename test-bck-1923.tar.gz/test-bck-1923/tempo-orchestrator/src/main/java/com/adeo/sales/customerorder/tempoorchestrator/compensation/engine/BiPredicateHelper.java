package com.adeo.sales.customerorder.tempoorchestrator.compensation.engine;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import org.apache.commons.lang3.BooleanUtils;
import reactor.core.publisher.Mono;

import java.util.function.BiPredicate;

public class BiPredicateHelper {
    private BiPredicateHelper() {
    }

    public static BiPredicate<RuleEngineContext, LineExecution> not(BiPredicate<RuleEngineContext, LineExecution> predicate) {
        return predicate.negate();
    }

    public static Mono<Boolean> and(Mono<Boolean> first, Mono<Boolean> second) {
        return first.flatMap(firstResult -> {
            if (BooleanUtils.isTrue(firstResult)) {
                return second;
            }
            return Mono.just(false);
        });
    }

    public static Mono<Boolean> or(Mono<Boolean> first, Mono<Boolean> second) {
        return first.flatMap(firstResult -> {
            if (BooleanUtils.isTrue(firstResult)) {
                return Mono.just(true);
            }
            return second;
        });
    }
}
