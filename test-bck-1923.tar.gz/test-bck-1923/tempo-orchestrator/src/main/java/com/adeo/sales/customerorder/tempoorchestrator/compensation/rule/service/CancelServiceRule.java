package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.service;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.service.ahs.AhsCommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_DELIVERY_CREATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_CANCEL_SERVICE_IS_THE_NEXT_STEP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_DECREASE_QUANTITY_ACTION_PROCESSING;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "CancelServiceRule",
    description = "Ask to AHS to cancel service",
    priority = 500)
public class CancelServiceRule {

    private final AhsCommandEventService ahsCommandEventService;

    private static final Predicate<ExecutionAction> IS_CANCEL_SERVICE_ACTION_SHOULD_BE_PROCESSED = IS_DECREASE_QUANTITY_ACTION_PROCESSING.and(IS_CANCEL_SERVICE_IS_THE_NEXT_STEP);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneExecutionAction(IS_CANCEL_SERVICE_ACTION_SHOULD_BE_PROCESSED);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.getFirstExecutionActionByPredicate(IS_CANCEL_SERVICE_ACTION_SHOULD_BE_PROCESSED)
            .map(actionToExecute -> {
                List<ImpactedLine> impactedServiceLines = actionToExecute.getAllImpactedLines()
                    .stream()
                    .filter(impactedLine -> impactedLine.isNextStepIsOfType(ImpactedLineStep.Type.CANCEL_SERVICE))
                    .toList();

                List<LineExecution> serviceLines = context.getOrderData()
                    .getLineExecutionsByIds(ImpactedLine.extractLineIds(impactedServiceLines))
                    .stream()
                    .filter(IS_LINE_SERVICE)
                    .filter(HAS_DELIVERY_CREATION_REQUESTED)
                    .toList();

                Set<LineExecution> associatedProducts = serviceLines
                    .stream()
                    .filter(serviceLine -> serviceLine.getConfigurationService() != null && serviceLine.getConfigurationService().getAssociatedLinesId() != null)
                    .flatMap(serviceLine -> serviceLine
                        .getConfigurationService()
                        .getAssociatedLinesId()
                        .stream()
                        .flatMap(lineId -> context.getOrderData().getFirstFindedLineExecutionById(lineId).stream()))
                    .collect(Collectors.toSet());

                List<LineExecution> linesToCancel = Stream.concat(serviceLines.stream(), associatedProducts.stream()).distinct().toList();

                return MonoUtil.infoLog("INTERNAL cancel services for request action id:{}", actionToExecute.getRequestId())
                    .then(this.ahsCommandEventService.sendCustomerOrderCancelledWithInstallation(context.getOrderData().getExistingCustomerOrder(), linesToCancel))
                    .doOnSuccess(unused -> updateStepsAndLines(serviceLines, impactedServiceLines));
            })
            .orElse(Mono.empty())
            .then();
    }

    private static void updateStepsAndLines(List<LineExecution> serviceLines, List<ImpactedLine> impactedServiceLines) {
        serviceLines.forEach(serviceLine -> serviceLine.getDelivery().getFlags().raiseFlagIfNot(CustomerOrderLineDeliveryStatus.ABORT_REQUESTED));
        impactedServiceLines.forEach(impactedLine ->
            impactedLine.getStepOfType(ImpactedLineStep.Type.CANCEL_SERVICE)
                .ifPresent(step -> step.getFlags().raiseFlag(ImpactedLineStep.Status.COMPLETED)));
    }

}
