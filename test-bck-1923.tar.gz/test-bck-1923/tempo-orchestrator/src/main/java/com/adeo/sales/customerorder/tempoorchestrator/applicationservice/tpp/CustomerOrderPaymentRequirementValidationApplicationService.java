package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.CreateOrUpdateCustomerOrderApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderAlreadyExists;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentRequirementValidationInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.Clock;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPaymentRequirements;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.repository.impl.LockPosgresRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.ReactiveTransactionManager;
import org.springframework.transaction.reactive.TransactionalOperator;
import reactor.core.publisher.Mono;

import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentRequirementComplianceReason.PENDING_AMOUNT_NOT_NULL_AND_HIGH_PENDING_SCORE;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentRequirementComplianceReason.REQUESTED_BY_COLLABORATOR_OR_SYSTEM;
import static com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentRequirementComplianceReason.STOCK_RESERVATION_REASONS;
import static com.adeo.sales.customerorder.tempoorchestrator.utils.LockUtils.getIdTrimmedUsedToLock;
import static com.adeo.sales.customerorder.tempoorchestrator.utils.LockUtils.getTransactionDefinition;
import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@Slf4j
@Component
@RequiredArgsConstructor
public class CustomerOrderPaymentRequirementValidationApplicationService {

    private final CreateOrUpdateCustomerOrderApplicationService createOrUpdateCustomerOrderApplicationService;

    private final RuleEngineService ruleEngineService;
    private final LockPosgresRepository lockPosgresRepository;
    private final ReactiveTransactionManager transactionManager;


    public Mono<Void> apply(PaymentRequirementValidationInput input) {
        return this.lockAndGetDataThenUpdate(input)
            .onErrorResume(CustomerOrderNotFound.class, error -> this.initCustomerOrder(input)
                .onErrorResume(
                    CustomerOrderAlreadyExists.class,
                    errorCreation -> this.lockAndGetDataThenUpdate(input)
                ));
    }

    private Mono<Void> lockAndGetDataThenUpdate(PaymentRequirementValidationInput input) {
        long idToLock = getIdTrimmedUsedToLock(input.getCustomerOrderId());
        TransactionalOperator rxtx = TransactionalOperator.create(transactionManager, getTransactionDefinition(this));
        return rxtx.transactional(
            lockPosgresRepository.acquireLocks(idToLock)
                .then(this.ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
                .doOnNext(
                    consumer((customerOrder, lineExecutions, alerts) -> updateLinePaymentRequirements(input, customerOrder, lineExecutions))
                )
                .flatMap(function(this.ruleEngineService.startRuleEngineAndUpdateLines()))
        );
    }

    private static void updateLinePaymentRequirements(PaymentRequirementValidationInput input, CustomerOrder customerOrder, List<LineExecution> lineExecutions) {
        if (customerOrder.getPaymentExecutionPolicy().getVersion() == null) {
            customerOrder.getPaymentExecutionPolicy().setVersion(input.getExecutionPolicyVersion());
        } else if (customerOrder.getPaymentExecutionPolicy().getVersion() < input.getExecutionPolicyVersion()) {
            customerOrder.getPaymentExecutionPolicy().setVersion(input.getExecutionPolicyVersion());
            lineExecutions.forEach(lineExecution -> lineExecution.getPaymentRequirements().setVersionMismatch(false));
        }

        if (customerOrder.isHaveToCheckTppRequirements()
            && !input.getLines().isEmpty()
            && input.getLines().get(0).getConfirmationRequirementCompliance() != null
            && input.getLines().get(0).getConfirmationRequirementCompliance().isCompliant()) {
            customerOrder.setHaveToCheckTppRequirements(false);
        }

        customerOrder.getPaymentExecutionPolicy().setId(input.getExecutionPolicyId());
        final var inputLineById = input.getLines().stream().collect(Collectors.toMap(PaymentRequirementValidationInput.Line::getId, Function.identity()));
        lineExecutions
            .forEach(lineExecution -> {
                final var inputLine = inputLineById.get(lineExecution.getLineId());
                if (inputLine != null) {
                    if (lineExecution.getPayment().getPaymentExecutionSystem() == null) {
                        lineExecution.getPayment().setPaymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.TPP);
                    }
                    lineExecution.increaseVersion();
                    lineExecution.getPaymentRequirements().setVersionMismatch(false);
                    getLineStockReservationComplianceReason(inputLine)
                        .filter(reason -> !REQUESTED_BY_COLLABORATOR_OR_SYSTEM.name().equals(reason))
                        .ifPresent(reason -> lineExecution.getPayment().setIsDelayedPayment(checkIsDelayedPayment(inputLine)));
                    raiseRequirementFlags(inputLine, lineExecution.getPaymentRequirements());
                }
            });
    }

    protected Mono<Void> initCustomerOrder(PaymentRequirementValidationInput input) {
        CustomerOrder customerOrderToCreate = CustomerOrder.builder()
            .id(input.getCustomerOrderId())
            .buCode(input.getBuCode())
            .paymentExecutionPolicy(new Clock(input.getExecutionPolicyId(), input.getExecutionPolicyVersion()))
            .version(1)
            .build();
        List<LineExecution> lines = input.getLines().stream().map(inputLine -> {
            LineExecutionPaymentRequirements lineExecutionPaymentRequirements = new LineExecutionPaymentRequirements();
            raiseRequirementFlags(inputLine, lineExecutionPaymentRequirements);
            Boolean isDelayedPayment = getLineStockReservationComplianceReason(inputLine)
                .filter(reason -> !REQUESTED_BY_COLLABORATOR_OR_SYSTEM.name().equals(reason))
                .map(reason -> checkIsDelayedPayment(inputLine))
                .orElse(null);
            return LineExecution.builder()
                .version(1)
                .lineId(inputLine.getId())
                .customerOrderId(input.getCustomerOrderId())
                .lineType(LineType.OFFER)
                .buCode(input.getBuCode())
                .payment(LineExecutionPayment.builder()
                    .isDelayedPayment(isDelayedPayment)
                    .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.TPP)
                    .build())
                .paymentRequirements(lineExecutionPaymentRequirements)
                .build();
        }).toList();

        long idToLock = getIdTrimmedUsedToLock(input.getCustomerOrderId());
        TransactionalOperator rxtx = TransactionalOperator.create(transactionManager, getTransactionDefinition(this));
        return rxtx.transactional(
                lockPosgresRepository.acquireLocks(idToLock)
                    .then(createOrUpdateCustomerOrderApplicationService.createOrderAndLines(customerOrderToCreate, lines)))
            .then(rxtx.transactional(
                lockPosgresRepository.acquireLocks(idToLock)
                    .then(ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
                    .flatMap(function(this.ruleEngineService.startRuleEngineAndUpdateLines()))
            ));
    }

    private static void raiseRequirementFlags(PaymentRequirementValidationInput.Line inputLine, LineExecutionPaymentRequirements lineExecutionPaymentRequirements) {
        raiseRequirementFlag(lineExecutionPaymentRequirements.getValidationFlags(), inputLine.getValidationRequirementCompliance());
        raiseRequirementFlag(lineExecutionPaymentRequirements.getConfirmationFlags(), inputLine.getConfirmationRequirementCompliance());
        raiseRequirementFlag(lineExecutionPaymentRequirements.getVendorOrderCreationFlags(), inputLine.getVendorOrderCreationRequirementCompliance());
        var stockReservationRequirementCompliance = inputLine.getStockReservationRequirementCompliance();
        var stockReservationReasonOptional = getLineStockReservationComplianceReason(inputLine);
        stockReservationReasonOptional
            .filter(STOCK_RESERVATION_REASONS::contains)
            .ifPresent(reason -> raiseRequirementFlag(lineExecutionPaymentRequirements.getStockReservationFlags(), stockReservationRequirementCompliance));

        raiseRequirementFlag(lineExecutionPaymentRequirements.getSalesValorizationFlags(), inputLine.getSalesValorizationRequirementCompliance());
    }

    private static Optional<String> getLineStockReservationComplianceReason(PaymentRequirementValidationInput.Line inputLine) {
        return inputLine.getStockReservationRequirementCompliance() != null ? Optional.ofNullable(inputLine.getStockReservationRequirementCompliance().getReason()) : Optional.empty();
    }

    private static void raiseRequirementFlag(Flags<RequirementStatus> lineExecutionPaymentRequirements, PaymentRequirementValidationInput.Line.Compliance compliance) {
        if (compliance != null && compliance.getOperationId() != null && compliance.getDate() != null) {
            lineExecutionPaymentRequirements.raiseFlagIfNot(
                compliance.getOperationId(),
                RequirementStatus.getStatusByBoolean(compliance.isCompliant()),
                compliance.getDate().atOffset(ZoneOffset.UTC)
            );
        }
    }


    private static boolean checkIsDelayedPayment(PaymentRequirementValidationInput.Line inputLine) {
        var stockReservationRequirementComplianceOptional = getLineStockReservationComplianceReason(inputLine);
        return stockReservationRequirementComplianceOptional.map(PENDING_AMOUNT_NOT_NULL_AND_HIGH_PENDING_SCORE.name()::equals).orElse(false);
    }

}
