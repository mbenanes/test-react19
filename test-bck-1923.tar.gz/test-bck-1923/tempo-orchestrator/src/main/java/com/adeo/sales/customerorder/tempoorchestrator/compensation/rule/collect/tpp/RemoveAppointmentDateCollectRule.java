package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.collect.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.CustomerOrderCollectService;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECT_APPOINTMENT_DATE_AFTER_DELIVERY_DATE_OR_NOT_EXISTING;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_TPP_COLLECT_IN_PROGRESS;

@RequiredArgsConstructor
@Slf4j
@Component
@Rule(name = "RemoveAppointmentDateCollectRule",
    description = "create an execution action when the new estimated is after the appointment date of all line of collect",
    priority = 1000)
public class RemoveAppointmentDateCollectRule {

    private final CustomerOrderCollectService customerOrderCollectService;
    private final OutgoingNotificationService outgoingNotificationService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.getOrderData().getExistingLinesByExecution()
            .entrySet()
            .stream()
            .anyMatch(lineExecutionsByExecutionEntry -> {
                final List<LineExecution> collectlineExecutionsInProgress = lineExecutionsByExecutionEntry.getValue().stream()
                    .filter(IS_TPP_COLLECT_IN_PROGRESS)
                    .toList();

                return !collectlineExecutionsInProgress.isEmpty() &&
                    collectlineExecutionsInProgress.stream()
                        .noneMatch(IS_COLLECT_APPOINTMENT_DATE_AFTER_DELIVERY_DATE_OR_NOT_EXISTING);
            });
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return Flux.fromIterable(context.getOrderData().getExistingLinesByExecution()
            .values())
            .filter(lineExecutions -> {
                final List<LineExecution> collectlineExecutionsInProgress = lineExecutions.stream()
                    .filter(IS_TPP_COLLECT_IN_PROGRESS)
                    .toList();

                return !collectlineExecutionsInProgress.isEmpty() &&
                    collectlineExecutionsInProgress.stream().noneMatch(IS_COLLECT_APPOINTMENT_DATE_AFTER_DELIVERY_DATE_OR_NOT_EXISTING);
            })
            .flatMap(lineExecutions -> {
                final LineExecution firstCollectLine = lineExecutions.get(0);
                final String customerOrderId = context.getCustomerOrderId();
                final String buCode = context.getBuCode();
                final String collectId = firstCollectLine.getDelivery().getCollect().getCollectId();
                final String storeId = firstCollectLine.getPayment().getStoreId();

                return customerOrderCollectService.cancelCollectAppointment(collectId, customerOrderId, buCode, storeId)
                    .then(outgoingNotificationService.sendCollectForecastedLateNotification(context.getOrderData().getExistingCustomerOrder(), lineExecutions))
                    .doOnSuccess(unused -> lineExecutions.forEach(lineExecution -> lineExecution.getDelivery().getCollect().setAppointmentDate(null)));
            }).then();
    }
}
