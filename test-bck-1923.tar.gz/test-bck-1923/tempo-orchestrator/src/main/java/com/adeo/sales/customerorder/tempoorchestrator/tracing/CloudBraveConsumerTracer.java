package com.adeo.sales.customerorder.tempoorchestrator.tracing;

import brave.Span;
import brave.Tracer;
import brave.Tracing;
import brave.propagation.ExtraFieldPropagation;
import brave.propagation.TraceContext;
import brave.propagation.TraceContextOrSamplingFlags;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.UnaryOperator;

@Component
@Slf4j
public class CloudBraveConsumerTracer implements CloudTracer{

    private final Tracing tracing;
    private final Tracer tracer;
    private final KafkaHeaderGetter kafkaHeaderGetter;

    public CloudBraveConsumerTracer(Tracing tracing, Tracer tracer) {
        this.tracing = tracing;
        this.tracer = tracer;
        this.kafkaHeaderGetter = new KafkaHeaderGetter();
    }

    public TraceContext startSpan(Message message) {
        final TraceContext.Extractor<MessageHeaders> extractor = tracing.propagation().extractor(kafkaHeaderGetter);
        final var extractedHeader = extractor.extract(message.getHeaders());
        final var span = startNewTraceOrUseHeaders(extractedHeader);

        final var recordType = message.getPayload().getClass().getSimpleName();
        final var topic = String.valueOf(message.getHeaders().get("kafka_receivedTopic"));

        span.name("received-message-" + recordType).kind(Span.Kind.CONSUMER).tag("kafka.topic", topic);
        span.remoteServiceName("kafka");
        final var timestamp = tracing.clock(span.context()).currentTimeMicroseconds();
        span.start(timestamp);
        addMetadataOnSpanAnLog(span, "event_topic", topic);
        addMetadataOnSpanAnLog(span, "event_offset", String.valueOf(message.getHeaders().get("kafka_offset")));
        addMetadataOnSpanAnLog(span, "event_partition", String.valueOf(message.getHeaders().get("kafka_receivedPartitionId")));

        tracer.withSpanInScope(span);
        return tracing.currentTraceContext().get();
    }

    private void addMetadataOnSpanAnLog(Span span, String key, String value) {
        span.tag(key, value);
        ExtraFieldPropagation.set(span.context(), key, value);
    }

    public void flagSpanInError(Throwable e) {
        if(tracer != null && tracer.currentSpan() != null ){
            tracer.currentSpan().error(e);
        }
    }

    public void finishSpan() {
        final var span = tracer.currentSpan();
        if(span != null) {
            final var timestamp = tracing.clock(span.context()).currentTimeMicroseconds();
            span.finish(timestamp);
        }
    }

    private Span startNewTraceOrUseHeaders(TraceContextOrSamplingFlags extractedHeader) {
        if (tracer.currentSpan() == null) {
            return tracer.newTrace();
        }
        return tracer.currentSpan();
    }

    public UnaryOperator<Mono<Void>> runInScope(Message message) {
        final var traceContext = this.startSpan(message);

        return mono -> mono
            .doOnError(this::flagSpanInError)
            .doOnTerminate(this::finishSpan)
            .subscriberContext(context -> context.put(TraceContext.class, traceContext));
    }
}
