package com.adeo.sales.customerorder.tempoorchestrator.repository.impl;

import io.r2dbc.spi.Statement;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.r2dbc.core.ConnectionAccessor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;


@Slf4j
@Component
@RequiredArgsConstructor
public class LockPosgresRepository {

    private final ConnectionAccessor connectionAccessor;

    public Mono<Void> acquireLocks(long id) {
        return this.connectionAccessor.inConnection(
            connection -> {
                final Statement statement = connection.createStatement("select pg_advisory_xact_lock(" + id + ")");

                return Mono.when(statement.execute());
            }

        ).then();
    }
}
