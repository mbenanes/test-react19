package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.stockvaluate.tpp;

import com.adeo.featuretoggle.FeatureRepository;
import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.FeatureToggleConfiguration;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.ProductOfferLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.StockValuationStatus;
import com.adeo.sales.customerorder.tempoorchestrator.service.UpdateAvailableActionService;
import com.adeo.sales.customerorder.tempoorchestrator.service.ValuateStockService;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.ValuateStockDto;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.ValuateStockLineDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_NOT_ASKED_STOCK_VALUATION;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECTABLE_DELIVERY_TYPE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_SHIPPED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OWNERSHIP_TRANSFER_REQUIREMENT_COMPLETED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SHIPPED_BY_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_STOCK_VALUATION_SUCCESS;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "AskStockValuationLinesTppRule",
    description = "Ask Stock valuation for SFW when the line is shipped or for SFP when the line is shipped for EXW or when the line is delivered for DDP",
    priority = 1100)
public class AskStockValuationLinesTppRule {
    public static final Predicate<LineExecution> IS_RESERVE_AND_COLLECT_BY_TEMPO = IS_COLLECTABLE_DELIVERY_TYPE.and(IS_EXTERNAL_SYSTEM_TEMPO);
    private static final Predicate<LineExecution> LINE_WITHOUT_STOCK_VALUATION_AND_VALUABLE = HAS_NOT_ASKED_STOCK_VALUATION
        .and(IS_OWNERSHIP_TRANSFER_REQUIREMENT_COMPLETED);
    private static final Predicate<LineExecution> IS_SHIPPED_BY_STORE_BY_TEMPO = IS_SHIPPED_BY_STORE.and(IS_EXTERNAL_SYSTEM_TEMPO);
    public static final Predicate<LineExecution> DELIVERY_LEGACY_NUMBER_IS_NULL = lineExecution -> lineExecution.getDelivery().getDeliveryLegacyNumber() == null;
    public static final Predicate<List<LineExecution>> ONE_LINES_ARE_VALUABLE_WITHOUT_PREVIOUS_VALUATION = lineExecutions -> lineExecutions.stream()
        .anyMatch(LINE_WITHOUT_STOCK_VALUATION_AND_VALUABLE.and(not(IS_SHIPPED_BY_STORE_BY_TEMPO))
            .and(not(IS_RESERVE_AND_COLLECT_BY_TEMPO))
        );
    public static final Predicate<List<LineExecution>> ALL_LINES_ARE_VALUABLE_WITHOUT_SUCCESS = lineExecutions -> lineExecutions.stream().filter(not(IS_RESERVE_AND_COLLECT_BY_TEMPO).and(not(IS_SHIPPED_BY_STORE_BY_TEMPO))).allMatch(not(IS_STOCK_VALUATION_SUCCESS).and(IS_OWNERSHIP_TRANSFER_REQUIREMENT_COMPLETED));

    private final ValuateStockService valuateStockService;
    private final FeatureRepository featureRepository;
    private final UpdateAvailableActionService updateAvailableActionService;

    // check if is a new shipped line and has never valorised before.
    @Condition
    public Mono<Boolean> when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return FeatureToggleConfiguration.isBackoFeatureEnabled(context.getBuCode(), this.featureRepository)
            .map(isFeatureEnabled -> isFeatureEnabled && context.hasAtLeastOneLine(LINE_WITHOUT_STOCK_VALUATION_AND_VALUABLE));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        this.logLineWithoutLegacyOrderNumber(context);

        return Flux.fromIterable(context.getOrderData().getExistingLineExecutions())
            .filter(not(IS_SHIPPED_BY_STORE_BY_TEMPO))
            .filter(lineExecution -> lineExecution.getDelivery().getDeliveryLegacyNumber() != null)
            .groupBy(lineExecution -> lineExecution.getDelivery().getDeliveryLegacyNumber())
            .flatMap(Flux::collectList)
            .filter(ONE_LINES_ARE_VALUABLE_WITHOUT_PREVIOUS_VALUATION.and(ALL_LINES_ARE_VALUABLE_WITHOUT_SUCCESS))
            .flatMap(lineExecutions -> {
                final var firstLine = lineExecutions.get(0);
                log.info("INTERNAL request valuate stock for {} lines: {}, for delivery legacy number {}", firstLine.getDelivery().getDeliveryType(), LineExecution.joinLineIds(lineExecutions), firstLine.getDelivery().getDeliveryLegacyNumber());
                return this.valuateStockService.sendValuateStockRequest(ValuateStockDto.builder()
                        .customerOrderNumber(context.getCustomerOrderId())
                        .buCode(context.getBuCode())
                        .legacyNumber(firstLine.getDelivery().getDeliveryLegacyNumber())
                        .storeCode(firstLine.getPayment().getStoreId())
                        .lines(lineExecutions.stream()
                            .map(lineExecution -> ValuateStockLineDto.builder()
                                .lineId(lineExecution.getLineId())
                                .productCode(context.getOrderData().getOfferLineByLineExecution(lineExecution).map(offerLine -> offerLine.getOffer().getRefLM()).orElse(null))
                                .quantity(context.getOrderData().getOfferLineByLineExecution(lineExecution).map(ProductOfferLine::getQuantity).orElse(null))
                                .build())
                            .collect(Collectors.toList())
                        )
                        .build())
                    .then(Mono.fromRunnable(() -> {
                        lineExecutions.forEach(lineExecution -> {
                            lineExecution.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_REQUESTED);
                            lineExecution.increaseVersion();
                            this.updateAvailableActionService.apply(context.getOrderData().getExistingLineExecutions(), lineExecution, context.getOrderData().getExistingCustomerOrder());
                        });
                    }));
            }).collectList().then();
    }

    private void logLineWithoutLegacyOrderNumber(RuleEngineContext context) {
        final var linesWithoutLegacyOrderNumber = context.getOrderData()
            .getLineExecutionsByPredicate(IS_DELIVERY_SHIPPED.and(IS_LINE_COMPOSITION_VALIDATED).and(DELIVERY_LEGACY_NUMBER_IS_NULL));

        if (!linesWithoutLegacyOrderNumber.isEmpty()) {
            log.warn("try to call backo to perform a stock valuation on shipped lines {} but no delivery legacy number found.", LineExecution.joinLineIds(linesWithoutLegacyOrderNumber));
        }
    }
}
