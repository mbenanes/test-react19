package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input;

import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;

import java.util.List;

public enum DORStatus {
    RESERVATION_VALIDATED,
    RESERVATION_FAILED,
    PREPARATION_FINISHED,
    ALLOCATION_FAILED,
    SHORTED,
    ALLOCATION_VALIDATED,
    PREPARATION_REJECTED,
    RELEASED,
    HANDOVER_STARTED,
    SHIPPED,
    DELIVERED,
    PARTIALLY_DELIVERED,
    CANCELLED,
    UNKNOWN;

    public static final List<DORStatus> CANCEL_STATUS = List.of(PREPARATION_REJECTED, ALLOCATION_FAILED, CANCELLED, SHORTED);
    public static final List<DORStatus> SHIPPED_OR_DELIVERED_STATUS = List.of(SHIPPED, DELIVERED, PARTIALLY_DELIVERED);

    public static DORStatus getEnum(String value) {
        try {
            return valueOf(value);
        } catch (IllegalArgumentException iae) {
            return UNKNOWN;
        }
    }

    public boolean isAllowedToUpdateDeliveryStatus(CustomerOrderLineDeliveryStatus lastStatus) {
        DORStatus inputDORStatus = this;
        if (CustomerOrderLineDeliveryStatus.NOT_CANCELLABLE_STATUS.contains(lastStatus) && CANCEL_STATUS.contains(inputDORStatus)) {
            return false;
        } else if (lastStatus == CustomerOrderLineDeliveryStatus.RECEIVED && inputDORStatus != DELIVERED) {
            return false;
        } else if (lastStatus == CustomerOrderLineDeliveryStatus.SHIPPED && !SHIPPED_OR_DELIVERED_STATUS.contains(inputDORStatus)) {
            return false;
        } else {
            return inputDORStatus != UNKNOWN;
        }
    }
}
