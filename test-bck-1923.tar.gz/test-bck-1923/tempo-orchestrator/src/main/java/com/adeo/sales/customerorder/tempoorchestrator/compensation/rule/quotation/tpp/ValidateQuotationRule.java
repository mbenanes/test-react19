package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.quotation.tpp;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.QuotationDataGetter;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_QUOTATION_VALIDATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_SALES_VALORIZATION_COMPLIANT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_TPP;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "ValidateQuotationRule",
    description = "Call quotation for validation",
    priority = 10)
public class ValidateQuotationRule {

    private final QuotationDataGetter quotationDataGetter;
    public static final Predicate<LineExecution> HAS_QUOTATION_TO_VALIDATE = IS_SALES_VALORIZATION_COMPLIANT
        .and(not(HAS_QUOTATION_VALIDATION_REQUESTED));

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.isCustomerOrderMatches(IS_VALIDATED) &&
            context.hasAtLeastOneLine(HAS_QUOTATION_TO_VALIDATE.and(PAYMENT_ORCHESTRATED_BY_TPP));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        CustomerOrder customerOrder = context.getOrderData().getExistingCustomerOrder();
        return MonoUtil.infoLog("INTERNAL validate quotation {} for order {}", customerOrder.getQuotation().getId(), customerOrder.getId())
            .then(this.quotationDataGetter.applyValidate(customerOrder))
            .doOnSuccess(unused -> context.getOrderData().getExistingLineExecutions().forEach(lineExecution -> lineExecution.getComposition().setQuotationValidationAsked(true)))
            .onErrorResume(throwable -> MonoUtil.errorLog("INTERNAL: Quotation validation failure on order {} fpr reason", customerOrder.getId(), throwable.getMessage()))
            .then();
    }
}
