package com.adeo.sales.customerorder.tempoorchestrator.service.impl;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.ExecutionToUpdate;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.UpdateExecution;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.UserOrLdap;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.service.UpdateExecutionService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@AllArgsConstructor
@Slf4j
@Service
public class UpdateExecutionServiceImpl implements UpdateExecutionService {

    private final EventProducer eventProducer;
    private final TopicsProperties topicsProperties;

    public Mono<Void> sendUpdateExecutionWithDecreaseQuantity(String customerOrderId, String buCode, Map<String, List<LineExecution>> impactedLines, OffsetDateTime dateToSendEvent, String reason, String functionalType){
        if (!impactedLines.isEmpty()) {
            final var updateExecution = this.buildUpdateExecutionWithDecreaseQuantity(customerOrderId, buCode, impactedLines, reason);
            return this.eventProducer.sendEvents(this.topicsProperties.getCommandV1(), customerOrderId, buCode, updateExecution, dateToSendEvent, functionalType);
        }
        return Mono.empty();
    }

    private UpdateExecution buildUpdateExecutionWithDecreaseQuantity(String customerOrderId, String buCode, Map<String, List<LineExecution>> lines, String reason){

        UserOrLdap.Builder userOrLdap = UserOrLdap.newBuilder()
                .setIdentifier("CUSTOMER")
                .setUserType("SYSTEM");

        var executionToUpdates = lines.entrySet().stream()
                .map(entry -> {
                    var executionId = entry.getKey();
                    var lineIds = entry.getValue();
                    List<ImpactedLine> impactedLines = lineIds.stream()
                    .map(line -> ImpactedLine.newBuilder()
                            .setLineId(line.getLineId())
                            .setQuantity(line.getQuantity())
                            .setReason(reason)
                            .build())
                    .collect(Collectors.toList());
                    return ExecutionToUpdate.newBuilder()
                            .setExecutionPlanId(executionId)
                            .setImpactedLines(impactedLines)
                            .build();
                })
                .toList();

        return UpdateExecution.newBuilder()
                .setExecutionToUpdate(executionToUpdates)
                .setBuCode(buCode)
                .setActionType("DECREASE_QUANTITY")
                .setAppSource("TOR")
                .setCustomerOrderId(customerOrderId)
                .setRequestedBy(userOrLdap.build())
                .setRequestedByBuilder(userOrLdap)
                .setRequestSourceId(customerOrderId)
                .build();
    }
}
