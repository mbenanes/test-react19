package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.capture;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.CaptureService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.ARE_ALL_LINES_DELIVERY_ACCEPTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAVE_ALL_LINES_STATUS_TO_ASK_CAPTURE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_BOMP;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.PaymentOperationType.CAPTURE_REQUESTED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Ask3PCapture",
    description = "Ask third party lines capture on bomp subcommands.",
    priority = 1000)
public class Ask3PCaptureRule {
    private static final Predicate<LineExecution> BOMP_LINE_NOT_CANCELED = IS_EXTERNAL_SYSTEM_BOMP
        .and(not(IS_LINE_COMPOSITION_CANCELED))
        .and(PAYMENT_ORCHESTRATED_BY_PSR);
    private static final Predicate<List<LineExecution>> ALL_NOT_CANCELED_LINES_CAN_BE_CAPTURED = ARE_ALL_LINES_DELIVERY_ACCEPTED.and(HAVE_ALL_LINES_STATUS_TO_ASK_CAPTURE);
    private final CaptureService captureService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return !findSubOrdersFilteredWithNonCanceledLines(context).isEmpty();
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return Flux.fromIterable(this.findSubOrdersFilteredWithNonCanceledLines(context))
            .flatMap(customerOrderLines ->
                this.sendCaptureCommand(context.getOrderData().getExistingCustomerOrder(), customerOrderLines)
                    .then(Mono.fromRunnable(() -> customerOrderLines.forEach(lineExecution -> {
                        lineExecution.getPayment().getPaymentExecution().getFlags().raiseFlag(CAPTURE_REQUESTED);
                        lineExecution.increaseVersion();
                    })))
            ).then();
    }

    private Mono<Void> sendCaptureCommand(CustomerOrder customerOrder, List<LineExecution> subOrderLines) {
        return MonoUtil.infoLog("INTERNAL ask to capture Bomp lines {} for the sub order with external id {}", LineExecution.joinLineIds(subOrderLines))
            .then(this.captureService.sendCommandCaptureCustomerOrderLines(customerOrder, subOrderLines));
    }

    private List<List<LineExecution>> findSubOrdersFilteredWithNonCanceledLines(RuleEngineContext context) {
        return context.getOrderData().getLineExecutionsByPredicate(BOMP_LINE_NOT_CANCELED)
            .stream()
            .collect(Collectors.groupingBy(l -> l.getExternalSystem().getId()))
            .values()
            .stream()
            .filter(ALL_NOT_CANCELED_LINES_CAN_BE_CAPTURED)
            .collect(Collectors.toList());
    }
}
