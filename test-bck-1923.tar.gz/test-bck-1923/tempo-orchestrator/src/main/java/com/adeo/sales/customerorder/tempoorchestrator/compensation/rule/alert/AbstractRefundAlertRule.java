package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert;

import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertReason;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationFailedSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.AlertMessageInput;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;

@Slf4j
@RequiredArgsConstructor
public abstract class AbstractRefundAlertRule {

    protected final AlertMessageService alertMessageService;

    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context, List<LineExecution> linesToAlert, AlertReason alertReason) {
        if (linesToAlert.isEmpty()) {
            return MonoUtil.infoLog("All lines with refund or cancel capture already have an alert or 3P lines handle is disabled");
        }

        final var alerts = this.buildAlert(context, linesToAlert, alertReason);

        return Flux.fromIterable(alerts)
            .flatMap(alert -> MonoUtil.infoLog("INTERNAL request alert {} creation for refund failed or delayed lines: {}", alert.getId(), alert.getImpactedLinesIds())
                .then(this.alertMessageService.sendCreateAlertMessage(this.buildAlertMessageInput(context, alert, context.getOrderData().getExistingCustomerOrder())))
            )
            .then(Mono.fromRunnable(() -> context.getAlertData().getExistingAlerts().addAll(alerts)
            ));
    }

    private List<Alert> buildAlert(RuleEngineContext context, List<LineExecution> linesToAlerts, AlertReason alertReason) {
        final var lineOperationByOperationId = linesToAlerts.stream().collect(Collectors.groupingBy(lineExecution -> lineExecution.getPayment().getPaymentExecution().getFlags().getLastFlag().getOperationId()));
        return lineOperationByOperationId.entrySet().stream()
            .map(lineEntry -> {
                final var alertId = UUID.randomUUID();
                final var impactedLineIds = LineExecution.lineIds(lineEntry.getValue());

                final var lineMetadataByLineId = linesToAlerts.stream()
                    .collect(Collectors.toMap(
                        LineExecution::getLineId,
                        line -> AlertSpecificData.LineMetadata.fromOrderAndLine(context.getOrderData().getExistingCustomerOrder(), line)
                    ));

                return Alert.builder()
                    .id(alertId)
                    .specificData(PaymentOperationFailedSpecificData.builder()
                        .reason(alertReason.name())
                        .receivedAt(OffsetDateTime.now())
                        .requestId(alertId.toString())
                        .operationId(lineEntry.getKey())
                        .lineMetadataByLineId(lineMetadataByLineId)
                        .build()
                    )
                    .impactedLinesIds(impactedLineIds)
                    .customerOrderId(context.getCustomerOrderId())
                    .buCode(context.getBuCode())
                    .status(AlertStatus.CREATION_REQUESTED)
                    .build();
            })
            .collect(Collectors.toList());
    }

    private AlertMessageInput buildAlertMessageInput(RuleEngineContext context, Alert alert, CustomerOrder existingCustomerOrder) {
        final var customerOrderLines = alert.getImpactedLinesIds().stream()
            .map(lineId -> context.getOrderData().getFirstFindedLineExecutionById(lineId).orElse(null))
            .filter(Objects::nonNull)
            .collect(Collectors.toList());

        return AlertMessageInput.builder()
            .alert(alert)
            .lineExecutions(customerOrderLines)
            .customerOrder(existingCustomerOrder)
            .build();
    }

}
