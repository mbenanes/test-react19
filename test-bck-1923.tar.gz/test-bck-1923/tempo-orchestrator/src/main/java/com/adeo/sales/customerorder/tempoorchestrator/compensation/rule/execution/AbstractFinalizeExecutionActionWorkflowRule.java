package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.execution;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import reactor.core.publisher.Mono;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationExecutionActionConditions.IS_EXECUTION_ACTION_PROCESSING;

abstract class AbstractFinalizeExecutionActionWorkflowRule {

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.getExecutionActionsByPredicate(IS_EXECUTION_ACTION_PROCESSING)
            .stream().anyMatch(ExecutionAction::executionIsDone);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final boolean executionActionIsTerminated = context.getExecutionActionsByPredicate(IS_EXECUTION_ACTION_PROCESSING)
            .stream().anyMatch(ExecutionAction::executionIsDone);
        if(executionActionIsTerminated) {
            context.getExecutionActionsByPredicate(IS_EXECUTION_ACTION_PROCESSING)
                .forEach(executionAction -> executionAction.getFlags().raiseFlagIfNot(ExecutionActionStatus.COMPLETED));
        }

        return Mono.empty();
    }

}
