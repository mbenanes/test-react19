package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl;

import com.adeo.sales.customerorder.external.api.client.tpp.TppApiClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Slf4j
@RequiredArgsConstructor
@Component
public class RestTppACL implements TppACL {

    private final TppApiClient tppApiClient;

    @Override
    public Mono<Void> checkTppRequirements(String customerOrderId, String tppId, String buCode) {
        return tppApiClient.checkTppRequirements(tppId, customerOrderId, buCode);
    }
}
