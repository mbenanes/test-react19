package com.adeo.sales.customerorder.tempoorchestrator.handler.psr;

import com.adeo.sales.customerorder.paymentscheduler.v2.payment.domainevent.LineRefundFailed;
import com.adeo.sales.customerorder.paymentscheduler.v2.payment.domainevent.PaymentRefundFailed;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.PaymentOperationApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.input.PaymentOperationInput;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationTechnicalStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.util.stream.Collectors;


@RequiredArgsConstructor
@Component
public class PaymentRefundFailedHandler implements EventHandler<PaymentRefundFailed> {
    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final PaymentOperationApplicationService applicationService;

    @Override
    @Transactional(transactionManager = "connectionFactoryTransactionManager")
    public Mono<Void> handle(PaymentRefundFailed event, EventMetaData eventMetaData) {
        final var customerOrderId = event.getState().getVectorClock().getCustomerOrder().getId();
        this.mappedDiagnosticContext.injectEventMinimalBUData(eventMetaData, customerOrderId);
        final var buCode = eventMetaData.getBuCode();

        final var inputLineIdsByOperation = event.getDelta().getLines().stream()
            .filter(lineRefundFailed -> lineRefundFailed.getLineType().equals("OFFER_LINE"))
            .collect(Collectors.groupingBy(LineRefundFailed::getOperationId, Collectors.mapping(LineRefundFailed::getLineId, Collectors.toList())));

        PaymentOperationInput input = PaymentOperationInput.buildInputFromEvent(event.getState().getRefunds(), inputLineIdsByOperation, customerOrderId, buCode, PaymentOperationTechnicalStatus.REJECTED);
        return this.applicationService.apply(input);
    }

    @Override
    public Class<?> getManagedEvent() {
        return PaymentRefundFailed.class;
    }
}
