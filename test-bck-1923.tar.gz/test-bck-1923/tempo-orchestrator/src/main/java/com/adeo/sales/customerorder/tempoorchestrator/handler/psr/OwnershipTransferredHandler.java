package com.adeo.sales.customerorder.tempoorchestrator.handler.psr;

import com.adeo.sales.customerorder.paymentscheduler.v2.payment.domainevent.OwnershipTransferred;
import com.adeo.sales.customerorder.paymentscheduler.v2.payment.domainevent.OwnershipTransferredLine;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.OwnershipTransferredApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.input.OwnershipTransferredInput;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.LinePaymentOperationHistory;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationTechnicalStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;


@RequiredArgsConstructor
@Slf4j
@Component
public class OwnershipTransferredHandler implements EventHandler<OwnershipTransferred> {

    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final OwnershipTransferredApplicationService ownershipTransferredApplicationService;

    @Override
    public Mono<Void> handle(OwnershipTransferred event, EventMetaData metaData) {
        mappedDiagnosticContext.injectEventMinimalBUData(metaData, event.getState().getCustomerOrderId());

        log.info("OwnershipTransferred consumes {} - message id: {}", metaData.getTopic(), metaData.getId().orElse("no id"));

        final var operations = createOwnershipTransferOperations(event, metaData.getBuCode(), event.getState().getCustomerOrderId());

        final var input = OwnershipTransferredInput.builder()
            .operations(operations)
            .lines(buildInputLines(event))
            .buCode(metaData.getBuCode())
            .customerOrderId(event.getState().getCustomerOrderId())
            .build();

        return ownershipTransferredApplicationService.apply(input);
    }

    private List<LinePaymentOperationHistory> createOwnershipTransferOperations(OwnershipTransferred event, String buCode, String customerOrderId) {
        return event.getDelta().getLines()
            .stream()
            .map(line -> LinePaymentOperationHistory.builder()
                .buCode(buCode)
                .operationId(line.getOperationId())
                .operationType(PaymentOperationType.OWNERSHIP_TRANSFER)
                .status(PaymentOperationTechnicalStatus.SUCCEED)
                .lineId(line.getId())
                .customerOrderId(customerOrderId)
                .build()
            ).collect(Collectors.toList());
    }

    private List<String> buildInputLines(OwnershipTransferred event) {
        return event.getDelta().getLines().stream()
            .map(OwnershipTransferredLine::getId)
            .collect(Collectors.toList());
    }

    @Override
    public Class<?> getManagedEvent() {
        return OwnershipTransferred.class;
    }
}
