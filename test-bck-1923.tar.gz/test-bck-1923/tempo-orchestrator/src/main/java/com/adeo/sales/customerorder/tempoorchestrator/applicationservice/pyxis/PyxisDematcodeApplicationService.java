package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.input.DematCodeInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@Slf4j
@RequiredArgsConstructor
@Service
public class PyxisDematcodeApplicationService {
    private final RuleEngineService ruleEngineService;

    public Mono<Void> apply(DematCodeInput input) {
        return ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode())
            .onErrorResume(CustomerOrderNotFound.class, error -> Mono.empty())
            .doOnNext(
                consumer((customerOrder, customerOrderLines, lineExecutions) -> this.setDematCode(customerOrder, input))
            )
            .flatMap(function(ruleEngineService.startRuleEngineAndUpdateLines()));
    }

    private void setDematCode(CustomerOrder customerOrder, DematCodeInput input) {
        customerOrder.setDematCode(input.getDematCode());
    }
}
