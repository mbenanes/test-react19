package com.adeo.sales.customerorder.tempoorchestrator.handler.psr;

import com.adeo.sales.customerorder.paymentscheduler.v2.execution.Execution;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.Line;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.Operation;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.PaymentOperationApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.input.PaymentOperationInput;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationTechnicalStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationType;
import lombok.AllArgsConstructor;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@AllArgsConstructor
public abstract class AbstractCancelOperationHandler {
    protected final MappedDiagnosticContext mappedDiagnosticContext;
    protected final PaymentOperationApplicationService applicationService;

    protected Map<PaymentOperationInput.OperationKey, List<String>> getImpactedLinesByOperationType(Execution execution) {
        return execution.getOperations()
            .stream()
            .collect(Collectors.toMap(
                    operation -> PaymentOperationInput.OperationKey.builder()
                        .type(PaymentOperationType.valueOf(operation.getType()))
                        .status(PaymentOperationTechnicalStatus.mapFromString(operation.getStatus()))
                        .operationId(operation.getId())
                        .build(),
                    operation -> operation.getLines()
                        .stream()
                        .filter(line -> line.getType().equals("OFFER_LINE"))
                        .map(Line::getId).collect(Collectors.toList())
                )
            );
    }

    protected Map<String, List<String>> getImpactedLinesByOperationId(Execution execution) {
        return execution.getOperations()
            .stream()
            .collect(Collectors.toMap(Operation::getId, operation -> operation.getLines()
                .stream()
                .filter(line -> line.getType().equals("OFFER_LINE"))
                .map(Line::getId).collect(Collectors.toList())));
    }

}
