package com.adeo.sales.customerorder.tempoorchestrator.model.line.execution;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.List;

@Builder
@Data
@EqualsAndHashCode
public class RefundResult {

    private BigDecimal rejectedRefundAmount;
    private List<String> adjustmentsId;
}
