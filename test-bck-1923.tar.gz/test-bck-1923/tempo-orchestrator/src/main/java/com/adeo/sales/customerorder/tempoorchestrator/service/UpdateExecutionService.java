package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

public interface UpdateExecutionService {
    Mono<Void> sendUpdateExecutionWithDecreaseQuantity(String customerOrderId, String buCode, Map<String, List<LineExecution>> impactedLines, OffsetDateTime dateToSendEvent, String reason, String functionalType);
}
