package com.adeo.sales.customerorder.tempoorchestrator.model.customerorder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.time.OffsetDateTime;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerOrderMetadata {
    private UserIdentifier createdBy;
    private UserIdentifier lastModifiedBy;
    private OffsetDateTime createdAt;
    private OffsetDateTime lastModifiedAt;
    private OffsetDateTime firstValidatedAt;
    private OffsetDateTime validatedAt;
    private UserIdentifier validationAskedBy;


    @JsonIgnore
    public Instant getCreationDate() {
        if (this.firstValidatedAt != null) {
            return this.firstValidatedAt.toInstant();
        } else if (this.createdAt != null) {
            return this.createdAt.toInstant();
        }
        return null;
    }

    @Builder
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class UserIdentifier {
        private String reference;
        private String type;
    }
}
