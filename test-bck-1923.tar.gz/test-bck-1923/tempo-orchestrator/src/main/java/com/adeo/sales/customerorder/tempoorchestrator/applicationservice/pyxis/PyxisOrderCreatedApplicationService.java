package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.input.PyxisOrderInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.CREATED;
import static reactor.function.TupleUtils.consumer;
import static reactor.function.TupleUtils.function;

@Slf4j
@RequiredArgsConstructor
@Service
public class PyxisOrderCreatedApplicationService {
    private final RuleEngineService ruleEngineService;

    public Mono<Void> apply(PyxisOrderInput input) {
        return ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode())
            .doOnNext(
                consumer((customerOrder, lineExecutions) -> this.setLegacyNumber(lineExecutions, input))
            )
            .flatMap(function(ruleEngineService.startRuleEngineAndUpdateLines()));
    }

    private void setLegacyNumber(List<LineExecution> lineExecutions, PyxisOrderInput input) {
        lineExecutions.stream()
            .filter(lineExecution -> input.getLineIds().contains(lineExecution.getLineId()))
            .forEach(lineExecution -> {
                lineExecution.getDelivery().getFlags().raiseFlag(CREATED);
                if (lineExecution.getExternalSystem() != null) {
                    final ExternalSystem externalSystem = lineExecution.getExternalSystem();
                    externalSystem.setName(ExternalSystem.SystemName.PYXIS);
                } else {
                    lineExecution.setExternalSystem(ExternalSystem.builder()
                        .origin(ExternalSystem.SystemName.PYXIS)
                        .name(ExternalSystem.SystemName.PYXIS)
                        .build());
                }
                lineExecution.fillExternalReferenceFieldsFromDelivery(input.getStoreCode(), input.getPyxisOrderNumber());

            });
    }
}
