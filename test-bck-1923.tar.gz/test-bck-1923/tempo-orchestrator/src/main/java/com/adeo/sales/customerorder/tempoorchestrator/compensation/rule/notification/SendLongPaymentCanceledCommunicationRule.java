package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_PAYMENT_REJECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_A_DELAYED_PAYMENT_MEAN;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_ORDER_CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_IN_STORE;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_PLACE_TYPE_ONLINE;
import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.NotificationStatus.NOTIFICATION_REQUESTED;
import static java.util.function.Predicate.not;

@Component
@Slf4j
@AllArgsConstructor
@Rule(name = "SendLongPaymentCanceledCommunicationRule",
    description = "Send customer order long payment canceled notification to customer (long payment).",
    priority = 1000)
public class SendLongPaymentCanceledCommunicationRule {

    private final OutgoingNotificationService notificationService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var mailIsNotAlreadySent = context.getOrderData().getExistingCustomerOrder().getLongPaymentCanceledNotificationStatus() == null;

        return mailIsNotAlreadySent &&
            context.hasAtLeastOneLine(HAS_PAYMENT_REJECTED.and(IS_A_DELAYED_PAYMENT_MEAN)) &&
            context.isCustomerOrderMatches(IS_PLACE_TYPE_ONLINE.and(IS_ORDER_CANCELED));
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return MonoUtil.infoLog("INTERNAL send notification long payment canceled for order {}", context.getOrderData().getExistingCustomerOrder().getId())
            .then(notificationService.sendLongPaymentCanceledNotification(context.getOrderData().getExistingCustomerOrder()))
            .then(Mono.fromRunnable(() -> {
                context.getOrderData().getExistingCustomerOrder().setLongPaymentCanceledNotificationStatus(NOTIFICATION_REQUESTED);
                context.getOrderData().getExistingLineExecutions().forEach(LineExecution::increaseVersion);
            }));
    }


}
