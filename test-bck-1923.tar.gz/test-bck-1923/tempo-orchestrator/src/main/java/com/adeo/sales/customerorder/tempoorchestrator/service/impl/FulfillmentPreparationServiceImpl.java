package com.adeo.sales.customerorder.tempoorchestrator.service.impl;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.service.FullfillmentPreparationService;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sis.dor.avro.business.fulfillmentorder.CustomerOrderCartItemAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.FulfillmentOrderAnticipatedPreparationAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.FulfillmentOrderPreparationAvro;
import com.adeo.sis.dor.avro.business.fulfillmentorder.ProductAvro;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class FulfillmentPreparationServiceImpl implements FullfillmentPreparationService {
    private final EventProducer eventProducer;
    private final TopicsProperties properties;

    @Override
    public Mono<Void> createOrderPreparation(List<LineExecution> lines, CustomerOrder customerOrder) {
        if (lines.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask to prepare the customer order on the 1P orchestrator system: {}", LineExecution.joinLineIds(lines));

        return Mono.just(FulfillmentOrderPreparationAvro.newBuilder()
            .setCustomerOrderIdentifier(customerOrder.getId())
            .setBusinessUnitIdentifier(customerOrder.getBuCode())
            .setCustomerOrderCartItems(this.buildCartItems(lines, customerOrder))
            .build()
        ).flatMap(orderPreparationRequest ->
            this.eventProducer.sendEvents(this.properties.getCreateDeliveryV2(customerOrder.getBuCode()), customerOrder.getId(), customerOrder.getBuCode(), orderPreparationRequest)
        );
    }

    @Override
    public Mono<Void> createOrderAnticipatedPreparation(List<LineExecution> lines, CustomerOrder customerOrder) {
        if (lines.isEmpty()) {
            return Mono.empty();
        }

        log.info("INTERNAL ask to force prepare the customer order on the 1P orchestrator system: {}", LineExecution.joinLineIds(lines));

        return Mono.just(FulfillmentOrderAnticipatedPreparationAvro.newBuilder()
            .setCustomerOrderIdentifier(customerOrder.getId())
            .setBusinessUnitIdentifier(customerOrder.getBuCode())
            .setCustomerOrderCartItems(this.buildCartItems(lines, customerOrder))
            .build()
        ).flatMap(orderAnticipatedPreparationRequest ->
            this.eventProducer.sendEvents(this.properties.getCreateDeliveryV2(customerOrder.getBuCode()), customerOrder.getId(), customerOrder.getBuCode(), orderAnticipatedPreparationRequest)
        );

    }

    private List<CustomerOrderCartItemAvro> buildCartItems(List<LineExecution> lines, CustomerOrder customerOrder) {
        return lines.stream()
            .map(offerCartItem -> {
                final var lineExecutionOption = LineExecution.getById(lines, offerCartItem.getLineId());
                final var offerLineOption = customerOrder.getProductOffer().getOfferLineById(offerCartItem.getLineId());
                if (lineExecutionOption.isEmpty() || offerLineOption.isEmpty()) {
                    log.warn("a line or an offer is not found in fulfillment mapping");
                    return null;
                }
                return CustomerOrderCartItemAvro.newBuilder()
                    .setCustomerOrderCartItemIdentifier(offerCartItem.getLineId())
                    .setIsTargetOrchestrationRequested(lineExecutionOption.get().getExternalSystem().isTempo())
                    .setFulfillmentOrderInitialQuantity(offerLineOption.get().getInitialOrderedQuantity())
                    .setProduct(ProductAvro.newBuilder()
                        .setProductAdeoReference(offerLineOption.get().getOffer().getAdeoKey())
                        .setProductBuReference(offerLineOption.get().getOffer().getRefLM())
                        .build())
                    .build();
            })
            .filter(Objects::nonNull)
            .collect(Collectors.toList());
    }
}
