package com.adeo.sales.customerorder.tempoorchestrator.handler.poslog;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.poslog.PosLogSalesApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.poslog.input.SoldOrderInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.poslog.input.SoldReference;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.handler.poslog.dto.PosLogOperation;
import com.adeo.sales.customerorder.tempoorchestrator.handler.poslog.mapper.POSLogRootMapper;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.nrf_arts.ixretail.namespace.avro.POSLogRoot;
import org.nrf_arts.ixretail.namespace.avro.RetailTransactionDomainSpecific;
import org.springframework.stereotype.Component;
import org.springframework.transaction.ReactiveTransactionManager;
import org.springframework.transaction.reactive.TransactionalOperator;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext.BU_CODE_KEY;
import static com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext.CUSTOMER_ID_KEY;
import static com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext.POSLOG_TRANSACTION_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext.SOURCE_TYPE_EVENT_VALUE;
import static com.adeo.sales.customerorder.tempoorchestrator.utils.LockUtils.getTransactionDefinition;

@Slf4j
@Component
@RequiredArgsConstructor
public class POSLogRootHandler implements EventHandler<POSLogRoot> {

    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final ReactiveTransactionManager transactionManager;

    private final PosLogSalesApplicationService posLogSalesApplicationService;

    @Override
    public Mono<Void> handle(POSLogRoot event, EventMetaData metaData) {
        final var buCode = getBuCode(event);
        final var transactionID = event.getTransaction().getTransactionID();
        this.mappedDiagnosticContext.enrichCurrentSpan(BU_CODE_KEY, buCode);
        this.mappedDiagnosticContext.enrichCurrentSpan(POSLOG_TRANSACTION_ID, transactionID);
        this.mappedDiagnosticContext.enrichCurrentSpan(SOURCE_TYPE_EVENT_VALUE, "POSLogRoot");
        log.info("INTERNAL receive postlog for transactionID {}", transactionID);

        if (this.isPosLogEligible(event)) {
            final var rxtx = TransactionalOperator.create(transactionManager, getTransactionDefinition(this));

            return Flux.fromIterable(POSLogRootMapper.toPosLogOperations(event))
                .collect(Collectors.groupingBy(PosLogOperation::getCustomerOrderId))
                .flatMapIterable(stringListMap -> stringListMap.entrySet())
                .doOnNext(paymentOperationByOrder -> this.mappedDiagnosticContext.enrichCurrentSpan(CUSTOMER_ID_KEY, paymentOperationByOrder.getKey()))
                .flatMap(paymentOperationByOrder ->
                    posLogSalesApplicationService.apply(buildSoldOrderInput(paymentOperationByOrder.getValue(), paymentOperationByOrder.getKey(), buCode))
                ).then()
                .transform(rxtx::transactional);
        }

        log.info("INTERNAL the POSLog is not eligible");
        return Mono.empty();
    }

    private String getBuCode(POSLogRoot event) {
        final var buIdentifier = event.getTransaction().getAdeoBusinessUnitIdentifier();
        if (buIdentifier == null) {
            throw new IllegalArgumentException("can not find the bu code on the POSLog event");
        }
        return StringUtils.leftPad(buIdentifier, 3, "0");
    }

    private boolean isPosLogEligible(POSLogRoot event) {
        final var transaction = event.getTransaction();
        final var retailTransaction = transaction.getRetailTransaction();
        final var isRealPoslog = !Boolean.TRUE.equals(transaction.getTrainingModeFlag$1());
        if (!isRealPoslog) {
            log.info("INTERNAL POSLog event is ignored because it is a training POSLog.");
        }
        final var isTransactionStatusIsFinished = "Finished".equals(retailTransaction.getTransactionStatus$1());
        if (!isTransactionStatusIsFinished) {
            log.info("INTERNAL POSLog event is ignored because the transaction status is not Finished.");
        }
        final var hasAtLeastOneTempoLine = this.hasAtLeastOneTempoLine(retailTransaction);
        if (!hasAtLeastOneTempoLine) {
            log.info("INTERNAL POSLog event is ignored because there is no tempo lines.");
        }
        final var hasBeenDoneOnStore = !"380".equals(transaction.getAdeoOperationalUnit().getID());
        if (!hasBeenDoneOnStore) {
            log.info("INTERNAL POSLog event is ignored because the related store is web (380).");
        }
        return isRealPoslog && isTransactionStatusIsFinished && hasAtLeastOneTempoLine && hasBeenDoneOnStore;
    }

    private boolean hasAtLeastOneTempoLine(RetailTransactionDomainSpecific retailTransaction) {
        return retailTransaction.getLineItem()
            .stream()
            .filter(line -> line.getAdeoExternalLink() != null)
            .anyMatch(line -> line.getAdeoExternalLink()
                .stream()
                .anyMatch(adeoExternalLink -> "tempo-id".equals(adeoExternalLink.getTypeCode())));
    }

    private SoldOrderInput buildSoldOrderInput(List<PosLogOperation> posLogOperations, String customerOrderId, String buCode) {
        return SoldOrderInput.builder()
            .customerOrderId(customerOrderId)
            .buCode(buCode)
            .references(posLogOperations.stream()
                .flatMap(posLogOperation -> posLogOperation.getSales().stream()
                    .map(posLogSale -> SoldReference.builder()
                        .reference(posLogSale.getReflm())
                        .referenceType(posLogSale.getType())
                        .quantity(posLogSale.getQuantity())
                        .build())
                ).toList())
            .build();
    }

    @Override
    public Class<?> getManagedEvent() {
        return POSLogRoot.class;
    }
}
