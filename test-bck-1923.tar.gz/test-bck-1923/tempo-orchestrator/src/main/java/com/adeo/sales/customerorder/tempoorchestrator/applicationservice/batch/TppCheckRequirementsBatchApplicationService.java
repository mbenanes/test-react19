package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.batch;

import com.adeo.sales.customerorder.external.api.client.exception.HttpFunctionalException;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.TppACL;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderRepository;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.ReactiveTransactionManager;
import org.springframework.transaction.reactive.TransactionalOperator;
import reactor.core.publisher.Mono;

import static com.adeo.sales.customerorder.tempoorchestrator.utils.LockUtils.getTransactionDefinition;

@Component
@RequiredArgsConstructor
@Slf4j
public class TppCheckRequirementsBatchApplicationService {

    private final CustomerOrderRepository customerOrderRepository;
    private final ReactiveTransactionManager transactionManager;
    private final TppACL tppACL;

    public Mono<Void> apply() {
        return customerOrderRepository.getTppRequirementToCheckCustomerOrder()
            .switchIfEmpty(MonoUtil.infoLog("INTERNAL 0 line executions requires tpp check "))
            .filter(customerOrder -> customerOrder.getPaymentExecutionPolicy() != null && customerOrder.getPaymentExecutionPolicy().getId() != null)
            .flatMap(customerOrder ->
                tppACL.checkTppRequirements(customerOrder.getId(), customerOrder.getPaymentExecutionPolicy().getId(), customerOrder.getBuCode())
                    .doOnSuccess(unused -> customerOrder.setHaveToCheckTppRequirements(false))
                    .onErrorResume(throwable -> {
                        if (throwable instanceof HttpFunctionalException) {
                            customerOrder.setHaveToCheckTppRequirements(false);
                            return MonoUtil.warnLog("INTERNAL: Functional error on tpp call for order {}", customerOrder.getId());
                        } else {
                            return MonoUtil.errorLog("INTERNAL: Technical error on tpp call for order {}", customerOrder.getId());
                        }
                    })
                    .thenReturn(customerOrder))
            .flatMap(customerOrderRepository::updateCustomerOrder)
            .then()
            .transform(TransactionalOperator.create(transactionManager, getTransactionDefinition(this))::transactional);
    }

}
