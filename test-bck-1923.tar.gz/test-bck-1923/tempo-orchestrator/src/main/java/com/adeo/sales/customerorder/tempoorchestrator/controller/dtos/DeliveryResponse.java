package com.adeo.sales.customerorder.tempoorchestrator.controller.dtos;

import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus;
import lombok.Builder;
import lombok.Data;

import java.time.OffsetDateTime;

@Builder
@Data
public class DeliveryResponse {
    private DeliveryDateResponseAndRequest initialPromiseDate;
    private DeliveryDateResponseAndRequest customerKnownDeliveryDate;
    private DeliveryDateResponseAndRequest estimatedDeliveryDate;
    private CollectStatus collectStatus;
    private OffsetDateTime collectAppointmentDate;
    private String collectId;
    private OffsetDateTime lastModifiedCollectStatusDate;

    private ShippingPoint shippingPoint;


    public enum  ShippingPoint {

        STORE,
        WAREHOUSE,
        SUPPLIER;
    }
}
