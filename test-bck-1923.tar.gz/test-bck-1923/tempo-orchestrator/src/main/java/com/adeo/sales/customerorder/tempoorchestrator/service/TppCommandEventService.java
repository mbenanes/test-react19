package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.handler.ApiNames;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import com.adeo.sales.tpp.avro.command.PaymentAdjustmentActionExecutionCreationRequest;
import com.adeo.sales.tpp.avro.command.PaymentRequirementActionExecutionCreationRequest;
import com.adeo.sales.tpp.avro.command.model.PaymentRequirementActionExecutionItem;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class TppCommandEventService {
    private final TopicsProperties topicsProperties;
    private final EventProducer eventProducer;

    public Mono<String> sendActionTypeRequirement(CustomerOrder customerOrder, String executionPlanId, List<LineExecution> lineExecutions, Instant statusDate, ActionType actionType) {
        String operationId = UUID.randomUUID().toString();
        PaymentRequirementActionExecutionCreationRequest event = PaymentRequirementActionExecutionCreationRequest.newBuilder()
            .setCustomerOrderId(customerOrder.getId())
            .setBuId(customerOrder.getBuCode())
            .setPaymentRequirementActionType(actionType.name())
            .setStatusDate(statusDate)
            .setCustomerOrderExecutionPlanId(executionPlanId)
            .setCustomerOrderPaymentExecutionPolicyVersion(customerOrder.getPaymentExecutionPolicy().getVersion())
            .setPaymentRequirementActionExecutionOperationSource(ApiNames.TOR)
            .setPaymentRequirementActionExecutionOperationSourceId(operationId)
            .setPaymentRequirementActionExecution(lineExecutions.stream()
                .map(line -> PaymentRequirementActionExecutionItem.newBuilder()
                    .setCustomerOrderCartItemId(line.getLineId())
                    .setQuantity(line.getQuantity())
                    .build())
                .toList())
            .build();
        return this.eventProducer.sendEvents(this.topicsProperties.getTppCommandEvent(), customerOrder.getId(), customerOrder.getBuCode(), event)
            .thenReturn(operationId);
    }

    public Mono<String> sendUnexecActionTypeRequirement(CustomerOrder customerOrder, String executionPlanId, List<ImpactedLine> lines, Instant statusDate, ActionType actionType) {
        String operationId = UUID.randomUUID().toString();
        PaymentRequirementActionExecutionCreationRequest event = PaymentRequirementActionExecutionCreationRequest.newBuilder()
            .setCustomerOrderId(customerOrder.getId())
            .setBuId(customerOrder.getBuCode())
            .setPaymentRequirementActionType(actionType.name())
            .setStatusDate(statusDate)
            .setCustomerOrderExecutionPlanId(executionPlanId)
            .setCustomerOrderPaymentExecutionPolicyVersion(customerOrder.getPaymentExecutionPolicy().getVersion())
            .setPaymentRequirementActionExecutionOperationSource(ApiNames.TOR)
            .setPaymentRequirementActionExecutionOperationSourceId(operationId)
            .setPaymentRequirementActionExecution(lines.stream()
                .map(line -> PaymentRequirementActionExecutionItem.newBuilder()
                    .setCustomerOrderCartItemId(line.getLineId())
                    .setQuantity(line.getQuantity().negate())
                    .build())
                .toList())
            .build();
        return this.eventProducer.sendEvents(this.topicsProperties.getTppCommandEvent(), customerOrder.getId(), customerOrder.getBuCode(), event)
            .thenReturn(operationId);
    }

    public Mono<String> sendPaymentAdjustmentActionExecutionCreationRequest(CustomerOrder customerOrder, List<ImpactedLine> lines) {

        final var paymentAdjustmentActionIds = lines.stream()
            .map(ImpactedLine::getPaymentAdjustmentActionId)
            .filter(paymentAdjustmentActionId -> !StringUtils.isEmpty(paymentAdjustmentActionId))
            .collect(Collectors.toSet());

        if (CollectionUtils.isEmpty(paymentAdjustmentActionIds)) {
            return MonoUtil.warnLog("Unable to send PaymentAdjustmentActionExecutionCreationRequest because PaymentAdjustmentActionIds for lines {} are null or empty", ImpactedLine.extractLineIds(lines));
        }

        String operationId = UUID.randomUUID().toString();
        PaymentAdjustmentActionExecutionCreationRequest event = PaymentAdjustmentActionExecutionCreationRequest.newBuilder()
            .setCustomerOrderId(customerOrder.getId())
            .setBuId(customerOrder.getBuCode())
            .setStatusDate(Instant.now())
            .setCustomerOrderPaymentExecutionPolicyVersion(customerOrder.getPaymentExecutionPolicy().getVersion())
            .setPaymentAdjustmentActionExecutionOperationSource(ApiNames.TOR)
            .setPaymentAdjustmentActionExecutionOperationSourceId(operationId)
            .setPaymentAdjustmentActionId(paymentAdjustmentActionIds.stream().toList())
            .build();

        return this.eventProducer.sendEvents(this.topicsProperties.getTppCommandEvent(), customerOrder.getId(), customerOrder.getBuCode(), event)
            .thenReturn(operationId);
    }
}
