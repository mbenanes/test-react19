package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.collect;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.service.PostponedEventService;
import com.adeo.sales.customerorder.tempoorchestrator.service.impl.OutcomingNotificationServiceImpl;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECT_APPOINTMENT_DATE_UPDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_COLLECT_EXPECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_EXTERNAL_SYSTEM_TEMPO;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_LINE_COMPOSITION_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_RESERVE_AND_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.PAYMENT_ORCHESTRATED_BY_PSR;

@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "UpdateCollectAppointmentDate",
    description = "update the appointment date when tor received a new appointmentDate",
    priority = 20)
public class UpdateCollectAppointmentDateRule {

    private final PostponedEventService postponedEventService;
    private final OutgoingNotificationService notificationService;

    private static final Predicate<LineExecution> LINES_TO_UPDATE_APPOINTMENT_DATE =
        IS_1P
            .and(IS_OFFER)
            .and(IS_EXTERNAL_SYSTEM_TEMPO)
            .and(IS_LINE_COMPOSITION_VALIDATED)
            .and(IS_COLLECT_EXPECTED)
            .and(IS_RESERVE_AND_COLLECT)
            .and(IS_COLLECT_APPOINTMENT_DATE_UPDATED)
            .and(PAYMENT_ORCHESTRATED_BY_PSR);

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(LINES_TO_UPDATE_APPOINTMENT_DATE) &&
            context.isCustomerOrderMatches(IS_VALIDATED);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var linesToUpdate = context.getOrderData().getLineExecutionsByPredicate(LINES_TO_UPDATE_APPOINTMENT_DATE);
        final var disableReminderHoursBeforeMono = this.postponedEventService.markEventAsNotToSend(context.getCustomerOrderId(), OutcomingNotificationServiceImpl.NotificationType.APPOINTMENT_REMINDER_HOURS_BEFORE.getTemplateType());
        final var disableReminderDayBeforeMono = this.postponedEventService.markEventAsNotToSend(context.getCustomerOrderId(), OutcomingNotificationServiceImpl.NotificationType.APPOINTMENT_REMINDER_DAY_BEFORE.getTemplateType());
        final var disableExpiredPostponedMono = this.postponedEventService.markEventAsNotToSend(context.getCustomerOrderId(), OutcomingNotificationServiceImpl.NotificationType.PICKUP_APPOINTMENT_EXPIRED.getTemplateType());
        final var sendPickupInStoreAppointmentUpdatingNotificationMono = this.notificationService.sendPickupInStoreAppointmentUpdatingNotification(context.getOrderData().getExistingCustomerOrder(), linesToUpdate);
        return MonoUtil.infoLog("INTERNAL update collect appointment date for lines: {}", LineExecution.joinLineIds(linesToUpdate))
            .then(Mono.zip(disableReminderHoursBeforeMono, disableReminderDayBeforeMono, disableExpiredPostponedMono, sendPickupInStoreAppointmentUpdatingNotificationMono))
            .then(Mono.fromRunnable(() -> this.updateLineExecutions(linesToUpdate)));
    }

    private void updateLineExecutions(List<LineExecution> linesToUpdate) {
        linesToUpdate.forEach(lineExecution -> {
            lineExecution.getDelivery().getCollect().setAppointmentReminderNotificationStatus(null);
            lineExecution.getDelivery().getCollect().setAppointmentExpiredNotificationStatus(null);
            lineExecution.getDelivery().getCollect().setAppointDateUpdated(false);
            lineExecution.increaseVersion();
        });
    }
}
