package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification;

import com.adeo.sales.customerorder.ruleengine.annotation.Action;
import com.adeo.sales.customerorder.ruleengine.annotation.Condition;
import com.adeo.sales.customerorder.ruleengine.annotation.Fact;
import com.adeo.sales.customerorder.ruleengine.annotation.Rule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertReason;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.CommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.utils.MonoUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner.CONTEXT_FACT_NAME;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationAlertsConditions.hasAnAlert;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.HAS_DELIVERY_DATE_UPDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_1P;

/**
 * To know if a new delivery date is available, the rule use the field `newDeliveryDate`.
 * If the newDeliveryDate != deliveryDate:
 * - we send a message to DOR
 * - we update the deliveryDate field
 * To avoid to have ugly extra useless field on database the newDeliveryDate is set to null when the message is sent to DOR.
 */
@Component
@Slf4j
@RequiredArgsConstructor
@Rule(name = "Inform1PDeliveryDateUpdated",
    description = "Inform delivery system that a new delivery date is available.",
    priority = 900)
public class Inform1PDeliveryDateUpdatedRule {
    private static final Predicate<LineExecution> LINE_1P_WITH_DELIVERY_DATE_UPDATED = IS_1P.and(HAS_DELIVERY_DATE_UPDATED);
    private static final List<String> alertReasonToSendUpdateAvailableToPromise = List.of(AlertReason.LATE.name());

    private final CommandEventService commandEventService;

    @Condition
    public boolean when(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        return context.hasAtLeastOneLine(LINE_1P_WITH_DELIVERY_DATE_UPDATED);
    }

    @Action
    public Mono<Void> then(@Fact(CONTEXT_FACT_NAME) RuleEngineContext context) {
        final var linesWithDeliveryDateUpdated = context.getOrderData().getExistingLineExecutions().stream()
            .filter(LINE_1P_WITH_DELIVERY_DATE_UPDATED)
            .collect(Collectors.partitioningBy(line -> hasAnAlert(context, line, alertReasonToSendUpdateAvailableToPromise)));
        final var linesWithAlert = linesWithDeliveryDateUpdated.get(Boolean.TRUE);
        final var linesWithoutAlert = linesWithDeliveryDateUpdated.get(Boolean.FALSE);

        linesWithoutAlert.forEach(this::updateLinesDeliveryDate);

        if (linesWithAlert.isEmpty()) {
            return MonoUtil.infoLog("INTERNAL there are no line with delivery date update and late alert. Don't Inform 1P system that delivery date is updated.");
        }
        return MonoUtil.infoLog("INTERNAL update delivery date for 1P lines: {}", LineExecution.joinLineIds(linesWithAlert))
            .then(this.commandEventService.sendUpdateDeliveryDate(linesWithAlert, context.getOrderData().getExistingCustomerOrder()))
            .then(Mono.fromRunnable(() -> {
                linesWithAlert.forEach(this::updateLinesDeliveryDate);
            }));
    }

    private void updateLinesDeliveryDate(LineExecution line) {
        line.getDelivery().setCustomerKnownDeliveryDate(line.getDelivery().getNewDeliveryDate());
        line.getDelivery().setNewDeliveryDate(null);
        line.increaseVersion();
    }

}
