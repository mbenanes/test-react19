package com.adeo.sales.customerorder.tempoorchestrator.configuration;

import com.adeo.sales.customerorder.tempoorchestrator.handler.EventHandler;
import com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaData;
import com.adeo.sales.customerorder.tempoorchestrator.metric.EventKafkaMetrics;
import com.adeo.sales.customerorder.tempoorchestrator.repository.exception.NoCurrentSpanException;
import com.adeo.sales.customerorder.tempoorchestrator.repository.impl.PostgresEventIdempotenceVerifier;
import com.adeo.sales.customerorder.tempoorchestrator.service.BindingLifecycleControl;
import com.adeo.sales.customerorder.tempoorchestrator.tracing.CloudTracer;
import io.r2dbc.spi.R2dbcNonTransientResourceException;
import io.vavr.collection.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.AvroRuntimeException;
import org.apache.avro.generic.GenericRecord;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.BeanCreationNotAllowedException;
import org.springframework.cloud.stream.config.ListenerContainerCustomizer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.ResolvableType;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.kafka.listener.AbstractMessageListenerContainer;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.transaction.CannotCreateTransactionException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.pool.PoolShutdownException;
import reactor.util.context.Context;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.RejectedExecutionException;
import java.util.function.Function;

@Configuration
@Slf4j
public class FunctionDispatcher {

    private final ApplicationContext context;
    private final EventKafkaMetrics eventKafkaMetrics;
    private final PostgresEventIdempotenceVerifier postgresEventIdempotenceVerifier;
    private final CloudTracer collectedCloudTracer;
    private final BindingLifecycleControl bindingLifecycleControl;
    private final Environment environment;
    private static final List<String> EVENT_ID_KEYS = List.of("id", "msgId");


    @Bean
    public ListenerContainerCustomizer<AbstractMessageListenerContainer<?, ?>> customizer() {
        return (container, destinationName, group) -> container.getContainerProperties().setClientId(destinationName + "." + group);
    }

    @Bean
    public Function<Flux<Message<Object>>, Mono<Void>> dispatchConsumerFromTempoComposerEvent() {
        return flux -> flux.flatMap(getMessageMonoFunction())
            .then();
    }

    public FunctionDispatcher(ApplicationContext context, EventKafkaMetrics eventKafkaMetrics, PostgresEventIdempotenceVerifier postgresEventIdempotenceVerifier, CloudTracer collectedCloudTracer, BindingLifecycleControl bindingLifecycleControl, Environment environment) {
        this.context = context;
        this.eventKafkaMetrics = eventKafkaMetrics;
        this.postgresEventIdempotenceVerifier = postgresEventIdempotenceVerifier;
        this.collectedCloudTracer = collectedCloudTracer;
        this.bindingLifecycleControl = bindingLifecycleControl;
        this.environment = environment;
    }

    @SuppressWarnings("rawtypes")
    @NotNull
    private Function<Message<Object>, Mono<?>> getMessageMonoFunction() {
        return message -> {
            Acknowledgment acknowledgment = message.getHeaders().get(KafkaHeaders.ACKNOWLEDGMENT, Acknowledgment.class);
            var beanNames = context.getBeanNamesForType(ResolvableType.forClassWithGenerics(EventHandler.class, message.getPayload().getClass()));

            var toIgnored = mustIgnoreEvent(message);

            if (beanNames.length > 0 && !toIgnored) {
                var bean = (EventHandler) context.getBean(beanNames[0]);

                return Mono.defer(() -> executeAndManageHandler(message, bean))
                    .doOnSubscribe(subscription -> log.info("INTERNAL start of treatment of message {} from topic {}", ((GenericRecord) message.getPayload()).getClass().getSimpleName(), message.getHeaders().get("kafka_receivedTopic")))
                    .doOnCancel(() ->
                        log.error("The mono for the record {} and event type {} has been canceled. The message is not acknowledged", recordToString(message), message.getPayload().getClass().getSimpleName())
                    )
                    .doOnSuccess(o -> {
                        {
                            log.info("INTERNAL end of treatment of message {}", message.getPayload().getClass().getSimpleName());
                            ackMessage(acknowledgment);
                        }
                    })
                    .doOnError(t -> this.logHandlerError(bean, message, (Throwable) t))
                    .onErrorResume(t -> {
                        ackMessageIfNecessary(t, acknowledgment, message);
                        this.logHandlerError(bean, message, (Throwable) t);
                        return Mono.empty();
                    });

            }
            ackMessage(acknowledgment);
            return Mono.empty();
        };
    }

    private boolean mustIgnoreEvent(Message<Object> message) {
        var toIgnored = false;
        if(environment.acceptsProfiles(Profiles.of("!prod"))) {
                final Optional<String> xTagValues = getHeader(message.getHeaders(), "x-tags");
                if(xTagValues.isPresent() ) {
                    return  Stream.of(xTagValues.get().split(";"))
                        .exists("ignored-by-tor"::equals);
                }
        }
        return toIgnored;
    }

    private void ackMessageIfNecessary(Object t, Acknowledgment acknowledgment, final Message<Object> message) {
        if (acknowledgment != null && (t instanceof DataAccessResourceFailureException || t instanceof R2dbcNonTransientResourceException || t instanceof CannotCreateTransactionException || t instanceof PoolShutdownException || t instanceof BeanCreationNotAllowedException || t instanceof RejectedExecutionException || t instanceof IllegalStateException || t instanceof NoCurrentSpanException) ) {
            final String messageMetadataInformation = recordToString(message);
            log.error("Acknowledgment not provided due to unavailable database or application is shutting down for {} ", messageMetadataInformation);
            bindingLifecycleControl.stoppedAndRestartConsumerAfterDuration("dispatchConsumerFromTempoComposerEvent-in-0");
        } else {
            ackMessage(acknowledgment);
        }
    }

    private static void ackMessage(Acknowledgment acknowledgment) {
        if(acknowledgment != null) {
            acknowledgment.acknowledge();
        }
    }


    @SuppressWarnings("unchecked")
    private Mono<Void> executeAndManageHandler(Message<Object> message, EventHandler<GenericRecord> bean) {
        final EventMetaData eventMetaData = new EventMetaData(getEventId(message), message);
        return bean.handle((GenericRecord) message.getPayload(), eventMetaData)
            .transform(this.collectedCloudTracer.runInScope(message))
            .transform(this.eventKafkaMetrics.addExecutionMetrics(message))
            .transform(this.postgresEventIdempotenceVerifier.stopIfEventAlreadyApplied(getEventId(message), message))
            .contextWrite(Context.of(EventMetaData.class, eventMetaData));

    }

    private String recordToString(final Message<Object> message) {
        return "[topic: " + message.getHeaders().get("kafka_receivedTopic") + ", offset: " + message.getHeaders().get("kafka_offset") + ", partition: " + message.getHeaders().get("kafka_receivedPartitionId") + "]";
    }

    @SuppressWarnings("rawtypes")
    private String getEventId(final Message message) {
        return EVENT_ID_KEYS.stream()
            .map(key -> getEventIdByKey(message, key))
            .filter(Objects::nonNull)
            .findFirst()
            .orElse(null);
    }

    private void logHandlerError(
        final EventHandler<? super GenericRecord> handler,
        final Message<Object> message,
        final Throwable error
    ) {
        log.error("error while processing the message of type {} {} with handler {}",
            message.getPayload().getClass().getSimpleName(),
            recordToString(message),
            handler.getClass().getSimpleName(),
            error
        );
    }

    @SuppressWarnings("rawtypes")
    private String getEventIdByKey(final Message message, String idKey) {
        try {
            final GenericRecord payload = (GenericRecord) message.getPayload();
            if(payload.get(idKey) != null) {
                return ((GenericRecord) message.getPayload()).get(idKey).toString();
            } else {
                return getValueFromHeaders(message.getHeaders(), idKey);
            }
        } catch (AvroRuntimeException ex) {
            return getValueFromHeaders(message.getHeaders(), idKey);
        }
    }

    private String getValueFromHeaders(final MessageHeaders headers, String idKey) {
            return  headers.get(idKey) != null ?  headers.get(idKey).toString() : null;
    }

    public Optional<String> getHeader(final MessageHeaders headers, String idKey) {
        return Optional.ofNullable(headers)
            .flatMap(messageHeaders -> Optional.ofNullable(messageHeaders.get(idKey)))
            .filter(byte[].class::isInstance)
            .map(header -> new String((byte[]) header));
    }

}
