\connect postgres

CREATE SCHEMA IF NOT EXISTS tempoorchestrator;
