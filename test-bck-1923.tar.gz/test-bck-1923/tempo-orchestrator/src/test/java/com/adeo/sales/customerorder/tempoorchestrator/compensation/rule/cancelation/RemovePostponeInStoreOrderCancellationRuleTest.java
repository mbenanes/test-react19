package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.cancelation;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.PaymentStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.service.PostponedEventService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.OffsetDateTime;
import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.PostponedEventStatus.POSTPONED_NOT_SENT;
import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.PostponedEventStatus.POSTPONED_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus.VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType.RESERVE_AND_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.service.CustomerOrderService.POSTPONE_CANCELLATION_FUNCTIONAL_TYPE;
import static com.adeo.sales.customerorder.tempoorchestrator.service.CustomerOrderService.POSTPONE_SELF_SERVICE_CANCELLATION_FUNCTIONAL_TYPE;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class RemovePostponeInStoreOrderCancellationRuleTest {

    private RemovePostponeInStoreOrderCancellationRule rule;

    @Mock
    private PostponedEventService postponedEventService;

    @BeforeEach
    void setUp() {
        rule = new RemovePostponeInStoreOrderCancellationRule(postponedEventService);
    }

    @Test
    void shouldAskToRemovePostponedEventWhenIsValidationAndConfirmationRequirementCompliant() {
        // Given
        final RuleEngineContext givenContext = getRuleEngineContext(RequirementStatus.COMPLIANT.name(), false);

        when(postponedEventService.postponedEventExistForOrderAndFunctionalType(any(), any())).thenReturn(Mono.just(true));
        when(postponedEventService.markEventAsNotToSend(any(), any())).thenReturn(Mono.empty());

        // When
        boolean result = rule.when(givenContext);

        // Then
        assertThat(result).isTrue();
        StepVerifier.create(rule.then(givenContext))
            .verifyComplete();

        verify(postponedEventService, times(2)).postponedEventExistForOrderAndFunctionalType(any(), any());
        verify(postponedEventService, times(2)).markEventAsNotToSend(any(), any());
        assertThat(givenContext.getOrderData().getExistingCustomerOrder().getAutoCancellation()).isEqualTo(POSTPONED_NOT_SENT);

        assertThat(rule.when(givenContext)).isFalse();
    }

    @Test
    void shouldAskToRemovePostponedEventWhenIsPaymentOwnershipTransfered() {
        // Given
        final RuleEngineContext givenContext = getRuleEngineContext(RequirementStatus.NOT_COMPLIANT.name(), true);

        when(postponedEventService.postponedEventExistForOrderAndFunctionalType(any(), any())).thenReturn(Mono.just(true));
        when(postponedEventService.markEventAsNotToSend(any(), any())).thenReturn(Mono.empty());

        // When
        boolean result = rule.when(givenContext);

        // Then
        assertThat(result).isTrue();
        StepVerifier.create(rule.then(givenContext))
            .verifyComplete();

        verify(postponedEventService, times(2)).postponedEventExistForOrderAndFunctionalType(any(), any());
        verify(postponedEventService, times(2)).markEventAsNotToSend(any(), any());
        assertThat(givenContext.getOrderData().getExistingCustomerOrder().getAutoCancellation()).isEqualTo(POSTPONED_NOT_SENT);

        assertThat(rule.when(givenContext)).isFalse();
    }

    @Test
    void shouldAskToRemovePostponedEventWhenIsValidationAndConfirmationRequirementCompliantWhenOneTaskExisting() {
        // Given
        final RuleEngineContext givenContext = getRuleEngineContext(RequirementStatus.COMPLIANT.name(), false);

        when(postponedEventService.postponedEventExistForOrderAndFunctionalType(any(), eq(POSTPONE_CANCELLATION_FUNCTIONAL_TYPE))).thenReturn(Mono.just(true));
        when(postponedEventService.postponedEventExistForOrderAndFunctionalType(any(), eq(POSTPONE_SELF_SERVICE_CANCELLATION_FUNCTIONAL_TYPE))).thenReturn(Mono.just(false));
        when(postponedEventService.markEventAsNotToSend(any(), any())).thenReturn(Mono.empty());

        // When
        boolean result = rule.when(givenContext);

        // Then
        assertThat(result).isTrue();
        StepVerifier.create(rule.then(givenContext))
            .verifyComplete();

        verify(postponedEventService, times(2)).postponedEventExistForOrderAndFunctionalType(any(), any());
        verify(postponedEventService, times(1)).markEventAsNotToSend(any(), any());
        assertThat(givenContext.getOrderData().getExistingCustomerOrder().getAutoCancellation()).isEqualTo(POSTPONED_NOT_SENT);

        assertThat(rule.when(givenContext)).isFalse();
    }

    private static RuleEngineContext getRuleEngineContext(String requirementStatus, boolean isOwnerShipTransfer) {
        RuleEngineContext givenContext = new RuleEngineContext();

        var givenLineExecution = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getPaymentRequirements().setValidationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), requirementStatus, null)));
        givenLineExecution.getPaymentRequirements().setConfirmationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), requirementStatus, null)));

        if(isOwnerShipTransfer)  givenLineExecution.getPayment().getFlags().raiseFlag(PaymentStatus.OWNERSHIP_TRANSFERRED);

        givenLineExecution.getPayment().setIsDelayedPayment(false);
        givenContext.setOrderData(OrderData.builder()
            .existingCustomerOrder(CustomerOrder.builder()
                .status(CustomerOrderStatus.VALIDATED)
                .autoCancellation(POSTPONED_REQUESTED)
                .orderPlaceType(CustomerOrderPlaceType.IN_STORE)
                .build())
            .existingLineExecutions(List.of(givenLineExecution))
            .build());
        return givenContext;
    }

}
