package com.adeo.sales.customerorder.tempoorchestrator.model;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.FixedDeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.RangeDeliveryDate;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class DeliveryDataTest {

    @Test
    public void durationBetween_usingTwoFixedDate() {
        final var date1 = new FixedDeliveryDate(OffsetDateTime.of(2021, 10, 10, 10, 10, 10, 10, ZoneOffset.UTC));
        final var date2 = new FixedDeliveryDate(OffsetDateTime.of(2021, 10, 10, 12, 10, 10, 10, ZoneOffset.UTC));

        final var result = date1.durationBetween(date2);

        assertEquals(Duration.ofHours(2), result);
    }

    @Test
    public void durationBetween_usingFixedAndRangeDate() {
        final var date1 = new FixedDeliveryDate(OffsetDateTime.of(2021, 10, 10, 10, 10, 10, 10, ZoneOffset.UTC));
        final var date2 = new RangeDeliveryDate(
            OffsetDateTime.of(2021, 10, 10, 10, 10, 10, 10, ZoneOffset.UTC),
            OffsetDateTime.of(2021, 10, 10, 10, 10, 11, 10, ZoneOffset.UTC)
        );

        final var result = date1.durationBetween(date2);

        assertEquals(Duration.ofSeconds(1), result);
    }

    @Test
    public void durationBetween_usingRangeDate() {
        final var date1 = new RangeDeliveryDate(
            OffsetDateTime.of(2021, 10, 10, 10, 10, 10, 10, ZoneOffset.UTC),
            OffsetDateTime.of(2021, 11, 10, 10, 10, 10, 10, ZoneOffset.UTC)
        );
        final var date2 = new RangeDeliveryDate(
            OffsetDateTime.of(2021, 10, 10, 10, 10, 10, 10, ZoneOffset.UTC),
            OffsetDateTime.of(2021, 12, 10, 10, 10, 10, 10, ZoneOffset.UTC)
        );

        final var result = date1.durationBetween(date2);

        assertEquals(Duration.ofDays(30), result);
    }
}
