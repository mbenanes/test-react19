package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.READ_ADJUSTMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.SEND_CANCELLATION_BY_VENDOR_NOTIFICATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.SEND_PAYMENT_REFUSED_NOTIFICATION;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateActionExecutionFromLines;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateContext;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.initializeSteps;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SendPaymentRefusedNotificationRuleTppTest {
    private SendPaymentRefusedNotificationRuleTpp rule;

    @Mock
    private OutgoingNotificationService outgoingNotificationService;


    @BeforeEach
    void setUp() {
        rule = new SendPaymentRefusedNotificationRuleTpp(outgoingNotificationService);
    }

    @Test
    void shouldSendNotificationRefusedPaymentIfDecreaseQuantityExecutionIsProcessing() {

        RuleEngineContext context = generateActionExecutionContext();

        assertThat(rule.when(context)).isTrue();
        MonoMock<Void> sendNotificationCall = MonoMock.empty();
        when(outgoingNotificationService.sendPaymentRefusedNotification(any(CustomerOrder.class))).thenReturn(sendNotificationCall);

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        verify(outgoingNotificationService).sendPaymentRefusedNotification(any(CustomerOrder.class));
        sendNotificationCall.expectHasBeenSubscribed();

        ExecutionAction executionAction = context.getOrderData().getExecutionActions().get(0);
        String thirdPartyExecutionID = context.getOrderData().getExistingLineExecutions().stream().filter(line -> line.getDelivery().getDeliveryType() == DeliveryType.THIRD_PARTY).findFirst().get().getExecutionId();
        assertThat(executionAction.getImpactedExecutionByExecutionId(thirdPartyExecutionID).get().getImpactedLines().get(0).getStepOfType(SEND_PAYMENT_REFUSED_NOTIFICATION).stream().anyMatch(step -> step.getFlags().lastFlagIs(ImpactedLineStep.Status.COMPLETED))).isTrue();

        assertThat(rule.when(context)).isFalse();
    }

    private RuleEngineContext generateActionExecutionContext() {
        LineExecution thirdPartyLine1 = generateALine(true, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);
        LineExecution thirdPartyLine2 = generateALine(true, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);

        String vendorId = UUID.randomUUID().toString();
        thirdPartyLine1.getExternalSystem().setId(vendorId);
        thirdPartyLine2.getExternalSystem().setId(vendorId);

        RuleEngineContext context = generateContext(List.of(thirdPartyLine1, thirdPartyLine2));

        ExecutionAction executionAction = generateActionExecutionFromLines(context.getCustomerOrderId(), List.of(thirdPartyLine1, thirdPartyLine2), ExecutionActionType.DECREASE_QUANTITY);

        ImpactedExecution impactedExecution3P = executionAction.getImpactedExecutionByExecutionId(thirdPartyLine1.getExecutionId()).get();

        initializeSteps(impactedExecution3P, List.of(DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP, EXECUTE_ADJUSTMENT_TPP, SEND_PAYMENT_REFUSED_NOTIFICATION), List.of(DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP, EXECUTE_ADJUSTMENT_TPP));

        executionAction.getFlags().raiseFlag(ExecutionActionStatus.PROCESSING);

        context.getOrderData().setExecutionActions(List.of(executionAction));
        return context;
    }
}
