package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.execution;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import org.assertj.core.api.AssertionsForClassTypes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus.EXPECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionReasonEnum.CANCELLATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionReasonEnum.REMAINING_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateActionExecutionFromLines;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateContext;
import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;


@ExtendWith(MockitoExtension.class)
class InitializeExecutionActionWorkflowRuleStartTest {

    private InitializeExecutionActionWorkflowRuleStart rule;

    @BeforeEach
    void setUp() {
        rule = new InitializeExecutionActionWorkflowRuleStart();
    }

    @Test
    void shouldInitializeDecreaseQuantityWorkflowOnUnpaidOrder() {
        RuleEngineContext context = generateActionExecutionContextForDecreaseQuantity(false);

        LineExecution sfwLine1 = context.getOrderData().getExistingLineExecutions().get(0);
        LineExecution sfpLine1 = context.getOrderData().getExistingLineExecutions().get(2);
        LineExecution orderAndCollectLine = context.getOrderData().getExistingLineExecutions().get(3);
        LineExecution thirdPartyLine1 = context.getOrderData().getExistingLineExecutions().get(4);
        LineExecution thirdPartyLine2 = context.getOrderData().getExistingLineExecutions().get(5);
        thirdPartyLine2.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.PREPARATION_REQUESTED);

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        ExecutionAction executionAction = context.getOrderData().getExecutionActions().get(0);
        assertThat(executionAction.getFlags().lastFlagIs(ExecutionActionStatus.PROCESSING)).isTrue();

        ImpactedExecution impactedExecutionSfw = executionAction.getImpactedExecutionByExecutionId(sfwLine1.getExecutionId()).get();
        impactedExecutionSfw.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(4);
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP).stream().anyMatch(step -> step.getPosition() == 2 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getPosition() == 3 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
            });

        ImpactedExecution impactedExecutionSfp = executionAction.getImpactedExecutionByExecutionId(sfpLine1.getExecutionId()).get();
        impactedExecutionSfp.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(3);
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getPosition() == 2 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
            }
        );

        ImpactedExecution impactedExecutionOrderAndCollect = executionAction.getImpactedExecutionByExecutionId(orderAndCollectLine.getExecutionId()).get();
        impactedExecutionOrderAndCollect.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(4);
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP).stream().anyMatch(step -> step.getPosition() == 2 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getPosition() == 3 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
            }
        );

        ImpactedExecution impactedExecutionThirdParty = executionAction.getImpactedExecutionByExecutionId(thirdPartyLine1.getExecutionId()).get();
        impactedExecutionThirdParty.getImpactedLines().forEach(
            impactedLine -> {
                if (impactedLine.getLineId().equals(thirdPartyLine1.getLineId())) {
                    assertThat(impactedLine.getSteps()).hasSize(3);
                    assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.ABORT_DELIVERY_3P).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                } else {
                    assertThat(impactedLine.getSteps()).hasSize(2);
                    assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.ABORT_DELIVERY_3P).isEmpty()).isTrue();
                }
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SEND_CANCELLATION_BY_VENDOR_NOTIFICATION).stream().anyMatch(step -> step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
            }
        );
    }

    @Test
    void shouldInitializeDecreaseQuantityWorkflow() {
        RuleEngineContext context = generateActionExecutionContextForDecreaseQuantity(true);

        LineExecution sfwLine1 = context.getOrderData().getExistingLineExecutions().get(0);
        LineExecution sfpLine1 = context.getOrderData().getExistingLineExecutions().get(2);
        LineExecution orderAndCollectLine = context.getOrderData().getExistingLineExecutions().get(3);
        LineExecution thirdPartyLine1 = context.getOrderData().getExistingLineExecutions().get(4);
        LineExecution thirdPartyLine2 = context.getOrderData().getExistingLineExecutions().get(5);
        thirdPartyLine2.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.REJECTED);

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        ExecutionAction executionAction = context.getOrderData().getExecutionActions().get(0);
        assertThat(executionAction.getFlags().lastFlagIs(ExecutionActionStatus.PROCESSING)).isTrue();

        ImpactedExecution impactedExecutionSfw = executionAction.getImpactedExecutionByExecutionId(sfwLine1.getExecutionId()).get();
        impactedExecutionSfw.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(6);
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP).stream().anyMatch(step -> step.getPosition() == 2 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getPosition() == 3 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.READ_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getPosition() == 4 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getPosition() == 5 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SEND_CANCELLATION_NOTIFICATION).stream().anyMatch(step -> step.getPosition() == 6 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
            });

        ImpactedExecution impactedExecutionSfp = executionAction.getImpactedExecutionByExecutionId(sfpLine1.getExecutionId()).get();
        impactedExecutionSfp.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(5);
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getPosition() == 2 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.READ_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getPosition() == 3 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getPosition() == 4 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SEND_CANCELLATION_NOTIFICATION).stream().anyMatch(step -> step.getPosition() == 5 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
            }
        );

        ImpactedExecution impactedExecutionOrderAndCollect = executionAction.getImpactedExecutionByExecutionId(orderAndCollectLine.getExecutionId()).get();
        impactedExecutionOrderAndCollect.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(6);
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP).stream().anyMatch(step -> step.getPosition() == 2 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getPosition() == 3 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.READ_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getPosition() == 4 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getPosition() == 5 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SEND_CANCELLATION_NOTIFICATION).stream().anyMatch(step -> step.getPosition() == 6 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
            }
        );

        ImpactedExecution impactedExecutionThirdParty = executionAction.getImpactedExecutionByExecutionId(thirdPartyLine1.getExecutionId()).get();
        impactedExecutionThirdParty.getImpactedLines().forEach(
            impactedLine -> {
                if (impactedLine.getLineId().equals(thirdPartyLine1.getLineId())) {
                    assertThat(impactedLine.getSteps()).hasSize(5);
                    assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.ABORT_DELIVERY_3P).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                } else {
                    assertThat(impactedLine.getSteps()).hasSize(4);
                    assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.ABORT_DELIVERY_3P).isEmpty()).isTrue();
                }
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.READ_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SEND_CANCELLATION_BY_VENDOR_NOTIFICATION).stream().anyMatch(step -> step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
            }
        );
    }

    @Test
    void shouldInitializeDecreaseQuantityWorkflowTriggeredByTOAWhenCollectIsREJECTED() {
        RuleEngineContext context = generateActionExecutionContextForDecreaseQuantity(true);

        LineExecution orderAndCollectLine = context.getOrderData().getExistingLineExecutions().get(3);
        orderAndCollectLine.getDelivery().getCollect().getFlags().raiseFlag(UUID.randomUUID().toString(), CollectStatus.REQUESTED);
        orderAndCollectLine.getDelivery().getCollect().setGlobalCollectStatus(CollectStatus.REJECTED);
        ExecutionAction executionAction = context.getOrderData().getExecutionActions().get(0);
        executionAction.setAppSource("TOA");

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();


        assertThat(executionAction.getFlags().lastFlagIs(ExecutionActionStatus.PROCESSING)).isTrue();

        ImpactedExecution impactedExecutionOrderAndCollect = executionAction.getImpactedExecutionByExecutionId(orderAndCollectLine.getExecutionId()).get();
        impactedExecutionOrderAndCollect.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(6);
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT).isPresent()).isFalse();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP).stream().anyMatch(step -> step.getPosition() == 2 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getPosition() == 3 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.READ_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getPosition() == 4 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getPosition() == 5 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SEND_CANCELLATION_NOTIFICATION).stream().anyMatch(step -> step.getPosition() == 6 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
            }
        );

    }

    @Test
    void shouldInitializeDecreaseQuantityWorkflowTriggeredByCoc() {
        RuleEngineContext context = generateActionExecutionContextForDecreaseQuantity(true);

        LineExecution orderAndCollectLine = context.getOrderData().getExistingLineExecutions().get(3);
        orderAndCollectLine.getDelivery().getCollect().getFlags().raiseFlag(UUID.randomUUID().toString(), EXPECTED);
        ExecutionAction executionAction = context.getOrderData().getExecutionActions().get(0);
        executionAction.setAppSource("COC");

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();


        assertThat(executionAction.getFlags().lastFlagIs(ExecutionActionStatus.PROCESSING)).isTrue();

        ImpactedExecution impactedExecutionOrderAndCollect = executionAction.getImpactedExecutionByExecutionId(orderAndCollectLine.getExecutionId()).get();
        impactedExecutionOrderAndCollect.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(6);
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && !step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP).stream().anyMatch(step -> step.getPosition() == 2 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getPosition() == 3 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.READ_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getPosition() == 4 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getPosition() == 5 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SEND_CANCELLATION_NOTIFICATION).stream().anyMatch(step -> step.getPosition() == 6 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
            }
        );

    }

    @Test
    void shouldInitializeDecreaseQuantityWorkflowInStore() {
        RuleEngineContext context = generateActionExecutionContextForDecreaseQuantity(true);
        context.getOrderData().getExistingCustomerOrder().setOrderPlaceType(CustomerOrderPlaceType.IN_STORE);

        LineExecution sfwLine1 = context.getOrderData().getExistingLineExecutions().get(0);
        LineExecution sfpLine1 = context.getOrderData().getExistingLineExecutions().get(2);
        LineExecution orderAndCollectLine = context.getOrderData().getExistingLineExecutions().get(3);

        orderAndCollectLine.getDelivery().getCollect().getFlags().raiseFlag(UUID.randomUUID().toString(), EXPECTED);

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        ExecutionAction executionAction = context.getOrderData().getExecutionActions().get(0);
        assertThat(executionAction.getFlags().lastFlagIs(ExecutionActionStatus.PROCESSING)).isTrue();

        ImpactedExecution impactedExecutionSfw = executionAction.getImpactedExecutionByExecutionId(sfwLine1.getExecutionId()).get();
        impactedExecutionSfw.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(4);
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP).stream().anyMatch(step -> step.getPosition() == 2 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getPosition() == 3 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.READ_ADJUSTMENT_TPP)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SEND_CANCELLATION_NOTIFICATION).isEmpty()).isTrue();
            });

        ImpactedExecution impactedExecutionSfp = executionAction.getImpactedExecutionByExecutionId(sfpLine1.getExecutionId()).get();
        impactedExecutionSfp.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(3);
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getPosition() == 2 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.READ_ADJUSTMENT_TPP)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SEND_CANCELLATION_NOTIFICATION).isEmpty()).isTrue();
            }
        );

        ImpactedExecution impactedExecutionOrderAndCollect = executionAction.getImpactedExecutionByExecutionId(orderAndCollectLine.getExecutionId()).get();
        impactedExecutionOrderAndCollect.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(5);
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY).stream().anyMatch(step -> step.getPosition() == 1 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT).stream().anyMatch(step -> step.getPosition() == 2 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP).stream().anyMatch(step -> step.getPosition() == 3 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION).stream().anyMatch(step -> step.getPosition() == 4 && step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED) && step.isBlocking())).isTrue();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.READ_ADJUSTMENT_TPP)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP)).isEmpty();
                assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SEND_CANCELLATION_NOTIFICATION).isEmpty()).isTrue();
            }
        );
    }

    @Test
    void shouldInitializeSplitCancellationRemainingCollectWorkflow() {
        RuleEngineContext context = generateActionExecutionContextForSplit(REMAINING_COLLECT.name());

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        ExecutionAction executionAction = context.getOrderData().getExecutionActions().get(0);
        assertThat(executionAction.getFlags().lastFlagIs(ExecutionActionStatus.PROCESSING)).isTrue();

        LineExecution orderAndCollectLine2 = context.getOrderData().getExistingLineExecutions().get(3);


        ImpactedExecution impactedExecutionOrderAndCollect = executionAction.getImpactedExecutionByExecutionId(orderAndCollectLine2.getExecutionId()).get();
        impactedExecutionOrderAndCollect.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(4);
                AssertionsForClassTypes.assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP)).isPresent();
                AssertionsForClassTypes.assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SPLIT_LINE_EXECUTION)).isPresent();
                AssertionsForClassTypes.assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.ASK_PREPARATION_REQUIREMENT_TPP)).isPresent();
                AssertionsForClassTypes.assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.CREATE_COLLECT)).isPresent();
            }
        );

    }

    @Test
    void shouldInitializeSplitCancellationWorkflow() {
        RuleEngineContext context = generateActionExecutionContextForSplit(CANCELLATION.name());

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        ExecutionAction executionAction = context.getOrderData().getExecutionActions().get(0);
        assertThat(executionAction.getFlags().lastFlagIs(ExecutionActionStatus.PROCESSING)).isTrue();

        LineExecution sfwLine2 = context.getOrderData().getExistingLineExecutions().get(1);
        LineExecution orderAndCollectLine2 = context.getOrderData().getExistingLineExecutions().get(3);

        ImpactedExecution impactedExecutionSfw = executionAction.getImpactedExecutionByExecutionId(sfwLine2.getExecutionId()).get();
        impactedExecutionSfw.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(1);
                AssertionsForClassTypes.assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SPLIT_LINE_EXECUTION)).isPresent();
            });

        ImpactedExecution impactedExecutionOrderAndCollect = executionAction.getImpactedExecutionByExecutionId(orderAndCollectLine2.getExecutionId()).get();
        impactedExecutionOrderAndCollect.getImpactedLines().forEach(
            impactedLine -> {
                assertThat(impactedLine.getSteps()).hasSize(1);
                AssertionsForClassTypes.assertThat(impactedLine.getStepOfType(ImpactedLineStep.Type.SPLIT_LINE_EXECUTION)).isPresent();
            }
        );

    }

    private RuleEngineContext generateActionExecutionContextForDecreaseQuantity(boolean confirmationRequirement) {
        LineExecution sfwLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, confirmationRequirement, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution sfwLine2 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, confirmationRequirement, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution sfpLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, confirmationRequirement, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, null, OFFER);
        LineExecution orderAndCollectLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, confirmationRequirement, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);
        LineExecution thirdPartyLine1 = generateALine(true, CustomerOrderLineDeliveryStatus.ACCEPTED, false, true, confirmationRequirement, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);
        LineExecution thirdPartyLine2 = generateALine(true, CustomerOrderLineDeliveryStatus.ACCEPTED, false, true, confirmationRequirement, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);

        orderAndCollectLine1.getDelivery().getCollect().setGlobalCollectStatus(EXPECTED);

        RuleEngineContext context = generateContext(List.of(sfwLine1, sfwLine2, sfpLine1, orderAndCollectLine1, thirdPartyLine1, thirdPartyLine2));

        ExecutionAction executionAction = generateActionExecutionFromLines(context.getCustomerOrderId(), context.getOrderData().getExistingLineExecutions(), ExecutionActionType.DECREASE_QUANTITY);

        executionAction.getFlags().raiseFlag(ExecutionActionStatus.CREATED);

        context.getOrderData().setExecutionActions(List.of(executionAction));
        return context;
    }

    private RuleEngineContext generateActionExecutionContextForSplit(String reason) {
        LineExecution sfwLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution sfwLine2 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution orderAndCollectLine1 = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);
        LineExecution orderAndCollectLine2 = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);

        RuleEngineContext context = generateContext(List.of(sfwLine1, sfwLine2, orderAndCollectLine1, orderAndCollectLine2));

        List<LineExecution> impactedLines = REMAINING_COLLECT.name().equals(reason) ? List.of(orderAndCollectLine2) : List.of(sfwLine2, orderAndCollectLine2);
        ExecutionAction executionAction = generateActionExecutionFromLines(context.getCustomerOrderId(), impactedLines, ExecutionActionType.SPLIT, reason);

        executionAction.getFlags().raiseFlag(ExecutionActionStatus.CREATED);

        context.getOrderData().setExecutionActions(List.of(executionAction));
        return context;
    }

}
