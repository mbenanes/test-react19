package com.adeo.sales.customerorder.tempoorchestrator.applicationservice;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.alerting.input.AlertClosedInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.AlertClosedApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.PromisedDateSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;
import reactor.util.function.Tuple5;
import reactor.util.function.Tuples;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AlertClosedApplicationServiceTest {

    private AlertClosedApplicationService applicationService;

    @Mock
    private RuleEngineService ruleEngineService;

    @BeforeEach
    void setUp() {
        applicationService = new AlertClosedApplicationService(ruleEngineService);
    }

    @Test
    void should_update_right_lines_and_alerts() {
        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .id(UUID.randomUUID().toString())
            .buCode("001")
            .build();
        String firstLineId = UUID.randomUUID().toString();
        String secondeLineId = UUID.randomUUID().toString();
        List<LineExecution> bddLineExecutions = List.of(LineExecution.builder()
                .lineId(firstLineId)
                .build(),
            LineExecution.builder()
                .lineId(secondeLineId)
                .build());

        List<Alert> bddAlerts = List.of(Alert.builder()
            .tempoAlertingId("alertId1")
            .buCode("001")
            .status(AlertStatus.PENDING)
            .impactedLinesIds(List.of(firstLineId))
            .specificData(PromisedDateSpecificData.builder()
                .reason("LATE")
                .build())
            .build());
        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLineExecutions, bddAlerts, List.of(), List.of()));
        when(ruleEngineService.lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        MonoMock<Void> runRuleEngineCall = MonoMock.empty();
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> runRuleEngineCall);

        AlertClosedInput input = AlertClosedInput.builder()
            .alertId("alertId1")
            .isConsideredDelivered(true)
            .buCode(bddCustomerOrder.getBuCode())
            .customerOrderId(bddCustomerOrder.getId())
            .impactedLineIds(List.of(firstLineId))
            .build();

        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        lockAndGetDataCall.expectHasBeenSubscribed();
        runRuleEngineCall.expectHasBeenSubscribed();

        verify(ruleEngineService).lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode());
        verify(ruleEngineService).startRuleEngineAndUpdateLines();

        assertThat(bddLineExecutions.get(0).getDelivery().isDeclaredDelivered()).isTrue();
        assertThat(bddLineExecutions.get(1).getDelivery().isDeclaredDelivered()).isFalse();
        assertThat(bddAlerts.get(0).getStatus()).isEqualTo(AlertStatus.CLOSED);
    }

    @Test
    void should_not_undelivered_lines_on_alertClosedReceivedWithoutDeclaredDelivered() {
        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .id(UUID.randomUUID().toString())
            .buCode("001")
            .build();
        String firstLineId = UUID.randomUUID().toString();
        String secondeLineId = UUID.randomUUID().toString();
        List<LineExecution> bddLineExecutions = List.of(LineExecution.builder()
                .lineId(firstLineId)
                .delivery(LineExecutionDelivery.builder().declaredDelivered(true).build())
                .build(),
            LineExecution.builder()
                .lineId(secondeLineId)
                .build());

        List<Alert> bddAlerts = List.of(Alert.builder()
            .tempoAlertingId("alertId1")
            .buCode("001")
            .status(AlertStatus.PENDING)
            .build());
        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLineExecutions, bddAlerts, List.of(), List.of()));
        when(ruleEngineService.lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        MonoMock<Void> runRuleEngineCall = MonoMock.empty();
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> runRuleEngineCall);

        AlertClosedInput input = AlertClosedInput.builder()
            .alertId("alertId1")
            .isConsideredDelivered(false)
            .buCode(bddCustomerOrder.getBuCode())
            .customerOrderId(bddCustomerOrder.getId())
            .impactedLineIds(List.of(firstLineId))
            .build();

        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        lockAndGetDataCall.expectHasBeenSubscribed();
        runRuleEngineCall.expectHasBeenSubscribed();

        verify(ruleEngineService).lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode());
        verify(ruleEngineService).startRuleEngineAndUpdateLines();

        assertThat(bddLineExecutions.get(0).getDelivery().isDeclaredDelivered()).isTrue();
        assertThat(bddLineExecutions.get(1).getDelivery().isDeclaredDelivered()).isFalse();
        assertThat(bddAlerts.get(0).getStatus()).isEqualTo(AlertStatus.CLOSED);
    }

    @Test
    void should_return_empty_if_customer_order_not_found() {
        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .id(UUID.randomUUID().toString())
            .buCode("001")
            .build();
        String lineId = UUID.randomUUID().toString();
        List<LineExecution> bddLineExecutions = List.of(LineExecution.builder()
            .lineId(lineId)
            .build());

        List<Alert> bddAlerts = List.of(Alert.builder()
            .tempoAlertingId("alertId1")
            .buCode("001")
            .status(AlertStatus.PENDING)
            .build());
        ;
        when(ruleEngineService.lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode()))
            .thenReturn(MonoMock.error(new CustomerOrderNotFound("")));

        MonoMock<Void> runRuleEngineCall = MonoMock.empty();
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> runRuleEngineCall);

        AlertClosedInput input = AlertClosedInput.builder()
            .alertId("alertId1")
            .isConsideredDelivered(true)
            .buCode(bddCustomerOrder.getBuCode())
            .customerOrderId(bddCustomerOrder.getId())
            .impactedLineIds(List.of(lineId))
            .build();

        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        runRuleEngineCall.expectHasNotBeenSubscribed();

        verify(ruleEngineService).lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode());
        verify(ruleEngineService).startRuleEngineAndUpdateLines();

        assertThat(bddLineExecutions.get(0).getDelivery().isDeclaredDelivered()).isFalse();
        assertThat(bddAlerts.get(0).getStatus()).isEqualTo(AlertStatus.PENDING);
    }
}
