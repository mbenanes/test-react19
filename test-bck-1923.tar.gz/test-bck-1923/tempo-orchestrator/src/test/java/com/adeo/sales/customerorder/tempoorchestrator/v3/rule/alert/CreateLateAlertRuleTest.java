package com.adeo.sales.customerorder.tempoorchestrator.v3.rule.alert;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.ApplicationProperties;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertReason;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.ShippingPoint;
import com.adeo.sales.customerorder.tempoorchestrator.repository.AlertRepository;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.AlertMessageInput;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.alert.AlertData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DelayType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecutionComposition;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert.CreateLateAlertRule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderLineStatus.VALIDATED;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreateLateAlertRuleTest {

    private CreateLateAlertRule rule;

    @Mock
    private AlertRepository alertRepository;

    @Mock
    private AlertMessageService alertMessageService;

    @Captor
    private ArgumentCaptor<List<Alert>> alertArgumentCaptor;

    @Captor
    private ArgumentCaptor<AlertMessageInput> alertMessageInputArgumentCaptor;

    @BeforeEach
    void setUp() {
        ApplicationProperties applicationProperties = new ApplicationProperties();
        applicationProperties.setMaxAlertToCreateByCustomerOrder(100);
        rule = new CreateLateAlertRule(alertRepository, alertMessageService, applicationProperties);
    }

    @Test
    void should_create_late_alert() {
        RuleEngineContext context = this.generateContext();

        assertThat(rule.when(context)).isTrue();

        MonoMock<List<Alert>> alertRepositoryCall = MonoMock.empty();
        when(alertRepository.upsert(alertArgumentCaptor.capture())).thenReturn(alertRepositoryCall);
        MonoMock<Void> alertMessageCall = MonoMock.empty();
        when(alertMessageService.sendCreateAlertMessage(alertMessageInputArgumentCaptor.capture())).thenReturn(alertMessageCall);

        StepVerifier.create(rule.then(context)).verifyComplete();

        alertRepositoryCall.expectHasBeenSubscribed();
        alertMessageCall.expectHasBeenSubscribed();

        verify(alertRepository).upsert(anyList());
        verify(alertMessageService, times(2)).sendCreateAlertMessage(any(AlertMessageInput.class));

        List<Alert> alertsSaved = alertArgumentCaptor.getValue();

        assertThat(alertsSaved).hasSize(2);

        LineExecution firstLine = context.getOrderData().getExistingLineExecutions().get(0);
        LineExecution secondLine = context.getOrderData().getExistingLineExecutions().get(1);
        assertThat(alertsSaved.stream().anyMatch(alert -> alert.getImpactedLinesIds().contains(firstLine.getLineId()))).isTrue();
        assertThat(alertsSaved.stream().anyMatch(alert -> alert.getImpactedLinesIds().contains(secondLine.getLineId()))).isTrue();

        assertThat(alertsSaved.stream().allMatch(
            alert -> alert.getBuCode().equals(context.getOrderData().getExistingCustomerOrder().getBuCode()) &&
                alert.getCustomerOrderId().equals(context.getOrderData().getExistingCustomerOrder().getId()) &&
                alert.getStatus().equals(AlertStatus.CREATION_REQUESTED) &&
                alert.getSpecificData().getReason().equals(AlertReason.LATE.name())
        )).isTrue();

        List<AlertMessageInput> alertMessageInputsSended = alertMessageInputArgumentCaptor.getAllValues();

        assertThat(alertMessageInputsSended).hasSize(2);

        assertThat(alertMessageInputsSended.stream().anyMatch(
            input -> input.getAlert().getImpactedLinesIds().equals(List.of(firstLine.getLineId())) &&
                input.getLineExecutions().equals(List.of(firstLine)) &&
                input.getCustomerOrder().equals(context.getOrderData().getExistingCustomerOrder())
        )).isTrue();
        assertThat(alertMessageInputsSended.stream().anyMatch(
            input -> input.getAlert().getImpactedLinesIds().equals(List.of(secondLine.getLineId())) &&
                input.getLineExecutions().equals(List.of(secondLine)) &&
                input.getCustomerOrder().equals(context.getOrderData().getExistingCustomerOrder())
        )).isTrue();
    }

    @Test
    void should_not_start_rule_because_order_not_validated() {
        RuleEngineContext context = this.generateContext();
        context.getOrderData().getExistingCustomerOrder().setStatus(CustomerOrderStatus.PENDING_VALIDATION);

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_because_lines_canceled() {
        RuleEngineContext context = this.generateContext();

        context.getOrderData().getExistingLineExecutions().forEach(lineExecution -> lineExecution.getComposition().getFlags().raiseFlag(CompositionOrderStatus.CANCELED));

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_because_lines_are_not_late() {
        RuleEngineContext context = this.generateContext();

        context.getOrderData().getExistingLineExecutions().forEach(lineExecution -> lineExecution.getDelivery().setDelayType(null));

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_because_lines_are_shipped() {
        RuleEngineContext context = this.generateContext();

        context.getOrderData().getExistingLineExecutions().forEach(lineExecution -> lineExecution.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.SHIPPED));

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_because_lines_are_declared_delivered() {
        RuleEngineContext context = this.generateContext();

        context.getOrderData().getExistingLineExecutions().forEach(lineExecution -> lineExecution.getDelivery().setDeclaredDelivered(true));

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_because_lines_has_already_an_alert() {
        RuleEngineContext context = this.generateContext();

        LineExecution firstLine = context.getOrderData().getExistingLineExecutions().get(0);
        LineExecution secondLine = context.getOrderData().getExistingLineExecutions().get(1);

        final Map<String, List<String>> impactedLineByExecution = Stream.of(firstLine, secondLine)
            .collect(Collectors.groupingBy(LineExecution::getExecutionId,
                Collectors.mapping(LineExecution::getLineId, Collectors.toList())));

        final var lineMetadataById = Stream.of(firstLine, secondLine)
            .map(line -> AlertSpecificData.LineMetadata.fromOrderAndLine(context.getOrderData().getExistingCustomerOrder(), line))
            .collect(Collectors.toMap(AlertSpecificData.LineMetadata::getLineId, Function.identity()));

        context.getAlertData().getExistingAlerts().add(Alert.buildNewAlert(context.getCustomerOrderId(), context.getBuCode(), impactedLineByExecution, ShippingPoint.WAREHOUSE.name(), "UNKNOWN_DELAY", null, null, null, null, LineExecutionPayment.PaymentExecutionSystem.PSR, List.of(), lineMetadataById));

        assertThat(rule.when(context)).isFalse();
    }

    private RuleEngineContext generateContext() {
        RuleEngineContext context = new RuleEngineContext();

        String SFWExecutionId = UUID.randomUUID().toString();
        LineExecution firstLineSfw = LineExecution.builder()
            .executionId(SFWExecutionId)
            .lineId(UUID.randomUUID().toString())
            .payment(LineExecutionPayment.builder()
                .build())
            .composition(LineExecutionComposition.builder()
                .flags(new Flags<>(new Flag("", OffsetDateTime.now(), VALIDATED.name(), null)))
                .build())
            .externalSystem(ExternalSystem.builder()
                .name(ExternalSystem.SystemName.TEMPO)
                .origin(ExternalSystem.SystemName.TEMPO)
                .id("12345")
                .build())
            .delivery(LineExecutionDelivery.builder()
                .deliveryType(DeliveryType.SFW)
                .shippingPoint(ShippingPoint.WAREHOUSE)
                .delayType(DelayType.LATE)
                .build())
            .build();

        LineExecution secondLineSfw = LineExecution.builder()
            .executionId(SFWExecutionId)
            .lineId(UUID.randomUUID().toString())
            .payment(LineExecutionPayment.builder()
                .build())
            .composition(LineExecutionComposition.builder()
                .flags(new Flags<>(new Flag("", OffsetDateTime.now(), VALIDATED.name(), null)))
                .build())
            .externalSystem(ExternalSystem.builder()
                .name(ExternalSystem.SystemName.TEMPO)
                .origin(ExternalSystem.SystemName.TEMPO)
                .id("12345")
                .build())
            .delivery(LineExecutionDelivery.builder()
                .deliveryType(DeliveryType.SFW)
                .delayType(DelayType.LATE)
                .shippingPoint(ShippingPoint.WAREHOUSE)
                .build())
            .build();

        LineExecution thirdLine3P = LineExecution.builder()
            .isSoldByAThirdPartyVendor(true)
            .lineId(UUID.randomUUID().toString())
            .payment(LineExecutionPayment.builder()
                .build())
            .delivery(LineExecutionDelivery.builder()
                .deliveryType(DeliveryType.THIRD_PARTY)
                .build())
            .build();

        context.setOrderData(OrderData.builder()
            .executionActions(new ArrayList<>())
            .existingCustomerOrder(CustomerOrder.builder()
                .id(UUID.randomUUID().toString())
                .buCode("001")
                .status(CustomerOrderStatus.VALIDATED)
                .build())
            .existingLineExecutions(List.of(firstLineSfw, secondLineSfw, thirdLine3P))
            .build());
        context.setAlertData(AlertData.builder()
            .existingAlerts(new ArrayList<>())
            .build());
        return context;
    }
}
