package com.adeo.sales.customerorder.tempoorchestrator.handler;


import com.adeo.bomp.order.model.avro.vendororderlines.State;
import com.adeo.bomp.order.model.avro.vendororderlines.VendorOrderlinesCreated;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.CustomerOrderLineCreatedApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.input.CustomerOrderLineCreatedInput;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.ApplicationProperties;
import com.adeo.sales.customerorder.tempoorchestrator.handler.bomp.VendorOrderLinesCreatedHandler;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaDataTestBuilder.mockEventMetaData;
import static com.adeo.sales.customerorder.tempoorchestrator.handler.VendorOrderlinesTestBuilder.aLine;
import static com.adeo.sales.customerorder.tempoorchestrator.handler.VendorOrderlinesTestBuilder.aVendorOrderlinesCreatedEvent;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class VendorPaymentOrderLinesCreatedHandlerTest {

    private VendorOrderLinesCreatedHandler sut;
    private CustomerOrderLineCreatedApplicationService customerOrderLineCreatedApplicationService;

    @BeforeEach
    public void setup() {
        MappedDiagnosticContext mappedDiagnosticContext = mock(MappedDiagnosticContext.class);

        customerOrderLineCreatedApplicationService = mock(CustomerOrderLineCreatedApplicationService.class);
        when(customerOrderLineCreatedApplicationService.apply(any(CustomerOrderLineCreatedInput.class))).thenReturn(Mono.empty());

        sut = new VendorOrderLinesCreatedHandler(customerOrderLineCreatedApplicationService, mappedDiagnosticContext, new ApplicationProperties());
    }

    @Test
    public void shouldCallApplicationService_lineCreated() {
        final var customerOrderId = "orderId";
        VendorOrderlinesCreated event = aVendorOrderlinesCreatedEvent(customerOrderId, "001-20300L8-A",
            List.of(
                aLine("CREATED-1", State.CREATED),
                aLine("CANCELED-1", State.CANCELED),
                aLine("CREATED-2", State.CREATED))
        );

        var result = sut.handle(event, mockEventMetaData());

        StepVerifier
            .create(result)
            .verifyComplete();
        verify(customerOrderLineCreatedApplicationService).apply(
            CustomerOrderLineCreatedInput.builder()
                .createdLineIds(List.of("CREATED-1", "CREATED-2"))
                .bompId("001-20300L8-A")
                .updatedBy("bomp")
                .customerOrderId(customerOrderId)
                .buCode("001")
                .build()
        );
    }
}
