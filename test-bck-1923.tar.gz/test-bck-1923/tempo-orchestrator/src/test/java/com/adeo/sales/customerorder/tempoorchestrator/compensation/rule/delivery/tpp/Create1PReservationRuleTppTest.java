package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.service.FullfillmentReservationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.OffsetDateTime;
import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus.VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType.RESERVE_AND_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class Create1PReservationRuleTppTest {

    private Create1PReservationRuleTpp rule;

    @Mock
    private FullfillmentReservationService fullfillmentReservationService;

    @BeforeEach
    void setUp() {
        rule = new Create1PReservationRuleTpp(fullfillmentReservationService);
    }

    @Test
    void shouldTriggerDorReservationWhenHaveReserveAndCollectByTempoWithTppAndTppValidationAndReceivedCustomerOrderValidated() {
        // Given
        LineExecution givenLineExecution = generateALine(false, null, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getPaymentRequirements().setStockReservationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.COMPLIANT.name(), null)));
        givenLineExecution.setExternalSystem(ExternalSystem.builder().name(ExternalSystem.SystemName.TEMPO).build());
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingCustomerOrder(CustomerOrder.builder()
                .status(CustomerOrderStatus.VALIDATED)
                .orderPlaceType(CustomerOrderPlaceType.IN_STORE)
                .build())
            .existingLineExecutions(List.of(givenLineExecution))
            .build());

        when(fullfillmentReservationService.createOrderReservation(anyList(), any())).thenReturn(Mono.empty());

        // When
        boolean result = rule.when(context);

        // Then
        assertThat(result).isTrue();
        StepVerifier.create(rule.then(context))
            .verifyComplete();
        verify(fullfillmentReservationService, times(1)).createOrderReservation(anyList(), any());
    }

    @Test
    void shouldTriggerDorReservationWhenIsTempoAndWeb() {
        // Given
        LineExecution givenLineExecution = generateALine(false, null, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getPaymentRequirements().setStockReservationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.COMPLIANT.name(), null)));
        givenLineExecution.setExternalSystem(ExternalSystem.builder().name(ExternalSystem.SystemName.TEMPO).build());
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
                .existingCustomerOrder(CustomerOrder.builder()
                        .status(CustomerOrderStatus.VALIDATED)
                        .orderPlaceType(CustomerOrderPlaceType.ONLINE)
                        .build())
                .existingLineExecutions(List.of(givenLineExecution))
                .build());

        when(fullfillmentReservationService.createOrderReservation(anyList(), any())).thenReturn(Mono.empty());

        // When
        boolean result = rule.when(context);

        // Then
        assertThat(result).isTrue();
        StepVerifier.create(rule.then(context))
                .verifyComplete();
        verify(fullfillmentReservationService, times(1)).createOrderReservation(anyList(), any());
    }

    @Test
    void shouldTriggerDorReservationWhenExternalSystemWhenIsPyxisAndWeb() {
        // Given
        LineExecution givenLineExecution = generateALine(false, null, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getPaymentRequirements().setStockReservationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.COMPLIANT.name(), null)));
        givenLineExecution.setExternalSystem(ExternalSystem.builder().name(ExternalSystem.SystemName.PYXIS).build());
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
                .existingCustomerOrder(CustomerOrder.builder()
                        .status(CustomerOrderStatus.VALIDATED)
                        .orderPlaceType(CustomerOrderPlaceType.ONLINE)
                        .build())
                .existingLineExecutions(List.of(givenLineExecution))
                .build());

        when(fullfillmentReservationService.createOrderReservation(anyList(), any())).thenReturn(Mono.empty());

        // When
        boolean result = rule.when(context);

        // Then
        assertThat(result).isTrue();
        StepVerifier.create(rule.then(context))
                .verifyComplete();
        verify(fullfillmentReservationService, times(1)).createOrderReservation(anyList(), any());
    }

    @Test
    void shouldNotTriggerDorReservationWhenIsSfpDelivery() {
        // Given
        LineExecution givenLineExecution = generateALine(false, null, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getPaymentRequirements().setStockReservationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.COMPLIANT.name(), null)));
        givenLineExecution.getDelivery().setDeliveryType(DeliveryType.SFP);
        givenLineExecution.setExternalSystem(ExternalSystem.builder().name(ExternalSystem.SystemName.TEMPO).build());
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
                .existingCustomerOrder(CustomerOrder.builder()
                        .status(CustomerOrderStatus.VALIDATED)
                        .orderPlaceType(CustomerOrderPlaceType.IN_STORE)
                        .build())
                .existingLineExecutions(List.of(givenLineExecution))
                .build());

        // When
        boolean result = rule.when(context);

        // Then
        assertThat(result).isFalse();
        verify(fullfillmentReservationService, times(0)).createOrderReservation(anyList(), any());
    }

    @Test
    void shouldNotTriggerDorReservationWhenExternalSystemWhenIsPyxisAndPlaceIsInStore() {
        // Given
        LineExecution givenLineExecution = generateALine(false, null, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getPaymentRequirements().setStockReservationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.COMPLIANT.name(), null)));
        givenLineExecution.setExternalSystem(ExternalSystem.builder().name(ExternalSystem.SystemName.PYXIS).build());
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
                .existingCustomerOrder(CustomerOrder.builder()
                        .status(CustomerOrderStatus.VALIDATED)
                        .orderPlaceType(CustomerOrderPlaceType.IN_STORE)
                        .build())
                .existingLineExecutions(List.of(givenLineExecution))
                .build());

        // When
        boolean result = rule.when(context);

        // Then
        assertThat(result).isFalse();
        verify(fullfillmentReservationService, times(0)).createOrderReservation(anyList(), any());
    }

    @Test
    void shouldNotTriggerDorReservationWhenReservationRequirementIsNotCompliant() {
        // Given
        LineExecution givenLineExecution = generateALine(false, null, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.setExternalSystem(ExternalSystem.builder().name(ExternalSystem.SystemName.TEMPO).build());
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingCustomerOrder(CustomerOrder.builder()
                .status(CustomerOrderStatus.VALIDATED)
                .build())
            .existingLineExecutions(List.of(givenLineExecution))
            .build());

        // When
        boolean result = rule.when(context);

        // Then
        assertThat(result).isFalse();
        verify(fullfillmentReservationService, times(0)).createOrderReservation(anyList(), any());
    }

    @Test
    void shouldNotTriggerDorReservationWhenDeliveryExecutionAlreadyStarted() {
        // Given
        LineExecution givenLineExecution = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getPaymentRequirements().setStockReservationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.COMPLIANT.name(), null)));
        givenLineExecution.setExternalSystem(ExternalSystem.builder().name(ExternalSystem.SystemName.TEMPO).build());
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingCustomerOrder(CustomerOrder.builder()
                .status(CustomerOrderStatus.VALIDATED)
                .build())
            .existingLineExecutions(List.of(givenLineExecution))
            .build());

        // When
        boolean result = rule.when(context);

        // Then
        assertThat(result).isFalse();
        verify(fullfillmentReservationService, times(0)).createOrderReservation(anyList(), any());
    }

}
