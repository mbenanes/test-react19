package com.adeo.sales.customerorder.tempoorchestrator.v3.rule.delivery;

import com.adeo.featuretoggle.Feature;
import com.adeo.featuretoggle.FeatureRepository;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery.tpp.Create1PDeliveryRuleTpp;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.service.FulfillmentOrderExecutionService;
import com.adeo.sales.customerorder.tempoorchestrator.service.impl.FirstPartyCommandServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class Create1PDeliveryRuleTppTest {

    private Create1PDeliveryRuleTpp rule;

    @Mock
    private FirstPartyCommandServiceImpl firstPartyCommandServiceImpl;

    @Mock
    private FulfillmentOrderExecutionService fulfillmentOrderExecutionService;

    @Mock
    private FeatureRepository featureRepository;

    @Mock
    private Feature feature;

    @Captor
    private ArgumentCaptor<List<LineExecution>> linesCaptor;

    @BeforeEach
    void setUp() {
        rule = new Create1PDeliveryRuleTpp(featureRepository, firstPartyCommandServiceImpl, fulfillmentOrderExecutionService);
    }

    @Test
    void should_process_rule_1P_line_only() {
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER)
            ))
            .existingCustomerOrder(CustomerOrder.builder().buCode("001").status(CustomerOrderStatus.VALIDATED).build())
            .build());

        when(feature.isEnabled()).thenReturn(Mono.just(true));
        when(featureRepository.getFeature("CreateDeliveryByFulfillmentOrderFrench")).thenReturn(feature);
        when(fulfillmentOrderExecutionService.createOrderExecution(linesCaptor.capture(), any(CustomerOrder.class))).thenReturn(Mono.empty());

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        verify(fulfillmentOrderExecutionService, times(1)).createOrderExecution(linesCaptor.capture(), any(CustomerOrder.class));
        LineExecution firstLine = context.getOrderData().getExistingLineExecutions().get(0);
        assertThat(firstLine.getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATION_REQUESTED)).isTrue();
        assertThat(firstLine.getComposition().isCancelable()).isFalse();
        assertThat(firstLine.getDelivery().getCancelable()).isFalse();
        assertThat(firstLine.getDelivery().getForceCancelable()).isFalse();

        assertThat(linesCaptor.getValue()).isNotEmpty();
        assertThat(linesCaptor.getValue()).hasSize(1);
    }

    @Test
    void should_process_rule_1P_send_orderexecutionrequest() {
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER)
            ))
            .existingCustomerOrder(CustomerOrder.builder().buCode("002").status(CustomerOrderStatus.VALIDATED).build())
            .build());

        when(feature.isEnabled()).thenReturn(Mono.just(false));
        when(featureRepository.getFeature("CreateDeliveryByFulfillmentOrderSpanish")).thenReturn(feature);
        when(firstPartyCommandServiceImpl.createOrderExecution(linesCaptor.capture(), any(CustomerOrder.class))).thenReturn(Mono.empty());

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();


        verify(firstPartyCommandServiceImpl, times(1)).createOrderExecution(linesCaptor.capture(), any(CustomerOrder.class));
        LineExecution firstLine = context.getOrderData().getExistingLineExecutions().get(0);
        assertThat(firstLine.getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATION_REQUESTED)).isTrue();
        assertThat(firstLine.getComposition().isCancelable()).isFalse();
        assertThat(firstLine.getDelivery().getCancelable()).isFalse();
        assertThat(firstLine.getDelivery().getForceCancelable()).isFalse();

        assertThat(linesCaptor.getValue()).isNotEmpty();
        assertThat(linesCaptor.getValue()).hasSize(1);
    }

    @Test
    void should_process_rule_1P_line_only_already_created() {
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(false, CustomerOrderLineDeliveryStatus.CREATION_REQUESTED, false, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER)
            ))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build())
            .build());

        lenient().when(firstPartyCommandServiceImpl.createOrderExecution(linesCaptor.capture(), any(CustomerOrder.class))).thenReturn(Mono.empty());

        assertThat(rule.when(context)).isFalse();

        verify(firstPartyCommandServiceImpl, never()).createOrderExecution(anyList(), any(CustomerOrder.class));
    }

    @Test
    void should_process_rule_3P_line_only() {
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(true, null, false, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER)
            ))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build())
            .build());

        lenient().when(firstPartyCommandServiceImpl.createOrderExecution(anyList(), any(CustomerOrder.class))).thenReturn(Mono.empty());

        assertThat(rule.when(context)).isFalse();

        verify(firstPartyCommandServiceImpl, never()).createOrderExecution(anyList(), any(CustomerOrder.class));
    }

    @Test
    void should_process_rule_1P_line_with_only_validation_requirement() {
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(true, null, false, true, false, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER)
            ))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build())
            .build());

        lenient().when(firstPartyCommandServiceImpl.createOrderExecution(anyList(), any(CustomerOrder.class))).thenReturn(Mono.empty());

        assertThat(rule.when(context)).isFalse();

        verify(firstPartyCommandServiceImpl, never()).createOrderExecution(anyList(), any(CustomerOrder.class));
    }

    @Test
    void should_process_rule_1P_line_but_composition_not_validated() {
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(true, null, false, true, false, CompositionOrderStatus.PENDING, DeliveryType.SFW, null, OFFER)
            ))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build())
            .build());

        lenient().when(firstPartyCommandServiceImpl.createOrderExecution(anyList(), any(CustomerOrder.class))).thenReturn(Mono.empty());

        assertThat(rule.when(context)).isFalse();

        verify(firstPartyCommandServiceImpl, never()).createOrderExecution(anyList(), any(CustomerOrder.class));
    }

    @Test
    void should_process_rule_3P_and_1P_lines() {
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER),
                generateALine(true, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER)
            ))
            .existingCustomerOrder(CustomerOrder.builder().buCode("001").status(CustomerOrderStatus.VALIDATED).orderPlaceType(CustomerOrderPlaceType.ONLINE).build())
            .build());

        when(feature.isEnabled()).thenReturn(Mono.just(true));
        when(featureRepository.getFeature("CreateDeliveryByFulfillmentOrderFrench")).thenReturn(feature);
        when(fulfillmentOrderExecutionService.createOrderExecution(linesCaptor.capture(), any(CustomerOrder.class))).thenReturn(Mono.empty());

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        verify(fulfillmentOrderExecutionService, times(1)).createOrderExecution(linesCaptor.capture(), any(CustomerOrder.class));
        LineExecution firstLine = context.getOrderData().getExistingLineExecutions().get(0);
        assertThat(firstLine.getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATION_REQUESTED)).isTrue();
        assertThat(firstLine.getComposition().isCancelable()).isFalse();
        assertThat(firstLine.getDelivery().getCancelable()).isFalse();
        assertThat(firstLine.getDelivery().getForceCancelable()).isFalse();

        assertThat(linesCaptor.getValue()).isNotEmpty();
        assertThat(linesCaptor.getValue()).hasSize(1);
    }

}
