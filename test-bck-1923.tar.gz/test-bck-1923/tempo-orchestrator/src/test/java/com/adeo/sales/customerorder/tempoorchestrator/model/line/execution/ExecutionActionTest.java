package com.adeo.sales.customerorder.tempoorchestrator.model.line.execution;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.jackson.SerializeSpecificRecordBase;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.avro.specific.SpecificRecordBase;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;

class ExecutionActionTest {

    ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new SimpleModule().addSerializer(SpecificRecordBase.class, new SerializeSpecificRecordBase()));
        objectMapper.registerModule(new Jdk8Module());
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }

    @Test
    void shouldReturnTheRightCurrentAndNextStep() throws IOException {
        ExecutionAction executionAction = objectMapper.readValue(this.getClass().getResource("/data.executionaction/Executionaction.json"), ExecutionAction.class);

        Assertions.assertThat(executionAction.getImpactedExecutions().get(0).getImpactedLines().get(0).getNextStep().isPresent()).isFalse();
        Assertions.assertThat(executionAction.getImpactedExecutions().get(0).getImpactedLines().get(0).getCurrentStep().get().getType()).isEqualTo(ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION);
    }

    @Test
    void shouldReturnTheFirstStep() throws IOException {
        ExecutionAction executionAction = objectMapper.readValue(this.getClass().getResource("/data.executionaction/ExecutionActionAllStepCreated.json"), ExecutionAction.class);


        Assertions.assertThat(executionAction.getImpactedExecutions().get(0).getImpactedLines().get(0).getNextStep().get().getType().equals(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY)).isTrue();
        Assertions.assertThat(executionAction.getImpactedExecutions().get(0).getImpactedLines().get(0).getCurrentStep().isPresent()).isFalse();
    }

    @Test
    void shouldReturnTheRightStepWhenExecutionActionIsCompleted() throws IOException {
        ExecutionAction executionAction = objectMapper.readValue(this.getClass().getResource("/data.executionaction/ExecutionActionAllStepCompleted.json"), ExecutionAction.class);

        Assertions.assertThat(executionAction.getImpactedExecutions().get(0).getImpactedLines().get(0).getNextStep().isPresent()).isFalse();
        Assertions.assertThat(executionAction.getImpactedExecutions().get(0).getImpactedLines().get(0).getCurrentStep().isPresent()).isFalse();
    }

}
