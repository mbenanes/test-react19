package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.notify.command.sendcustomerordernotification.SendCustomerOrderNotification;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.postpone.PostponeNotificationEventConfiguration;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.timezones.TimezonesConfiguration;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.service.impl.OutcomingNotificationServiceImpl;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDeliveryCollect;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.ConfigDataApplicationContextInitializer;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.service.impl.OutcomingNotificationServiceImpl.NotificationType.APPOINTMENT_REMINDER_DAY_BEFORE;
import static com.adeo.sales.customerorder.tempoorchestrator.service.impl.OutcomingNotificationServiceImpl.NotificationType.APPOINTMENT_REMINDER_HOURS_BEFORE;
import static com.adeo.sales.customerorder.tempoorchestrator.service.impl.OutcomingNotificationServiceImpl.NotificationType.PICKUP_APPOINTMENT_EXPIRED;
import static org.mockito.Mockito.when;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(initializers = ConfigDataApplicationContextInitializer.class)
@EnableConfigurationProperties(value = {PostponeNotificationEventConfiguration.class, TimezonesConfiguration.class})
@ActiveProfiles("test")
class OutcomingNotificationServiceImplTest {

    @Autowired
    public TopicsProperties properties;
    @Autowired
    public PostponeNotificationEventConfiguration postponeNotificationEventConfiguration;
    @Autowired
    public EventProducer eventProducer;

    @Autowired
    private OutgoingNotificationService outgoingNotificationService;

    @Captor
    ArgumentCaptor<OffsetDateTime> actualDateToSend;

    private final OffsetDateTime appointmentDateOutsideIdling = OffsetDateTime.now(ZoneId.of("Indian/Reunion")).withHour(18).withMinute(0).plusDays(3);
    private final String buCode = "001";

    private static DateFormat formatter = new SimpleDateFormat("h'h'mm");



    @Test
    void When_AppointmentHasPostponedEmailConfiguration_Expect_SendAppointmentPostponedNotification() {
        RuleEngineContext ruleEngineContext = generateContext(appointmentDateOutsideIdling);

        when(eventProducer.sendEvents(ArgumentMatchers.anyList(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(SendCustomerOrderNotification.class), actualDateToSend.capture(), ArgumentMatchers.anyString())).thenReturn(Mono.empty());

        final List<String> textualDurationList = postponeNotificationEventConfiguration.getPostponeConfiguration(APPOINTMENT_REMINDER_DAY_BEFORE.getTemplateType(), buCode).getPostponeValue();
        OffsetDateTime expectedDateToSend = appointmentDateOutsideIdling.plus(Duration.parse(textualDurationList.get(0)));

        StepVerifier.create(outgoingNotificationService.sendAppointmentReminderDayBeforeNotification(ruleEngineContext.getOrderData().getExistingCustomerOrder(), ruleEngineContext.getOrderData().getExistingLineExecutions())).verifyComplete();

        Assertions.assertThat(actualDateToSend.getValue()).isEqualTo(expectedDateToSend);
    }

    @Test
    void When_AppointmentHasPostponedSmsConfiguration_Expect_SendAppointmentPostponedNotification() {
        RuleEngineContext ruleEngineContext = generateContext(appointmentDateOutsideIdling);

        when(eventProducer.sendEvents(ArgumentMatchers.anyList(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(SendCustomerOrderNotification.class), actualDateToSend.capture(), ArgumentMatchers.anyString())).thenReturn(Mono.empty());

        final List<String> textualDurationList = postponeNotificationEventConfiguration.getPostponeConfiguration(APPOINTMENT_REMINDER_HOURS_BEFORE.getTemplateType(), buCode).getPostponeValue();
        OffsetDateTime expectedDateToSend = appointmentDateOutsideIdling.plus(Duration.parse(textualDurationList.get(0)));

        StepVerifier.create(outgoingNotificationService.sendAppointmentReminderHoursBeforeNotification(ruleEngineContext.getOrderData().getExistingCustomerOrder(), ruleEngineContext.getOrderData().getExistingLineExecutions())).verifyComplete();

        Assertions.assertThat(actualDateToSend.getValue()).isEqualTo(expectedDateToSend);
    }

    @Test
    void When_AppointmentHasPostponedSmsConfigurationInIdling_Expect_SendAppointmentPostponedNotificationOnIdleFromAtDayBefore() throws ParseException {
        OffsetDateTime appointmentDateInsideIdling = OffsetDateTime.now(ZoneId.of("Indian/Reunion")).withHour(9).withMinute(15).plusDays(3);
        RuleEngineContext ruleEngineContext = generateContext(appointmentDateInsideIdling);

        when(eventProducer.sendEvents(ArgumentMatchers.anyList(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(SendCustomerOrderNotification.class), actualDateToSend.capture(), ArgumentMatchers.anyString())).thenReturn(Mono.empty());

        StepVerifier.create(outgoingNotificationService.sendAppointmentReminderHoursBeforeNotification(ruleEngineContext.getOrderData().getExistingCustomerOrder(), ruleEngineContext.getOrderData().getExistingLineExecutions())).verifyComplete();

        final String hourIdleFrom = postponeNotificationEventConfiguration.getPostponeConfiguration(APPOINTMENT_REMINDER_HOURS_BEFORE.getTemplateType(), buCode).getHourIdleFrom();
        OffsetDateTime dateIdleFom = hourIdleFrom != null ? getParsedDate(formatter, hourIdleFrom) : null;

        Assertions.assertThat(actualDateToSend.getValue()).isEqualTo(appointmentDateInsideIdling.withHour(dateIdleFom.getHour()).withMinute(dateIdleFom.getMinute()).minusDays(1));
    }
    @Test
    void When_AppointmentHasPostponedSmsConfigurationInIdling_Expect_SendAppointmentPostponedNotificationOnIdleFromAtSameDay() throws ParseException {
        OffsetDateTime appointmentDateInsideIdling = OffsetDateTime.now(ZoneId.of("Indian/Reunion")).withHour(22).withMinute(15).plusDays(3);
        RuleEngineContext ruleEngineContext = generateContext(appointmentDateInsideIdling);

        when(eventProducer.sendEvents(ArgumentMatchers.anyList(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(SendCustomerOrderNotification.class), actualDateToSend.capture(), ArgumentMatchers.anyString())).thenReturn(Mono.empty());

        StepVerifier.create(outgoingNotificationService.sendAppointmentReminderHoursBeforeNotification(ruleEngineContext.getOrderData().getExistingCustomerOrder(), ruleEngineContext.getOrderData().getExistingLineExecutions())).verifyComplete();

        final String hourIdleFrom = postponeNotificationEventConfiguration.getPostponeConfiguration(APPOINTMENT_REMINDER_HOURS_BEFORE.getTemplateType(), buCode).getHourIdleFrom();
        OffsetDateTime dateIdleFom = hourIdleFrom != null ? getParsedDate(formatter,hourIdleFrom) : null;

        Assertions.assertThat(actualDateToSend.getValue()).isEqualTo(appointmentDateInsideIdling.withHour(dateIdleFom.getHour()).withMinute(dateIdleFom.getMinute()));
    }

    @Test
    void When_AppointmentHasPostponedSmsConfigurationEqualsIdlingFrom_Expect_SendAppointmentPostponedNotificationOnIdleFromAtSameDay() throws ParseException {
        OffsetDateTime appointmentDateInsideIdling = OffsetDateTime.now(ZoneId.of("Indian/Reunion")).withHour(21).withMinute(0).plusDays(3);
        RuleEngineContext ruleEngineContext = generateContext(appointmentDateInsideIdling);

        when(eventProducer.sendEvents(ArgumentMatchers.anyList(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(SendCustomerOrderNotification.class), actualDateToSend.capture(), ArgumentMatchers.anyString())).thenReturn(Mono.empty());

        StepVerifier.create(outgoingNotificationService.sendAppointmentReminderHoursBeforeNotification(ruleEngineContext.getOrderData().getExistingCustomerOrder(), ruleEngineContext.getOrderData().getExistingLineExecutions())).verifyComplete();

        final String hourIdleFrom = postponeNotificationEventConfiguration.getPostponeConfiguration(APPOINTMENT_REMINDER_HOURS_BEFORE.getTemplateType(), buCode).getHourIdleFrom();
        OffsetDateTime dateIdleFom = hourIdleFrom != null ? getParsedDate(formatter, hourIdleFrom) : null;

        Assertions.assertThat(actualDateToSend.getValue()).isEqualTo(appointmentDateInsideIdling.withHour(dateIdleFom.getHour()).withMinute(dateIdleFom.getMinute()));
    }

    @Test
    void When_AppointmentExpiredHasPostponedConfiguration_Expect_SendAppointmentExpiredPostponedNotifications() {
        RuleEngineContext ruleEngineContext = generateContext(appointmentDateOutsideIdling);
        final var monoEmptyJPlus1 = MonoMock.<Void>empty();
        final var monoEmptyJPlus2 = MonoMock.<Void>empty();
        final var monoEmptyJPlus4 = MonoMock.<Void>empty();
        final var monoEmptyJPlus7 = MonoMock.<Void>empty();

        final List<String> textualDurationList = postponeNotificationEventConfiguration.getPostponeConfiguration(PICKUP_APPOINTMENT_EXPIRED.getTemplateType(), buCode).getPostponeValue();
        OffsetDateTime expectedDateToSend1 = appointmentDateOutsideIdling.plus(Duration.parse(textualDurationList.get(0)));
        OffsetDateTime expectedDateToSend2 = appointmentDateOutsideIdling.plus(Duration.parse(textualDurationList.get(1)));
        OffsetDateTime expectedDateToSend3 = appointmentDateOutsideIdling.plus(Duration.parse(textualDurationList.get(2)));
        OffsetDateTime expectedDateToSend4 = appointmentDateOutsideIdling.plus(Duration.parse(textualDurationList.get(3)));

        when(eventProducer.sendEvents(ArgumentMatchers.anyList(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(SendCustomerOrderNotification.class), ArgumentMatchers.eq(expectedDateToSend1), ArgumentMatchers.anyString())).thenReturn(monoEmptyJPlus1);
        when(eventProducer.sendEvents(ArgumentMatchers.anyList(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(SendCustomerOrderNotification.class), ArgumentMatchers.eq(expectedDateToSend2), ArgumentMatchers.anyString())).thenReturn(monoEmptyJPlus2);
        when(eventProducer.sendEvents(ArgumentMatchers.anyList(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(SendCustomerOrderNotification.class), ArgumentMatchers.eq(expectedDateToSend3), ArgumentMatchers.anyString())).thenReturn(monoEmptyJPlus4);
        when(eventProducer.sendEvents(ArgumentMatchers.anyList(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(SendCustomerOrderNotification.class), ArgumentMatchers.eq(expectedDateToSend4), ArgumentMatchers.anyString())).thenReturn(monoEmptyJPlus7);

        StepVerifier.create(outgoingNotificationService.sendPickupInStoreAppointmentExpiredNotification(ruleEngineContext.getOrderData().getExistingCustomerOrder(), ruleEngineContext.getOrderData().getExistingLineExecutions()))
            .verifyComplete();

        monoEmptyJPlus1.expectHasBeenSubscribed();
        monoEmptyJPlus2.expectHasBeenSubscribed();
        monoEmptyJPlus4.expectHasBeenSubscribed();
        monoEmptyJPlus7.expectHasBeenSubscribed();

    }

    private static OffsetDateTime getParsedDate(DateFormat dtf, String textualDate) throws ParseException {
        return  Instant.ofEpochMilli(dtf.parse(textualDate).getTime())
            .atZone(ZoneId.systemDefault())
            .toOffsetDateTime();
    }

    private RuleEngineContext generateContext(OffsetDateTime appointmentDate){
        RuleEngineContext context = new RuleEngineContext();

        final CustomerOrder customerOrder = CustomerOrder.builder().buCode(buCode).id("22314516-d0a9-43af-9105-9fe13fb9bb11").version(1).firstValidatedAt(OffsetDateTime.now(ZoneId.of("Indian/Reunion"))).build();
        final LineExecutionDelivery lineExecutionDelivery = LineExecutionDelivery.builder()
            .appointmentDate(appointmentDate)
            .collect(LineExecutionDeliveryCollect.builder()
                .appointmentDate(appointmentDate)
                .build())
            .build();
        final LineExecution lineExecution = LineExecution.builder()
            .delivery(lineExecutionDelivery)
            .payment(LineExecutionPayment.builder()
                .storeId("295")
                .build())
            .build();
        context.getOrderData().setExistingCustomerOrder(customerOrder);
        context.getOrderData().setExistingLineExecutions(List.of(lineExecution));

        return context;
    }

    @TestConfiguration
    static class AdditionalConfig {

        @MockBean
        public TopicsProperties properties;
        @Autowired
        public PostponeNotificationEventConfiguration postponeNotificationEventConfiguration;
        @MockBean
        public EventProducer eventProducer;

        @Autowired
        public TimezonesConfiguration timezonesConfiguration;

        @Bean
        public OutgoingNotificationService outgoingNotificationService(){
            return new OutcomingNotificationServiceImpl(properties, postponeNotificationEventConfiguration, timezonesConfiguration, eventProducer);
        }

    }

}
