package com.adeo.sales.customerorder.tempoorchestrator.handler;

import com.adeo.featuretoggle.Feature;
import com.adeo.sales.customerorder.paymentscheduler.v2.common.DistributedClock;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.Execution;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.VectorClock;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.domainevent.CapturePaymentCaptureFailed;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.domainevent.CapturePaymentCaptureFailedDelta;
import com.adeo.sales.customerorder.paymentscheduler.v2.execution.domainevent.LineCapturePaymentCaptureFailed;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.PaymentCaptureFailedApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.psr.input.PaymentCaptureFailedInput;
import com.adeo.sales.customerorder.tempoorchestrator.handler.psr.CapturePaymentCaptureFailedHandler;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import reactor.test.StepVerifier;

import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaDataTestBuilder.mockEventMetaData;
import static org.mockito.ArgumentMatchers.any;

public class CapturePaymentCaptureFailedHandlerTest {

    @Test
    public void should_call_applicationservice_with_failed_lines() {
        final var applicationService = Mockito.mock(PaymentCaptureFailedApplicationService.class);
        final var mappedDiagnosticContext = Mockito.mock(MappedDiagnosticContext.class);

        final var handler = new CapturePaymentCaptureFailedHandler(applicationService, mappedDiagnosticContext);
        final var customerOrderId = "customerOrderId";
        final var line1Id = "line1Id";
        final var line2Id = "line2Id";
        final var rejectedLines = List.of(
            buildLine(line1Id),
            buildLine(line2Id)
        );
        final var event = buildCustomerOrderLinesPaymentCaptureFailed(customerOrderId, rejectedLines);
        final var monoMock = MonoMock.<Void>empty();
        final var featureMock = Mockito.mock(Feature.class);
        Mockito.when(featureMock.isEnabled()).thenReturn(MonoMock.just(false));
        Mockito.when(applicationService.apply(any())).thenReturn(monoMock);

        final var result = handler.handle(event, mockEventMetaData());

        StepVerifier.create(result)
            .verifyComplete();

        final var expectedInput = PaymentCaptureFailedInput.builder()
            .rejectedLineIds(List.of(line1Id, line2Id))
            .buCode("001")
            .customerOrderId(customerOrderId)
            .build();
        Mockito.verify(applicationService).apply(expectedInput);
        monoMock.expectHasBeenSubscribed();
    }

    private LineCapturePaymentCaptureFailed buildLine(String lineId) {
        return LineCapturePaymentCaptureFailed.newBuilder()
            .setCustomerOrderId("customerOrderId")
            .setType("3P")
            .setId(lineId)
            .build();
    }

    private CapturePaymentCaptureFailed buildCustomerOrderLinesPaymentCaptureFailed(String customerOrderId, List<LineCapturePaymentCaptureFailed> rejectedLines) {
        return CapturePaymentCaptureFailed.newBuilder()
            .setId("id")
            .setType("CapturePaymentCaptureFailed")
            .setState(Execution.newBuilder()
                .setId("1")
                .setCustomerOrderId(customerOrderId)
                .setCurrencyCode("EUR")
                .setSchedules(List.of())
                .setOperations(List.of())
                .setVectorClock(VectorClock.newBuilder()
                    .setExecution(DistributedClock.newBuilder()
                        .setId("1")
                        .setVersion(1)
                        .build())
                    .setDelivery(DistributedClock.newBuilder()
                        .setId("1")
                        .setVersion(1)
                        .build())
                    .setQuotation(DistributedClock.newBuilder()
                        .setId("1")
                        .setVersion(1)
                        .build())
                    .setProposition(DistributedClock.newBuilder()
                        .setId("1")
                        .setVersion(1)
                        .build())
                    .setCustomerOrder(DistributedClock.newBuilder()
                        .setId("1")
                        .setVersion(1)
                        .build())
                    .build())
                .build())
            .setDelta(CapturePaymentCaptureFailedDelta.newBuilder()
                .setId("1")
                .setCustomerOrderId(customerOrderId)
                .setLines(rejectedLines)
                .setVectorClock(VectorClock.newBuilder()
                    .setExecution(DistributedClock.newBuilder()
                        .setId("1")
                        .setVersion(1)
                        .build())
                    .setDelivery(DistributedClock.newBuilder()
                        .setId("1")
                        .setVersion(1)
                        .build())
                    .setQuotation(DistributedClock.newBuilder()
                        .setId("1")
                        .setVersion(1)
                        .build())
                    .setProposition(DistributedClock.newBuilder()
                        .setId("1")
                        .setVersion(1)
                        .build())
                    .setCustomerOrder(DistributedClock.newBuilder()
                        .setId("1")
                        .setVersion(1)
                        .build())
                    .build())
                .build())
            .build();
    }
}
