package com.adeo.sales.customerorder.tempoorchestrator.handler;

import org.mockito.Mockito;

import java.util.Optional;

public class EventMetaDataTestBuilder {

    public static EventMetaData mockEventMetaData() {
        final var mock = Mockito.mock(EventMetaData.class);
        Mockito.when(mock.getHeader("bu-code")).thenReturn(Optional.of("001"));
        Mockito.when(mock.getId()).thenReturn(Optional.of("id"));
        Mockito.when(mock.getTopic()).thenReturn("topic");

        return mock;
    }
}
