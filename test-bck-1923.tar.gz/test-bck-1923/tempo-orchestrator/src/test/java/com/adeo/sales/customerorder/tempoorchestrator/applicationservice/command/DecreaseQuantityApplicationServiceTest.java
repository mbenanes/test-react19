package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.ActionType;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.ExecutionData;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.LineData;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.OwnerRequest;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.command.input.UpdateExecutionInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.QuantityNotValidError;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem.SystemName.BOMP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.mockRuleEngineService;
import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class DecreaseQuantityApplicationServiceTest {

    @Mock
    private RuleEngineService ruleEngineService;

    @Captor
    private ArgumentCaptor<List<ExecutionAction>> executionActions;

    private DecreaseQuantityApplicationService applicationService;

    @BeforeEach
    void setUp() {
        applicationService = new DecreaseQuantityApplicationService(ruleEngineService);
    }

    @Test
    void should_create_execution_actions_if_quantity_is_correct() {
        CustomerOrder bddCustomerOrder = CustomerOrder.builder().build();
        List<LineExecution> bddLines = new ArrayList<>(List.of(
            generateALine(true, CustomerOrderLineDeliveryStatus.CREATED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, BOMP, OFFER)
        ));
        bddLines.get(0).setExecutionId("executionId");


        final var getDataCall = mockRuleEngineService(ruleEngineService, bddCustomerOrder, bddLines);

        List<ExecutionData> executionsToUpdate = new ArrayList<>();
        executionsToUpdate.add(ExecutionData.builder()
            .executionId("executionId")
            .lineData(new ArrayList<>(List.of(LineData.builder()
                .lineId(bddLines.get(0).getLineId())
                .quantity(new BigDecimal(1))
                .reason("reason")
                .build())))
            .build());

        StepVerifier.create(applicationService.apply(UpdateExecutionInput.builder()
                .buCode("001")
                .customerOrderId("1234")
                .requestId("requestId")
                .appSource("appsource")
                .ownerRequest(OwnerRequest.builder().build())
                .action(ActionType.DECREASE_QUANTITY)
                .executionsToUpdate(executionsToUpdate)
                .build()))
            .verifyComplete();

        getDataCall.expectHasBeenSubscribed();

        verify(ruleEngineService).startRuleEngineAndUpdateLines(any(CustomerOrder.class), anyList(), anyList(), executionActions.capture(), anyList());

        assertThat(executionActions.getValue()).hasSize(1);
    }

    @Test
    void should_not_create_execution_actions_if_quantity_are_already_decreased() {
        CustomerOrder bddCustomerOrder = CustomerOrder.builder().build();
        List<LineExecution> bddLines = new ArrayList<>(List.of(
            generateALine(true, CustomerOrderLineDeliveryStatus.CREATED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, BOMP, OFFER)
        ));

        bddLines.get(0).setExecutionId("executionId");

        final var createdExecutionActionFlag = new Flags<ExecutionActionStatus>();
        createdExecutionActionFlag.raiseFlagIfNot(ExecutionActionStatus.CREATED);
        List<ExecutionAction> executionActionsInBdd = new ArrayList<>();
        executionActionsInBdd.add(ExecutionAction.builder()
                .flags(createdExecutionActionFlag)
            .actionType(ExecutionActionType.DECREASE_QUANTITY)
            .requestId("old_requestId")
            .customerOrderId("1234")
            .buCode("001")
            .impactedExecutions(List.of(ImpactedExecution.builder()
                .currentExecutionId("executionId")
                .impactedLines(List.of(ImpactedLine.builder()
                    .quantity(new BigDecimal(1))
                    .reason("aReason")
                    .lineId(bddLines.get(0).getLineId())
                    .build()))
                .build()))
            .build());

        final var getDataCall = mockRuleEngineService(ruleEngineService, bddCustomerOrder, bddLines, executionActionsInBdd);

        List<ExecutionData> executionsToUpdate = new ArrayList<>();
        executionsToUpdate.add(ExecutionData.builder()
            .executionId("executionId")
            .lineData(new ArrayList<>(List.of(LineData.builder()
                .lineId(bddLines.get(0).getLineId())
                .quantity(new BigDecimal(1))
                .reason("reason")
                .build())))
            .build());

        StepVerifier.create(applicationService.apply(UpdateExecutionInput.builder()
                .buCode("001")
                .customerOrderId("1234")
                .requestId("requestId")
                .appSource("appsource")
                .ownerRequest(OwnerRequest.builder().build())
                .action(ActionType.DECREASE_QUANTITY)
                .executionsToUpdate(executionsToUpdate)
                .build()))
            .verifyError(QuantityNotValidError.class);

        getDataCall.expectHasBeenSubscribed();

        verify(ruleEngineService).startRuleEngineAndUpdateLines(any(CustomerOrder.class), anyList(), anyList(), executionActions.capture(), anyList());

        assertThat(executionActions.getValue()).hasSize(1);
    }

    @Test
    void should_create_execution_actions_if_quantity_are_not_all_already_decreased_in_progress() {
        CustomerOrder bddCustomerOrder = CustomerOrder.builder().build();
        final LineExecution lineExecution = generateALine(true, CustomerOrderLineDeliveryStatus.CREATED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, BOMP, OFFER);
        lineExecution.setInitialQuantity(new BigDecimal(3));
        lineExecution.setQuantity(new BigDecimal(2));
        lineExecution.getComposition().setQuantity(new BigDecimal(2));

        List<LineExecution> bddLines = new ArrayList<>(List.of(
lineExecution
        ));
        bddLines.get(0).setExecutionId("executionId");

        final var createdExecutionActionFlag = new Flags<ExecutionActionStatus>();
        createdExecutionActionFlag.raiseFlagIfNot(ExecutionActionStatus.CREATED);

        final var completedExecutionActionFlag = new Flags<ExecutionActionStatus>();
        completedExecutionActionFlag.raiseFlagIfNot(ExecutionActionStatus.COMPLETED);

        final ExecutionAction firstExecutionAction = ExecutionAction.builder()
            .flags(completedExecutionActionFlag)
            .actionType(ExecutionActionType.DECREASE_QUANTITY)
            .requestId("old_requestId")
            .customerOrderId("1234")
            .buCode("001")
            .impactedExecutions(List.of(ImpactedExecution.builder()
                .currentExecutionId("executionId")
                .impactedLines(List.of(ImpactedLine.builder()
                    .quantity(new BigDecimal(1))
                    .reason("aReason")
                    .lineId(bddLines.get(0).getLineId())
                    .build()))
                .build()))
            .build();

        final ExecutionAction secondExecutionAction = ExecutionAction.builder()
            .flags(createdExecutionActionFlag)
            .actionType(ExecutionActionType.DECREASE_QUANTITY)
            .requestId("old_requestId")
            .customerOrderId("1234")
            .buCode("001")
            .impactedExecutions(List.of(ImpactedExecution.builder()
                .currentExecutionId("executionId")
                .impactedLines(List.of(ImpactedLine.builder()
                    .quantity(new BigDecimal(1))
                    .reason("aReason")
                    .lineId(bddLines.get(0).getLineId())
                    .build()))
                .build()))
            .build();


        List<ExecutionAction> executionActionsInBdd = new ArrayList<>();
        executionActionsInBdd.addAll(List.of(firstExecutionAction, secondExecutionAction));

        final var getDataCall = mockRuleEngineService(ruleEngineService, bddCustomerOrder, bddLines, executionActionsInBdd);

        List<ExecutionData> executionsToUpdate = new ArrayList<>();
        executionsToUpdate.add(ExecutionData.builder()
            .executionId("executionId")
            .lineData(new ArrayList<>(List.of(LineData.builder()
                .lineId(bddLines.get(0).getLineId())
                .quantity(new BigDecimal(1))
                .reason("reason")
                .build())))
            .build());

        StepVerifier.create(applicationService.apply(UpdateExecutionInput.builder()
                .buCode("001")
                .customerOrderId("1234")
                .requestId("requestId")
                .appSource("appsource")
                .ownerRequest(OwnerRequest.builder().build())
                .action(ActionType.DECREASE_QUANTITY)
                .executionsToUpdate(executionsToUpdate)
                .build()))
            .verifyComplete();

        getDataCall.expectHasBeenSubscribed();

        verify(ruleEngineService).startRuleEngineAndUpdateLines(any(CustomerOrder.class), anyList(), anyList(), executionActions.capture(), anyList());

        assertThat(executionActions.getValue()).hasSize(3);
    }

    @Test
    void should_not_create_execution_actions_if_quantity_are_all_already_decreased_in_progress() {
        CustomerOrder bddCustomerOrder = CustomerOrder.builder().build();
        final LineExecution lineExecution = generateALine(true, CustomerOrderLineDeliveryStatus.CREATED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, BOMP, OFFER);
        lineExecution.setInitialQuantity(new BigDecimal(3));
        lineExecution.setQuantity(new BigDecimal(1));
        lineExecution.getComposition().setQuantity(new BigDecimal(1));

        List<LineExecution> bddLines = new ArrayList<>(List.of(
            lineExecution
        ));
        bddLines.get(0).setExecutionId("executionId");

        final var createdExecutionActionFlag = new Flags<ExecutionActionStatus>();
        createdExecutionActionFlag.raiseFlagIfNot(ExecutionActionStatus.CREATED);

        final var completedExecutionActionFlag = new Flags<ExecutionActionStatus>();
        completedExecutionActionFlag.raiseFlagIfNot(ExecutionActionStatus.COMPLETED);

        final ExecutionAction firstExecutionAction = ExecutionAction.builder()
            .flags(completedExecutionActionFlag)
            .actionType(ExecutionActionType.DECREASE_QUANTITY)
            .requestId("old_requestId")
            .customerOrderId("1234")
            .buCode("001")
            .impactedExecutions(List.of(ImpactedExecution.builder()
                .currentExecutionId("executionId")
                .impactedLines(List.of(ImpactedLine.builder()
                    .quantity(new BigDecimal(1))
                    .reason("aReason")
                    .lineId(bddLines.get(0).getLineId())
                    .build()))
                .build()))
            .build();

        final ExecutionAction secondExecutionAction = ExecutionAction.builder()
            .flags(createdExecutionActionFlag)
            .actionType(ExecutionActionType.DECREASE_QUANTITY)
            .requestId("old_requestId")
            .customerOrderId("1234")
            .buCode("001")
            .impactedExecutions(List.of(ImpactedExecution.builder()
                .currentExecutionId("executionId")
                .impactedLines(List.of(ImpactedLine.builder()
                    .quantity(new BigDecimal(1))
                    .reason("aReason")
                    .lineId(bddLines.get(0).getLineId())
                    .build()))
                .build()))
            .build();


        List<ExecutionAction> executionActionsInBdd = new ArrayList<>();
        executionActionsInBdd.addAll(List.of(firstExecutionAction, secondExecutionAction));

        final var getDataCall = mockRuleEngineService(ruleEngineService, bddCustomerOrder, bddLines, executionActionsInBdd);

        List<ExecutionData> executionsToUpdate = new ArrayList<>();
        executionsToUpdate.add(ExecutionData.builder()
            .executionId("executionId")
            .lineData(new ArrayList<>(List.of(LineData.builder()
                .lineId(bddLines.get(0).getLineId())
                .quantity(new BigDecimal(1))
                .reason("reason")
                .build())))
            .build());

        StepVerifier.create(applicationService.apply(UpdateExecutionInput.builder()
                .buCode("001")
                .customerOrderId("1234")
                .requestId("requestId")
                .appSource("appsource")
                .ownerRequest(OwnerRequest.builder().build())
                .action(ActionType.DECREASE_QUANTITY)
                .executionsToUpdate(executionsToUpdate)
                .build()))
            .verifyError(QuantityNotValidError.class);

        getDataCall.expectHasBeenSubscribed();

        verify(ruleEngineService).startRuleEngineAndUpdateLines(any(CustomerOrder.class), anyList(), anyList(), executionActions.capture(), anyList());

        assertThat(executionActions.getValue()).hasSize(2);
    }
}
