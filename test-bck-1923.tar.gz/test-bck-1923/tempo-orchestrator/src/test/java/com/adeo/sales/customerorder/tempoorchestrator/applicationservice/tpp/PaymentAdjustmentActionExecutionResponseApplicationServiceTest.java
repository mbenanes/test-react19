package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentAdjustmentActionExecutionResponseInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppErrorType;
import com.adeo.sales.customerorder.tempoorchestrator.model.Clock;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.util.function.Tuples;

import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.READ_ADJUSTMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateActionExecutionFromLines;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.initializeSteps;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PaymentAdjustmentActionExecutionResponseApplicationServiceTest {
    private PaymentAdjustmentActionExecutionResponseApplicationService service;

    @Mock
    private RuleEngineService ruleEngineService;

    @BeforeEach
    void setUp() {
        service = new PaymentAdjustmentActionExecutionResponseApplicationService(ruleEngineService);
    }

    @Test
    void shouldSetExecuteAdjustmentStepToCompleted() {
        String policyId = UUID.randomUUID().toString();

        List<LineExecution> bddLines = List.of(
            RuleTestUtils.generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER)
        );
        bddLines.get(0).setLineId(UUID.randomUUID().toString());
        bddLines.get(0).setVersion(1);

        String executionId = UUID.randomUUID().toString();
        bddLines.get(0).setExecutionId(executionId);

        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .paymentExecutionPolicy(new Clock(policyId, 1))
            .id(UUID.randomUUID().toString())
            .buCode("001")
            .build();

        String paymentAdjustmentActionId = UUID.randomUUID().toString();

        PaymentAdjustmentActionExecutionResponseInput input = PaymentAdjustmentActionExecutionResponseInput.builder()
            .customerOrderId(bddCustomerOrder.getId())
            .buCode(bddCustomerOrder.getBuCode())
            .status("APPROVED")
            .tppVersion(2)
            .paymentAdjustmentActionIds(List.of(paymentAdjustmentActionId))
            .build();

        ExecutionAction executionAction = generateActionExecutionFromLines(bddCustomerOrder.getId(), bddLines, ExecutionActionType.DECREASE_QUANTITY);
        executionAction.getFlags().raiseFlag(ExecutionActionStatus.PROCESSING);

        ImpactedExecution impactedExecutionSfw = executionAction.getImpactedExecutionByExecutionId(bddLines.get(0).getExecutionId()).get();

        initializeSteps(impactedExecutionSfw, List.of(DECREASE_QUANTITY_DELIVERY, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP, EXECUTE_ADJUSTMENT_TPP), List.of(DECREASE_QUANTITY_DELIVERY, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP));

        ImpactedLine.getCorrespondingLine(impactedExecutionSfw.getImpactedLines(), bddLines.get(0).getLineId()).ifPresent(line -> {
            line.setPaymentAdjustmentActionId(paymentAdjustmentActionId);
            line.getStepOfType(EXECUTE_ADJUSTMENT_TPP).ifPresent(s -> s.getFlags().raiseFlag(ImpactedLineStep.Status.PROCESSING));
        });

        when(ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
            .thenReturn(
                Mono.just(Tuples.of(bddCustomerOrder, bddLines, List.of(), List.of(executionAction), List.of()))
            );
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> Mono.empty());

        StepVerifier.create(service.apply(input)).verifyComplete();

        verify(ruleEngineService, times(1)).lockAndGetData(input.getCustomerOrderId(), input.getBuCode());

        assertThat(ImpactedLine.getCorrespondingLine(impactedExecutionSfw.getImpactedLines(), bddLines.get(0).getLineId()).stream().anyMatch(il -> il.getStepOfType(EXECUTE_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getFlags().lastFlagIs(ImpactedLineStep.Status.COMPLETED)))).isTrue();
    }


    @Test
    void shouldSetExecuteAdjustmentStepToFailed() {
        String policyId = UUID.randomUUID().toString();

        List<LineExecution> bddLines = List.of(
            RuleTestUtils.generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER)
        );
        bddLines.get(0).setLineId(UUID.randomUUID().toString());
        bddLines.get(0).setVersion(1);

        String executionId = UUID.randomUUID().toString();
        bddLines.get(0).setExecutionId(executionId);

        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .paymentExecutionPolicy(new Clock(policyId, 1))
            .id(UUID.randomUUID().toString())
            .buCode("001")
            .build();

        String paymentAdjustmentActionId = UUID.randomUUID().toString();

        PaymentAdjustmentActionExecutionResponseInput input = PaymentAdjustmentActionExecutionResponseInput.builder()
            .customerOrderId(bddCustomerOrder.getId())
            .buCode(bddCustomerOrder.getBuCode())
            .status("REJECTED")
            .tppVersion(2)
            .paymentAdjustmentActionIds(List.of(paymentAdjustmentActionId))
            .build();

        ExecutionAction executionAction = generateActionExecutionFromLines(bddCustomerOrder.getId(), bddLines, ExecutionActionType.DECREASE_QUANTITY);
        executionAction.getFlags().raiseFlag(ExecutionActionStatus.PROCESSING);

        ImpactedExecution impactedExecutionSfw = executionAction.getImpactedExecutionByExecutionId(bddLines.get(0).getExecutionId()).get();

        initializeSteps(impactedExecutionSfw, List.of(DECREASE_QUANTITY_DELIVERY, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP, EXECUTE_ADJUSTMENT_TPP), List.of(DECREASE_QUANTITY_DELIVERY, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP));

        ImpactedLine.getCorrespondingLine(impactedExecutionSfw.getImpactedLines(), bddLines.get(0).getLineId()).ifPresent(line -> {
            line.setPaymentAdjustmentActionId(paymentAdjustmentActionId);
            line.getStepOfType(EXECUTE_ADJUSTMENT_TPP).ifPresent(s -> s.getFlags().raiseFlag(ImpactedLineStep.Status.PROCESSING));
        });

        when(ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
            .thenReturn(
                Mono.just(Tuples.of(bddCustomerOrder, bddLines, List.of(), List.of(executionAction), List.of()))
            );
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> Mono.empty());

        StepVerifier.create(service.apply(input)).verifyComplete();

        verify(ruleEngineService, times(1)).lockAndGetData(input.getCustomerOrderId(), input.getBuCode());

        assertThat(ImpactedLine.getCorrespondingLine(impactedExecutionSfw.getImpactedLines(), bddLines.get(0).getLineId()).stream().anyMatch(il -> il.getStepOfType(EXECUTE_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getFlags().lastFlagIs(ImpactedLineStep.Status.FAILED)))).isTrue();
        assertThat(bddLines.get(0).getPaymentRequirements().isVersionMismatch()).isFalse();
    }

    @Test
    void shouldSetExecuteAdjustmentStepToCreatedAndVersionMissmatch() {
        String policyId = UUID.randomUUID().toString();

        List<LineExecution> bddLines = List.of(
            RuleTestUtils.generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER)
        );
        bddLines.get(0).setLineId(UUID.randomUUID().toString());
        bddLines.get(0).setVersion(1);

        String executionId = UUID.randomUUID().toString();
        bddLines.get(0).setExecutionId(executionId);

        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .paymentExecutionPolicy(new Clock(policyId, 1))
            .id(UUID.randomUUID().toString())
            .buCode("001")
            .build();

        String paymentAdjustmentActionId = UUID.randomUUID().toString();

        PaymentAdjustmentActionExecutionResponseInput input = PaymentAdjustmentActionExecutionResponseInput.builder()
            .customerOrderId(bddCustomerOrder.getId())
            .buCode(bddCustomerOrder.getBuCode())
            .status("REJECTED")
            .tppVersion(2)
            .tppErrorType(TppErrorType.PAYMENT_EXECUTION_POLICY_VERSION_MISMATCH.name())
            .paymentAdjustmentActionIds(List.of(paymentAdjustmentActionId))
            .build();

        ExecutionAction executionAction = generateActionExecutionFromLines(bddCustomerOrder.getId(), bddLines, ExecutionActionType.DECREASE_QUANTITY);
        executionAction.getFlags().raiseFlag(ExecutionActionStatus.PROCESSING);

        ImpactedExecution impactedExecutionSfw = executionAction.getImpactedExecutionByExecutionId(bddLines.get(0).getExecutionId()).get();

        initializeSteps(impactedExecutionSfw, List.of(DECREASE_QUANTITY_DELIVERY, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP, EXECUTE_ADJUSTMENT_TPP), List.of(DECREASE_QUANTITY_DELIVERY, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP));

        ImpactedLine.getCorrespondingLine(impactedExecutionSfw.getImpactedLines(), bddLines.get(0).getLineId()).ifPresent(line -> {
            line.setPaymentAdjustmentActionId(paymentAdjustmentActionId);
            line.getStepOfType(EXECUTE_ADJUSTMENT_TPP).ifPresent(s -> s.getFlags().raiseFlag(ImpactedLineStep.Status.PROCESSING));
        });

        when(ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
            .thenReturn(
                Mono.just(Tuples.of(bddCustomerOrder, bddLines, List.of(), List.of(executionAction), List.of()))
            );
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> Mono.empty());

        StepVerifier.create(service.apply(input)).verifyComplete();

        verify(ruleEngineService, times(1)).lockAndGetData(input.getCustomerOrderId(), input.getBuCode());

        assertThat(ImpactedLine.getCorrespondingLine(impactedExecutionSfw.getImpactedLines(), bddLines.get(0).getLineId()).stream().anyMatch(il -> il.getStepOfType(EXECUTE_ADJUSTMENT_TPP).stream().anyMatch(step -> step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED)))).isTrue();

        assertThat(bddLines.get(0).getPaymentRequirements().isVersionMismatch()).isTrue();
    }
}
