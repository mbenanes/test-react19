package com.adeo.sales.customerorder.tempoorchestrator.v3.rule.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppErrorType;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.tpp.AskOwnerShipTransferRequirementExecutionRule;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.StockValuationStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.service.TppCommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AskOwnerShipTransfertRequirementExectionTest {

    private AskOwnerShipTransferRequirementExecutionRule askOwnerShipTransfertRequirementExection;


    @Mock
    private TppCommandEventService tppCommandEventService;

    @Captor
    private ArgumentCaptor<List<LineExecution>> linesCaptorFirst;

    @Captor
    private ArgumentCaptor<List<LineExecution>> linesCaptorSecond;

    @BeforeEach
    void setUp() {
        askOwnerShipTransfertRequirementExection = new AskOwnerShipTransferRequirementExecutionRule(tppCommandEventService);
    }


    @Test
    void should_send_ownerShipTransfer_requirement_command_on_right_predicate() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "EXW", OFFER);
        LineExecution secondLineSFW = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, "DDP", OFFER);

        //move to requirement delivery step completed and stock valuate.
        firstLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));
        secondLineSFW.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));

        Execution execution1 = Execution.builder()
            .id(UUID.randomUUID().toString())
            .build();
        Execution execution2 = Execution.builder()
            .id(UUID.randomUUID().toString())
            .build();
        firstLineSFP.setExecutionId(execution1.getId());
        secondLineSFW.setExecutionId(execution2.getId());

        context.setOrderData(OrderData.builder()
            .executionActions(List.of())
            .existingLineExecutions(List.of(
                firstLineSFP, secondLineSFW
            ))
            .executions(List.of(execution1, execution2))
            .existingCustomerOrder(CustomerOrder.builder().buCode("001").status(CustomerOrderStatus.VALIDATED).build())
            .build());

        MonoMock<String> commandServiceCallFirst = MonoMock.just("operationId1");
        when(this.tppCommandEventService.sendActionTypeRequirement(any(CustomerOrder.class), eq(firstLineSFP.getExecutionId()), linesCaptorFirst.capture(), any(Instant.class), eq(ActionType.OWNERSHIP_TRANSFER))).thenReturn(commandServiceCallFirst);

        MonoMock<String> commandServiceCallSecond = MonoMock.just("operationId2");
        when(this.tppCommandEventService.sendActionTypeRequirement(any(CustomerOrder.class), eq(secondLineSFW.getExecutionId()), linesCaptorSecond.capture(), any(Instant.class), eq(ActionType.OWNERSHIP_TRANSFER))).thenReturn(commandServiceCallSecond);

        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isTrue();

        StepVerifier.create(this.askOwnerShipTransfertRequirementExection.then(context)).verifyComplete();

        commandServiceCallFirst.expectHasBeenSubscribed();
        commandServiceCallSecond.expectHasBeenSubscribed();

        assertThat(linesCaptorFirst.getValue()).hasSize(1);
        assertThat(linesCaptorFirst.getValue().get(0)).isEqualTo(firstLineSFP);
        assertThat(linesCaptorFirst.getValue().get(0).getPaymentRequirements().getOwnerShippedTransfertFlags().lastFlagIs(RequirementStatus.REQUESTED)).isTrue();
        assertThat(linesCaptorFirst.getValue().get(0).getPaymentRequirements().getOwnerShippedTransfertFlags().getLastFlag().getOperationId()).isEqualTo("operationId1");

        assertThat(linesCaptorSecond.getValue()).hasSize(1);
        assertThat(linesCaptorSecond.getValue().get(0)).isEqualTo(secondLineSFW);
        assertThat(linesCaptorSecond.getValue().get(0).getPaymentRequirements().getOwnerShippedTransfertFlags().lastFlagIs(RequirementStatus.REQUESTED)).isTrue();
        assertThat(linesCaptorSecond.getValue().get(0).getPaymentRequirements().getOwnerShippedTransfertFlags().getLastFlag().getOperationId()).isEqualTo("operationId2");

        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isFalse();
    }

    @Test
    void should_not_send_ownerShipTransfer_requirement_command_with_associated_product_with_service_if_all_associated_product_are_not_ready() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution serviceLine = generateALine(false, CustomerOrderLineDeliveryStatus.CREATION_REQUESTED, true, true, CompositionOrderStatus.VALIDATED, null, null, SERVICE);
        LineExecution secondLineSFW = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);

        Execution execution1 = Execution.builder()
            .id(UUID.randomUUID().toString())
            .build();
        serviceLine.setExecutionId(execution1.getId());
        secondLineSFW.setExecutionId(execution1.getId());

        context.setOrderData(OrderData.builder()
            .executionActions(List.of())
            .existingLineExecutions(List.of(
                serviceLine, secondLineSFW
            ))
            .executions(List.of(execution1))
            .existingCustomerOrder(CustomerOrder.builder().buCode("001").status(CustomerOrderStatus.VALIDATED).build())
            .build());

        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isFalse();
    }

    @Test
    void should_send_ownerShipTransfer_requirement_command_with_associated_product_with_service() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution serviceLine = generateALine(false, CustomerOrderLineDeliveryStatus.CREATION_REQUESTED, true, true, CompositionOrderStatus.VALIDATED, null, null, SERVICE);
        LineExecution secondLineSFW = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, "DDP", OFFER);

        //move to requirement delivery step completed and stock valuate.
        serviceLine.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));
        secondLineSFW.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));

        Execution execution1 = Execution.builder()
            .id(UUID.randomUUID().toString())
            .build();
        serviceLine.setExecutionId(execution1.getId());
        secondLineSFW.setExecutionId(execution1.getId());

        context.setOrderData(OrderData.builder()
            .executionActions(List.of())
            .existingLineExecutions(List.of(
                serviceLine, secondLineSFW
            ))
            .executions(List.of(execution1))
            .existingCustomerOrder(CustomerOrder.builder().buCode("001").status(CustomerOrderStatus.VALIDATED).build())
            .build());

        MonoMock<String> commandServiceCallFirst = MonoMock.just("operationId1");
        when(this.tppCommandEventService.sendActionTypeRequirement(any(CustomerOrder.class), eq(serviceLine.getExecutionId()), linesCaptorFirst.capture(), any(Instant.class), eq(ActionType.OWNERSHIP_TRANSFER))).thenReturn(commandServiceCallFirst);

        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isTrue();

        StepVerifier.create(this.askOwnerShipTransfertRequirementExection.then(context)).verifyComplete();

        commandServiceCallFirst.expectHasBeenSubscribed();

        assertThat(linesCaptorFirst.getAllValues()).hasSize(1);
        assertThat(linesCaptorFirst.getValue()).hasSize(2);
        assertThat(linesCaptorFirst.getValue()).contains(secondLineSFW);
        assertThat(linesCaptorFirst.getValue()).contains(serviceLine);
        linesCaptorFirst.getValue().forEach(line -> {
            assertThat(line.getPaymentRequirements().getOwnerShippedTransfertFlags().lastFlagIs(RequirementStatus.REQUESTED)).isTrue();
            assertThat(line.getPaymentRequirements().getOwnerShippedTransfertFlags().getLastFlag().getOperationId()).isEqualTo("operationId1");
        });

        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isFalse();
    }

    @Test
    void should_not_ask_ownerShipTransfert_requirement_when_sfp_incoterm_is_not_compliant() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, null, OFFER);
        LineExecution thirdLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "DDP", OFFER);

        //move to requirement delivery step completed and stock valuate.
        firstLineSFP.getPaymentRequirements().getShippingFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));
        thirdLineSFP.getPaymentRequirements().getShippingFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));


        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                firstLineSFP, thirdLineSFP
            ))
            .existingCustomerOrder(CustomerOrder.builder().buCode("001").status(CustomerOrderStatus.VALIDATED).build())
            .executionActions(List.of())
            .executions(List.of())
            .build());

        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isFalse();

    }

    @Test
    void should_not_ask_ownerShipTransfert_requirement_when_not_delivery_requirement_not_completed() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "EXW", OFFER);
        LineExecution secondLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "DDP", OFFER);

        Execution execution = Execution.builder()
            .id(UUID.randomUUID().toString())
            .build();
        firstLineSFP.setExecutionId(execution.getId());
        secondLineSFP.setExecutionId(execution.getId());

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                firstLineSFP, secondLineSFP
            ))
            .existingCustomerOrder(CustomerOrder.builder().buCode("001").status(CustomerOrderStatus.VALIDATED).build())
            .executionActions(List.of())
            .executions(List.of(execution))
            .build());

        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isFalse();

        firstLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.REQUESTED, Instant.now().atOffset(ZoneOffset.UTC));
        secondLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.REQUESTED, Instant.now().atOffset(ZoneOffset.UTC));

        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isFalse();

    }

    @Test
    void should_not_ask_delivery_requirement_when_composition_is_not_validate() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.CANCELED, DeliveryType.SFP, "EXW", OFFER);
        LineExecution secondLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.CANCELED, DeliveryType.SFP, "DDP", OFFER);

        //move to requirement delivery step completed and stock valuate.
        firstLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));
        firstLineSFP.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_SUCCEED);
        secondLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));
        secondLineSFP.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_SUCCEED);

        Execution execution = Execution.builder()
            .id(UUID.randomUUID().toString())
            .build();
        firstLineSFP.setExecutionId(execution.getId());
        secondLineSFP.setExecutionId(execution.getId());

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                firstLineSFP, secondLineSFP
            ))
            .executions(List.of(execution))
            .executionActions(List.of())
            .existingCustomerOrder(CustomerOrder.builder().buCode("001").status(CustomerOrderStatus.VALIDATED).build())
            .build());

        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isFalse();
    }


    @Test
    void should_not_start_rule_if_is_already_on_failure_state_or_already_done() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "EXW", OFFER);
        LineExecution secondLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "DDP", OFFER);

        //move to requirement delivery step completed and stock valuate.
        firstLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));
        firstLineSFP.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_SUCCEED);
        secondLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));
        secondLineSFP.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_SUCCEED);

        Execution execution = Execution.builder()
            .id(UUID.randomUUID().toString())
            .build();
        firstLineSFP.setExecutionId(execution.getId());
        secondLineSFP.setExecutionId(execution.getId());

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                firstLineSFP, secondLineSFP
            ))
            .executionActions(List.of())
            .executions(List.of(execution))
            .existingCustomerOrder(CustomerOrder.builder().buCode("001").status(CustomerOrderStatus.VALIDATED).build())
            .build());

        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isTrue();

        firstLineSFP.getPaymentRequirements().getOwnerShippedTransfertFlags().raiseFlag(RequirementStatus.REJECTED);
        secondLineSFP.getPaymentRequirements().getOwnerShippedTransfertFlags().raiseFlag(RequirementStatus.REJECTED);

        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isFalse();

        firstLineSFP.getPaymentRequirements().getOwnerShippedTransfertFlags().raiseFlagWithFailedReason(RequirementStatus.FAILED, TppErrorType.PAYMENT_EXECUTION_POLICY_VERSION_MISMATCH.name());
        firstLineSFP.getPaymentRequirements().setVersionMismatch(true);
        secondLineSFP.getPaymentRequirements().getOwnerShippedTransfertFlags().raiseFlagWithFailedReason(RequirementStatus.FAILED, TppErrorType.PAYMENT_EXECUTION_POLICY_VERSION_MISMATCH.name());
        secondLineSFP.getPaymentRequirements().setVersionMismatch(true);

        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isFalse();

        firstLineSFP.getPaymentRequirements().setVersionMismatch(false);
        secondLineSFP.getPaymentRequirements().setVersionMismatch(false);
        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isTrue();

        firstLineSFP.getPaymentRequirements().getOwnerShippedTransfertFlags().raiseFlag(RequirementStatus.APPROVED);
        secondLineSFP.getPaymentRequirements().getOwnerShippedTransfertFlags().raiseFlag(RequirementStatus.APPROVED);
        assertThat(this.askOwnerShipTransfertRequirementExection.when(context)).isFalse();
    }

}
