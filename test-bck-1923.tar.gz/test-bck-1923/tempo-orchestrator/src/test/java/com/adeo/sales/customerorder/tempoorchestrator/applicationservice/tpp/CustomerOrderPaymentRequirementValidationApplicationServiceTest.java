package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.CreateOrUpdateCustomerOrderApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentRequirementComplianceReason;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentRequirementValidationInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.Clock;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.repository.impl.LockPosgresRepository;
import com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.encoder.org.apache.commons.lang3.BooleanUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.transaction.ReactiveTransaction;
import org.springframework.transaction.ReactiveTransactionManager;
import org.springframework.transaction.interceptor.DefaultTransactionAttribute;
import org.springframework.transaction.interceptor.TransactionAttribute;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.util.function.Tuples;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class CustomerOrderPaymentRequirementValidationApplicationServiceTest {

    private CustomerOrderPaymentRequirementValidationApplicationService service;
    @Mock
    private CreateOrUpdateCustomerOrderApplicationService createOrUpdateCustomerOrderApplicationService;

    @Mock
    private RuleEngineService ruleEngineService;

    @Mock
    private final ReactiveTransactionManager transactionManager = mock(ReactiveTransactionManager.class);

    @Mock
    private final ReactiveTransaction status = mock(ReactiveTransaction.class);

    @Mock
    private LockPosgresRepository lockPosgresRepository;

    @Captor
    private ArgumentCaptor<List<LineExecution>> linesCaptor;

    @BeforeEach
    void setUp() {
        service = new CustomerOrderPaymentRequirementValidationApplicationService(createOrUpdateCustomerOrderApplicationService, ruleEngineService, lockPosgresRepository, transactionManager);
        TransactionAttribute transactionAttribute = new DefaultTransactionAttribute();

        when(transactionManager.getReactiveTransaction(transactionAttribute)).thenReturn(Mono.just(status));
        when(transactionManager.commit(status)).thenReturn(Mono.empty());
        when(lockPosgresRepository.acquireLocks(any(Long.class))).thenReturn(Mono.empty());
    }

    @ParameterizedTest
    @CsvSource(
        value = {
            "true,CONFIRMATION_AMOUNT_NEEDED_REACHED,false,false",
            "false,CONFIRMATION_AMOUNT_NEEDED_REACHED,false,false",
            "true,PENDING_AMOUNT_NOT_NULL_AND_HIGH_PENDING_SCORE,true,true",
            "false,PENDING_AMOUNT_NOT_NULL_AND_HIGH_PENDING_SCORE,false,true",
            "true,REQUESTED_BY_COLLABORATOR_OR_SYSTEM,true,null",
            "false,REQUESTED_BY_COLLABORATOR_OR_SYSTEM,false,null"
        },
        nullValues = {"null"}
    )
    void should_create_customer_order_with_minimal_data(String inputStockReservationFlag, String inputStockReservationReason, String stockReservationFlagAssertion, String delayedPaymentAssertion) {
        when(transactionManager.rollback(status)).thenReturn(Mono.empty());

        String lineId = UUID.randomUUID().toString();
        String policyId = UUID.randomUUID().toString();
        PaymentRequirementValidationInput input = PaymentRequirementValidationInput.builder()
            .customerOrderId(UUID.randomUUID().toString())
            .buCode("001")
            .executionPolicyId(policyId)
            .executionPolicyVersion(1)
            .lines(List.of(PaymentRequirementValidationInput.Line.builder()
                .id(lineId)
                .validationRequirementCompliance(generateCompliant(true))
                .confirmationRequirementCompliance(generateCompliant(true))
                .vendorOrderCreationRequirementCompliance(generateCompliant(false))
                .stockReservationRequirementCompliance(generateCompliant(BooleanUtils.toBoolean(inputStockReservationFlag), inputStockReservationReason))
                .build()))
            .build();


        List<LineExecution> bddLines = List.of(RuleTestUtils.generateALine(false, null, false, false, null, null, null, OFFER));
        bddLines.get(0).setLineId(lineId);
        bddLines.get(0).setVersion(1);

        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .paymentExecutionPolicy(new Clock(policyId, 1))
            .build();

        when(ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
            .thenReturn(
                Mono.error(new CustomerOrderNotFound("")),
                Mono.just(Tuples.of(bddCustomerOrder, bddLines, List.of(), List.of(), List.of()))
            );

        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> Mono.empty());
        lenient().when(createOrUpdateCustomerOrderApplicationService.createOrderAndLines(any(CustomerOrder.class), linesCaptor.capture())).thenReturn(Mono.empty());

        StepVerifier.create(service.apply(input)).verifyComplete();

        verify(ruleEngineService, times(2)).lockAndGetData(input.getCustomerOrderId(), input.getBuCode());
        verify(createOrUpdateCustomerOrderApplicationService, times(1)).createOrderAndLines(any(CustomerOrder.class), linesCaptor.capture());

        List<LineExecution> updatedLines = linesCaptor.getValue();

        assertThat(updatedLines).isNotEmpty();
        LineExecution firstLine = updatedLines.get(0);
        assertThat(firstLine.getVersion()).isEqualTo(1);
        assertThat(firstLine.getPaymentRequirements().getValidationFlags().lastFlagIs(RequirementStatus.COMPLIANT)).isTrue();
        assertThat(firstLine.getPaymentRequirements().getValidationFlags().getLastFlag().getOperationId()).isNotNull();
        assertThat(firstLine.getPaymentRequirements().getValidationFlags().getLastFlag().getDateTime()).isNotNull();
        assertThat(firstLine.getPaymentRequirements().getConfirmationFlags().lastFlagIs(RequirementStatus.COMPLIANT)).isTrue();
        assertThat(firstLine.getPaymentRequirements().getConfirmationFlags().getLastFlag().getOperationId()).isNotNull();
        assertThat(firstLine.getPaymentRequirements().getConfirmationFlags().getLastFlag().getDateTime()).isNotNull();
        assertThat(firstLine.getPayment().getIsDelayedPayment()).isEqualTo(delayedPaymentAssertion != null ? BooleanUtils.toBoolean(delayedPaymentAssertion) : null);
        assertThat(firstLine.getPaymentRequirements().getStockReservationFlags().lastFlagIs(RequirementStatus.COMPLIANT)).isEqualTo(BooleanUtils.toBoolean(stockReservationFlagAssertion));
        assertThat(firstLine.getPaymentRequirements().getVendorOrderCreationFlags().lastFlagIs(RequirementStatus.NOT_COMPLIANT)).isTrue();
    }

    private static PaymentRequirementValidationInput.Line.Compliance generateCompliant(boolean compliant, String reason) {
        return PaymentRequirementValidationInput.Line.Compliance.builder()
            .date(Instant.now())
            .operationId(UUID.randomUUID().toString())
            .compliant(compliant)
            .reason(reason)
            .build();
    }

    @ParameterizedTest
    @CsvSource(
        value = {
            "true,CONFIRMATION_AMOUNT_NEEDED_REACHED,false,false",
            "false,CONFIRMATION_AMOUNT_NEEDED_REACHED,false,false",
            "true,PENDING_AMOUNT_NOT_NULL_AND_HIGH_PENDING_SCORE,true,true",
            "false,PENDING_AMOUNT_NOT_NULL_AND_HIGH_PENDING_SCORE,false,true",
            "true,REQUESTED_BY_COLLABORATOR_OR_SYSTEM,true,null",
            "false,REQUESTED_BY_COLLABORATOR_OR_SYSTEM,false,null"
        },
        nullValues = {"null"}
    )
    void should_update_customer_order_requirements_web_order(String inputStockReservationFlag, String inputStockReservationReason, String stockReservationFlagAssertion, String delayedPaymentAssertion) {
        String lineId = UUID.randomUUID().toString();
        String policyId = UUID.randomUUID().toString();
        PaymentRequirementValidationInput input = PaymentRequirementValidationInput.builder()
            .customerOrderId(UUID.randomUUID().toString())
            .buCode("001")
            .executionPolicyId(policyId)
            .executionPolicyVersion(1)
            .lines(List.of(PaymentRequirementValidationInput.Line.builder()
                .id(lineId)
                .validationRequirementCompliance(generateCompliant(true))
                .confirmationRequirementCompliance(generateCompliant(true))
                .vendorOrderCreationRequirementCompliance(generateCompliant(false))
                .stockReservationRequirementCompliance(generateCompliant(BooleanUtils.toBoolean(inputStockReservationFlag), inputStockReservationReason))
                .build()))
            .build();


        List<LineExecution> bddLines = List.of(RuleTestUtils.generateALine(false, null, false, false, null, null, null, OFFER));
        bddLines.get(0).setLineId(lineId);
        bddLines.get(0).setVersion(1);

        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .paymentExecutionPolicy(new Clock(policyId, 1))
            .build();

        when(ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
            .thenReturn(
                Mono.just(Tuples.of(bddCustomerOrder, bddLines, List.of(), List.of(), List.of()))
            );

        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> Mono.empty());

        StepVerifier.create(service.apply(input)).verifyComplete();

        verify(ruleEngineService, times(1)).lockAndGetData(input.getCustomerOrderId(), input.getBuCode());
        verify(createOrUpdateCustomerOrderApplicationService, never()).createOrderAndLines(any(CustomerOrder.class), anyList());

        LineExecution firstLine = bddLines.get(0);
        assertThat(firstLine.getVersion()).isEqualTo(2);
        assertThat(firstLine.getPaymentRequirements().getValidationFlags().lastFlagIs(RequirementStatus.COMPLIANT)).isTrue();
        assertThat(firstLine.getPaymentRequirements().getValidationFlags().getLastFlag().getOperationId()).isNotNull();
        assertThat(firstLine.getPaymentRequirements().getValidationFlags().getLastFlag().getDateTime()).isNotNull();
        assertThat(firstLine.getPaymentRequirements().getConfirmationFlags().lastFlagIs(RequirementStatus.COMPLIANT)).isTrue();
        assertThat(firstLine.getPaymentRequirements().getConfirmationFlags().getLastFlag().getOperationId()).isNotNull();
        assertThat(firstLine.getPaymentRequirements().getConfirmationFlags().getLastFlag().getDateTime()).isNotNull();
        assertThat(firstLine.getPayment().getIsDelayedPayment()).isEqualTo(delayedPaymentAssertion != null ? BooleanUtils.toBoolean(delayedPaymentAssertion) : null);
        assertThat(firstLine.getPaymentRequirements().getStockReservationFlags().lastFlagIs(RequirementStatus.COMPLIANT)).isEqualTo(BooleanUtils.toBoolean(stockReservationFlagAssertion));
        assertThat(firstLine.getPaymentRequirements().getVendorOrderCreationFlags().lastFlagIs(RequirementStatus.NOT_COMPLIANT)).isTrue();
    }

    private static PaymentRequirementValidationInput.Line.Compliance generateCompliant(boolean compliant) {
        return generateCompliant(compliant, PaymentRequirementComplianceReason.CONFIRMATION_AMOUNT_NEEDED_REACHED.name());
    }

}
