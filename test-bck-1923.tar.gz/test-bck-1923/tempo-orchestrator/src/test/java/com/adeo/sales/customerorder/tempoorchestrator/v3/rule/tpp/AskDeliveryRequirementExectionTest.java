package com.adeo.sales.customerorder.tempoorchestrator.v3.rule.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppErrorType;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.tpp.AskDeliveryRequirementExecutionRule;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ConfigurationService;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.service.TppCommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateCompositionFlags;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AskDeliveryRequirementExectionTest {

    private AskDeliveryRequirementExecutionRule askDeliveryRequirementExecutionRule;

    @Mock
    private TppCommandEventService tppCommandEventService;

    @Captor
    private ArgumentCaptor<List<LineExecution>> linesCaptor;

    @BeforeEach
    void setUp() {
        askDeliveryRequirementExecutionRule = new AskDeliveryRequirementExecutionRule(tppCommandEventService);
    }

    @Test
    void should_send_delivery_requirement_command_on_right_predicate() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "EXW", ExternalSystem.SystemName.TEMPO, OFFER);
        LineExecution secondLineSFW = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "DDP", ExternalSystem.SystemName.TEMPO, OFFER);

        Execution execution1 = Execution.builder().id(UUID.randomUUID().toString()).build();
        Execution execution2 = Execution.builder().id(UUID.randomUUID().toString()).build();
        firstLineSFP.setExecutionId(execution1.getId());
        secondLineSFW.setExecutionId(execution2.getId());

        context.setOrderData(OrderData.builder()
            .executionActions(List.of())
            .existingLineExecutions(List.of(
                firstLineSFP, secondLineSFW
            ))
            .executions(List.of(execution1, execution2))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build())
            .build());

        MonoMock<String> commandServiceCall = MonoMock.just("operationId");
        when(this.tppCommandEventService.sendActionTypeRequirement(any(CustomerOrder.class), any(), linesCaptor.capture(), any(Instant.class), eq(ActionType.DELIVERY))).thenReturn(commandServiceCall);

        assertThat(this.askDeliveryRequirementExecutionRule.when(context)).isTrue();

        StepVerifier.create(this.askDeliveryRequirementExecutionRule.then(context)).verifyComplete();

        commandServiceCall.expectHasBeenSubscribed();

        assertThat(linesCaptor.getAllValues()).hasSize(2);
        linesCaptor.getAllValues().forEach(lines -> {
            assertThat(lines.get(0).getPaymentRequirements().getDeliveryFlags().lastFlagIs(RequirementStatus.REQUESTED)).isTrue();
            assertThat(lines.get(0).getPaymentRequirements().getDeliveryFlags().getLastFlag().getOperationId()).isEqualTo("operationId");
        });

        assertThat(this.askDeliveryRequirementExecutionRule.when(context)).isFalse();
    }

    @Test
    void should_send_delivery_requirement_command_on_associated_product_with_service() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution serviceLine = generateALine(false, CustomerOrderLineDeliveryStatus.CREATION_REQUESTED, true, true, true, false, false, CompositionOrderStatus.VALIDATED, null, null, ExternalSystem.SystemName.TEMPO, SERVICE);
        serviceLine.setConfigurationService(ConfigurationService.builder().id(UUID.randomUUID().toString()).associatedLinesId(new ArrayList<>()).build());
        LineExecution secondLineSFW = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, true, false, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, ExternalSystem.SystemName.TEMPO, OFFER);

        Execution execution1 = Execution.builder().id(UUID.randomUUID().toString()).build();
        Execution execution2 = Execution.builder().id(UUID.randomUUID().toString()).build();
        serviceLine.setExecutionId(execution1.getId());
        secondLineSFW.setExecutionId(execution2.getId());

        context.setOrderData(OrderData.builder()
            .executionActions(List.of())
            .existingLineExecutions(List.of(
                serviceLine, secondLineSFW
            ))
            .executions(List.of(execution1, execution2))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build())
            .build());

        MonoMock<String> commandServiceCall = MonoMock.just("operationId");
        when(this.tppCommandEventService.sendActionTypeRequirement(any(CustomerOrder.class), any(), linesCaptor.capture(), any(Instant.class), eq(ActionType.DELIVERY))).thenReturn(commandServiceCall);

        assertThat(this.askDeliveryRequirementExecutionRule.when(context)).isTrue();

        StepVerifier.create(this.askDeliveryRequirementExecutionRule.then(context)).verifyComplete();

        commandServiceCall.expectHasBeenSubscribed();

        List<List<LineExecution>> allValues = linesCaptor.getAllValues();
        assertThat(allValues).hasSize(1);
        assertThat(linesCaptor.getValue()).hasSize(1);
        assertThat(linesCaptor.getValue()).doesNotContain(serviceLine);
        assertThat(linesCaptor.getValue()).contains(secondLineSFW);

        assertThat(this.askDeliveryRequirementExecutionRule.when(context)).isFalse();
    }

    @Test
    void should_not_ask_delivery_requirement_when_not_considered_delivered() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "EXW", OFFER);
        LineExecution secondLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "DDP", OFFER);

        Execution execution = Execution.builder().id(UUID.randomUUID().toString()).build();

        firstLineSFP.setExecutionId(execution.getId());
        secondLineSFP.setExecutionId(execution.getId());

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                firstLineSFP, secondLineSFP
            ))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build())
            .executions(List.of())
            .build());

        context.getOrderData().setExecutionActions(new ArrayList<>());

        assertThat(this.askDeliveryRequirementExecutionRule.when(context)).isFalse();

    }

    @Test
    void should_not_ask_delivery_requirement_when_composition_is_not_validate() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.PENDING, DeliveryType.SFP, "EXW", OFFER);
        LineExecution secondLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.PENDING, DeliveryType.SFP, "DDP", OFFER);

        Execution execution = Execution.builder().id(UUID.randomUUID().toString()).build();
        firstLineSFP.setExecutionId(execution.getId());
        secondLineSFP.setExecutionId(execution.getId());

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                firstLineSFP, secondLineSFP
            ))
            .executions(List.of(execution))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build())
            .build());

        context.getOrderData().setExecutionActions(new ArrayList<>());

        assertThat(this.askDeliveryRequirementExecutionRule.when(context)).isFalse();

        //And when composition is canceled
        firstLineSFP.getComposition().setFlags(generateCompositionFlags(CompositionOrderStatus.CANCELED));
        secondLineSFP.getComposition().setFlags(generateCompositionFlags(CompositionOrderStatus.CANCELED));

        assertThat(this.askDeliveryRequirementExecutionRule.when(context)).isFalse();
    }

    @Test
    void should_not_ask_delivery_requirement_for_pyxis_order() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution secondLinePyxis = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.RESERVE_AND_COLLECT, null, ExternalSystem.SystemName.PYXIS, OFFER);

        Execution execution = Execution.builder().id(UUID.randomUUID().toString()).build();
        secondLinePyxis.setExecutionId(execution.getId());

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                secondLinePyxis
            ))
            .executions(List.of(execution))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build())
            .build());

        context.getOrderData().setExecutionActions(new ArrayList<>());

        assertThat(this.askDeliveryRequirementExecutionRule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_if_is_already_on_failure_state_or_already_done() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "EXW", ExternalSystem.SystemName.TEMPO, OFFER);
        LineExecution secondLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "DDP", ExternalSystem.SystemName.TEMPO, OFFER);

        Execution execution = Execution.builder().id(UUID.randomUUID().toString()).build();
        firstLineSFP.setExecutionId(execution.getId());
        secondLineSFP.setExecutionId(execution.getId());

        context.setOrderData(OrderData.builder()
            .executionActions(List.of())
            .existingLineExecutions(List.of(
                firstLineSFP, secondLineSFP
            ))
            .executions(List.of(execution))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build())
            .build());


        assertThat(this.askDeliveryRequirementExecutionRule.when(context)).isTrue();
        firstLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlag(RequirementStatus.REJECTED);
        secondLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlag(RequirementStatus.REJECTED);

        assertThat(askDeliveryRequirementExecutionRule.when(context)).isFalse();

        firstLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlagWithFailedReason(RequirementStatus.FAILED, TppErrorType.PAYMENT_EXECUTION_POLICY_VERSION_MISMATCH.name());
        firstLineSFP.getPaymentRequirements().setVersionMismatch(true);
        secondLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlagWithFailedReason(RequirementStatus.FAILED, TppErrorType.PAYMENT_EXECUTION_POLICY_VERSION_MISMATCH.name());
        secondLineSFP.getPaymentRequirements().setVersionMismatch(true);

        assertThat(askDeliveryRequirementExecutionRule.when(context)).isFalse();

        firstLineSFP.getPaymentRequirements().setVersionMismatch(false);
        secondLineSFP.getPaymentRequirements().setVersionMismatch(false);
        assertThat(askDeliveryRequirementExecutionRule.when(context)).isTrue();

        firstLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlag(RequirementStatus.APPROVED);
        secondLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlag(RequirementStatus.APPROVED);
        assertThat(askDeliveryRequirementExecutionRule.when(context)).isFalse();
    }

}
