package com.adeo.sales.customerorder.tempoorchestrator.converter;

import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentLineType;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperation;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationType;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOrderLine;
import com.adeo.ulys.payment.event.kafka.bean.v2.PaymentUpdatedV2;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PaymentOperationConverterTest {
    ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new Jdk8Module());
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.registerModule(new ParameterNamesModule());
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Test
    void shouldTransformPaymentUpdateV2ToPaymentOperations() throws IOException {
        //GIVEN
        PaymentUpdatedV2 paymentUpdatedV2 = objectMapper.readValue(this.getClass().getResource("/data/ulys/PaymentUpdatedV2.json"), PaymentUpdatedV2.class);

        PaymentOrderLine paymentOrderLineDelivery1 = PaymentOrderLine.builder().id("b15c00f0-f0b2-46f9-b5f2-3de43d3e106d").type(PaymentLineType.DELIVERY_LINE).build();
        PaymentOrderLine paymentOrderLineDelivery2 = PaymentOrderLine.builder().id("633ec45f-2e17-4401-a764-b25368ee8c15").type(PaymentLineType.DELIVERY_LINE).build();
        PaymentOrderLine paymentOrderLineOffer1 = PaymentOrderLine.builder().id("4a53915c-7dcb-4369-8346-6653ee5b1209").type(PaymentLineType.OFFER_LINE).build();
        PaymentOrderLine paymentOrderLineOffer2 = PaymentOrderLine.builder().id("52520764-8e12-4b60-bb4b-90ab4b43c42d").type(PaymentLineType.OFFER_LINE).build();
        PaymentOrderLine paymentOrderLineOffer3 = PaymentOrderLine.builder().id("b98e6a44-3693-4ba5-b5e7-d419059b19ec").type(PaymentLineType.OFFER_LINE).build();

        //WHEN
        final var paymentOperationConverter = new PaymentOperationConverter();
        List<PaymentOperation> paymentOperations = paymentOperationConverter.convert(paymentUpdatedV2, "001");

        //THEN
        assertEquals(3, paymentOperations.size());

        PaymentOperation paymentOperation1 = paymentOperations.get(0);
        assertEquals("001", paymentOperation1.getBuCode());
        assertEquals("ee3af691-6ce3-453c-ac18-34b8150804ff", paymentOperation1.getTransactionId());
        assertEquals("878fadf8-2b92-4273-92b6-596266627922", paymentOperation1.getCustomerOrderId());
        assertEquals(30, paymentOperation1.getCustomerOrderVersion());
        assertEquals(PaymentOperationType.AUTHORIZATION, paymentOperation1.getOperation());
        assertEquals("PAYMENT_CARD_WEB", paymentOperation1.getPaymentMean());
        assertEquals(BigDecimal.valueOf(388.33), paymentOperation1.getAmount());
        assertEquals(PaymentOperationStatus.ACCEPTED, paymentOperation1.getStatus());
        assertEquals(Instant.ofEpochMilli(1702292117666L), paymentOperation1.getOperationDate());
        assertEquals(5, paymentOperation1.getPaymentOrderLines().size());
        assertTrue(paymentOperation1.getPaymentOrderLines().containsAll(Arrays.asList(paymentOrderLineDelivery1, paymentOrderLineDelivery2, paymentOrderLineOffer1, paymentOrderLineOffer2, paymentOrderLineOffer3)));

        PaymentOperation paymentOperation2 = paymentOperations.get(1);
        assertEquals("001", paymentOperation2.getBuCode());
        assertEquals("98a8c913-58db-4a27-a058-e1b5137593a3", paymentOperation2.getTransactionId());
        assertEquals("878fadf8-2b92-4273-92b6-596266627922", paymentOperation2.getCustomerOrderId());
        assertEquals(30, paymentOperation2.getCustomerOrderVersion());
        assertEquals(PaymentOperationType.PAYMENT, paymentOperation2.getOperation());
        assertEquals("PAYMENT_CARD_WEB", paymentOperation2.getPaymentMean());
        assertEquals(BigDecimal.valueOf(232.52), paymentOperation2.getAmount());
        assertEquals(PaymentOperationStatus.ACCEPTED, paymentOperation2.getStatus());
        assertEquals(Instant.ofEpochMilli(1702292193763L), paymentOperation2.getOperationDate());
        assertEquals(3, paymentOperation2.getPaymentOrderLines().size());
        assertTrue(paymentOperation2.getPaymentOrderLines().containsAll(Arrays.asList(paymentOrderLineDelivery1, paymentOrderLineOffer1, paymentOrderLineOffer2)));

        PaymentOperation paymentOperation3 = paymentOperations.get(2);
        assertEquals("001", paymentOperation3.getBuCode());
        assertEquals("83be3aff-a72e-4cfa-a028-793bf087c518", paymentOperation3.getTransactionId());
        assertEquals("878fadf8-2b92-4273-92b6-596266627922", paymentOperation3.getCustomerOrderId());
        assertEquals(30, paymentOperation3.getCustomerOrderVersion());
        assertEquals(PaymentOperationType.CANCEL_AUTHORIZATION, paymentOperation3.getOperation());
        assertEquals("PAYMENT_CARD_WEB", paymentOperation3.getPaymentMean());
        assertEquals(BigDecimal.valueOf(155.81), paymentOperation3.getAmount());
        assertEquals(PaymentOperationStatus.ACCEPTED, paymentOperation3.getStatus());
        assertEquals(Instant.ofEpochMilli(1702460843916L), paymentOperation3.getOperationDate());
        assertEquals(2, paymentOperation3.getPaymentOrderLines().size());
        assertTrue(paymentOperation3.getPaymentOrderLines().containsAll(Arrays.asList(paymentOrderLineDelivery2, paymentOrderLineOffer3)));
    }

    @Test
    void shouldTransformPaymentUpdateV2ToPaymentOperationsWithMultibancoInfo() throws IOException {
        //GIVEN
        PaymentUpdatedV2 paymentUpdatedV2 = objectMapper.readValue(this.getClass().getResource("/data/ulys/PaymentUpdatedV2ValidMultiBanco.json"), PaymentUpdatedV2.class);

        PaymentOrderLine paymentOrderLineOffer = PaymentOrderLine.builder().id("c5e3af61-663b-4865-8d07-715583044b04").type(PaymentLineType.OFFER_LINE).build();
        PaymentOrderLine paymentOrderLineDelivery = PaymentOrderLine.builder().id("d5be3711-98a7-40c8-a63b-4b29185b9b1d").type(PaymentLineType.DELIVERY_LINE).build();

        //WHEN
        final var paymentOperationConverter = new PaymentOperationConverter();
        List<PaymentOperation> paymentOperations = paymentOperationConverter.convert(paymentUpdatedV2, "001");

        //THEN
        assertEquals(1, paymentOperations.size());

        PaymentOperation paymentOperation = paymentOperations.get(0);
        assertEquals("001", paymentOperation.getBuCode());
        assertEquals("20240e4c-7bdf-40ed-b84c-fbc249cbf811", paymentOperation.getTransactionId());
        assertEquals("2624e67e-7a6e-4fbd-aa45-ec76af3df63c", paymentOperation.getCustomerOrderId());
        assertEquals(46, paymentOperation.getCustomerOrderVersion());
        assertEquals(PaymentOperationType.AUTHORIZATION, paymentOperation.getOperation());
        assertEquals("MULTIBANCO", paymentOperation.getPaymentMean());
        assertEquals(BigDecimal.valueOf(43.50), paymentOperation.getAmount());
        assertEquals(PaymentOperationStatus.PENDING, paymentOperation.getStatus());
        assertEquals(Instant.ofEpochMilli(1709629314181L), paymentOperation.getOperationDate());
        assertEquals(2, paymentOperation.getPaymentOrderLines().size());
        assertTrue(paymentOperation.getPaymentOrderLines().containsAll(Arrays.asList(paymentOrderLineOffer, paymentOrderLineDelivery)));
        Map<String, String> multibancoData = paymentOperation.getPaymentExternalData();
        assertEquals("642397627", multibancoData.get("PAYMENT_REFERENCE"));
        assertEquals("46606", multibancoData.get("ENTITY"));
        assertEquals("2024-03-06T09:01:54.206Z", multibancoData.get("EXPIRATION_DATE"));
    }

    @Test
    void shouldNotCreateAuthorisationOperation() throws IOException {
        //GIVEN
        PaymentUpdatedV2 paymentUpdatedV2 = objectMapper.readValue(this.getClass().getResource("/data/ulys/PaymentUpdatedV2WithNotManagedStatus.json"), PaymentUpdatedV2.class);
        PaymentOrderLine orderLineOffer = PaymentOrderLine.builder().id("ba8b3df6-88a0-4535-bd0e-6d25bc37a8a7").type(PaymentLineType.OFFER_LINE).build();
        PaymentOrderLine orderLineDelivery = PaymentOrderLine.builder().id("bcfe91f2-c1d9-4fb7-8cef-c856e2c47edc").type(PaymentLineType.DELIVERY_LINE).build();

        //WHEN
        final var paymentOperationConverter = new PaymentOperationConverter();
        List<PaymentOperation> paymentOperations = paymentOperationConverter.convert(paymentUpdatedV2, "001");

        //THEN
        assertEquals(1, paymentOperations.size());

        PaymentOperation paymentOperation = paymentOperations.get(0);
        assertEquals("001", paymentOperation.getBuCode());
        assertEquals("ab6ed6b8-3d4d-4681-8646-10843f0ce437", paymentOperation.getTransactionId());
        assertEquals("d775228b-72e3-4170-b4f6-bd1d6dc5e7d6", paymentOperation.getCustomerOrderId());
        assertEquals(47, paymentOperation.getCustomerOrderVersion());
        assertEquals(PaymentOperationType.PAYMENT, paymentOperation.getOperation());
        assertEquals("FAST_BANK_TRANSFER", paymentOperation.getPaymentMean());
        assertEquals(BigDecimal.valueOf(24.99), paymentOperation.getAmount());
        assertEquals(PaymentOperationStatus.ACCEPTED, paymentOperation.getStatus());
        assertEquals(Instant.ofEpochMilli(1714380449421L), paymentOperation.getOperationDate());
        assertEquals(2, paymentOperation.getPaymentOrderLines().size());
        assertTrue(paymentOperation.getPaymentOrderLines().containsAll(Arrays.asList(orderLineOffer, orderLineDelivery)));
        assertTrue(paymentOperation.getPaymentExternalData().isEmpty());
    }
}
