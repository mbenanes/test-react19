package com.adeo.sales.customerorder.tempoorchestrator.v3.rule.notification;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.tpp.SendOrderValidationCommunicationRuleTPP;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.NotificationStatus.NOTIFICATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SendOrderValidationCommunicationRuleTPPTest {

    private SendOrderValidationCommunicationRuleTPP rule;
    @Mock
    private OutgoingNotificationService notificationService;

    @BeforeEach
    void setUp() {
        rule = new SendOrderValidationCommunicationRuleTPP(notificationService);
    }

    @Test
    void should_process_rule_1P_line_only() {
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(false, null, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER)
            ))
            .existingCustomerOrder(CustomerOrder.builder()
                .id(UUID.randomUUID().toString())
                .buCode("001")
                .status(CustomerOrderStatus.VALIDATED)
                .orderPlaceType(CustomerOrderPlaceType.ONLINE)
                .build())
            .build());

        when(notificationService.sendValidationNotification(context.getOrderData().getExistingCustomerOrder())).thenReturn(Mono.empty());

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        verify(notificationService, times(1)).sendValidationNotification(context.getOrderData().getExistingCustomerOrder());
        assertThat(context.getOrderData().getExistingCustomerOrder().getNotificationStatus()).isEqualTo(NOTIFICATION_REQUESTED);
    }

    @Test
    void should_send_validation_notification_for_IN_STORE_ORDER_orchestrated_by_pyxis_created_on_elo() {
        RuleEngineContext context = new RuleEngineContext();

        final CustomerOrder customerOrder = CustomerOrder.builder()
            .id(UUID.randomUUID().toString())
            .buCode("001")
            .status(CustomerOrderStatus.VALIDATED)
            .orderPlaceType(CustomerOrderPlaceType.IN_STORE)
            .build();

        final LineExecution eloLineOrchestratedByPyxis = generateALine(false, null, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.RESERVE_AND_COLLECT, null, OFFER);
        eloLineOrchestratedByPyxis.setExternalSystem(ExternalSystem.builder().storeCode("019").id("425996").name(ExternalSystem.SystemName.PYXIS).build());
        eloLineOrchestratedByPyxis.setCustomerOrderId(customerOrder.getId());

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                eloLineOrchestratedByPyxis
            ))
            .existingCustomerOrder(customerOrder)
            .build());

        when(notificationService.sendValidationNotification(context.getOrderData().getExistingCustomerOrder())).thenReturn(Mono.empty());

        assertThat(rule.when(context)).isFalse();
        eloLineOrchestratedByPyxis.getDelivery().getFlags().raiseFlagIfNot(CustomerOrderLineDeliveryStatus.CREATED);
        assertThat(rule.when(context)).isTrue();


        StepVerifier.create(rule.then(context))
            .verifyComplete();

        verify(notificationService, times(1)).sendValidationNotification(context.getOrderData().getExistingCustomerOrder());
        assertThat(context.getOrderData().getExistingCustomerOrder().getNotificationStatus()).isEqualTo(NOTIFICATION_REQUESTED);
    }

    @Test
    void should_process_rule_3P_line_only() {
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(true, null, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER)
            ))
            .existingCustomerOrder(CustomerOrder.builder()
                .id(UUID.randomUUID().toString())
                .buCode("001")
                .status(CustomerOrderStatus.VALIDATED)
                .orderPlaceType(CustomerOrderPlaceType.ONLINE)
                .build())
            .build());

        when(notificationService.sendValidationNotification(context.getOrderData().getExistingCustomerOrder())).thenReturn(Mono.empty());

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        verify(notificationService, times(1)).sendValidationNotification(context.getOrderData().getExistingCustomerOrder());
        assertThat(context.getOrderData().getExistingCustomerOrder().getNotificationStatus()).isEqualTo(NOTIFICATION_REQUESTED);
    }

    @Test
    void should_process_rule_1P_line_only_no_confirmation_requirement() {
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(false, null, true, false, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER)
            ))
            .existingCustomerOrder(CustomerOrder.builder()
                .id(UUID.randomUUID().toString())
                .buCode("001")
                .status(CustomerOrderStatus.VALIDATED)
                .orderPlaceType(CustomerOrderPlaceType.ONLINE)
                .build())
            .build());

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_process_rule_1P_line_only_composition_pending() {
        RuleEngineContext context = new RuleEngineContext();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(false, null, true, true, CompositionOrderStatus.PENDING, DeliveryType.SFW, null, OFFER)
            ))
            .existingCustomerOrder(CustomerOrder.builder()
                .id(UUID.randomUUID().toString())
                .buCode("001")
                .status(CustomerOrderStatus.VALIDATED)
                .orderPlaceType(CustomerOrderPlaceType.ONLINE)
                .build())
            .build());

        assertThat(rule.when(context)).isFalse();
    }

}
