package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tco;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.converter.Converter;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.Offer;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.ProductOffer;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.ProductOfferLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecutionComposition;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPaymentRequirements;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LineExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.impl.LockPosgresRepository;
import com.adeo.sales.customerorder.tempoorchestrator.service.impl.DomainEventServiceImpl;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.transaction.ReactiveTransactionManager;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.CUSTOMER_ORDER_ID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CustomerOrderValidatedApplicationServiceTest {

    private CustomerOrderValidationApplicationService applicationService;
    @Mock
    private DomainEventServiceImpl domainEventServiceACL;
    @Mock
    private Converter<com.adeo.sales.customerorder.CustomerOrder, CustomerOrder> tempoComposerEventToCustomerOrderConverter;
    @Mock
    private Converter<com.adeo.sales.customerorder.CustomerOrder, List<LineExecution>> tempoComposerEventToLineExecutionsConverters;
    @Mock
    private RuleEngineService ruleEngineService;
    @Mock
    private CustomerOrderRepository customerOrderRepository;
    @Mock
    private LineExecutionRepository lineExecutionRepository;
    @Mock
    private ExecutionRepository executionRepository;
    @Mock
    private LockPosgresRepository lockPosgresRepository;
    @Mock
    private ReactiveTransactionManager transactionManager;

    @BeforeEach
    void setUp() {
        applicationService = new CustomerOrderValidationApplicationService(domainEventServiceACL, tempoComposerEventToCustomerOrderConverter, tempoComposerEventToLineExecutionsConverters,
            ruleEngineService, customerOrderRepository, lineExecutionRepository, executionRepository, lockPosgresRepository, transactionManager);
    }

    @Test
    void should_have_to_call_tpp() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        final var validationFlag = new Flags<RequirementStatus>();
        validationFlag.raiseFlagIfNot(RequirementStatus.COMPLIANT);

        final var validatedFlag = new Flags<CompositionOrderStatus>();
        validatedFlag.raiseFlagIfNot(CompositionOrderStatus.VALIDATED);

        final var inputOffer = List.of(ProductOfferLine.builder()
            .status("VALIDATED")
            .build());

        final var lines = List.of(LineExecution.builder()
                .payment(LineExecutionPayment.builder()
                    .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.TPP)
                    .build())
                .paymentRequirements(LineExecutionPaymentRequirements.builder()
                    .validationFlags(validationFlag)
                    .build())
                .composition(LineExecutionComposition.builder()
                    .flags(validatedFlag)
                    .build())
                .build(),
            LineExecution.builder()
                .payment(LineExecutionPayment.builder()
                    .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.TPP)
                    .build())
                .paymentRequirements(LineExecutionPaymentRequirements.builder()
                    .validationFlags(validationFlag)
                    .build())
                .composition(LineExecutionComposition.builder()
                    .flags(validatedFlag)
                    .build())
                .build());
        Method privateMethod = applicationService.getClass().getDeclaredMethod("haveToCallTppForCheckRequirements", List.class, List.class);
        privateMethod.setAccessible(true);
        boolean result = (boolean) privateMethod.invoke(applicationService, new Object[] {lines, inputOffer});
        assertTrue(result);
    }

    @Test
    void should_not_have_to_call_tpp_on_psr_lines() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        final var validationFlag = new Flags<RequirementStatus>();
        validationFlag.raiseFlagIfNot(RequirementStatus.COMPLIANT);

        final var validatedFlag = new Flags<CompositionOrderStatus>();
        validatedFlag.raiseFlagIfNot(CompositionOrderStatus.VALIDATED);

        final var lines = List.of(LineExecution.builder()
                .payment(LineExecutionPayment.builder()
                    .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.PSR)
                    .build())
                .paymentRequirements(LineExecutionPaymentRequirements.builder()
                    .validationFlags(validationFlag)
                    .build())
                .composition(LineExecutionComposition.builder()
                    .flags(validatedFlag)
                    .build())
                .build(),
            LineExecution.builder()
                .payment(LineExecutionPayment.builder()
                    .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.PSR)
                    .build())
                .paymentRequirements(LineExecutionPaymentRequirements.builder()
                    .validationFlags(validationFlag)
                    .build())
                .composition(LineExecutionComposition.builder()
                    .flags(validatedFlag)
                    .build())
                .build());
        Method privateMethod = applicationService.getClass().getDeclaredMethod("haveToCallTppForCheckRequirements", List.class, List.class);
        privateMethod.setAccessible(true);
        boolean result = (boolean) privateMethod.invoke(applicationService, new Object[] {lines, List.of()});
        assertFalse(result);
    }

    @Test
    void should_not_have_to_call_tpp_without_requirements() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        final var cancelledFlag = new Flags<CompositionOrderStatus>();
        cancelledFlag.raiseFlagIfNot(CompositionOrderStatus.CANCELED);

        final var lines = List.of(LineExecution.builder()
                .payment(LineExecutionPayment.builder()
                    .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.PSR)
                    .build())
                .composition(LineExecutionComposition.builder()
                    .flags(cancelledFlag)
                    .build())
                .build(),
            LineExecution.builder()
                .payment(LineExecutionPayment.builder()
                    .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.PSR)
                    .build())
                .composition(LineExecutionComposition.builder()
                    .flags(cancelledFlag)
                    .build())
                .build());
        Method privateMethod = applicationService.getClass().getDeclaredMethod("haveToCallTppForCheckRequirements", List.class, List.class);
        privateMethod.setAccessible(true);
        boolean result = (boolean) privateMethod.invoke(applicationService, new Object[] {lines, List.of()});
        assertFalse(result);
    }

    @Test
    void should_not_have_to_call_tpp_on_cancelled_lines() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        final var validationFlag = new Flags<RequirementStatus>();
        validationFlag.raiseFlagIfNot(RequirementStatus.COMPLIANT);

        final var cancelledFlag = new Flags<CompositionOrderStatus>();
        cancelledFlag.raiseFlagIfNot(CompositionOrderStatus.CANCELED);

        final var lines = List.of(LineExecution.builder()
                .payment(LineExecutionPayment.builder()
                    .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.PSR)
                    .build())
                .paymentRequirements(LineExecutionPaymentRequirements.builder()
                    .validationFlags(validationFlag)
                    .build())
                .composition(LineExecutionComposition.builder()
                    .flags(cancelledFlag)
                    .build())
                .build(),
            LineExecution.builder()
                .payment(LineExecutionPayment.builder()
                    .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.PSR)
                    .build())
                .paymentRequirements(LineExecutionPaymentRequirements.builder()
                    .validationFlags(validationFlag)
                    .build())
                .composition(LineExecutionComposition.builder()
                    .flags(cancelledFlag)
                    .build())
                .build());
        Method privateMethod = applicationService.getClass().getDeclaredMethod("haveToCallTppForCheckRequirements", List.class, List.class);
        privateMethod.setAccessible(true);
        boolean result = (boolean) privateMethod.invoke(applicationService, lines, List.of());
        assertFalse(result);
    }

    @Test
    void should_not_have_to_call_tpp_without_lines() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        final var lines = List.of();
        Method privateMethod = applicationService.getClass().getDeclaredMethod("haveToCallTppForCheckRequirements", List.class, List.class);
        privateMethod.setAccessible(true);
        boolean result = (boolean) privateMethod.invoke(applicationService, new Object[] {lines, List.of()});
        assertFalse(result);
    }

    @ParameterizedTest
    @CsvSource(
        value = {
            "STANDARD,PRODUCT,null,null,null",
            "TAILOR_MADE,PRODUCT,configurationComponent,a42p3t1z-1ze2-96ui-gh69-9et125878okl,null",
            "TAILOR_MADE,PRODUCT,configuredProduct,a42p3t1z-1ze2-96ui-gh69-9et125878okl,d77c1c3b-5ac7-41ec-bd27-8ad740354abg"
        },
        nullValues = {"null"}
    )
    void should_set_execution_selector(String itemCategory, String itemType, String executionSelector, String configurationId, String configuredProductId) {
        // Given
        final var customerOrder = CustomerOrder.builder()
            .id(CUSTOMER_ORDER_ID)
            .productOffer(ProductOffer.builder()
                .id("c5fa149a-3fc3-4d62-bf9e-cd53d36853cf")
                .items(
                    List.of(
                        ProductOfferLine.builder()
                            .id("2a7604f0-3001-45ad-b8e6-e68388a1caf3")
                            .itemCategory(itemCategory)
                            .itemType(itemType)
                            .configurationId(configurationId)
                            .configuredProductId(configuredProductId)
                            .build()
                    ))
                .build())
            .build();

        final var validationFlag = new Flags<RequirementStatus>();
        validationFlag.raiseFlagIfNot(RequirementStatus.COMPLIANT);

        final var validatedFlag = new Flags<CompositionOrderStatus>();
        validatedFlag.raiseFlagIfNot(CompositionOrderStatus.VALIDATED);

        final var lines = List.of(LineExecution.builder()
                .lineId("2a7604f0-3001-45ad-b8e6-e68388a1caf3")
                .payment(LineExecutionPayment.builder()
                    .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.TPP)
                    .build())
                .paymentRequirements(LineExecutionPaymentRequirements.builder()
                    .validationFlags(validationFlag)
                    .build())
                .composition(LineExecutionComposition.builder()
                    .flags(validatedFlag)
                    .build())
                .build(),
            LineExecution.builder()
                .lineId("8c1b5e1a-3152-47ae-b184-4f92d1fbc6a1")
                .payment(LineExecutionPayment.builder()
                    .paymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.TPP)
                    .build())
                .paymentRequirements(LineExecutionPaymentRequirements.builder()
                    .validationFlags(validationFlag)
                    .build())
                .composition(LineExecutionComposition.builder()
                    .flags(validatedFlag)
                    .build())
                .build());

        MonoMock<Void> mockEmpty = MonoMock.empty();
        when(customerOrderRepository.saveCustomerOrder(any())).thenReturn(mockEmpty);
        when(lineExecutionRepository.save(any())).thenReturn(mockEmpty);

        // When
        applicationService.createCustomerOrderAndLines(customerOrder, lines);

        // Then
        assertThat(lines.stream().findFirst().get().getComposition().getExecutionSelector()).isEqualTo(executionSelector);
    }

}
