package com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.RuleEngineCompensationConditions.IS_DELIVERY_REQUIREMENT_COMPLETED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class OrderDataTest {

    @Test
    void shouldReturnRightGroupOfLineExecutionForOwnerShipAskRequirement(){
        final String idExecution = UUID.randomUUID().toString();
        RuleEngineContext context = new RuleEngineContext();
        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "EXW", OFFER);
        LineExecution secondLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "DDP", OFFER);

        firstLineSFP.setExecutionId(idExecution);
        secondLineSFP.setExecutionId(idExecution);
        firstLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));
        secondLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));

        final String idExecution2 = UUID.randomUUID().toString();
        LineExecution thirdLineSFW = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, "EXW", OFFER);
        thirdLineSFW.setExecutionId(idExecution2);
        secondLineSFP.getPaymentRequirements().getPreparationFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));

        context.setOrderData(OrderData. builder()
            .existingLineExecutions(List.of(firstLineSFP, secondLineSFP))
            .existingCustomerOrder(CustomerOrder.builder().buCode("001").status(CustomerOrderStatus.VALIDATED).build())
            .build());

        boolean test = context.getOrderData().getExistingLinesByExecution().isEmpty() ? false : context.getOrderData().getExistingLinesByExecution()
            .entrySet()
            .stream()
            .anyMatch(stringListEntry -> stringListEntry.getValue().stream()
                .allMatch(IS_DELIVERY_REQUIREMENT_COMPLETED));


        assertThat(test).isTrue();

        final List<String> idExecutions = context.getOrderData().getExistingLinesByExecution()
            .entrySet()
            .stream()
            .filter(stringListEntry -> stringListEntry.getValue().stream()
                .allMatch(IS_DELIVERY_REQUIREMENT_COMPLETED))
            .flatMap(stringListEntry -> stringListEntry.getValue().stream())
            .map(lineExecution -> lineExecution.getExecutionId())
            .distinct()
            .toList();

        assertThat(idExecutions.size()).isEqualTo(1);
        assertThat(idExecutions.get(0)).isEqualTo(idExecution);
    }

    @Test
    void shouldReturnAnyGroupOfLineExecutionForOwnerShipAskRequirement(){
        final String idExecution = UUID.randomUUID().toString();
        RuleEngineContext context = new RuleEngineContext();
        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "EXW", OFFER);
        LineExecution secondLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "DDP", OFFER);

        firstLineSFP.setExecutionId(idExecution);
        secondLineSFP.setExecutionId(idExecution);
        firstLineSFP.getPaymentRequirements().getDeliveryFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));

        final String idExecution2 = UUID.randomUUID().toString();
        LineExecution thirdLineSFW = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, "EXW", OFFER);
        thirdLineSFW.setExecutionId(idExecution2);
        secondLineSFP.getPaymentRequirements().getPreparationFlags().raiseFlagIfNot(UUID.randomUUID().toString(), RequirementStatus.APPROVED, Instant.now().atOffset(ZoneOffset.UTC));

        context.setOrderData(OrderData. builder()
            .existingLineExecutions(List.of(firstLineSFP, secondLineSFP))
            .existingCustomerOrder(CustomerOrder.builder().buCode("001").status(CustomerOrderStatus.VALIDATED).build())
            .build());

        boolean test = context.getOrderData().getExistingLinesByExecution().isEmpty() ? false : context.getOrderData().getExistingLinesByExecution()
            .entrySet()
            .stream()
            .anyMatch(stringListEntry -> stringListEntry.getValue().stream()
                .allMatch(IS_DELIVERY_REQUIREMENT_COMPLETED));


        assertThat(test).isFalse();

        final List<String> idExecutions = context.getOrderData().getExistingLinesByExecution()
            .entrySet()
            .stream()
            .filter(stringListEntry -> stringListEntry.getValue().stream()
                .allMatch(IS_DELIVERY_REQUIREMENT_COMPLETED))
            .flatMap(stringListEntry -> stringListEntry.getValue().stream())
            .map(lineExecution -> lineExecution.getExecutionId())
            .distinct()
            .toList();

        assertThat(idExecutions.size()).isEqualTo(0);
    }

}
