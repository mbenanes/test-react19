package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert;


import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.alert.AlertData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.PromisedDateSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.service.UpdateAvailableActionService;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.AlertMessageInput;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class Create1POutOfStockAlertTest {
    private Create1POutOfStockAlert rule;

    @Mock
    private AlertMessageService alertMessageService;
    @Mock
    private UpdateAvailableActionService updateAvailableActionService;

    @Captor
    private ArgumentCaptor<AlertMessageInput> alertMessageInputArgumentCaptor;

    @BeforeEach
    void setUp() {
        rule = new Create1POutOfStockAlert(alertMessageService, updateAvailableActionService);
    }

    @Test
    void shouldCreateOutOfStockAlertForRejectedHomeDeliveryLines() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution lineSFW = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        lineSFW.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.REJECTED);

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                lineSFW
            ))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).buCode("001").build())
            .executionActions(new ArrayList<>())
            .build());

        MonoMock<Void> alertMessageCall = MonoMock.empty();

        lenient().when(alertMessageService.sendCreateAlertMessage(alertMessageInputArgumentCaptor.capture())).thenReturn(alertMessageCall);

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        alertMessageCall.expectHasBeenSubscribed();

        verify(alertMessageService, times(1)).sendCreateAlertMessage(any(AlertMessageInput.class));

        assertThat(alertMessageInputArgumentCaptor.getValue().getAlert().getSpecificData().getReason()).isEqualTo("OUT_OF_STOCK");
        assertThat(alertMessageInputArgumentCaptor.getValue().getAlert().getImpactedLinesIds()).hasSize(1);
        assertThat(alertMessageInputArgumentCaptor.getValue().getAlert().getImpactedLinesIds()).contains(lineSFW.getLineId());
    }

    @Test
    void shouldCreateOutOfStockAlertForCollectDeliveryTypesWithoutHandover() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution lineOrderAndCollect = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);
        lineOrderAndCollect.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.REJECTED);
        LineExecution lineReserveAndCollect = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.RESERVE_AND_COLLECT, null, OFFER);
        lineReserveAndCollect.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.REJECTED);

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                lineOrderAndCollect,
                lineReserveAndCollect
            ))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).buCode("001").build())
            .executionActions(new ArrayList<>())
            .build());

        MonoMock<Void> alertMessageCall = MonoMock.empty();

        lenient().when(alertMessageService.sendCreateAlertMessage(alertMessageInputArgumentCaptor.capture())).thenReturn(alertMessageCall);

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        alertMessageCall.expectHasBeenSubscribed();

        verify(alertMessageService, times(1)).sendCreateAlertMessage(any(AlertMessageInput.class));

        assertThat(alertMessageInputArgumentCaptor.getValue().getAlert().getSpecificData().getReason()).isEqualTo("OUT_OF_STOCK");
        assertThat(alertMessageInputArgumentCaptor.getValue().getAlert().getImpactedLinesIds()).hasSize(2);
        assertThat(alertMessageInputArgumentCaptor.getValue().getAlert().getImpactedLinesIds()).contains(lineReserveAndCollect.getLineId());
        assertThat(alertMessageInputArgumentCaptor.getValue().getAlert().getImpactedLinesIds()).contains(lineOrderAndCollect.getLineId());
    }


    @Test
    void shouldNotCreateOutOfStockAlertForCollectDeliveryTypesWithHandoverButWithNoCollectStatus() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution lineOrderAndCollect = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);
        lineOrderAndCollect.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.HANDOVER_STARTED);
        lineOrderAndCollect.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.REJECTED);
        LineExecution lineReserveAndCollect = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.RESERVE_AND_COLLECT, null, OFFER);
        lineReserveAndCollect.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.HANDOVER_STARTED);
        lineReserveAndCollect.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.REJECTED);

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                lineOrderAndCollect,
                lineReserveAndCollect
            ))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).buCode("001").build())
            .executionActions(new ArrayList<>())
            .build());

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void shouldNotCreateOutOfStockAlertForCollectDeliveryTypesWithHandoverAndNotCollectedOrCancelledCollectStatus() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution lineOrderAndCollect = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);
        lineOrderAndCollect.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.HANDOVER_STARTED);
        lineOrderAndCollect.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.REJECTED);
        lineOrderAndCollect.getDelivery().getCollect().getFlags().raiseFlag(CollectStatus.CANCELLED);
        LineExecution lineReserveAndCollect = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.RESERVE_AND_COLLECT, null, OFFER);
        lineReserveAndCollect.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.HANDOVER_STARTED);
        lineReserveAndCollect.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.REJECTED);
        lineReserveAndCollect.getDelivery().getCollect().getFlags().raiseFlag(CollectStatus.NOT_COLLECTED);

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                lineOrderAndCollect,
                lineReserveAndCollect
            ))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).buCode("001").build())
            .executionActions(new ArrayList<>())
            .build());


        MonoMock<Void> alertMessageCall = MonoMock.empty();

        lenient().when(alertMessageService.sendCreateAlertMessage(alertMessageInputArgumentCaptor.capture())).thenReturn(alertMessageCall);

        assertThat(rule.when(context)).isFalse();

    }

    @Test
    void shouldDoNothingIfThereAreNoRejectedLines() {
        RuleEngineContext context = new RuleEngineContext();
        LineExecution lineSFW = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        lineSFW.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.ACCEPTED);
        LineExecution lineSFP = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, null, OFFER);
        lineSFP.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.ACCEPTED);
        LineExecution lineOrderAndCollect = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);
        lineOrderAndCollect.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.ACCEPTED);
        LineExecution lineReserveAndCollect = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.RESERVE_AND_COLLECT, null, OFFER);
        lineReserveAndCollect.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.ACCEPTED);

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                lineSFW,
                lineSFP,
                lineOrderAndCollect,
                lineReserveAndCollect
            ))
            .existingCustomerOrder(CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).buCode("001").build())
            .executionActions(new ArrayList<>())
            .build());

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void shouldDoNothingIfAnAlertAlreadyExists() {
        String customerOrderId = UUID.randomUUID().toString();
        RuleEngineContext context = new RuleEngineContext();
        LineExecution lineSFW = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        lineSFW.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.REJECTED);

        context.setAlertData(AlertData.builder()
            .existingAlerts(List.of(Alert.builder()
                .customerOrderId(customerOrderId)
                .status(AlertStatus.CREATED)
                .specificData(PromisedDateSpecificData.builder()
                    .reason("OUT_OF_STOCK")
                    .build())
                .buCode("001")
                .impactedLinesIds(List.of(lineSFW.getLineId()))
                .build()))
            .build());
        context.setOrderData(OrderData.builder()
            .executionActions(new ArrayList<>())
            .existingLineExecutions(List.of(
                lineSFW
            ))
            .existingCustomerOrder(CustomerOrder.builder()
                .status(CustomerOrderStatus.VALIDATED)
                .buCode("001")
                .id(customerOrderId)
                .build())
            .build());

        assertThat(rule.when(context)).isFalse();
    }
}
