package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.service;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ConfigurationService;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.service.ahs.AhsCommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus.CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus.VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class StartExecutionServiceRuleTest {

    private StartExecutionServiceRule rule;

    @Mock
    private AhsCommandEventService ahsCommandEventService;

    @Captor
    private ArgumentCaptor<List<LineExecution>> outputLineExecutionsCaptor;

    @BeforeEach
    void setUp() {
        rule = new StartExecutionServiceRule(ahsCommandEventService);
    }

    @Test
    void shouldStartServiceExecution() {
        LineExecution serviceLine1 = generateALine(false, null, false, true, false, false, VALIDATED, null, null, SERVICE);
        LineExecution associatedProductLine2WithService1 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution associatedProductLine1WithService1 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);

        LineExecution serviceLine2 = generateALine(false, null, false, true, false, false, VALIDATED, null, null, SERVICE);
        LineExecution associatedProductLineWithService2 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);

        LineExecution serviceAlone = generateALine(false, null, false, true, false, false, VALIDATED, null, null, SERVICE);

        LineExecution serviceLine3 = generateALine(false, null, false, true, false, false, VALIDATED, null, null, SERVICE);
        LineExecution associatedProductLine1WithService3 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution associatedCanceledProductWithService3 = generateALine(false, null, false, true, false, false, CANCELED, DeliveryType.SFW, null, OFFER);

        String givenConfigurationIdentifier1 = UUID.randomUUID().toString();
        serviceLine1.setConfigurationService(ConfigurationService.builder()
            .id(givenConfigurationIdentifier1)
            .associatedLinesId(LineExecution.lineIds(List.of(associatedProductLine1WithService1, associatedProductLine2WithService1)))
            .build());

        String givenConfigurationIdentifier2 = UUID.randomUUID().toString();
        serviceLine2.setConfigurationService(ConfigurationService.builder()
            .id(givenConfigurationIdentifier2)
            .associatedLinesId(LineExecution.lineIds(List.of(associatedProductLineWithService2)))
            .build());

        String givenConfigurationIdentifier3 = UUID.randomUUID().toString();
        serviceAlone.setConfigurationService(ConfigurationService.builder()
            .id(givenConfigurationIdentifier3)
            .associatedLinesId(List.of())
            .build());

        String givenConfigurationIdentifier4 = UUID.randomUUID().toString();
        serviceLine3.setConfigurationService(ConfigurationService.builder()
            .id(givenConfigurationIdentifier4)
            .associatedLinesId(LineExecution.lineIds(List.of(associatedProductLine1WithService3, associatedCanceledProductWithService3)))
            .build());

        RuleEngineContext context = new RuleEngineContext();

        List<LineExecution> allLines = List.of(associatedProductLine1WithService1, associatedProductLine2WithService1, serviceLine1, associatedProductLineWithService2, serviceLine2, serviceAlone, associatedProductLine1WithService3, associatedCanceledProductWithService3, serviceLine3);
        context.setOrderData(OrderData.builder()
            .existingCustomerOrder(CustomerOrder.builder()
                .status(CustomerOrderStatus.VALIDATED)
                .orderPlaceType(CustomerOrderPlaceType.IN_STORE)
                .build())
            .existingLineExecutions(allLines)
            .build());

        MonoMock<Void> ahsCall1 = MonoMock.empty();
        when(ahsCommandEventService.sendCustomerOrderValidatedWithInstallation(any(CustomerOrder.class), outputLineExecutionsCaptor.capture())).thenReturn(ahsCall1);

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        ahsCall1.expectHasBeenSubscribed();

        verify(ahsCommandEventService, times(1)).sendCustomerOrderValidatedWithInstallation(eq(context.getOrderData().getExistingCustomerOrder()), anyList());

        List<LineExecution> expectedResultLines = List.of(associatedProductLine1WithService1, associatedProductLine2WithService1, serviceLine1, associatedProductLineWithService2, serviceLine2, serviceAlone, associatedProductLine1WithService3, serviceLine3);
        List<LineExecution> resultLines = outputLineExecutionsCaptor.getValue();
        assertThat(resultLines).hasSize(expectedResultLines.size());
        resultLines.forEach(line -> assertThat(LineExecution.joinLineIds(expectedResultLines)).contains(line.getLineId()));

        assertThat(serviceLine1.getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATION_REQUESTED)).isTrue();
        assertThat(serviceLine2.getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATION_REQUESTED)).isTrue();
        assertThat(serviceAlone.getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATION_REQUESTED)).isTrue();
        assertThat(serviceLine3.getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATION_REQUESTED)).isTrue();

        //DO not trigger rule second time because delivery status has changed
        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void shouldStartServiceWithoutDuplicatesExecution() {
        LineExecution serviceLine1 = generateALine(false, null, false, true, false, false, VALIDATED, null, null, SERVICE);
        LineExecution associatedProductLine2WithService1 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution associatedProductLine1WithService1 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);

        LineExecution serviceLine2 = generateALine(false, null, false, true, false, false, VALIDATED, null, null, SERVICE);
        LineExecution associatedProductLineWithService2 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);

        LineExecution serviceLine3 = generateALine(false, null, false, true, false, false, VALIDATED, null, null, SERVICE);
        LineExecution associatedProductLine1WithService3 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution associatedCanceledProductWithService3 = generateALine(false, null, false, true, false, false, CANCELED, DeliveryType.SFW, null, OFFER);

        String givenConfigurationIdentifier1 = UUID.randomUUID().toString();
        ConfigurationService configurationService = ConfigurationService.builder()
            .id(givenConfigurationIdentifier1)
            .associatedLinesId(LineExecution.lineIds(List.of(associatedProductLine1WithService1, associatedProductLine2WithService1, associatedProductLineWithService2, associatedProductLine1WithService3, associatedCanceledProductWithService3)))
            .build();
        serviceLine1.setConfigurationService(configurationService);
        serviceLine2.setConfigurationService(configurationService);
        serviceLine3.setConfigurationService(configurationService);

        RuleEngineContext context = new RuleEngineContext();

        List<LineExecution> allLines = List.of(associatedProductLine1WithService1, associatedProductLine2WithService1, serviceLine1, associatedProductLineWithService2, serviceLine2, associatedProductLine1WithService3, associatedCanceledProductWithService3, serviceLine3);
        context.setOrderData(OrderData.builder()
            .existingCustomerOrder(CustomerOrder.builder()
                .status(CustomerOrderStatus.VALIDATED)
                .orderPlaceType(CustomerOrderPlaceType.IN_STORE)
                .build())
            .existingLineExecutions(allLines)
            .build());

        MonoMock<Void> ahsCall1 = MonoMock.empty();
        when(ahsCommandEventService.sendCustomerOrderValidatedWithInstallation(any(CustomerOrder.class), outputLineExecutionsCaptor.capture())).thenReturn(ahsCall1);

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        ahsCall1.expectHasBeenSubscribed();

        verify(ahsCommandEventService, times(1)).sendCustomerOrderValidatedWithInstallation(eq(context.getOrderData().getExistingCustomerOrder()), anyList());

        List<LineExecution> expectedResultLines = List.of(associatedProductLine1WithService1, associatedProductLine2WithService1, serviceLine1, associatedProductLineWithService2, serviceLine2, associatedProductLine1WithService3, serviceLine3);
        List<LineExecution> resultLines = outputLineExecutionsCaptor.getValue();
        assertThat(resultLines).hasSize(expectedResultLines.size());
        resultLines.forEach(line -> assertThat(LineExecution.joinLineIds(expectedResultLines)).contains(line.getLineId()));

        assertThat(serviceLine1.getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATION_REQUESTED)).isTrue();
        assertThat(serviceLine2.getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATION_REQUESTED)).isTrue();
        assertThat(serviceLine3.getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATION_REQUESTED)).isTrue();

        //DO not trigger rule second time because delivery status has changed
        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void shouldNotStartServiceExecutionBecauseOneAssociatedLineNotValidated() {
        LineExecution serviceLine1 = generateALine(false, null, false, true, true, false, VALIDATED, null, null, SERVICE);
        LineExecution associatedProductLine1WithService1 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution associatedProductLine2WithService1 = generateALine(false, null, false, false, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);

        List<LineExecution> allLines = List.of(associatedProductLine1WithService1, associatedProductLine2WithService1, serviceLine1);

        String givenConfigurationIdentifier1 = UUID.randomUUID().toString();
        serviceLine1.setConfigurationService(ConfigurationService.builder()
            .id(givenConfigurationIdentifier1)
            .associatedLinesId(LineExecution.lineIds(List.of(associatedProductLine1WithService1, associatedProductLine2WithService1)))
            .build());

        RuleEngineContext context = new RuleEngineContext();

        context.setOrderData(OrderData.builder()
            .existingCustomerOrder(CustomerOrder.builder()
                .status(CustomerOrderStatus.VALIDATED)
                .orderPlaceType(CustomerOrderPlaceType.IN_STORE)
                .build())
            .existingLineExecutions(allLines)
            .build());

        assertThat(rule.when(context)).isFalse();
    }

}
