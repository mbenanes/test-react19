package com.adeo.sales.customerorder.tempoorchestrator.v3.rule.quotation;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.QuotationDataGetter;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.input.CashingStoreAssignerInput;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.quotation.ProvideCashingStoreIdAndCreateLoyaltyLineRule;
import com.adeo.sales.customerorder.tempoorchestrator.model.Clock;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderMetadata;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProvideCashingStoreIdAndCreateLoyaltyLineRuleTest {

    private ProvideCashingStoreIdAndCreateLoyaltyLineRule rule;

    @Mock
    private QuotationDataGetter quotationDataGetter;

    @BeforeEach
    void setUp() {
        rule = new ProvideCashingStoreIdAndCreateLoyaltyLineRule(quotationDataGetter);
    }

    @Test
    void should_retrieve_cashing_store_id_if_missing() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode("001")
            .metadata(CustomerOrderMetadata.builder()
                .createdAt(OffsetDateTime.now())
                .createdBy(CustomerOrderMetadata.UserIdentifier.builder()
                    .reference("")
                    .type("")
                    .build())
                .build())
            .quotation(new Clock(UUID.randomUUID().toString(), 1))
            .build();

        LineExecution firstLine = generateALine(false, null, true, false, CompositionOrderStatus.VALIDATED, null, null, OFFER);
        firstLine.getPayment().setStoreId(null);

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(new ArrayList<>(List.of(firstLine)))
            .existingCustomerOrder(customerOrder)
            .build());

        MonoMock<QuotationDataGetter.QuotationData> quotationCall = MonoMock.just(QuotationDataGetter.QuotationData.builder()
            .metadataByOfferLineId(Map.of(firstLine.getLineId(), QuotationDataGetter.LineMetadata.builder()
                .cashingStore("011")
                .build()))
            .loyaltyFees(List.of(QuotationDataGetter.LoyaltyFee.builder()
                .id(UUID.randomUUID().toString())
                .cashingStore("011")
                .amount(BigDecimal.ONE)
                .refLM("1234")
                .vendorId("12345")
                .build()))
            .build());

        when(quotationDataGetter.apply(any(CashingStoreAssignerInput.class))).thenReturn(quotationCall);

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context)).verifyComplete();

        verify(quotationDataGetter, times(1)).apply(any(CashingStoreAssignerInput.class));

        quotationCall.expectHasBeenSubscribed();

        assertThat(firstLine.getPayment().getStoreId()).isEqualTo("011");

        assertThat(context.getOrderData().getExistingLineExecutions()).hasSize(2);

        LineExecution loyaltyFee = context.getOrderData().getExistingLineExecutions().get(1);
        assertThat(loyaltyFee.getLineType()).isEqualTo(LineType.LOYALTY_FEE);
    }

    @Test
    void should_not_start_rule_because_already_have_cashing_store() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode("001")
            .metadata(CustomerOrderMetadata.builder()
                .createdAt(OffsetDateTime.now())
                .createdBy(CustomerOrderMetadata.UserIdentifier.builder()
                    .reference("")
                    .type("")
                    .build())
                .build())
            .quotation(new Clock(UUID.randomUUID().toString(), 1))
            .build();

        LineExecution firstLine = generateALine(false, null, true, false, CompositionOrderStatus.VALIDATED, null, null, OFFER);
        firstLine.getPayment().setStoreId("001");

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(new ArrayList<>(List.of(firstLine)))
            .existingCustomerOrder(customerOrder)
            .build());

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_because_not_have_composition_quotation_id() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode("001")
            .metadata(CustomerOrderMetadata.builder()
                .createdAt(OffsetDateTime.now())
                .createdBy(CustomerOrderMetadata.UserIdentifier.builder()
                    .reference("")
                    .type("")
                    .build())
                .build())
            .build();

        LineExecution firstLine = generateALine(false, null, true, false, CompositionOrderStatus.VALIDATED, null, null, OFFER);
        firstLine.getPayment().setStoreId(null);

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(new ArrayList<>(List.of(firstLine)))
            .existingCustomerOrder(customerOrder)
            .build());

        assertThat(rule.when(context)).isFalse();
    }

}

