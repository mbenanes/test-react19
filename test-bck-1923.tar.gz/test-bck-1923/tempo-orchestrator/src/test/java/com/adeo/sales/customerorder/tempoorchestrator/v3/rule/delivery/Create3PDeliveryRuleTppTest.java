package com.adeo.sales.customerorder.tempoorchestrator.v3.rule.delivery;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.ThirdPartyDeliveryCommandManager;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery.tpp.Create3PDeliveryRuleTpp;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class Create3PDeliveryRuleTppTest {

    private Create3PDeliveryRuleTpp rule;

    @Mock
    private ThirdPartyDeliveryCommandManager thirdPartyDeliveryCommandManager;

    @Captor
    private ArgumentCaptor<List<LineExecution>> linesCaptor;

    @BeforeEach
    void setUp() {
        rule = new Create3PDeliveryRuleTpp(thirdPartyDeliveryCommandManager);
    }

    @Test
    void should_create_3P_order() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder existingCustomerOrder = CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(false, null, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER),
                generateALine(true, null, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER)
            ))
            .existingCustomerOrder(existingCustomerOrder)
            .build());

        MonoMock<Void> thirdPartyCall = MonoMock.empty();
        when(thirdPartyDeliveryCommandManager.createCommand(linesCaptor.capture(), any(CustomerOrder.class))).thenReturn(thirdPartyCall);

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        verify(thirdPartyDeliveryCommandManager, times(1)).createCommand(linesCaptor.capture(), any(CustomerOrder.class));

        thirdPartyCall.expectHasBeenSubscribed();

        assertThat(linesCaptor.getValue()).hasSize(1);
        assertThat(linesCaptor.getValue().get(0).getLineId()).isEqualTo(context.getOrderData().getExistingLineExecutions().get(1).getLineId());
        assertThat(linesCaptor.getValue().get(0).getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATION_REQUESTED)).isTrue();

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_if_no_3p_lines() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder existingCustomerOrder = CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(false, null, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER),
                generateALine(false, null, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER)
            ))
            .existingCustomerOrder(existingCustomerOrder)
            .build());

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_if_composition_status_not_validated() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder existingCustomerOrder = CustomerOrder.builder().status(CustomerOrderStatus.PENDING_VALIDATION).build();
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                generateALine(false, null, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER),
                generateALine(true, null, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER)
            ))
            .existingCustomerOrder(existingCustomerOrder)
            .build());

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_if_delivery_date_not_confirmed() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder existingCustomerOrder = CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build();
        LineExecution firstLine = generateALine(true, null, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);
        firstLine.getComposition().setPromisedDateConfirmed(false);
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                firstLine
            ))
            .existingCustomerOrder(existingCustomerOrder)
            .build());

        assertThat(rule.when(context)).isFalse();
    }


    @Test
    void should_not_start_rule_if_requirements_not_compliant() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder existingCustomerOrder = CustomerOrder.builder().status(CustomerOrderStatus.VALIDATED).build();
        LineExecution firstLine = generateALine(true, null, false, false, false, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                firstLine
            ))
            .existingCustomerOrder(existingCustomerOrder)
            .build());

        assertThat(rule.when(context)).isFalse();

        firstLine.getPaymentRequirements().getValidationFlags().raiseFlag(RequirementStatus.COMPLIANT);

        assertThat(rule.when(context)).isFalse();

        firstLine.getPaymentRequirements().getConfirmationFlags().raiseFlag(RequirementStatus.COMPLIANT);

        assertThat(rule.when(context)).isFalse();

        firstLine.getPaymentRequirements().getVendorOrderCreationFlags().raiseFlag(RequirementStatus.COMPLIANT);

        assertThat(rule.when(context)).isTrue();
    }
}
