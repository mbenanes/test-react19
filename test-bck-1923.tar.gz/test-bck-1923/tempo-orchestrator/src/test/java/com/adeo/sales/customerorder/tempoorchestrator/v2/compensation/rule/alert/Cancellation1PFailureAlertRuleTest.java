package com.adeo.sales.customerorder.tempoorchestrator.v2.compensation.rule.alert;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.FixedDeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.alert.AlertData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert.Cancellation1PFailureAlertRule;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.alert.tpp.Cancellation1PFailureAlertTPPRule;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertReason;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.AlertSpecificData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment;
import com.adeo.sales.customerorder.tempoorchestrator.service.AlertMessageService;
import com.adeo.sales.customerorder.tempoorchestrator.service.dto.AlertMessageInput;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.execution.InitializeExecutionActionWorkflowRuleStart.addStep;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class Cancellation1PFailureAlertRuleTest {

    private Cancellation1PFailureAlertRule rule;

    private Cancellation1PFailureAlertTPPRule cancellation1PFailureAlertRuleTest;

    @Mock
    private AlertMessageService alertMessageService;


    @Captor
    private ArgumentCaptor<AlertMessageInput> alertMessageInputCaptor;

    @BeforeEach
    void setUp() {
        rule = new Cancellation1PFailureAlertRule(alertMessageService);
        cancellation1PFailureAlertRuleTest = new Cancellation1PFailureAlertTPPRule(alertMessageService);
    }

    @Test
    void shouldNotSendAlertBecauseStatusInvalid() {
        RuleEngineContext context = this.generateContext();
        List<LineExecution> linesExecutions = context.getOrderData().getExistingLineExecutions();
        linesExecutions.get(0).getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.CANCELED);
        linesExecutions.get(1).getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.CANCELED);
        context.getOrderData().setExecutionActions(List.of());

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void shouldNotSendAlertBecauseAlertAlreadyExists() {
        RuleEngineContext context = this.generateContext();
        List<LineExecution> linesExecutions = context.getOrderData().getExistingLineExecutions();
        Map<String, List<String>> impactedLineByExecution = Map.of(linesExecutions.get(0).getExecutionId(), List.of(linesExecutions.get(0).getLineId()));


        final var lineMetadataById = linesExecutions.stream()
            .map(line -> AlertSpecificData.LineMetadata.fromOrderAndLine(context.getOrderData().getExistingCustomerOrder(), line))
            .collect(Collectors.toMap(AlertSpecificData.LineMetadata::getLineId, Function.identity()));

        context.getAlertData().getExistingAlerts().add(Alert.buildNewAlert(context.getCustomerOrderId(), context.getBuCode(), impactedLineByExecution, "WAREHOUSE", AlertReason.CUSTOMER_CANCELLATION_FAILURE.name(), null, null, null, null, LineExecutionPayment.PaymentExecutionSystem.TPP, List.of(), lineMetadataById));

        generateActionExecutionContext(context);

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void shouldSendAlertDecreaseQuantityFailed() {
        RuleEngineContext context = this.generateContext();
        List<LineExecution> linesExecutions = context.getOrderData().getExistingLineExecutions();
        linesExecutions.stream()
            .forEach(lineExecution -> {
                lineExecution.getPayment().setPaymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.TPP);
                lineExecution.getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.ABORT_FAILED);
            });

        generateActionExecutionContext(context);

        MonoMock<Void> alertMessageServiceCall = MonoMock.empty();
        when(alertMessageService.sendCreateAlertMessage(any(AlertMessageInput.class))).thenReturn(alertMessageServiceCall);

        assertThat(cancellation1PFailureAlertRuleTest.when(context)).isTrue();

        StepVerifier.create(cancellation1PFailureAlertRuleTest.then(context)).verifyComplete();

        alertMessageServiceCall.expectHasBeenSubscribed();

        verify(alertMessageService).sendCreateAlertMessage(alertMessageInputCaptor.capture());

        Alert createdAlert = alertMessageInputCaptor.getValue().getAlert();
        assertThat(createdAlert).isNotNull();
        assertThat(createdAlert.getSpecificData().getReason()).isEqualTo(AlertReason.CUSTOMER_CANCELLATION_FAILURE.name());
        assertThat(createdAlert.getImpactedLinesIds()).hasSize(1);
        assertThat(createdAlert.getImpactedLinesIds().get(0)).isEqualTo(linesExecutions.get(0).getLineId());
    }


    @Test
    void shouldSendAlertAbortFailed() {
        RuleEngineContext context = this.generateContext();
        context.getOrderData().setExecutionActions(List.of());
        List<LineExecution> linesExecutions = context.getOrderData().getExistingLineExecutions();
        linesExecutions.get(0).getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.ABORT_FAILED);
        linesExecutions.get(1).getDelivery().getFlags().raiseFlag(CustomerOrderLineDeliveryStatus.ABORT_FAILED);
        linesExecutions.get(0).getPayment().setPaymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.PSR);
        linesExecutions.get(1).getPayment().setPaymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.PSR);

        MonoMock<Void> alertMessageServiceCall = MonoMock.empty();
        when(alertMessageService.sendCreateAlertMessage(any(AlertMessageInput.class))).thenReturn(alertMessageServiceCall);

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context)).verifyComplete();

        alertMessageServiceCall.expectHasBeenSubscribed();

        verify(alertMessageService).sendCreateAlertMessage(alertMessageInputCaptor.capture());

        Alert createdAlert = alertMessageInputCaptor.getValue().getAlert();
        assertThat(createdAlert).isNotNull();
        assertThat(createdAlert.getSpecificData().getReason()).isEqualTo(AlertReason.CUSTOMER_CANCELLATION_FAILURE.name());
        assertThat(createdAlert.getImpactedLinesIds()).hasSize(1);
        assertThat(createdAlert.getImpactedLinesIds().get(0)).isEqualTo(linesExecutions.get(0).getLineId());
    }

    private RuleEngineContext generateContext() {
        RuleEngineContext context = new RuleEngineContext();

        LineExecution firstLineSfw = LineExecution.builder()
            .executionId(UUID.randomUUID().toString())
            .lineId(UUID.randomUUID().toString())
            .payment(LineExecutionPayment.builder()
                .build())
            .delivery(LineExecutionDelivery.builder()
                .deliveryType(DeliveryType.SFW)
                .customerKnownDeliveryDate(new FixedDeliveryDate(OffsetDateTime.now()))
                .build())
            .executionId(UUID.randomUUID().toString())
            .build();

        LineExecution firstLineSfp = LineExecution.builder()
            .executionId(UUID.randomUUID().toString())
            .isSoldByAThirdPartyVendor(true)
            .lineId(UUID.randomUUID().toString())
            .payment(LineExecutionPayment.builder()
                .build())
            .delivery(LineExecutionDelivery.builder()
                .deliveryType(DeliveryType.SFP)
                .customerKnownDeliveryDate(new FixedDeliveryDate(OffsetDateTime.now()))
                .build())
            .executionId(UUID.randomUUID().toString())
            .build();

        context.setOrderData(OrderData.builder()
            .existingCustomerOrder(CustomerOrder.builder()
                .buCode("001")
                .id(UUID.randomUUID().toString())
                .build())
            .existingLineExecutions(List.of(firstLineSfw, firstLineSfp))
            .build());
        context.setAlertData(AlertData.builder().build());
        return context;
    }

    private void generateActionExecutionContext(RuleEngineContext context) {
        LineExecution sfwLine = context.getOrderData().getExistingLineExecutions().get(0);

        ImpactedLine impactedLine = ImpactedLine.builder()
            .quantity(sfwLine.getQuantity())
            .lineId(sfwLine.getLineId())
            .build();
        addStep(impactedLine.getSteps(), ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY, true);
        addStep(impactedLine.getSteps(), ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP, true);
        addStep(impactedLine.getSteps(), ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION, true);
        impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY).get().getFlags().raiseFlag(ImpactedLineStep.Status.FAILED);
        ExecutionAction executionAction = ExecutionAction.builder()
            .actionType(ExecutionActionType.DECREASE_QUANTITY)
            .createdAt(Instant.now())
            .impactedExecutions(List.of(ImpactedExecution.builder()
                .currentExecutionId(sfwLine.getExecutionId())
                .impactedLines(List.of(impactedLine))
                .build()))
            .customerOrderId(context.getCustomerOrderId())
            .build();
        executionAction.getFlags().raiseFlag(ExecutionActionStatus.FAILED);

        context.getOrderData().setExecutionActions(List.of(executionAction));
    }
}
