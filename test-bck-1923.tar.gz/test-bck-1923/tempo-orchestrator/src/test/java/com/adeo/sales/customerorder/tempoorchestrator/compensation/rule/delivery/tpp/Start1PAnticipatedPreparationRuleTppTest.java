package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.service.FullfillmentPreparationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.OffsetDateTime;
import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus.VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType.RESERVE_AND_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class Start1PAnticipatedPreparationRuleTppTest {

    private Start1PAnticipatedPreparationRuleTpp rule;
    RuleEngineContext givenContext;

    @Mock
    private FullfillmentPreparationService fullfillmentAnticipatedPreparationService;

    @BeforeEach
    void setUp() {
        rule = new Start1PAnticipatedPreparationRuleTpp(fullfillmentAnticipatedPreparationService);
        givenContext = new RuleEngineContext();
        givenContext.setOrderData(OrderData.builder()
            .existingCustomerOrder(CustomerOrder.builder()
                .status(CustomerOrderStatus.VALIDATED)
                .build())
            .build());
    }

    @Test
    void shouldTriggerPreparationWhenReceivedConfirmationRequirement() {
        // Given
        var givenLineExecution = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getPaymentRequirements().setStockReservationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.COMPLIANT.name(), null)));
        givenLineExecution.setExternalSystem(ExternalSystem.builder().name(ExternalSystem.SystemName.TEMPO).build());
        OffsetDateTime firstValidatedAt = OffsetDateTime.now();
        OffsetDateTime appointmentDateTooClosed = firstValidatedAt.plusHours(1).plusMinutes(59);
        givenLineExecution.getComposition().setCreatedAt(firstValidatedAt);
        givenLineExecution.getDelivery().getCollect().setAppointmentDate(appointmentDateTooClosed);
        givenLineExecution.getDelivery().getCollect().getFlags().raiseFlag(CollectStatus.EXPECTED);

        givenContext.getOrderData().setExistingLineExecutions(List.of(givenLineExecution));
        givenContext.getOrderData().getExistingCustomerOrder().setOrderPlaceType(CustomerOrderPlaceType.IN_STORE);

        when(fullfillmentAnticipatedPreparationService.createOrderAnticipatedPreparation(anyList(), any())).thenReturn(Mono.empty());


        // When
        boolean result = rule.when(givenContext);

        // Then
        assertThat(result).isTrue();
        StepVerifier.create(rule.then(givenContext))
            .verifyComplete();
        verify(fullfillmentAnticipatedPreparationService, times(1)).createOrderAnticipatedPreparation(anyList(), any());
    }

    @Test
    void shouldNotTriggerPreparationWhenExternalSystemIsPyxisAndPlaceIsInStore() {
        // Given
        var givenLineExecution = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getPaymentRequirements().setStockReservationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.COMPLIANT.name(), null)));
        givenLineExecution.getPaymentRequirements().setPreparationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.APPROVED.name(), null)));
        givenLineExecution.setExternalSystem(ExternalSystem.builder().name(ExternalSystem.SystemName.PYXIS).build());

        OffsetDateTime firstValidatedAt = OffsetDateTime.now();
        OffsetDateTime appointmentDateTooClosed = OffsetDateTime.now().plusHours(2);
        givenLineExecution.getComposition().setCreatedAt(firstValidatedAt);
        givenLineExecution.getDelivery().getCollect().setAppointmentDate(appointmentDateTooClosed);
        givenLineExecution.getDelivery().getCollect().getFlags().raiseFlag(CollectStatus.EXPECTED);

        givenContext.getOrderData().setExistingLineExecutions(List.of(givenLineExecution));
        givenContext.getOrderData().getExistingCustomerOrder().setOrderPlaceType(CustomerOrderPlaceType.IN_STORE);

        // When
        boolean result = rule.when(givenContext);

        // Then
        assertThat(result).isFalse();
    }

    @Test
    void shouldNotTriggerPreparationWhenPreparationRequirementIsNotCompliant() {
        // Given
        var givenLineExecution = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getPaymentRequirements().setStockReservationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.COMPLIANT.name(), null)));
        givenLineExecution.getPaymentRequirements().setPreparationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.FAILED.name(), null)));

        OffsetDateTime firstValidatedAt = OffsetDateTime.now();
        OffsetDateTime appointmentDateTooClosed = OffsetDateTime.now().plusHours(2);
        givenLineExecution.getComposition().setCreatedAt(firstValidatedAt);
        givenLineExecution.getDelivery().getCollect().setAppointmentDate(appointmentDateTooClosed);
        givenLineExecution.getDelivery().getCollect().getFlags().raiseFlag(CollectStatus.EXPECTED);

        givenContext.getOrderData().setExistingLineExecutions(List.of(givenLineExecution));

        // When
        boolean result = rule.when(givenContext);

        // Then
        assertThat(result).isFalse();
    }

    @Test
    void shouldNotTriggerPreparationWhenReservationRequirementNotCompliant() {
        // Given
        var givenLineExecution = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getPaymentRequirements().setStockReservationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.COMPLIANT.name(), null)));
        givenLineExecution.getPaymentRequirements().setConfirmationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.NOT_COMPLIANT.name(), null)));

        OffsetDateTime firstValidatedAt = OffsetDateTime.now();
        OffsetDateTime appointmentDateTooClosed = OffsetDateTime.now().plusHours(2);
        givenLineExecution.getComposition().setCreatedAt(firstValidatedAt);
        givenLineExecution.getDelivery().getCollect().setAppointmentDate(appointmentDateTooClosed);
        givenLineExecution.getDelivery().getCollect().getFlags().raiseFlag(CollectStatus.EXPECTED);

        givenContext.getOrderData().setExistingLineExecutions(List.of(givenLineExecution));

        // When
        boolean result = rule.when(givenContext);

        // Then
        assertThat(result).isFalse();
    }

    @Test
    void shouldNotTriggerPreparationWhenDeliveryIsOnReservationRequested() {
        var givenLineExecution = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVATION_REQUESTED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getPaymentRequirements().setStockReservationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.COMPLIANT.name(), null)));
        givenLineExecution.getPaymentRequirements().setPreparationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.APPROVED.name(), null)));
        givenLineExecution.getPaymentRequirements().setConfirmationFlags(new Flags<>());

        OffsetDateTime firstValidatedAt = OffsetDateTime.now();
        OffsetDateTime appointmentDateTooClosed = OffsetDateTime.now().plusHours(2);
        givenLineExecution.getComposition().setCreatedAt(firstValidatedAt);
        givenLineExecution.getDelivery().getCollect().setAppointmentDate(appointmentDateTooClosed);
        givenLineExecution.getDelivery().getCollect().getFlags().raiseFlag(CollectStatus.EXPECTED);

        givenContext.getOrderData().setExistingLineExecutions(List.of(givenLineExecution));

        // When
        boolean result = rule.when(givenContext);

        // Then
        assertThat(result).isFalse();
    }

    @Test
    void shouldNotTriggerPreparationWhenDeliveryDateIsNotConfirmed() {
        var givenLineExecution = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution.getDelivery().setFlags(null);
        givenLineExecution.getPaymentRequirements().setStockReservationFlags(new Flags<>(new Flag("", OffsetDateTime.now(), RequirementStatus.COMPLIANT.name(), null)));
        givenLineExecution.getComposition().setPromisedDateConfirmed(false);

        OffsetDateTime firstValidatedAt = OffsetDateTime.now();
        OffsetDateTime appointmentDateTooClosed = OffsetDateTime.now().plusHours(2);
        givenLineExecution.getComposition().setCreatedAt(firstValidatedAt);
        givenLineExecution.getDelivery().getCollect().setAppointmentDate(appointmentDateTooClosed);
        givenLineExecution.getDelivery().getCollect().getFlags().raiseFlag(CollectStatus.EXPECTED);

        givenContext.getOrderData().setExistingLineExecutions(List.of(givenLineExecution));

        // When
        boolean result = rule.when(givenContext);

        // Then
        assertThat(result).isFalse();
    }



}
