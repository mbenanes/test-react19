package com.adeo.sales.customerorder.tempoorchestrator.applicationservice;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.CustomerOrderLineCreatedApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.input.CustomerOrderLineCreatedInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecutionComposition;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.assertj.core.api.AssertionsForInterfaceTypes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;
import reactor.util.function.Tuple5;
import reactor.util.function.Tuples;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderLineStatus.VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.CREATION_REQUESTED;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class CustomerPaymentOrderLineCreatedApplicationServiceTest {

    private static final String EXTERNAL_ORCHESTRATOR_ID = "001-20300L8-A";
    private static final String CUSTOMER_ORDER_ID = "customerOrderId";
    private static final String BU_CODE = "001";

    private CustomerOrderLineCreatedApplicationService applicationService;

    @Mock
    private RuleEngineService ruleEngineService;


    @BeforeEach
    public void setup() {
        applicationService = new CustomerOrderLineCreatedApplicationService(ruleEngineService);
    }

    @Test
    void should_update_line_deliver_status_and_system_id() {
           CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .id(CUSTOMER_ORDER_ID)
            .buCode(BU_CODE)
            .build();
        String lineId = UUID.randomUUID().toString();
        List<LineExecution> bddLineExecutions = List.of(LineExecution.builder()
            .lineId(lineId)
            .externalSystem(ExternalSystem.builder()
                .origin(ExternalSystem.SystemName.BOMP)
                .name(ExternalSystem.SystemName.BOMP)
                .build())
            .composition(LineExecutionComposition.builder()
                .flags(new Flags<>(new Flag("", OffsetDateTime.now(), VALIDATED.name(), null)))
                .build())
            .delivery(LineExecutionDelivery.builder()
                .deliveryType(DeliveryType.THIRD_PARTY)
                .flags(new Flags<>(new Flag("", OffsetDateTime.now(), CREATION_REQUESTED.name(), null)))
                .build())
            .build());

        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLineExecutions, List.of(), List.of(), List.of()));
        lenient().when(ruleEngineService.lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        MonoMock<Void> runRuleEngineCall = MonoMock.empty();
        lenient().when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> runRuleEngineCall);

        CustomerOrderLineCreatedInput input = CustomerOrderLineCreatedInput.builder()
            .createdLineIds(List.of(lineId))
            .bompId(EXTERNAL_ORCHESTRATOR_ID)
            .customerOrderId(CUSTOMER_ORDER_ID)
            .buCode(BU_CODE)
            .build();
        StepVerifier.create(applicationService.apply(input))
            .verifyComplete();

        lockAndGetDataCall.expectHasBeenSubscribed();
        runRuleEngineCall.expectHasBeenSubscribed();

        verify(ruleEngineService).lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode());
        verify(ruleEngineService).startRuleEngineAndUpdateLines();

        assertThat(bddLineExecutions.get(0).getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATED)).isTrue();
        AssertionsForInterfaceTypes.assertThat(bddLineExecutions.get(0).getExternalSystem().getName()).isEqualTo(ExternalSystem.SystemName.BOMP);
        AssertionsForInterfaceTypes.assertThat(bddLineExecutions.get(0).getExternalSystem().getOrigin()).isEqualTo(ExternalSystem.SystemName.BOMP);
        assertThat(bddLineExecutions.get(0).getExternalSystem().getId()).isEqualTo(EXTERNAL_ORCHESTRATOR_ID);
        assertThat(bddLineExecutions.get(0).getExternalSystem().getStoreCode()).isEqualTo(null);
    }
}
