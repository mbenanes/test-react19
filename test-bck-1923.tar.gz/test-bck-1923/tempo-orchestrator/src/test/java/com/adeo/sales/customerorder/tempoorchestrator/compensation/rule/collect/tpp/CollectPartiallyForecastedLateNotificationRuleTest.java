package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.collect.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.dto.dst.FixedDeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.collect.tpp.CollectPartiallyForecastedLateNotificationRule;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.NotificationStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus.VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType.RESERVE_AND_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CollectPartiallyForecastedLateNotificationRuleTest {

    @Captor
    private ArgumentCaptor<List<LineExecution>> linesCaptor;

    private CollectPartiallyForecastedLateNotificationRule rule;

    @Mock
    private OutgoingNotificationService notificationService;

    @BeforeEach
    void setUp() {
        rule = new CollectPartiallyForecastedLateNotificationRule(notificationService);
    }

    @Test
    void shouldSendPartialDelayedNotification() {
        var givenExecutionIdA = UUID.randomUUID().toString();
        var givenLineExecution1 = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        var givenLineExecution2 = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);

        givenLineExecution1.setExecutionId(givenExecutionIdA);
        givenLineExecution2.setExecutionId(givenExecutionIdA);
        var collect = givenLineExecution1.getDelivery().getCollect();
        collect.setFlags(new Flags<>(new Flag("", OffsetDateTime.now(), CollectStatus.EXPECTED.name(), null)));
        collect.setGlobalCollectStatus(CollectStatus.EXPECTED);
        givenLineExecution1.getDelivery().setEstimatedDeliveryDate(new FixedDeliveryDate(OffsetDateTime.now()));
        collect.setAppointmentDate(OffsetDateTime.now().plusDays(2));

        var collect2 = givenLineExecution2.getDelivery().getCollect();
        collect2.setFlags(new Flags<>(new Flag("", OffsetDateTime.now(), CollectStatus.EXPECTED.name(), null)));
        collect2.setGlobalCollectStatus(CollectStatus.EXPECTED);
        givenLineExecution1.getDelivery().setEstimatedDeliveryDate(new FixedDeliveryDate(OffsetDateTime.now()));
        collect2.setAppointmentDate(OffsetDateTime.now().plusDays(2));

        var givenCustomerOrderId = UUID.randomUUID().toString();
        var givenContext = new RuleEngineContext();
        givenContext.setOrderData(OrderData.builder()
            .executions(List.of(Execution.builder().id(givenExecutionIdA).build()))
            .existingCustomerOrder(CustomerOrder.builder()
                .id(givenCustomerOrderId)
                .status(CustomerOrderStatus.VALIDATED)
                .orderPlaceType(CustomerOrderPlaceType.IN_STORE)
                .build())
            .existingLineExecutions(List.of(givenLineExecution1, givenLineExecution2))
            .build());

        assertThat(rule.when(givenContext)).isFalse();

        givenLineExecution1.getDelivery().setEstimatedDeliveryDate(new FixedDeliveryDate(OffsetDateTime.now().plusDays(4)));

        assertThat(rule.when(givenContext)).isTrue();

        when(notificationService.sendCollectPartiallyForecastedLateNotification(any(CustomerOrder.class), linesCaptor.capture())).thenReturn(Mono.empty());

        StepVerifier.create(rule.then(givenContext))
            .verifyComplete();

        assertThat(linesCaptor.getValue().stream()
            .filter(lineExecution -> lineExecution.getLineId().equals(givenLineExecution1.getLineId()))
            .findFirst().get()
            .getDelivery().getCollect().getPartialDelayedNotificationStatus()).isEqualTo(NotificationStatus.NOTIFICATION_REQUESTED);
    }
}
