package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.ExecutionToUpdate;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.UpdateExecution;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.UserOrLdap;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import com.adeo.sales.customerorder.tempoorchestrator.service.impl.UpdateExecutionServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UpdateExecutionServiceImplTest {

    private UpdateExecutionService updateExecutionService;
    @Mock
    private TopicsProperties topicsProperties;
    @Mock
    private EventProducer eventProducer;

    @BeforeEach
    public void setUp() {
         this.updateExecutionService = new UpdateExecutionServiceImpl(eventProducer, topicsProperties);
    }

    @Test
    public void shouldSendUpdateExecutionWithDecreaseQuantity() {
        // Given
        var givenCustomerOrderId = UUID.randomUUID().toString();
        var givenBuCode = "001";
        var givenLineId = UUID.randomUUID().toString();
        var givenExecutionId = UUID.randomUUID().toString();
        var givenLineExecution = LineExecution.builder()
                .lineId(givenLineId)
                .quantity(BigDecimal.ZERO)
                .build();
        var givenImpactedLines = Map.of(givenExecutionId, List.of(givenLineExecution));
        var givenDateToSendEvent = OffsetDateTime.now();
        var givenReason = "reason";
        var givenUserOrLdap = UserOrLdap.newBuilder()
                .setIdentifier("CUSTOMER")
                .setUserType("SYSTEM")
                .build();
        var givenImpactedLine = ImpactedLine.newBuilder()
                .setLineId(givenLineId)
                .setQuantity(BigDecimal.ZERO)
                .setReason("reason")
                .build();
        var givenExecutionToUpdate = ExecutionToUpdate.newBuilder()
                .setExecutionPlanId(givenExecutionId)
                .setImpactedLines(List.of(givenImpactedLine))
                .build();
        var givenUpdateExecution = UpdateExecution.newBuilder()
                .setBuCode(givenBuCode)
                .setActionType("DECREASE_QUANTITY")
                .setAppSource("TOR")
                .setCustomerOrderId(givenCustomerOrderId)
                .setRequestSourceId(givenCustomerOrderId)
                .setRequestedBy(givenUserOrLdap)
                .setExecutionToUpdate(List.of(givenExecutionToUpdate))
                .build();
        var givenTopic = "topic";
        var givenTopics = List.of(givenTopic);
        var givenFunctionalType = "CancelOrder";

        when(topicsProperties.getCommandV1()).thenReturn(givenTopics);
        when(eventProducer.sendEvents(givenTopics, givenCustomerOrderId, givenBuCode, givenUpdateExecution, givenDateToSendEvent, givenFunctionalType)).thenReturn(Mono.empty());

        // When
        var result = updateExecutionService.sendUpdateExecutionWithDecreaseQuantity(givenCustomerOrderId, givenBuCode, givenImpactedLines, givenDateToSendEvent, givenReason, givenFunctionalType);

        // Then
        StepVerifier.create(result).verifyComplete();
        verify(eventProducer, times(1)).sendEvents(topicsProperties.getCommandV1(), givenCustomerOrderId, givenBuCode, givenUpdateExecution, givenDateToSendEvent, givenFunctionalType);
    }

    @Test
    public void shouldNotSendUpdateExecutionWithDecreaseQuantityWhenLineIsEmpty() {
        // Given
        var givenCustomerOrderId = UUID.randomUUID().toString();
        var givenBuCode = "001";

        var givenExecutionId = UUID.randomUUID().toString();
        Map<String, List<LineExecution>> givenImpactedLines = new HashMap<>();
        var givenDateToSendEvent = OffsetDateTime.now();
        var givenReason = "reason";
        var givenUserOrLdap = UserOrLdap.newBuilder()
                .setIdentifier("CUSTOMER")
                .setUserType("SYSTEM")
                .build();
        var givenImpactedLine = ImpactedLine.newBuilder()
                .setLineId("lineId")
                .setQuantity(BigDecimal.ZERO)
                .setReason("reason")
                .build();
        var givenExecutionToUpdate = ExecutionToUpdate.newBuilder()
                .setExecutionPlanId(givenExecutionId)
                .setImpactedLines(List.of(givenImpactedLine))
                .build();
        var givenUpdateExecution = UpdateExecution.newBuilder()
                .setBuCode(givenBuCode)
                .setActionType("DECREASE_QUANTITY")
                .setAppSource("TOR")
                .setCustomerOrderId(givenCustomerOrderId)
                .setRequestSourceId(givenCustomerOrderId)
                .setRequestedBy(givenUserOrLdap)
                .setExecutionToUpdate(List.of(givenExecutionToUpdate))
                .build();
        var givenTopic = "topic";
        var givenTopics = List.of(givenTopic);
        var givenFunctionalType = "CancelOrder";

        when(topicsProperties.getCommandV1()).thenReturn(givenTopics);

        // When
        var result = updateExecutionService.sendUpdateExecutionWithDecreaseQuantity(givenCustomerOrderId, givenBuCode, givenImpactedLines, givenDateToSendEvent, givenReason, givenFunctionalType);

        // Then
        StepVerifier.create(result).verifyComplete();
        verify(eventProducer, times(0)).sendEvents(topicsProperties.getCommandV1(), givenCustomerOrderId, givenBuCode, givenUpdateExecution, givenDateToSendEvent, givenFunctionalType);
    }

}
