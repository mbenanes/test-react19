package com.adeo.sales.customerorder.tempoorchestrator.v3.domain.execution.model;

import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class FlagsTest {

    @Test
    void raiseFlagWithSameDateButDifferentTypeWorks() {
        Flags<TestFlag> flags = new Flags<>();

        OffsetDateTime dateTime = OffsetDateTime.now();
        flags.raiseFlagIfNot(TestFlag.FLAG1, dateTime);
        assertThat(flags.getOrderedByDateFlags().size()).isEqualTo(1);

        flags.raiseFlagIfNot(TestFlag.FLAG2, dateTime);
        assertThat(flags.getOrderedByDateFlags().size()).isEqualTo(2);
    }

    @Test
    public void testLastFlagIsWithTwoFlags() throws JsonProcessingException {
        final var objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        final Flags<TestFlag> flags = objectMapper.readValue("{\n" +
            "            \"orderedByDateFlags\": [\n" +
            "                {\n" +
            "                    \"type\": \"FLAG1\",\n" +
            "                    \"dateTime\": \"2022-09-27T15:18:14.614242Z\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"type\": \"FLAG2\",\n" +
            "                    \"dateTime\": \"2022-09-27T15:18:14.00+02:00:00\"\n" +
            "                }\n" +
            "            ]\n" +
            "        }", Flags.class);

        Assertions.assertTrue(flags.lastFlagIs(TestFlag.FLAG1));
    }

    @Test
    public void testLastFlagIsWithoutFlags() throws JsonProcessingException {
        final var objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        final Flags<TestFlag> flags = objectMapper.readValue("{\n" +
            "            \"orderedByDateFlags\": []\n" +
            "        }", Flags.class);

        Assertions.assertFalse(flags.lastFlagIs(TestFlag.FLAG2));
        Assertions.assertFalse(flags.lastFlagIs(TestFlag.FLAG1));
    }

    public enum TestFlag {
        FLAG1,
        FLAG2
    }
}
