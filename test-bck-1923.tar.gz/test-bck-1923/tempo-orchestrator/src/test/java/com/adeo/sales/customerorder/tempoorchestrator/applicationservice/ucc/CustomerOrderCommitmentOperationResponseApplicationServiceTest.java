package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.ucc;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderCommitmentResponseException;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.ucc.input.CustomerOrderPaymentCommitmentInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.Clock;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.StockValuationStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.PaymentStatus;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.test.publisher.PublisherProbe;
import reactor.util.function.Tuples;

import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CustomerOrderCommitmentOperationResponseApplicationServiceTest {

    private CustomerOrderCommitmentOperationResponseApplicationService customerOrderCommitmentOperationResponseApplicationService;

    @Mock
    private RuleEngineService ruleEngineService;


    @BeforeEach
    void setUp() {
        customerOrderCommitmentOperationResponseApplicationService = new CustomerOrderCommitmentOperationResponseApplicationService(ruleEngineService);
    }

    @Test
    public void should_call_ruleEngine_with_right_flag() {

        String customerOrderID = UUID.randomUUID().toString();
        String sourceId = UUID.randomUUID().toString();
        final CustomerOrderPaymentCommitmentInput input = CustomerOrderPaymentCommitmentInput.builder()
            .customerOrderId(customerOrderID)
            .buCode("001")
            .sourceId(sourceId)
            .statusCommitment(CustomerOrderPaymentCommitmentInput.StatusCommitment.APPROVED)
            .build();

        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "EXW", OFFER);
        LineExecution secondLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "DDP", OFFER);

        //move to requirement delivery step completed and stock valuate.
        firstLineSFP.getPayment().getFlags().raiseFlag(sourceId, PaymentStatus.OWNERSHIP_TRANSFER_REQUESTED);
        firstLineSFP.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_SUCCEED);
        secondLineSFP.getPayment().getFlags().raiseFlag(sourceId, PaymentStatus.OWNERSHIP_TRANSFER_REQUESTED);
        secondLineSFP.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_SUCCEED);


        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .paymentExecutionPolicy(new Clock(UUID.randomUUID().toString(), 1))
            .build();

        when(ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
            .thenReturn(
                Mono.just(Tuples.of(bddCustomerOrder, List.of(firstLineSFP, secondLineSFP), List.of(), List.of(), List.of()))
            );

        PublisherProbe<Void> probe = PublisherProbe.empty();
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> probe.mono());

        StepVerifier.create(customerOrderCommitmentOperationResponseApplicationService.apply(input)).verifyComplete();

        verify(ruleEngineService, times(1)).lockAndGetData(input.getCustomerOrderId(), input.getBuCode());
        verify(ruleEngineService, times(1)).startRuleEngineAndUpdateLines();

        probe.assertWasSubscribed();

        Assertions.assertThat(firstLineSFP.getPayment().getFlags().getLastFlag().getType()).isEqualTo(PaymentStatus.OWNERSHIP_TRANSFERRED.name());

    }

    @Test
    public void should_not_call_ruleEngine_for_non_existing_sourceId() {

        String customerOrderID = UUID.randomUUID().toString();
        String sourceId = UUID.randomUUID().toString();
        final CustomerOrderPaymentCommitmentInput input = CustomerOrderPaymentCommitmentInput.builder()
            .customerOrderId(customerOrderID)
            .buCode("001")
            .sourceId(UUID.randomUUID().toString())
            .statusCommitment(CustomerOrderPaymentCommitmentInput.StatusCommitment.APPROVED)
            .build();

        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "EXW", OFFER);
        LineExecution secondLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "DDP", OFFER);

        //move to requirement delivery step completed and stock valuate.
        firstLineSFP.getPayment().getFlags().raiseFlag(sourceId, PaymentStatus.OWNERSHIP_TRANSFER_REQUESTED);
        firstLineSFP.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_SUCCEED);
        secondLineSFP.getPayment().getFlags().raiseFlag(sourceId, PaymentStatus.OWNERSHIP_TRANSFER_REQUESTED);
        secondLineSFP.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_SUCCEED);

        firstLineSFP.getPayment().getFlags().raiseFlag(sourceId, PaymentStatus.OWNERSHIP_TRANSFER_REQUESTED);
        firstLineSFP.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_SUCCEED);
        secondLineSFP.getPayment().getFlags().raiseFlag(sourceId, PaymentStatus.OWNERSHIP_TRANSFER_REQUESTED);
        secondLineSFP.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_SUCCEED);


        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .paymentExecutionPolicy(new Clock(UUID.randomUUID().toString(), 1))
            .build();

        when(ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
            .thenReturn(
                Mono.just(Tuples.of(bddCustomerOrder, List.of(firstLineSFP, secondLineSFP), List.of(), List.of(), List.of()))
            );

        PublisherProbe<Void> probe = PublisherProbe.empty();
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> probe.mono());

        StepVerifier.create(customerOrderCommitmentOperationResponseApplicationService.apply(input)).verifyError(CustomerOrderCommitmentResponseException.class);

        verify(ruleEngineService, times(1)).lockAndGetData(input.getCustomerOrderId(), input.getBuCode());
        probe.assertWasNotSubscribed();

        Assertions.assertThat(firstLineSFP.getPayment().getFlags().hasOperationId(input.getSourceId())).isFalse();

    }

    @Test
    public void should_not_call_ruleEngine_for_response_already_treated() {

        String customerOrderID = UUID.randomUUID().toString();
        String sourceId = UUID.randomUUID().toString();
        final CustomerOrderPaymentCommitmentInput input = CustomerOrderPaymentCommitmentInput.builder()
            .customerOrderId(customerOrderID)
            .buCode("001")
            .sourceId(sourceId)
            .statusCommitment(CustomerOrderPaymentCommitmentInput.StatusCommitment.APPROVED)
            .build();

        LineExecution firstLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.SHIPPED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "EXW", OFFER);
        LineExecution secondLineSFP = generateALine(false, CustomerOrderLineDeliveryStatus.RECEIVED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, "DDP", OFFER);

        //move to requirement delivery step completed and stock valuate.
        firstLineSFP.getPayment().getFlags().raiseFlag(sourceId, PaymentStatus.OWNERSHIP_TRANSFERRED);
        firstLineSFP.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_SUCCEED);
        secondLineSFP.getPayment().getFlags().raiseFlag(sourceId, PaymentStatus.OWNERSHIP_TRANSFERRED);
        secondLineSFP.getDelivery().setStockValuationStatus(StockValuationStatus.STOCK_VALUATION_SUCCEED);

        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .paymentExecutionPolicy(new Clock(UUID.randomUUID().toString(), 1))
            .build();

        when(ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
            .thenReturn(
                Mono.just(Tuples.of(bddCustomerOrder, List.of(firstLineSFP, secondLineSFP), List.of(), List.of(), List.of()))
            );

        PublisherProbe<Void> probe = PublisherProbe.empty();
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> probe.mono());

        StepVerifier.create(customerOrderCommitmentOperationResponseApplicationService.apply(input)).verifyError(CustomerOrderCommitmentResponseException.class);

        verify(ruleEngineService, times(1)).lockAndGetData(input.getCustomerOrderId(), input.getBuCode());
        probe.assertWasNotSubscribed();


    }
}
