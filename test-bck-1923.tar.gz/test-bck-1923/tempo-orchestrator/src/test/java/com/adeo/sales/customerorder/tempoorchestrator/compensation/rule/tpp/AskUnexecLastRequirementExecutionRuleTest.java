package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPaymentRequirements;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.service.TppCommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.temporal.TemporalUnit;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus.APPROVED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus.UNEXEC_APPROVED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus.UNEXEC_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateActionExecutionFromLines;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateContext;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.initializeSteps;
import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AskUnexecLastRequirementExecutionRuleTest {

    private AskUnexecLastRequirementExecutionRule rule;

    @Mock
    private TppCommandEventService tppCommandEventService;

    @Captor
    private ArgumentCaptor<List<ImpactedLine>> impactedLinesCaptor;
    @Captor
    private ArgumentCaptor<CustomerOrder> customerOrderCaptor;

    @BeforeEach
    void setUp() {
        rule = new AskUnexecLastRequirementExecutionRule(tppCommandEventService);
    }

    @Test
    void shouldSendUnexecRequirementIfItIsTheNextStep() {
        RuleEngineContext context = generateActionExecutionContext();

        LineExecution sfwLine1 = context.getOrderData().getExistingLineExecutions().get(0);
        sfwLine1.getPaymentRequirements().getPreparationFlags().raiseFlag(UNEXEC_APPROVED);
        sfwLine1.getPaymentRequirements().getDeliveryFlags().raiseFlag(APPROVED, OffsetDateTime.now().plusMinutes(2));
        LineExecution sfwLine2 = context.getOrderData().getExistingLineExecutions().get(1);
        sfwLine2.getPaymentRequirements().getPreparationFlags().raiseFlag(UNEXEC_APPROVED);
        sfwLine2.getPaymentRequirements().getDeliveryFlags().raiseFlag(APPROVED, OffsetDateTime.now().plusMinutes(2));
        LineExecution sfpLine1 = context.getOrderData().getExistingLineExecutions().get(2);
        sfpLine1.getPaymentRequirements().getPreparationFlags().raiseFlag(UNEXEC_APPROVED);
        sfpLine1.getPaymentRequirements().getDeliveryFlags().raiseFlag(APPROVED, OffsetDateTime.now().plusMinutes(2));

        assertThat(rule.when(context)).isTrue();

        MonoMock<String> decreaseQuantityCall = MonoMock.just(UUID.randomUUID().toString());
        when(tppCommandEventService.sendUnexecActionTypeRequirement(customerOrderCaptor.capture(), anyString(), impactedLinesCaptor.capture(), any(Instant.class), eq(ActionType.DELIVERY))).thenReturn(decreaseQuantityCall);

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        decreaseQuantityCall.expectHasBeenSubscribed();

        LineExecution orderAndCollectLine = context.getOrderData().getExistingLineExecutions().get(3);

        verify(tppCommandEventService, times(1)).sendUnexecActionTypeRequirement(eq(context.getOrderData().getExistingCustomerOrder()), eq(sfwLine1.getExecutionId()), anyList(), any(Instant.class), eq(ActionType.DELIVERY));
        verify(tppCommandEventService, times(1)).sendUnexecActionTypeRequirement(eq(context.getOrderData().getExistingCustomerOrder()), eq(sfpLine1.getExecutionId()), anyList(), any(Instant.class), eq(ActionType.DELIVERY));

        assertThat(impactedLinesCaptor.getAllValues()).hasSize(2);


        List<ImpactedLine> impactedLinesSfw = impactedLinesCaptor.getAllValues().stream().filter(lines -> lines.stream().anyMatch(line -> line.getLineId().equals(sfwLine1.getLineId()))).findFirst().get();
        assertThat(impactedLinesSfw).hasSize(2);
        assertThat(impactedLinesSfw.get(0).getLineId()).isEqualTo(sfwLine1.getLineId());
        assertThat(impactedLinesSfw.get(1).getLineId()).isEqualTo(sfwLine2.getLineId());

        List<ImpactedLine> impactedLinesSfp = impactedLinesCaptor.getAllValues().stream().filter(lines -> lines.stream().anyMatch(line -> line.getLineId().equals(sfpLine1.getLineId()))).findFirst().get();
        assertThat(impactedLinesSfp).hasSize(1);
        assertThat(impactedLinesSfp.get(0).getLineId()).isEqualTo(sfpLine1.getLineId());

        assertThat(impactedLinesCaptor.getAllValues().stream()
            .flatMap(Collection::stream)
            .noneMatch(impactedLine -> impactedLine.getLineId().equals(orderAndCollectLine.getLineId())))
            .isTrue();

        ExecutionAction executionAction = context.getOrderData().getExecutionActions().get(0);

        ImpactedExecution impactedExecutionSfw = executionAction.getImpactedExecutionByExecutionId(sfwLine1.getExecutionId()).get();
        impactedExecutionSfw.getImpactedLines().forEach(impactedLine -> impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP)
            .ifPresent(step -> {
                assertThat(step.getType()).isEqualTo(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP);
                assertThat(step.getFlags().lastFlagIs(ImpactedLineStep.Status.PROCESSING)).isTrue();
            }));

        ImpactedExecution impactedExecutionSfp = executionAction.getImpactedExecutionByExecutionId(sfpLine1.getExecutionId()).get();
        impactedExecutionSfp.getImpactedLines().forEach(impactedLine -> impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP)
            .ifPresent(step -> {
                assertThat(step.getType()).isEqualTo(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP);
                assertThat(step.getFlags().lastFlagIs(ImpactedLineStep.Status.PROCESSING)).isTrue();
            }));

        ImpactedExecution impactedExecutionOrderAndCollect = executionAction.getImpactedExecutionByExecutionId(orderAndCollectLine.getExecutionId()).get();
        impactedExecutionOrderAndCollect.getImpactedLines().forEach(impactedLine -> impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP)
            .ifPresent(step -> {
                assertThat(step.getType()).isEqualTo(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP);
                assertThat(step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED)).isTrue();
            }));

        assertThat(context.getOrderData().getExistingLineExecutions().stream()
            .map(LineExecution::getPaymentRequirements)
            .map(LineExecutionPaymentRequirements::getDeliveryFlags)
            .map(Flags::getOrderedByDateFlags)
            .flatMap(Collection::stream)
            .filter(flag -> flag!= null && UNEXEC_REQUESTED.name().equals(flag.getType()))
            .count()).isEqualTo(3);
    }

    @Test
    void shouldSendUnexecRequirementIfItIsTheNextStepAndLastFlagIsUnexecApproved() {
        RuleEngineContext context = generateActionExecutionContext();

        context.getOrderData().getExistingLineExecutions()
            .stream()
            .filter(lineExecution -> lineExecution.getPaymentRequirements().getPreparationFlags() != null)
            .filter(lineExecution -> lineExecution.getPaymentRequirements().getPreparationFlags().hasFlag(APPROVED))
            .forEach(lineExecution -> {
                lineExecution.getPaymentRequirements().getPreparationFlags().raiseFlag(UNEXEC_REQUESTED);
                lineExecution.getPaymentRequirements().getPreparationFlags().raiseFlag(UNEXEC_APPROVED);
            });


        assertThat(rule.when(context)).isTrue();

        MonoMock<String> decreaseQuantityCall = MonoMock.just(UUID.randomUUID().toString());
        when(tppCommandEventService.sendUnexecActionTypeRequirement(customerOrderCaptor.capture(), anyString(), impactedLinesCaptor.capture(), any(Instant.class), eq(ActionType.PREPARATION))).thenReturn(decreaseQuantityCall);

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        decreaseQuantityCall.expectHasBeenSubscribed();

        LineExecution sfwLine1 = context.getOrderData().getExistingLineExecutions().get(0);
        LineExecution sfwLine2 = context.getOrderData().getExistingLineExecutions().get(1);
        LineExecution sfpLine1 = context.getOrderData().getExistingLineExecutions().get(2);
        LineExecution orderAndCollectLine = context.getOrderData().getExistingLineExecutions().get(3);

        verify(tppCommandEventService, times(1)).sendUnexecActionTypeRequirement(eq(context.getOrderData().getExistingCustomerOrder()), eq(sfwLine1.getExecutionId()), anyList(), any(Instant.class), eq(ActionType.PREPARATION));
        verify(tppCommandEventService, times(1)).sendUnexecActionTypeRequirement(eq(context.getOrderData().getExistingCustomerOrder()), eq(sfpLine1.getExecutionId()), anyList(), any(Instant.class), eq(ActionType.PREPARATION));

        assertThat(impactedLinesCaptor.getAllValues()).hasSize(2);


        List<ImpactedLine> impactedLinesSfw = impactedLinesCaptor.getAllValues().stream().filter(lines -> lines.stream().anyMatch(line -> line.getLineId().equals(sfwLine1.getLineId()))).findFirst().get();
        assertThat(impactedLinesSfw).hasSize(2);
        assertThat(impactedLinesSfw.get(0).getLineId()).isEqualTo(sfwLine1.getLineId());
        assertThat(impactedLinesSfw.get(1).getLineId()).isEqualTo(sfwLine2.getLineId());

        List<ImpactedLine> impactedLinesSfp = impactedLinesCaptor.getAllValues().stream().filter(lines -> lines.stream().anyMatch(line -> line.getLineId().equals(sfpLine1.getLineId()))).findFirst().get();
        assertThat(impactedLinesSfp).hasSize(1);
        assertThat(impactedLinesSfp.get(0).getLineId()).isEqualTo(sfpLine1.getLineId());

        assertThat(impactedLinesCaptor.getAllValues().stream()
            .flatMap(Collection::stream)
            .noneMatch(impactedLine -> impactedLine.getLineId().equals(orderAndCollectLine.getLineId())))
            .isTrue();

        ExecutionAction executionAction = context.getOrderData().getExecutionActions().get(0);

        ImpactedExecution impactedExecutionSfw = executionAction.getImpactedExecutionByExecutionId(sfwLine1.getExecutionId()).get();
        impactedExecutionSfw.getImpactedLines().forEach(impactedLine -> impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP)
            .ifPresent(step -> {
                assertThat(step.getType()).isEqualTo(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP);
                assertThat(step.getFlags().lastFlagIs(ImpactedLineStep.Status.PROCESSING)).isTrue();
            }));

        ImpactedExecution impactedExecutionSfp = executionAction.getImpactedExecutionByExecutionId(sfpLine1.getExecutionId()).get();
        impactedExecutionSfp.getImpactedLines().forEach(impactedLine -> impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP)
            .ifPresent(step -> {
                assertThat(step.getType()).isEqualTo(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP);
                assertThat(step.getFlags().lastFlagIs(ImpactedLineStep.Status.PROCESSING)).isTrue();
            }));

        ImpactedExecution impactedExecutionOrderAndCollect = executionAction.getImpactedExecutionByExecutionId(orderAndCollectLine.getExecutionId()).get();
        impactedExecutionOrderAndCollect.getImpactedLines().forEach(impactedLine -> impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP)
            .ifPresent(step -> {
                assertThat(step.getType()).isEqualTo(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP);
                assertThat(step.getFlags().lastFlagIs(ImpactedLineStep.Status.CREATED)).isTrue();
            }));

        assertThat(context.getOrderData().getExistingLineExecutions().stream()
            .map(LineExecution::getPaymentRequirements)
            .map(LineExecutionPaymentRequirements::getPreparationFlags)
            .map(Flags::getOrderedByDateFlags)
            .flatMap(Collection::stream)
            .filter(flag -> flag!= null && UNEXEC_REQUESTED.name().equals(flag.getType()))
            .count()).isEqualTo(6);
    }


    private RuleEngineContext generateActionExecutionContext() {
        LineExecution sfwLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, false, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution sfwLine2 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, false, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution sfpLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, false, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, null, OFFER);
        LineExecution orderAndCollectLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, false, true, true, false, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);

        RuleEngineContext context = generateContext(List.of(sfwLine1, sfwLine2, sfpLine1, orderAndCollectLine1));

        ExecutionAction executionAction = generateActionExecutionFromLines(context.getCustomerOrderId(), context.getOrderData().getExistingLineExecutions(), ExecutionActionType.DECREASE_QUANTITY);

        ImpactedExecution impactedExecutionSfw = executionAction.getImpactedExecutionByExecutionId(sfwLine1.getExecutionId()).get();
        ImpactedExecution impactedExecutionSfp = executionAction.getImpactedExecutionByExecutionId(sfpLine1.getExecutionId()).get();
        ImpactedExecution impactedExecutionOrderAndCollect = executionAction.getImpactedExecutionByExecutionId(orderAndCollectLine1.getExecutionId()).get();

        initializeSteps(impactedExecutionSfw, List.of(DECREASE_QUANTITY_DELIVERY, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION), List.of(DECREASE_QUANTITY_DELIVERY));
        initializeSteps(impactedExecutionSfp, List.of(UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION), List.of());
        initializeSteps(impactedExecutionOrderAndCollect, List.of(DECREASE_QUANTITY_DELIVERY, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION), List.of(DECREASE_QUANTITY_DELIVERY));

        executionAction.getFlags().raiseFlag(ExecutionActionStatus.PROCESSING);

        context.getOrderData().setExecutionActions(List.of(executionAction));
        return context;
    }
}
