package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.delivery.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.bomp.ThirdPartyDeliveryCommandManager;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.service.UpdateAvailableActionService;
import com.adeo.sales.customerorder.tempoorchestrator.service.impl.UpdateAvailableActionServiceImpl;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.assertj.core.api.AssertionsForInterfaceTypes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.ABORT_DELIVERY_3P;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateActionExecutionFromLines;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateContext;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.initializeSteps;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class Abort3PDeliveryRuleTppTest {

    private Abort3PDeliveryRuleTpp rule;

    @Mock
    private ThirdPartyDeliveryCommandManager thirdPartyDeliveryCommandManager;

    @Captor
    private ArgumentCaptor<List<LineExecution>> lineExecutionsCaptor;

    @BeforeEach
    void setUp() {
        UpdateAvailableActionService updateAvailableActionService = new UpdateAvailableActionServiceImpl();
        rule = new Abort3PDeliveryRuleTpp(updateAvailableActionService, thirdPartyDeliveryCommandManager);
    }

    @Test
    void shouldAbort3PDeliveryIfDecreaseQuantityExecutionIsProcessing() {

        RuleEngineContext context = generateActionExecutionContext();

        assertThat(rule.when(context)).isTrue();
        MonoMock<Void> abort3POrderCall = MonoMock.empty();
        when(thirdPartyDeliveryCommandManager.abortCustomerOrderLines(lineExecutionsCaptor.capture(), eq(context.getOrderData().getExistingCustomerOrder()))).thenReturn(abort3POrderCall);

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        verify(thirdPartyDeliveryCommandManager).abortCustomerOrderLines(anyList(), any(CustomerOrder.class));
        abort3POrderCall.expectHasBeenSubscribed();

        ExecutionAction executionAction = context.getOrderData().getExecutionActions().get(0);
        String thirdPartyExecutionID = context.getOrderData().getExistingLineExecutions().stream().filter(line -> line.getDelivery().getDeliveryType() == DeliveryType.THIRD_PARTY).findFirst().get().getExecutionId();
        assertThat(executionAction.getImpactedExecutionByExecutionId(thirdPartyExecutionID).get().getImpactedLines().get(0).getStepOfType(ABORT_DELIVERY_3P).stream().anyMatch(step -> step.getFlags().lastFlagIs(ImpactedLineStep.Status.PROCESSING))).isTrue();

        List<LineExecution> lineExecutionsDecreased = lineExecutionsCaptor.getValue();
        AssertionsForInterfaceTypes.assertThat(lineExecutionsDecreased).hasSize(2);
        AssertionsForInterfaceTypes.assertThat(lineExecutionsDecreased).contains(context.getOrderData().getExistingLineExecutions().get(0));
        AssertionsForInterfaceTypes.assertThat(lineExecutionsDecreased).contains(context.getOrderData().getExistingLineExecutions().get(1));

        assertThat(context.getOrderData().getExistingLineExecutions()
            .stream()
            .filter(line -> line.getDelivery().getDeliveryType() == DeliveryType.THIRD_PARTY)
            .allMatch(line -> line.getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.ABORT_REQUESTED))).isTrue();

        assertThat(rule.when(context)).isFalse();

    }

    private RuleEngineContext generateActionExecutionContext() {
        LineExecution thirdPartyLine1 = generateALine(true, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);
        LineExecution thirdPartyLine2 = generateALine(true, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);
        LineExecution sfpLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, null, OFFER);
        LineExecution orderAndCollectLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, false, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);

        RuleEngineContext context = generateContext(List.of(thirdPartyLine1, thirdPartyLine2, sfpLine1, orderAndCollectLine1));

        ExecutionAction executionAction = generateActionExecutionFromLines(context.getCustomerOrderId(), List.of(thirdPartyLine1, thirdPartyLine2, sfpLine1), ExecutionActionType.DECREASE_QUANTITY);

        ImpactedExecution impactedExecution3P = executionAction.getImpactedExecutionByExecutionId(thirdPartyLine1.getExecutionId()).get();
        ImpactedExecution impactedExecutionSfp = executionAction.getImpactedExecutionByExecutionId(sfpLine1.getExecutionId()).get();

        initializeSteps(impactedExecution3P, List.of(ABORT_DELIVERY_3P, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION), List.of());
        initializeSteps(impactedExecutionSfp, List.of(UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION), List.of());

        executionAction.getFlags().raiseFlag(ExecutionActionStatus.PROCESSING);

        context.getOrderData().setExecutionActions(List.of(executionAction));
        return context;
    }
}
