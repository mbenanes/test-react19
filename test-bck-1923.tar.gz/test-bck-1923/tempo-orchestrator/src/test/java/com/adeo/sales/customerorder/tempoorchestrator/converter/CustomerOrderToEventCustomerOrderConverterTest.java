package com.adeo.sales.customerorder.tempoorchestrator.converter;

import com.adeo.sales.customerorder.ProductOffer;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.jackson.SerializeSpecificRecordBase;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import org.apache.avro.specific.SpecificRecordBase;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CustomerOrderToEventCustomerOrderConverterTest {

    private final ObjectMapper objectMapper = new ObjectMapper()
        .registerModule(new SimpleModule().addSerializer(SpecificRecordBase.class, new SerializeSpecificRecordBase()));

    @Test
    public void shouldTransformCustomerOrderToOutcomingNotificationCustomerOrder() {
        final var ignoredProperties = new HashMap<String, Object>();
        ignoredProperties.put("productOffer", ProductOffer.newBuilder().setId("testId").setVersion(1).setItems(List.of()).build());
        ignoredProperties.put("properties-not-in-output-event", "test");

        final var modelCustomerOrder = CustomerOrder.builder()
            .customerOrderNumber("test")
            .buCode("0001")
            .ignoredProperties(ignoredProperties)
            .build();

        final var converter = new CustomerOrderToEventCustomerOrderConverter(objectMapper);

        final var result = converter.convert(modelCustomerOrder);

        assertEquals("testId", result.getProductOffer().getId());
        assertEquals(1, result.getProductOffer().getVersion());
        assertEquals("test", result.getCustomerOrderNumber());
        assertEquals("0001", result.getBuCode());
    }
}
