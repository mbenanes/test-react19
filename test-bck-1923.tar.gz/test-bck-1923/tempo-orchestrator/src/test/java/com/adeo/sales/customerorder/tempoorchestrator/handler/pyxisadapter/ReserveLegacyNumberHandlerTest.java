package com.adeo.sales.customerorder.tempoorchestrator.handler.pyxisadapter;

import com.adeo.pyxis.colegacy.avro.ReserveLegacyNumber;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.ReserveLegacyNumberApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.input.ReserveLegacyNumberInput;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.handler.EventMetaDataTestBuilder.mockEventMetaData;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ReserveLegacyNumberHandlerTest {

    private ReserveLegacyNumberHandler reserveLegacyNumberHandler;
    private MappedDiagnosticContext mappedDiagnosticContext = Mockito.mock(MappedDiagnosticContext.class);
    private ReserveLegacyNumberApplicationService reserveLegacyNumberApplicationService = Mockito.mock(ReserveLegacyNumberApplicationService.class);


    @BeforeEach
    void beforeEach(){
        reserveLegacyNumberHandler = new ReserveLegacyNumberHandler(mappedDiagnosticContext, reserveLegacyNumberApplicationService);
    }


    @Test
    void dontTreatEventForPyxisOrder(){
        final ReserveLegacyNumber event = ReserveLegacyNumber.newBuilder()
            .setCustomerOrderId("380-442571")
            .setReservedLegacyNumbers(List.of())
            .setBuCode("005")
            .build();

        StepVerifier.create(reserveLegacyNumberHandler.handle(event, mockEventMetaData()))
            .verifyComplete();

        verify(reserveLegacyNumberApplicationService, times(0)).apply(any(ReserveLegacyNumberInput.class));

    }

    @Test
    void treatEventForTempoOrder(){
        final ReserveLegacyNumber event = ReserveLegacyNumber.newBuilder()
            .setCustomerOrderId("0417bf87-1c89-4fae-ae59-412661849cbe")
            .setReservedLegacyNumbers(List.of())
            .setBuCode("005")
            .build();

        when(reserveLegacyNumberApplicationService.apply(any(ReserveLegacyNumberInput.class))).thenReturn(Mono.empty());

        StepVerifier.create(reserveLegacyNumberHandler.handle(event, mockEventMetaData()))
            .verifyComplete();

        verify(reserveLegacyNumberApplicationService, times(1)).apply(any(ReserveLegacyNumberInput.class));

    }

}
