package com.adeo.sales.customerorder.tempoorchestrator.service;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.postpone.PostponeConfiguration;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.timezones.BuTimezoneConfiguration;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.timezones.TimezonesConfiguration;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDeliveryCollect;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.LineExecutionPayment;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;


class PostponeConfigurationServiceTest {

    @Test
    void shouldCalculateDateToSendGMTPlus2() {
        PostponeConfiguration configuration = buildPostPoneConfiguration(List.of("PT-2H"), "19h00", "8h00");
        String franceBuCode = "001";
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode(franceBuCode)
            .build();
        customerOrder.setId(UUID.randomUUID().toString());
        final var timezonesConfiguration = buildTimeZoneConfiguration();

        String zone = timezonesConfiguration.getBuCodes().get(franceBuCode).getDefaultTimeZone();

        List<LineExecution> lineExecutions = buildLineExecutionWithAppointmentDate(2100, 9, 15, 11, 15, zone);

        List<OffsetDateTime> dateToSendList = PostponeConfigurationService.getDateToSendList(configuration, timezonesConfiguration, customerOrder, lineExecutions, "test");
        assertThat(dateToSendList).isNotNull();
        assertThat(dateToSendList).isNotEmpty();
        assertThat(dateToSendList.get(0)).isEqualTo(buildOffsetDateTime(2100, 9, 15, 9, 15, zone));
    }

    @Test
    void shouldCalculateDateToSendGMTPlus2MinorBound() {
        PostponeConfiguration configuration = buildPostPoneConfiguration(List.of("PT-2H"), "19h00", "8h00");
        String franceBuCode = "001";
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode(franceBuCode)
            .build();
        customerOrder.setId(UUID.randomUUID().toString());
        final var timezonesConfiguration = buildTimeZoneConfiguration();

        String zone = timezonesConfiguration.getBuCodes().get(franceBuCode).getDefaultTimeZone();

        List<LineExecution> lineExecutions = buildLineExecutionWithAppointmentDate(2100, 9, 15, 9, 15, zone);

        List<OffsetDateTime> dateToSendList = PostponeConfigurationService.getDateToSendList(configuration, timezonesConfiguration, customerOrder, lineExecutions, "test");
        assertThat(dateToSendList).isNotNull();
        assertThat(dateToSendList).isNotEmpty();
        assertThat(dateToSendList.get(0)).isEqualTo(buildOffsetDateTime(2100, 9, 14, 19, 0, zone));
    }

    @Test
    void shouldCalculateDateToSendGMTPlus2ActualDateTooEarlyShouldBeNull() {
        PostponeConfiguration configuration = buildPostPoneConfiguration(List.of("PT-24H"), null, null);
        String franceBuCode = "001";
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode(franceBuCode)
            .build();
        customerOrder.setId(UUID.randomUUID().toString());
        final var timezonesConfiguration = buildTimeZoneConfiguration();

        String zone = timezonesConfiguration.getBuCodes().get(franceBuCode).getDefaultTimeZone();

        OffsetDateTime now = OffsetDateTime.now(ZoneId.of(zone));

        //We set the appointDate less than 24h in the future
        OffsetDateTime appointmentDate = now.plus(23, ChronoUnit.HOURS);

        List<LineExecution> lineExecutions = buildLineExecutionWithAppointmentDate(appointmentDate.getYear(), appointmentDate.getMonth().getValue(), appointmentDate.getDayOfMonth(), appointmentDate.getHour(), appointmentDate.getMinute(), zone);

        List<OffsetDateTime> dateToSendList = PostponeConfigurationService.getDateToSendList(configuration, timezonesConfiguration, customerOrder, lineExecutions, "test");
        assertThat(dateToSendList).isNotNull();
        assertThat(dateToSendList).isEmpty();
    }

    @Test
    void shouldCalculateDateToSendGMTPlus3() {
        PostponeConfiguration configuration = buildPostPoneConfiguration(List.of("PT-2H"), "19h00", "8h00");
        String greeceBuCode = "002";
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode(greeceBuCode)
            .build();
        customerOrder.setId(UUID.randomUUID().toString());
        final var timezonesConfiguration = buildTimeZoneConfiguration();

        String zone = timezonesConfiguration.getBuCodes().get(greeceBuCode).getDefaultTimeZone();

        List<LineExecution> lineExecutions = buildLineExecutionWithAppointmentDate(2100, 9, 15, 11, 15, zone);

        List<OffsetDateTime> dateToSendList = PostponeConfigurationService.getDateToSendList(configuration, timezonesConfiguration, customerOrder, lineExecutions, "test");
        assertThat(dateToSendList).isNotNull();
        assertThat(dateToSendList).isNotEmpty();
        assertThat(dateToSendList.get(0)).isEqualTo(buildOffsetDateTime(2100, 9, 15, 9, 15, zone));
    }

    @Test
    void shouldCalculateDateToSendGMTPlus3MinorBound() {
        PostponeConfiguration configuration = buildPostPoneConfiguration(List.of("PT-2H"), "19h00", "8h00");
        String greeceBuCode = "002";
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode(greeceBuCode)
            .build();
        customerOrder.setId(UUID.randomUUID().toString());
        final var timezonesConfiguration = buildTimeZoneConfiguration();

        String zone = timezonesConfiguration.getBuCodes().get(greeceBuCode).getDefaultTimeZone();

        List<LineExecution> lineExecutions = buildLineExecutionWithAppointmentDate(2100, 9, 15, 9, 15, zone);

        List<OffsetDateTime> dateToSendList = PostponeConfigurationService.getDateToSendList(configuration, timezonesConfiguration, customerOrder, lineExecutions, "test");
        assertThat(dateToSendList).isNotNull();
        assertThat(dateToSendList).isNotEmpty();
        assertThat(dateToSendList.get(0)).isEqualTo(buildOffsetDateTime(2100, 9, 14, 19, 0, zone));
    }

    @Test
    void shouldCalculateDateToSendGMTPlus3ForMultiplePostpone() {
        PostponeConfiguration configuration = buildPostPoneConfiguration(List.of("PT-2H", "PT-6H"), null, null);
        String greeceBuCode = "002";
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode(greeceBuCode)
            .build();
        customerOrder.setId(UUID.randomUUID().toString());
        final var timezonesConfiguration = buildTimeZoneConfiguration();

        String zone = timezonesConfiguration.getBuCodes().get(greeceBuCode).getDefaultTimeZone();

        List<LineExecution> lineExecutions = buildLineExecutionWithAppointmentDate(2100, 9, 15, 9, 15, zone);

        List<OffsetDateTime> dateToSendList = PostponeConfigurationService.getDateToSendList(configuration, timezonesConfiguration, customerOrder, lineExecutions, "test");


        assertThat(dateToSendList).isNotNull();
        assertThat(dateToSendList).isNotEmpty();
        assertThat(dateToSendList.size()).isEqualTo(2);
        assertThat(dateToSendList.get(0)).isEqualTo(buildOffsetDateTime(2100, 9, 15, 7, 15, zone));
        assertThat(dateToSendList.get(1)).isEqualTo(buildOffsetDateTime(2100, 9, 15, 3, 15, zone));

    }

    private static List<LineExecution> buildLineExecutionWithAppointmentDate(int year, int month, int dayOfMonth, int hour, int minute, String zone) {
        OffsetDateTime startDate = buildOffsetDateTime(year, month, dayOfMonth, hour, minute, zone);

        return List.of(LineExecution.builder()
            .delivery(LineExecutionDelivery.builder()
                .collect(LineExecutionDeliveryCollect.builder()
                    .appointmentDate(startDate)
                    .build())
                .build())
            .payment(LineExecutionPayment.builder()
                .storeId("010")
                .build())
            .build());
    }


    private static TimezonesConfiguration buildTimeZoneConfiguration() {
        TimezonesConfiguration timezonesConfiguration = new TimezonesConfiguration();
        timezonesConfiguration.setBuCodes(Map.of(
            "001", BuTimezoneConfiguration.builder()
                .defaultTimeZone("Europe/Paris")
                .specificStoresTimezones(Map.of())
                .build(),
            "002", BuTimezoneConfiguration.builder()
                .defaultTimeZone("Europe/Athens")
                .specificStoresTimezones(Map.of())
                .build())
        );
        return timezonesConfiguration;
    }

    private static PostponeConfiguration buildPostPoneConfiguration(List<String> postponeValues, String hourIdleFrom, String hourIdleTo) {
        PostponeConfiguration configuration = new PostponeConfiguration();
        configuration.setHourIdleFrom(hourIdleFrom);
        configuration.setHourIdleTo(hourIdleTo);
        configuration.setPostponeMethod(PostponeConfiguration.PostponeMethod.BEFORE);
        configuration.setPostponeValue(postponeValues);
        configuration.setPostponeStartingDate(PostponeConfiguration.PostponeStartingDate.APPOINTMENT);
        return configuration;
    }

    public static OffsetDateTime buildOffsetDateTime(int year, int month, int dayOfMonth, int hour, int minute, String zone) {
        Instant with = Instant.now()
            .atZone(ZoneOffset.UTC)
            .with(ChronoField.MONTH_OF_YEAR, 9)
            .with(ChronoField.DAY_OF_MONTH, 15)
            .toInstant();
        ZoneOffset currentOffsetForMyZone = ZoneId.of(zone).getRules().getOffset(with);
        return OffsetDateTime.of(year, month, dayOfMonth, hour, minute, 0, 0, currentOffsetForMyZone);
    }

}
