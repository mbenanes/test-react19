package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.collect.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDeliveryCollect;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.CustomerOrderCollectService;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import com.adeo.tempocollect.avro.request.CustomerOrderCollectRequested;
import org.assertj.core.api.AssertionsForInterfaceTypes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionReasonEnum.REMAINING_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.ASK_PREPARATION_REQUIREMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.CREATE_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.SPLIT_LINE_EXECUTION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateActionExecutionFromLines;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateContext;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.initializeSteps;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreateCollectTppRuleTest {

    @Mock
    private CustomerOrderCollectService collectService;

    @Captor
    private ArgumentCaptor<List<LineExecution>> linesToCreateCollect;

    @Mock
    private CustomerOrderCollectRequested customerOrderCollectRequested;

    private CreateCollectTppRule rule;

    @BeforeEach
    void setUp() {
        rule = new CreateCollectTppRule(collectService);
    }

    @Test
    void shouldCreateCollectWithoutExecutionAction() {
        RuleEngineContext context = generateActionExecutionContext();

        assertThat(rule.when(context)).isTrue();
        MonoMock<CustomerOrderCollectRequested> createCollectCall = MonoMock.just(customerOrderCollectRequested);
        when(collectService.createCustomerOrderCollect(linesToCreateCollect.capture(), eq(context.getOrderData().getExistingCustomerOrder()))).thenReturn(createCollectCall);

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        verify(collectService, times(1)).createCustomerOrderCollect(anyList(), any(CustomerOrder.class));
        createCollectCall.expectHasBeenSubscribed();

        List<LineExecution> lineWithCollectToCreate = linesToCreateCollect.getValue();
        AssertionsForInterfaceTypes.assertThat(lineWithCollectToCreate).hasSize(2);
        assertThat(lineWithCollectToCreate.stream().allMatch(line -> line.getDelivery().getCollect().getFlags().lastFlagIs(CollectStatus.REQUESTED))).isTrue();

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void shouldCreateOneCollectByExecution() {
        RuleEngineContext context = generateActionExecutionContext();
        final String otherExecutionId = UUID.randomUUID().toString();
        context.getOrderData().getExistingLineExecutions().get(1).setExecutionId(otherExecutionId);

        assertThat(rule.when(context)).isTrue();
        MonoMock<CustomerOrderCollectRequested> createCollectCall = MonoMock.just(customerOrderCollectRequested);
        when(collectService.createCustomerOrderCollect(linesToCreateCollect.capture(), eq(context.getOrderData().getExistingCustomerOrder()))).thenReturn(createCollectCall);

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        verify(collectService, times(2)).createCustomerOrderCollect(anyList(), any(CustomerOrder.class));
        createCollectCall.expectHasBeenSubscribed();

        List<LineExecution> lineWithCollectToCreate = linesToCreateCollect.getValue();
        AssertionsForInterfaceTypes.assertThat(lineWithCollectToCreate).hasSize(1);
        assertThat(lineWithCollectToCreate.stream().allMatch(line -> line.getDelivery().getCollect().getFlags().lastFlagIs(CollectStatus.REQUESTED))).isTrue();

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void shouldCreateCollectWithExecutionActionOfTypeSplitForRemainingCollect() {
        RuleEngineContext context = generateActionExecutionContext();

        final LineExecution lineOrderAndCollect1 = context.getOrderData().getExistingLineExecutions().get(1);
        final LineExecutionDeliveryCollect lineExecutionDeliveryCollect1 = LineExecutionDeliveryCollect.builder().build();
        lineExecutionDeliveryCollect1.getFlags().raiseFlag(CollectStatus.REQUESTED);

        lineOrderAndCollect1.getDelivery().setCollect(lineExecutionDeliveryCollect1);

        LineExecution lineOrderAndCollect2 = context.getOrderData().getExistingLineExecutions().get(2);
        final String idExecutionGeneratedAfterSplit = UUID.randomUUID().toString();
        lineOrderAndCollect2.setExecutionId(idExecutionGeneratedAfterSplit);

        ExecutionAction executionAction = generateActionExecutionFromLines(context.getCustomerOrderId(), List.of(lineOrderAndCollect2), ExecutionActionType.SPLIT, REMAINING_COLLECT.name());

        ImpactedExecution impactedExecutionOrderAndCollect = executionAction.getImpactedExecutionByExecutionId(lineOrderAndCollect2.getExecutionId()).get();

        initializeSteps(impactedExecutionOrderAndCollect, List.of(UNEXEC_REQUIREMENT_TPP, SPLIT_LINE_EXECUTION, ASK_PREPARATION_REQUIREMENT_TPP, CREATE_COLLECT), List.of(UNEXEC_REQUIREMENT_TPP, SPLIT_LINE_EXECUTION, ASK_PREPARATION_REQUIREMENT_TPP));

        executionAction.getFlags().raiseFlag(ExecutionActionStatus.PROCESSING);

        context.getOrderData().setExecutionActions(List.of(executionAction));

        assertThat(rule.when(context)).isTrue();
        MonoMock<CustomerOrderCollectRequested> createCollectCall = MonoMock.just(customerOrderCollectRequested);
        when(collectService.createCustomerOrderCollect(linesToCreateCollect.capture(), eq(context.getOrderData().getExistingCustomerOrder()))).thenReturn(createCollectCall);

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        verify(collectService).createCustomerOrderCollect(anyList(), any(CustomerOrder.class));
        createCollectCall.expectHasBeenSubscribed();

        List<LineExecution> lineWithCollectToCreate = linesToCreateCollect.getValue();
        AssertionsForInterfaceTypes.assertThat(lineWithCollectToCreate).hasSize(1);
        assertThat(lineWithCollectToCreate.stream().allMatch(line -> line.getDelivery().getCollect().getFlags().lastFlagIs(CollectStatus.REQUESTED))).isTrue();

        assertThat(rule.when(context)).isFalse();
    }


    @Test
    void shouldNotCreateCollectBecauseAnExecutionActionIsProcessing() {
        RuleEngineContext context = generateActionExecutionContext();

        context.getOrderData().setExecutionActions(List.of(ExecutionAction.builder()
            .actionType(ExecutionActionType.DECREASE_QUANTITY)
            .build()));

        context.getOrderData().getExecutionActions().get(0).getFlags().raiseFlag(ExecutionActionStatus.PROCESSING);

        assertThat(rule.when(context)).isFalse();
    }

    private RuleEngineContext generateActionExecutionContext() {
        LineExecution sfwLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution orderAndCollectLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);
        LineExecution orderAndCollectLine2 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);

        RuleEngineContext context = generateContext(List.of(sfwLine1, orderAndCollectLine1, orderAndCollectLine2));

        context.getOrderData().setExecutionActions(List.of());
        return context;
    }
}
