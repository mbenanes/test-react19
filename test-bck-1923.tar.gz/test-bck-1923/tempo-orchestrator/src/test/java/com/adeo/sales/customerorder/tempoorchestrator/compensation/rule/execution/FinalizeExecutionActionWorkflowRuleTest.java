package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.execution;

import com.adeo.sales.customerorder.ruleengine.core.EngineRunner;
import com.adeo.sales.customerorder.ruleengine.springimpl.SpringRuleEngineRunner;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationContext;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.execution.InitializeExecutionActionWorkflowRuleStart.addStep;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(MockitoExtension.class)
class FinalizeExecutionActionWorkflowRuleTest {

    private FinalizeExecutionActionWorkflowRule rule;

    @Mock
    private ApplicationContext ctx;

    @BeforeEach
    void setUp() {
        rule = new FinalizeExecutionActionWorkflowRule(ctx);

    }

    @Test
    void shouldFinalizeExecutionActionWhenAllStepAreDone() {
        final SpringRuleEngineRunner springRuleEngineRunner = Mockito.mock(SpringRuleEngineRunner.class);
        Mockito.when(ctx.getBean(SpringRuleEngineRunner.class)).thenReturn(springRuleEngineRunner);
        Mockito.when(springRuleEngineRunner.retryFireRules(ArgumentMatchers.any(RuleEngineContext.class))).thenReturn(Mono.empty().then());

        RuleEngineContext context = generateActionExecutionContext();

        context.getOrderData()
            .getExecutionActions()
            .forEach(executionAction -> executionAction.getImpactedExecutions()
                .forEach(impactedExecution -> impactedExecution.getImpactedLines()
                    .forEach(impactedLine -> impactedLine.getSteps()
                        .forEach(step -> step.getFlags().raiseFlagIfNot(ImpactedLineStep.Status.COMPLETED)))));

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        assertThat(context.getOrderData().getExecutionActions().get(0).getFlags().lastFlagIs(ExecutionActionStatus.COMPLETED)).isTrue();

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void shouldNotFinalizeExecutionActionBecauseAStepIsNotDone() {
        final SpringRuleEngineRunner springRuleEngineRunner = Mockito.mock(SpringRuleEngineRunner.class);
        Mockito.when(ctx.getBean(SpringRuleEngineRunner.class)).thenReturn(springRuleEngineRunner);

        RuleEngineContext context = generateActionExecutionContext();

        context.getOrderData()
            .getExecutionActions()
            .forEach(executionAction -> executionAction.getImpactedExecutions()
                .forEach(impactedExecution -> impactedExecution.getImpactedLines()
                    .forEach(impactedLine -> {
                        impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY).get().getFlags().raiseFlagIfNot(ImpactedLineStep.Status.COMPLETED);
                        impactedLine.getStepOfType(ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP).get().getFlags().raiseFlagIfNot(ImpactedLineStep.Status.COMPLETED);
                        impactedLine.getStepOfType(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY).get().getFlags().raiseFlagIfNot(ImpactedLineStep.Status.PROCESSING);
                    })));

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void shouldNotFinalizeExecutionActionBecauseNonBlockingStepIsFailed() {
        final SpringRuleEngineRunner springRuleEngineRunner = Mockito.mock(SpringRuleEngineRunner.class);
        Mockito.when(ctx.getBean(SpringRuleEngineRunner.class)).thenReturn(springRuleEngineRunner);
        Mockito.when(springRuleEngineRunner.retryFireRules(ArgumentMatchers.any(RuleEngineContext.class))).thenReturn(Mono.empty().then());

        RuleEngineContext context = generateActionExecutionContext();

        context.getOrderData()
            .getExecutionActions()
            .stream()
            .map(ExecutionAction::getAllImpactedLines)
            .flatMap(Collection::stream)
            .map(ImpactedLine::getSteps)
                .flatMap(Collection::stream)
                    .filter(impactedLineStep -> impactedLineStep.getType().equals(ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY))
                        .forEach(impactedLineStep -> {
                            impactedLineStep.setBlocking(false);
                            impactedLineStep.getFlags().raiseFlagIfNot(ImpactedLineStep.Status.FAILED);
                        });


        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        assertThat(context.getOrderData().getExecutionActions().get(0).getFlags().lastFlagIs(ExecutionActionStatus.PROCESSING)).isTrue();
    }


    private RuleEngineContext generateActionExecutionContext() {

        RuleEngineContext context = new RuleEngineContext();
        LineExecution sfwLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution sfwLine2 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.CANCELED, DeliveryType.SFW, null, OFFER);
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                sfwLine1,
                sfwLine2
            ))
            .existingCustomerOrder(CustomerOrder.builder()
                .status(CustomerOrderStatus.VALIDATED)
                .buCode("001")
                .build())
            .executions(new ArrayList<>(List.of(Execution.builder()
                .id(UUID.randomUUID().toString())
                .build())))
            .build());

        context.getOrderData().getExistingLineExecutions().forEach(lineExecution -> lineExecution.setExecutionId(context.getOrderData().getExecutions().get(0).getId()));

        ImpactedLine impactedLine = ImpactedLine.builder()
            .quantity(sfwLine1.getQuantity())
            .lineId(sfwLine1.getLineId())
            .build();
        addStep(impactedLine.getSteps(), ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY, true);
        addStep(impactedLine.getSteps(), ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP, true);
        addStep(impactedLine.getSteps(), ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION, true);

        ExecutionAction executionAction = ExecutionAction.builder()
            .actionType(ExecutionActionType.DECREASE_QUANTITY)
            .createdAt(Instant.now())
            .impactedExecutions(List.of(ImpactedExecution.builder()
                .currentExecutionId(sfwLine1.getExecutionId())
                .impactedLines(List.of(impactedLine))
                .build()))
            .customerOrderId(context.getCustomerOrderId())
            .build();
        executionAction.getFlags().raiseFlag(ExecutionActionStatus.PROCESSING);

        context.getOrderData().setExecutionActions(List.of(executionAction));
        return context;
    }
}
