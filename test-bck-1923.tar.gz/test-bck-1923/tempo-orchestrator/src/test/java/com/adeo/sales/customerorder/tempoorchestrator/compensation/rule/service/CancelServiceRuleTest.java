package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.service;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ConfigurationService;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.service.ahs.AhsCommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.CREATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus.CANCELED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus.VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.CANCEL_SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateActionExecutionFromLines;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.initializeSteps;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CancelServiceRuleTest {

    private CancelServiceRule rule;

    @Mock
    private AhsCommandEventService ahsCommandEventService;

    @Captor
    private ArgumentCaptor<List<LineExecution>> outputLineExecutionsCaptor;

    @BeforeEach
    void setUp() {
        rule = new CancelServiceRule(ahsCommandEventService);
    }

    @Test
    void shouldStartServiceExecution() {
        LineExecution serviceLine1 = generateALine(false, null, false, true, false, false, VALIDATED, null, null, SERVICE);
        LineExecution associatedProductLine2WithService1 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution associatedProductLine1WithService1 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);

        LineExecution serviceLine2 = generateALine(false, null, false, true, false, false, VALIDATED, null, null, SERVICE);
        LineExecution associatedProductLineWithService2 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);

        LineExecution serviceAlone = generateALine(false, null, false, true, false, false, VALIDATED, null, null, SERVICE);

        LineExecution serviceLine3 = generateALine(false, null, false, true, false, false, VALIDATED, null, null, SERVICE);
        LineExecution associatedProductLine1WithService3 = generateALine(false, null, false, true, false, false, VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution associatedCanceledProductWithService3 = generateALine(false, null, false, true, false, false, CANCELED, DeliveryType.SFW, null, OFFER);

        Execution execution1 = Execution.builder().id(UUID.randomUUID().toString()).build();
        serviceLine1.setExecutionId(execution1.getId());
        associatedProductLine1WithService1.setExecutionId(execution1.getId());
        associatedProductLine2WithService1.setExecutionId(execution1.getId());
        String givenConfigurationIdentifier1 = UUID.randomUUID().toString();
        serviceLine1.setConfigurationService(ConfigurationService.builder()
            .id(givenConfigurationIdentifier1)
            .associatedLinesId(LineExecution.lineIds(List.of(associatedProductLine1WithService1, associatedProductLine2WithService1)))
            .build());
        serviceLine1.setDelivery(LineExecutionDelivery.builder().flags(new Flags<>(new Flag("", OffsetDateTime.now(), CREATION_REQUESTED.name(), null))).build());

        Execution execution2 = Execution.builder().id(UUID.randomUUID().toString()).build();
        serviceLine2.setExecutionId(execution2.getId());
        associatedProductLineWithService2.setExecutionId(execution2.getId());
        String givenConfigurationIdentifier2 = UUID.randomUUID().toString();
        serviceLine2.setConfigurationService(ConfigurationService.builder()
            .id(givenConfigurationIdentifier2)
            .associatedLinesId(LineExecution.lineIds(List.of(associatedProductLineWithService2)))
            .build());
        serviceLine2.setDelivery(LineExecutionDelivery.builder().flags(new Flags<>(new Flag("", OffsetDateTime.now(), CREATION_REQUESTED.name(), null))).build());

        Execution execution3 = Execution.builder().id(UUID.randomUUID().toString()).build();
        serviceAlone.setExecutionId(execution3.getId());
        String givenConfigurationIdentifier3 = UUID.randomUUID().toString();
        serviceAlone.setConfigurationService(ConfigurationService.builder()
            .id(givenConfigurationIdentifier3)
            .associatedLinesId(List.of())
            .build());
        serviceAlone.setDelivery(LineExecutionDelivery.builder().flags(new Flags<>(new Flag("", OffsetDateTime.now(), CREATION_REQUESTED.name(), null))).build());

        Execution execution4 = Execution.builder().id(UUID.randomUUID().toString()).build();
        serviceLine3.setExecutionId(execution4.getId());
        associatedProductLine1WithService3.setExecutionId(execution4.getId());
        associatedCanceledProductWithService3.setExecutionId(UUID.randomUUID().toString());
        String givenConfigurationIdentifier4 = UUID.randomUUID().toString();
        serviceLine3.setConfigurationService(ConfigurationService.builder()
            .id(givenConfigurationIdentifier4)
            .associatedLinesId(LineExecution.lineIds(List.of(associatedProductLine1WithService3, associatedCanceledProductWithService3)))
            .build());
        serviceLine3.setDelivery(LineExecutionDelivery.builder().flags(new Flags<>(new Flag("", OffsetDateTime.now(), CREATION_REQUESTED.name(), null))).build());

        RuleEngineContext context = new RuleEngineContext();

        List<LineExecution> allLines = List.of(associatedProductLine1WithService1, associatedProductLine2WithService1, serviceLine1, associatedProductLineWithService2, serviceLine2, serviceAlone, associatedProductLine1WithService3, associatedCanceledProductWithService3, serviceLine3);
        context.setOrderData(OrderData.builder()
            .existingCustomerOrder(CustomerOrder.builder()
                .status(CustomerOrderStatus.VALIDATED)
                .orderPlaceType(CustomerOrderPlaceType.IN_STORE)
                .build())
            .executions(List.of(execution1, execution2, execution3, execution4))
            .existingLineExecutions(allLines)
            .build());

        ExecutionAction executionAction = generateActionExecutionFromLines(context.getCustomerOrderId(), context.getOrderData().getExistingLineExecutions(), ExecutionActionType.DECREASE_QUANTITY);

        ImpactedExecution impactedExecutionService1 = executionAction.getImpactedExecutionByExecutionId(execution1.getId()).get();
        ImpactedExecution impactedExecutionService2 = executionAction.getImpactedExecutionByExecutionId(execution2.getId()).get();
        ImpactedExecution impactedExecutionServiceAlone = executionAction.getImpactedExecutionByExecutionId(execution3.getId()).get();
        ImpactedExecution impactedExecutionService3 = executionAction.getImpactedExecutionByExecutionId(execution4.getId()).get();

        initializeSteps(impactedExecutionService1, List.of(DECREASE_QUANTITY_DELIVERY, CANCEL_SERVICE, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION), List.of(DECREASE_QUANTITY_DELIVERY));
        initializeSteps(impactedExecutionService2, List.of(DECREASE_QUANTITY_DELIVERY, CANCEL_SERVICE, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION), List.of(DECREASE_QUANTITY_DELIVERY));
        initializeSteps(impactedExecutionServiceAlone, List.of(CANCEL_SERVICE, DECREASE_QUANTITY_COMPOSITION), List.of());
        initializeSteps(impactedExecutionService3, List.of(DECREASE_QUANTITY_DELIVERY, CANCEL_SERVICE, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION), List.of(DECREASE_QUANTITY_DELIVERY));

        executionAction.getFlags().raiseFlag(ExecutionActionStatus.PROCESSING);

        context.getOrderData().setExecutionActions(List.of(executionAction));

        MonoMock<Void> ahsCall1 = MonoMock.empty();
        when(ahsCommandEventService.sendCustomerOrderCancelledWithInstallation(any(CustomerOrder.class), outputLineExecutionsCaptor.capture())).thenReturn(ahsCall1);

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        ahsCall1.expectHasBeenSubscribed();

        verify(ahsCommandEventService, times(1)).sendCustomerOrderCancelledWithInstallation(eq(context.getOrderData().getExistingCustomerOrder()), anyList());

        assertThat(outputLineExecutionsCaptor.getAllValues()).hasSize(1);

        List<LineExecution> outputLines = outputLineExecutionsCaptor.getValue();
        assertThat(outputLines).hasSize(9);
        assertThat(outputLines).contains(serviceLine1);
        assertThat(outputLines).contains(associatedProductLine2WithService1);
        assertThat(outputLines).contains(associatedProductLine1WithService1);
        assertThat(outputLines).contains(serviceLine2);
        assertThat(outputLines).contains(associatedProductLineWithService2);
        assertThat(outputLines).contains(serviceAlone);
        assertThat(outputLines).contains(serviceLine3);
        assertThat(outputLines).contains(associatedProductLine1WithService3);
        assertThat(outputLines).contains(associatedCanceledProductWithService3);
    }

}
