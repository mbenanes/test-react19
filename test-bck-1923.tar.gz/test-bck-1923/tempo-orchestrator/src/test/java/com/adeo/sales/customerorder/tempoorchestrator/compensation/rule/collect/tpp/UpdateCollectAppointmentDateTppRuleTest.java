package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.collect.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.collect.tpp.UpdateCollectAppointmentDateCommunicationTppRule;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ConfigurationService;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import com.adeo.sales.customerorder.tempoorchestrator.service.PostponedEventService;
import com.adeo.sales.customerorder.tempoorchestrator.service.impl.OutcomingNotificationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus.VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.SERVICE;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType.RESERVE_AND_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UpdateCollectAppointmentDateTppRuleTest {

    private UpdateCollectAppointmentDateCommunicationTppRule rule;

    @Mock
    private PostponedEventService postponedEventService;

    @Mock
    private OutgoingNotificationService notificationService;

    @BeforeEach
    void setUp() {
        rule = new UpdateCollectAppointmentDateCommunicationTppRule(postponedEventService, notificationService);
    }

    @Test
    void shouldSendNotificationByExecutionId() {
        // Given
        var givenExecutionIdA = UUID.randomUUID().toString();
        var givenExecutionIdB = UUID.randomUUID().toString();
        var givenExecutionIdC = UUID.randomUUID().toString();
        var givenLineExecution1 = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        var givenLineExecution2 = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        var givenLineExecution3 = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        var givenLineExecution4 = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        var givenLineExecution5 = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        var givenLineService = generateALine(false, CustomerOrderLineDeliveryStatus.CREATION_REQUESTED, false, true, true, false, VALIDATED, null, null, SERVICE);
        givenLineService.setConfigurationService(ConfigurationService.builder()
            .associatedLinesId(List.of(givenLineExecution5.getLineId()))
            .build());

        givenLineExecution1.setExecutionId(givenExecutionIdA);
        givenLineExecution2.setExecutionId(givenExecutionIdA);
        givenLineExecution3.setExecutionId(givenExecutionIdB);
        givenLineExecution4.setExecutionId(givenExecutionIdB);
        givenLineExecution5.setExecutionId(givenExecutionIdC);
        givenLineService.setExecutionId(givenExecutionIdC);
        populateCollect(givenLineExecution1);
        populateCollect(givenLineExecution2);
        populateCollect(givenLineExecution3);
        populateCollect(givenLineExecution4);
        populateCollect(givenLineExecution5);


        var givenCustomerOrderId = UUID.randomUUID().toString();
        var givenContext = new RuleEngineContext();
        givenContext.setOrderData(OrderData.builder()
            .existingCustomerOrder(CustomerOrder.builder()
                .id(givenCustomerOrderId)
                .status(CustomerOrderStatus.VALIDATED)
                .orderPlaceType(CustomerOrderPlaceType.IN_STORE)
                .build())
            .existingLineExecutions(List.of(givenLineExecution1, givenLineExecution2, givenLineExecution3, givenLineExecution4, givenLineExecution5, givenLineService))
            .build());
        var givenAppointmentReminderHoursBeforeTemplateType = OutcomingNotificationServiceImpl.NotificationType.APPOINTMENT_REMINDER_HOURS_BEFORE.getTemplateType();
        var givenAppointmentReminderDayBeforeTemplateType = OutcomingNotificationServiceImpl.NotificationType.APPOINTMENT_REMINDER_DAY_BEFORE.getTemplateType();
        var givenPickupAppointmentExpiredTemplateType = OutcomingNotificationServiceImpl.NotificationType.PICKUP_APPOINTMENT_EXPIRED.getTemplateType();

        when(postponedEventService.markEventAsNotToSend(givenCustomerOrderId, givenAppointmentReminderHoursBeforeTemplateType)).thenReturn(Mono.empty());
        when(postponedEventService.markEventAsNotToSend(givenCustomerOrderId, givenAppointmentReminderDayBeforeTemplateType)).thenReturn(Mono.empty());
        when(postponedEventService.markEventAsNotToSend(givenCustomerOrderId, givenPickupAppointmentExpiredTemplateType)).thenReturn(Mono.empty());
        when(notificationService.sendPickupInStoreAppointmentUpdatingNotification(givenContext.getOrderData().getExistingCustomerOrder(), List.of(givenLineExecution1, givenLineExecution2))).thenReturn(Mono.empty());
        when(notificationService.sendPickupInStoreAppointmentUpdatingNotification(givenContext.getOrderData().getExistingCustomerOrder(), List.of(givenLineExecution3, givenLineExecution4))).thenReturn(Mono.empty());


        // When
        var result = rule.when(givenContext);

        // Then
        assertThat(result).isTrue();

        StepVerifier.create(rule.then(givenContext))
            .expectComplete()
            .verify();

        verify(postponedEventService, times(1)).markEventAsNotToSend(givenContext.getCustomerOrderId(), givenAppointmentReminderHoursBeforeTemplateType);
        verify(postponedEventService, times(1)).markEventAsNotToSend(givenContext.getCustomerOrderId(), givenAppointmentReminderDayBeforeTemplateType);
        verify(postponedEventService, times(1)).markEventAsNotToSend(givenContext.getCustomerOrderId(), givenPickupAppointmentExpiredTemplateType);
        verify(notificationService, times(1)).sendPickupInStoreAppointmentUpdatingNotification(givenContext.getOrderData().getExistingCustomerOrder(), List.of(givenLineExecution1, givenLineExecution2));
        verify(notificationService, times(1)).sendPickupInStoreAppointmentUpdatingNotification(givenContext.getOrderData().getExistingCustomerOrder(), List.of(givenLineExecution3, givenLineExecution4));
        verify(notificationService, never()).sendPickupInStoreAppointmentUpdatingNotification(givenContext.getOrderData().getExistingCustomerOrder(), List.of(givenLineExecution5));
        List.of(givenLineExecution1, givenLineExecution2, givenLineExecution3, givenLineExecution4)
            .forEach(lineExecution -> {
                assertThat(lineExecution.getDelivery().getCollect().getAppointmentReminderNotificationStatus()).isNull();
                assertThat(lineExecution.getDelivery().getCollect().getAppointmentExpiredNotificationStatus()).isNull();
                assertThat(lineExecution.getDelivery().getCollect().isAppointDateUpdated()).isFalse();
                assertThat(lineExecution.getVersion()).isEqualTo(2);
            });

    }

    @Test
    void shouldNotSendNotificationByExecutionId_WithCollectNotCompliant() {
        // Given
        var givenExecutionIdA = UUID.randomUUID().toString();
        var givenExecutionIdB = UUID.randomUUID().toString();
        var givenLineExecution1 = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        var givenLineExecution2 = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        var givenLineExecution3 = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        var givenLineExecution4 = generateALine(false, CustomerOrderLineDeliveryStatus.RESERVED, true, true, true, true, VALIDATED, RESERVE_AND_COLLECT, null, OFFER);
        givenLineExecution1.setExecutionId(givenExecutionIdA);
        givenLineExecution2.setExecutionId(givenExecutionIdA);
        givenLineExecution3.setExecutionId(givenExecutionIdB);
        givenLineExecution4.setExecutionId(givenExecutionIdB);


        var givenCustomerOrderId = UUID.randomUUID().toString();
        var givenContext = new RuleEngineContext();
        givenContext.setOrderData(OrderData.builder()
            .existingCustomerOrder(CustomerOrder.builder()
                .id(givenCustomerOrderId)
                .status(CustomerOrderStatus.VALIDATED)
                .orderPlaceType(CustomerOrderPlaceType.IN_STORE)
                .build())
            .existingLineExecutions(List.of(givenLineExecution1, givenLineExecution2, givenLineExecution3, givenLineExecution4))
            .build());
        var givenAppointmentReminderHoursBeforeTemplateType = OutcomingNotificationServiceImpl.NotificationType.APPOINTMENT_REMINDER_HOURS_BEFORE.getTemplateType();
        var givenAppointmentReminderDayBeforeTemplateType = OutcomingNotificationServiceImpl.NotificationType.APPOINTMENT_REMINDER_DAY_BEFORE.getTemplateType();
        var givenPickupAppointmentExpiredTemplateType = OutcomingNotificationServiceImpl.NotificationType.PICKUP_APPOINTMENT_EXPIRED.getTemplateType();

        // When
        var result = rule.when(givenContext);

        // Then
        assertThat(result).isFalse();

        verify(postponedEventService, times(0)).markEventAsNotToSend(givenContext.getCustomerOrderId(), givenAppointmentReminderHoursBeforeTemplateType);
        verify(postponedEventService, times(0)).markEventAsNotToSend(givenContext.getCustomerOrderId(), givenAppointmentReminderDayBeforeTemplateType);
        verify(postponedEventService, times(0)).markEventAsNotToSend(givenContext.getCustomerOrderId(), givenPickupAppointmentExpiredTemplateType);
        verify(notificationService, times(0)).sendPickupInStoreAppointmentUpdatingNotification(givenContext.getOrderData().getExistingCustomerOrder(), List.of(givenLineExecution1, givenLineExecution2));
        verify(notificationService, times(0)).sendPickupInStoreAppointmentUpdatingNotification(givenContext.getOrderData().getExistingCustomerOrder(), List.of(givenLineExecution3, givenLineExecution4));
    }

    private void populateCollect(LineExecution givenLineExecution) {
        var collect = givenLineExecution.getDelivery().getCollect();
        collect.setFlags(new Flags<>(new Flag("", OffsetDateTime.now(), CollectStatus.EXPECTED.name(), null)));
        collect.setAppointmentDate(OffsetDateTime.now().plusHours(1));
        collect.setAppointDateUpdated(true);
    }
}
