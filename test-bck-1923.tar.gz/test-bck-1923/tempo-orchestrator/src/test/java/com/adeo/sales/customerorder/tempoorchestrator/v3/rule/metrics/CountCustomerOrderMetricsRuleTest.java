package com.adeo.sales.customerorder.tempoorchestrator.v3.rule.metrics;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.metrics.CountCustomerOrderMetricsRule;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderPlaceType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.service.MetricCounterService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.util.ArrayList;
import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CountCustomerOrderMetricsRuleTest {
    private CountCustomerOrderMetricsRule rule;

    @Mock
    private MetricCounterService metricCounterService;

    @BeforeEach
    void setUp() {
        rule = new CountCustomerOrderMetricsRule(metricCounterService);
    }

    @Test
    void should_count_customer_order_metrics() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode("001")
            .orderPlaceType(CustomerOrderPlaceType.ONLINE)
            .isCountMetricGenerated(false)
            .build();

        LineExecution firstLine = generateALine(false, null, true, false, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, ExternalSystem.SystemName.TEMPO, OFFER);

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(new ArrayList<>(List.of(firstLine)))
            .existingCustomerOrder(customerOrder)
            .build());

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context)).verifyComplete();

        verify(metricCounterService, times(1)).countLineExecutionOrchestratingSystem(customerOrder, context.getOrderData().getExistingLineExecutions());
        verify(metricCounterService, times(1)).countLineExecutionDeliveryType(customerOrder, context.getOrderData().getExistingLineExecutions());

        assertThat(customerOrder.isCountMetricGenerated()).isEqualTo(true);

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_because_no_delivery_type() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode("001")
            .orderPlaceType(CustomerOrderPlaceType.ONLINE)
            .isCountMetricGenerated(false)
            .build();

        LineExecution firstLine = generateALine(false, null, true, false, CompositionOrderStatus.VALIDATED, null, null, ExternalSystem.SystemName.TEMPO, OFFER);

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(new ArrayList<>(List.of(firstLine)))
            .existingCustomerOrder(customerOrder)
            .build());

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_because_no_orchestrating_system() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode("001")
            .orderPlaceType(CustomerOrderPlaceType.ONLINE)
            .isCountMetricGenerated(false)
            .build();

        LineExecution firstLine = generateALine(false, null, true, false, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, null, OFFER);

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(new ArrayList<>(List.of(firstLine)))
            .existingCustomerOrder(customerOrder)
            .build());

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_because_no_order_place_type() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode("001")
            .isCountMetricGenerated(false)
            .build();

        LineExecution firstLine = generateALine(false, null, true, false, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, ExternalSystem.SystemName.TEMPO, OFFER);

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(new ArrayList<>(List.of(firstLine)))
            .existingCustomerOrder(customerOrder)
            .build());

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_because_composition_status_not_validated() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder customerOrder = CustomerOrder.builder()
            .buCode("001")
            .orderPlaceType(CustomerOrderPlaceType.ONLINE)
            .isCountMetricGenerated(false)
            .build();

        LineExecution firstLine = generateALine(false, null, true, false, CompositionOrderStatus.PENDING, DeliveryType.SFW, null, ExternalSystem.SystemName.TEMPO, OFFER);

        context.setOrderData(OrderData.builder()
            .existingLineExecutions(new ArrayList<>(List.of(firstLine)))
            .existingCustomerOrder(customerOrder)
            .build());

        assertThat(rule.when(context)).isFalse();
    }
}
