package com.adeo.sales.customerorder.tempoorchestrator.v3.rule.orchestratingsystem;

import com.adeo.sales.customerorder.external.api.client.legacyacl.dto.OrchestratingSystemResponse;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.acl.LegacyACL;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.orchestratingsystem.RetrieveOrchestratingSystemRule;
import com.adeo.sales.customerorder.tempoorchestrator.model.Clock;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RetrieveOrchestratingSystemRuleTest {

    private RetrieveOrchestratingSystemRule rule;
    @Mock
    private LegacyACL legacyACL;

    @BeforeEach
    void setUp() {
        rule = new RetrieveOrchestratingSystemRule(legacyACL);
    }

    @Test
    void should_retrieve_orchestrating_system_information_if_missing_and_has_order_number() {

        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder customerOrder = CustomerOrder.builder()
            .status(CustomerOrderStatus.VALIDATED)
            .buCode("001")
            .customerOrderNumber("XXXXXX")
            .delivery(new Clock(UUID.randomUUID().toString(), 1))
            .build();
        LineExecution firstLine = generateALine(false, null, true, false, CompositionOrderStatus.VALIDATED, null, null, null, OFFER);
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(
                firstLine
            ))
            .existingCustomerOrder(customerOrder)
            .build());

        OrchestratingSystemResponse orchestratingSystemResponse = new OrchestratingSystemResponse();
        orchestratingSystemResponse.setCustomerOrderId(customerOrder.getId());
        OrchestratingSystemResponse.Data orchestratingInfoData = new OrchestratingSystemResponse.Data();
        orchestratingInfoData.setOrchestratingSystem("TEMPO");
        orchestratingInfoData.setCustomerOrderLinesId(List.of(firstLine.getLineId()));
        orchestratingSystemResponse.setData(List.of(orchestratingInfoData));

        MonoMock<OrchestratingSystemResponse> legacyACLCall = MonoMock.just(orchestratingSystemResponse);
        when(legacyACL.askOrchestratingSystem(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(legacyACLCall);

        assertThat(rule.when(context)).isTrue();

        StepVerifier.create(rule.then(context)).verifyComplete();

        verify(legacyACL, times(1)).askOrchestratingSystem(customerOrder.getId(), customerOrder.getBuCode());

        legacyACLCall.expectHasBeenSubscribed();

        assertThat(firstLine.getExternalSystem()).isNotNull();
        assertThat(firstLine.getExternalSystem().getId()).isNotNull();
        assertThat(firstLine.getExternalSystem().getName()).isEqualTo(ExternalSystem.SystemName.TEMPO);
    }

    @Test
    void should_not_start_rule_because_have_already_orchestrating_system() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder customerOrder = CustomerOrder.builder()
            .status(CustomerOrderStatus.VALIDATED)
            .buCode("001")
            .customerOrderNumber("XXXXXX")
            .delivery(new Clock(UUID.randomUUID().toString(), 1))
            .build();
        LineExecution firstLine = generateALine(false,
            null,
            true,
            false,
            CompositionOrderStatus.VALIDATED,
            null,
            null,
            ExternalSystem.SystemName.TEMPO, OFFER);
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(firstLine))
            .existingCustomerOrder(customerOrder)
            .build());

        assertThat(rule.when(context)).isFalse();
    }

    @Test
    void should_not_start_rule_because_not_have_customer_order_number() {
        RuleEngineContext context = new RuleEngineContext();
        CustomerOrder customerOrder = CustomerOrder.builder()
            .status(CustomerOrderStatus.VALIDATED)
            .buCode("001")
            .customerOrderNumber(null)
            .delivery(new Clock(UUID.randomUUID().toString(), 1))
            .build();
        LineExecution firstLine = generateALine(false,
            null,
            true,
            false,
            CompositionOrderStatus.VALIDATED,
            null,
            null,
            OFFER);
        context.setOrderData(OrderData.builder()
            .existingLineExecutions(List.of(firstLine))
            .existingCustomerOrder(customerOrder)
            .build());

        assertThat(rule.when(context)).isFalse();
    }
}
