package com.adeo.sales.customerorder.tempoorchestrator.applicationservice;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.PyxisOrderCreationFailureApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.pyxis.input.PyxisOrderInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;
import reactor.util.function.Tuple5;
import reactor.util.function.Tuples;

import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.ACCEPTED;
import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PyxisOrderCreationFailureApplicationServiceTest {
    private PyxisOrderCreationFailureApplicationService service;

    @Mock
    private RuleEngineService ruleEngineService;

    @BeforeEach
    void setUp() {
        service = new PyxisOrderCreationFailureApplicationService(ruleEngineService);
    }

    @Test
    void should_set_line_to_creation_failed() {
        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .id(UUID.randomUUID().toString())
            .buCode("001")
            .build();
        String lineId = UUID.randomUUID().toString();
        final LineExecution lineExecution = LineExecution.builder()
            .lineId(lineId)
            .build();
        lineExecution.getDelivery().getFlags().raiseFlagIfNot(ACCEPTED);
        List<LineExecution> bddLineExecutions = List.of(lineExecution);


        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLineExecutions, List.of(), List.of(), List.of()));
        when(ruleEngineService.lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        MonoMock<Void> runRuleEngineCall = MonoMock.empty();
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> runRuleEngineCall);

        PyxisOrderInput input = PyxisOrderInput.builder()
            .lineIds(List.of(bddLineExecutions.get(0).getLineId()))
            .customerOrderId(bddCustomerOrder.getId())
            .buCode(bddCustomerOrder.getBuCode())
            .build();

        StepVerifier.create(service.apply(input)).verifyComplete();

        lockAndGetDataCall.expectHasBeenSubscribed();
        runRuleEngineCall.expectHasBeenSubscribed();

        verify(ruleEngineService).lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode());
        verify(ruleEngineService).startRuleEngineAndUpdateLines();

        assertThat(bddLineExecutions.get(0).getDelivery().getFlags().lastFlagIs(CustomerOrderLineDeliveryStatus.CREATION_FAILED)).isTrue();
        assertThat(bddLineExecutions.get(0).getDelivery().getCancelable()).isTrue();
    }
}
