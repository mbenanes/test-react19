package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentRequirementActionExecutionResponseInput;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.PaymentRequirementActionExecutionResponseInput.Line;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.tpp.input.TppAllowedStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.payment.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.util.function.Tuple5;
import reactor.util.function.Tuples;

import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PaymentRequirementActionExecutionResponseApplicationServiceTest {

    private PaymentRequirementActionExecutionResponseApplicationService applicationService;

    @Mock
    private RuleEngineService ruleEngineService;

    @BeforeEach
    void setUp() {
        applicationService = new PaymentRequirementActionExecutionResponseApplicationService(ruleEngineService);
    }

    @Test
    void should_update_shipping_requirement_and_start_rule_engine() {
        final String executionId = UUID.randomUUID().toString();
        LineExecution firstLine = generateALine(true, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);
        firstLine.setExecutionId(executionId);
        firstLine.getPaymentRequirements().getShippingFlags().raiseFlag(RequirementStatus.REQUESTED);
        LineExecution secondLine = generateALine(true, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);
        secondLine.setExecutionId(executionId);
        secondLine.getPaymentRequirements().getShippingFlags().raiseFlag(RequirementStatus.REQUESTED);


        List<LineExecution> bddLines = List.of(firstLine, secondLine);
        List<Line> impacteRequirementLines = bddLines.stream().map(lineExecution -> Line.builder().id(lineExecution.getLineId()).build()).collect(Collectors.toList());

        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .build();

        final var input = PaymentRequirementActionExecutionResponseInput.builder()
            .customerOrderId(UUID.randomUUID().toString())
            .buCode("001")
            .operationId(UUID.randomUUID().toString())
            .customerOrderExecutionPlanId(firstLine.getExecutionId())
            .status(TppAllowedStatus.APPROVED)
            .statusDate(Instant.now())
            .isUnexecAction(false)
            .lines(impacteRequirementLines)
            .actionType("SHIPPING")
            .build();

        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLines, List.of(), List.of(), List.of()));
        when(ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> Mono.empty());

        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        lockAndGetDataCall.expectHasBeenSubscribed();

        verify(ruleEngineService).lockAndGetData(input.getCustomerOrderId(), input.getBuCode());
        verify(ruleEngineService).startRuleEngineAndUpdateLines();

        bddLines.forEach(line -> assertThat(line.getPaymentRequirements().getShippingFlags().lastFlagIs(RequirementStatus.APPROVED)).isTrue());
    }

    @Test
    void should_not_update_shipping_requirement_because_status_is_not_requested() {
        LineExecution firstLine = generateALine(true, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);
        LineExecution secondLine = generateALine(true, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);

        List<LineExecution> bddLines = List.of(firstLine, secondLine);
        List<Line> impacteRequirementLines = bddLines.stream().map(lineExecution -> Line.builder().id(lineExecution.getLineId()).build()).collect(Collectors.toList());


        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .build();

        final var input = PaymentRequirementActionExecutionResponseInput.builder()
            .customerOrderId(UUID.randomUUID().toString())
            .buCode("001")
            .operationId(UUID.randomUUID().toString())
            .status(TppAllowedStatus.APPROVED)
            .statusDate(Instant.now())
            .isUnexecAction(false)
            .lines(impacteRequirementLines)
            .actionType("SHIPPING")
            .build();

        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLines, List.of(), List.of(), List.of()));
        when(ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        MonoMock<Void> ruleEngineCall = MonoMock.empty();
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> ruleEngineCall);

        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        lockAndGetDataCall.expectHasBeenSubscribed();
        ruleEngineCall.expectHasBeenSubscribed();

        verify(ruleEngineService).lockAndGetData(input.getCustomerOrderId(), input.getBuCode());
        verify(ruleEngineService).startRuleEngineAndUpdateLines();

        bddLines.forEach(line -> assertThat(line.getPaymentRequirements().getShippingFlags().lastFlagIs(RequirementStatus.APPROVED)).isFalse());
    }

    @Test
    void should_not_start_rule_engine_because_order_not_found() {
        LineExecution firstLine = generateALine(true, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);
        LineExecution secondLine = generateALine(true, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.THIRD_PARTY, null, OFFER);

        List<LineExecution> bddLines = List.of(firstLine, secondLine);
        List<Line> impacteRequirementLines = bddLines.stream().map(lineExecution -> Line.builder().id(lineExecution.getLineId()).build()).collect(Collectors.toList());

        final var input = PaymentRequirementActionExecutionResponseInput.builder()
            .customerOrderId(UUID.randomUUID().toString())
            .buCode("001")
            .operationId(UUID.randomUUID().toString())
            .status(TppAllowedStatus.APPROVED)
            .statusDate(Instant.now())
            .lines(impacteRequirementLines)
            .actionType("SHIPPING")
            .build();

        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> error = MonoMock.error(new CustomerOrderNotFound(""));
        when(ruleEngineService.lockAndGetData(input.getCustomerOrderId(), input.getBuCode()))
            .thenReturn(error);

        MonoMock<Void> ruleEngineCall = MonoMock.empty();
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> ruleEngineCall);

        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        error.expectHasBeenSubscribed();
        ruleEngineCall.expectHasNotBeenSubscribed();

        verify(ruleEngineService).lockAndGetData(input.getCustomerOrderId(), input.getBuCode());
        verify(ruleEngineService).startRuleEngineAndUpdateLines();

        bddLines.forEach(line -> assertThat(line.getPaymentRequirements().getShippingFlags().lastFlagIs(RequirementStatus.APPROVED)).isFalse());
    }

}
