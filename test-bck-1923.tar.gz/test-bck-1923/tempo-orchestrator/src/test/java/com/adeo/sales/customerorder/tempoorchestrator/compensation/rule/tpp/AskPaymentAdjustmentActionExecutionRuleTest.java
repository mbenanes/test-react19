package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.tpp;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep;
import com.adeo.sales.customerorder.tempoorchestrator.service.TppCommandEventService;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.assertj.core.api.AssertionsForInterfaceTypes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus.EXPECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_COMPOSITION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.DECREASE_QUANTITY_DELIVERY;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.EXECUTE_ADJUSTMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.READ_ADJUSTMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ImpactedLineStep.Type.UNEXEC_REQUIREMENT_TPP;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateActionExecutionFromLines;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateContext;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.initializeSteps;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AskPaymentAdjustmentActionExecutionRuleTest {

    private AskPaymentAdjustmentActionExecutionRule rule;

    @Mock
    private TppCommandEventService tppCommandEventService;

    @Captor
    private ArgumentCaptor<List<ImpactedLine>> impactedLinesCaptor;

    @BeforeEach
    void setUp() {
        rule = new AskPaymentAdjustmentActionExecutionRule(tppCommandEventService);
    }

    @Test
    void shouldRequestAdjustmentExecution() {
        RuleEngineContext context = generateActionExecutionContext();

        assertThat(rule.when(context)).isTrue();

        MonoMock<String> requestCall = MonoMock.just("");
        when(tppCommandEventService.sendPaymentAdjustmentActionExecutionCreationRequest(eq(context.getOrderData().getExistingCustomerOrder()), impactedLinesCaptor.capture())).thenReturn(requestCall);

        StepVerifier.create(rule.then(context))
            .verifyComplete();

        verify(tppCommandEventService).sendPaymentAdjustmentActionExecutionCreationRequest(any(CustomerOrder.class), anyList());
        requestCall.expectHasBeenSubscribed();

        ExecutionAction executionAction = context.getOrderData().getExecutionActions().get(0);
        assertThat(executionAction.getImpactedExecutions()
            .stream()
            .flatMap(l -> l.getImpactedLines().stream())
            .anyMatch(line -> {
                Optional<ImpactedLineStep> executeAdjustmentStep = line.getStepOfType(EXECUTE_ADJUSTMENT_TPP);
                return executeAdjustmentStep.get().getFlags().lastFlagIs(ImpactedLineStep.Status.PROCESSING) || executeAdjustmentStep.get().getFlags().lastFlagIs(ImpactedLineStep.Status.COMPLETED);
            }))
            .isTrue();

        List<ImpactedLine> adjustmentRequested = impactedLinesCaptor.getValue();
        AssertionsForInterfaceTypes.assertThat(adjustmentRequested).hasSize(2);

        assertThat(rule.when(context)).isFalse();
    }

    private RuleEngineContext generateActionExecutionContext() {
        LineExecution sfwLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution sfwLine2 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFW, null, OFFER);
        LineExecution sfpLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.SFP, null, OFFER);
        LineExecution orderAndCollectLine1 = generateALine(false, CustomerOrderLineDeliveryStatus.ACCEPTED, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);

        orderAndCollectLine1.getDelivery().getCollect().getFlags().raiseFlagIfNot(EXPECTED);

        RuleEngineContext context = generateContext(List.of(sfwLine1, sfwLine2, sfpLine1, orderAndCollectLine1));

        ExecutionAction executionAction = generateActionExecutionFromLines(context.getCustomerOrderId(), context.getOrderData().getExistingLineExecutions(), ExecutionActionType.DECREASE_QUANTITY);

        ImpactedExecution impactedExecutionSfw = executionAction.getImpactedExecutionByExecutionId(sfwLine1.getExecutionId()).get();
        ImpactedExecution impactedExecutionSfp = executionAction.getImpactedExecutionByExecutionId(sfpLine1.getExecutionId()).get();
        ImpactedExecution impactedExecutionOrderAndCollect = executionAction.getImpactedExecutionByExecutionId(orderAndCollectLine1.getExecutionId()).get();

        initializeSteps(impactedExecutionSfw, List.of(DECREASE_QUANTITY_DELIVERY, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP, EXECUTE_ADJUSTMENT_TPP), List.of(DECREASE_QUANTITY_DELIVERY, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP, READ_ADJUSTMENT_TPP));
        initializeSteps(impactedExecutionSfp, List.of(UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP, EXECUTE_ADJUSTMENT_TPP, READ_ADJUSTMENT_TPP, EXECUTE_ADJUSTMENT_TPP), List.of(UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP, EXECUTE_ADJUSTMENT_TPP, READ_ADJUSTMENT_TPP));
        initializeSteps(impactedExecutionOrderAndCollect, List.of(DECREASE_QUANTITY_DELIVERY, DECREASE_QUANTITY_COLLECT, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION, READ_ADJUSTMENT_TPP, EXECUTE_ADJUSTMENT_TPP), List.of(DECREASE_QUANTITY_DELIVERY, DECREASE_QUANTITY_COLLECT, UNEXEC_REQUIREMENT_TPP, DECREASE_QUANTITY_COMPOSITION));

        executionAction.getFlags().raiseFlag(ExecutionActionStatus.PROCESSING);

        String uuidAdjustment = UUID.randomUUID().toString();
        impactedExecutionSfw.getImpactedLines().forEach(line -> line.setPaymentAdjustmentActionId(uuidAdjustment));

        context.getOrderData().setExecutionActions(List.of(executionAction));
        return context;
    }

}
