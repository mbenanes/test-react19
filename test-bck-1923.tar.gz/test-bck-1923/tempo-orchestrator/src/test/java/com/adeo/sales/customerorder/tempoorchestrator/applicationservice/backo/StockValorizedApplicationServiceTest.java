package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.backo;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.backo.input.StockValorizedInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.Offer;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecutionComposition;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.StockValuationStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderLineRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LineExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;
import reactor.util.function.Tuple5;
import reactor.util.function.Tuples;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderLineStatus.VALIDATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.legacy.CustomerOrderLineDeliveryStatus.SHIPPED;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class StockValorizedApplicationServiceTest {

    public static final String BU_CODE = "003";
    public static final String DELIVERY_LEGACY_NUMBER = "3333";
    public static final String STORE_CODE = "021";
    public static final String CUSTOMER_ORDER_ID = UUID.randomUUID().toString();
    @Mock
    private RuleEngineService ruleEngineService;

    @Mock
    private LineExecutionRepository lineExecutionRepository;
    @Mock
    private CustomerOrderLineRepository customerOrderLineRepository;

    private StockValorizedApplicationService applicationService;

    @BeforeEach
    void setUp() {
        applicationService = new StockValorizedApplicationService(ruleEngineService, lineExecutionRepository, customerOrderLineRepository);
    }

    @Test
    void should_set_stock_valuate_succeed() {

        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .id(CUSTOMER_ORDER_ID)
            .buCode(BU_CODE)
            .build();
        String lineId1 = UUID.randomUUID().toString();

        LineExecution line1 = generateLine(lineId1, "111111");

        LineExecution line2 = generateLine(lineId1, "222222");

        List<LineExecution> bddLineExecutions = List.of(line1, line2);

        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLineExecutions, List.of(), List.of(), List.of()));
        lenient().when(ruleEngineService.lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        MonoMock<Void> runRuleEngineCall = MonoMock.empty();
        lenient().when(ruleEngineService.startRuleEngineAndUpdateLines(any(CustomerOrder.class), anyList(),anyList(),anyList(),anyList())).thenReturn(runRuleEngineCall);

        StockValorizedInput input = StockValorizedInput.builder()
            .succeed(true)
            .buCode(BU_CODE)
            .deliveryLegacyNumber(DELIVERY_LEGACY_NUMBER)
            .storeCode(STORE_CODE)
            .productReferences(List.of("111111", "222222"))
            .build();
        when(lineExecutionRepository.getByDeliveryLegacyNumber(input.getDeliveryLegacyNumber(), input.getBuCode(), input.getStoreCode()))
            .thenReturn(Flux.fromIterable(bddLineExecutions));
        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        lockAndGetDataCall.expectHasBeenSubscribed();
        runRuleEngineCall.expectHasBeenSubscribed();

        verify(lineExecutionRepository).getByDeliveryLegacyNumber(DELIVERY_LEGACY_NUMBER, BU_CODE, STORE_CODE);

        bddLineExecutions.forEach(lineExecution -> assertThat(lineExecution.getDelivery().getStockValuationStatus() == StockValuationStatus.STOCK_VALUATION_SUCCEED).isTrue());
    }

    @Test
    void should_set_stock_valuate_failed() {

        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .id(CUSTOMER_ORDER_ID)
            .buCode(BU_CODE)
            .build();
        String lineId1 = UUID.randomUUID().toString();

        LineExecution line1 = generateLine(lineId1, "111111");

        LineExecution line2 = generateLine(lineId1, "222222");

        List<LineExecution> bddLineExecutions = List.of(line1, line2);

        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLineExecutions, List.of(), List.of(), List.of()));
        lenient().when(ruleEngineService.lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        MonoMock<Void> runRuleEngineCall = MonoMock.empty();
        lenient().when(ruleEngineService.startRuleEngineAndUpdateLines(any(CustomerOrder.class), anyList(),anyList(),anyList(),anyList())).thenReturn(runRuleEngineCall);

        StockValorizedInput input = StockValorizedInput.builder()
            .succeed(false)
            .buCode(BU_CODE)
            .deliveryLegacyNumber(DELIVERY_LEGACY_NUMBER)
            .storeCode(STORE_CODE)
            .productReferences(List.of("111111", "222222"))
            .build();
        when(lineExecutionRepository.getByDeliveryLegacyNumber(input.getDeliveryLegacyNumber(), input.getBuCode(), input.getStoreCode()))
            .thenReturn(Flux.fromIterable(bddLineExecutions));
        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        lockAndGetDataCall.expectHasBeenSubscribed();
        runRuleEngineCall.expectHasBeenSubscribed();

        verify(lineExecutionRepository).getByDeliveryLegacyNumber(DELIVERY_LEGACY_NUMBER, BU_CODE, STORE_CODE);

        bddLineExecutions.forEach(lineExecution -> assertThat(lineExecution.getDelivery().getStockValuationStatus() == StockValuationStatus.STOCK_VALUATION_FAILED).isTrue());
    }

    @Test
    void should_not_set_stock_valuate_succeed_because_multiple_orders() {

        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .id(CUSTOMER_ORDER_ID)
            .buCode(BU_CODE)
            .build();
        String lineId1 = UUID.randomUUID().toString();

        LineExecution line1 = generateLine(lineId1, "111111");

        LineExecution line2 = generateLine(lineId1, "222222");
        LineExecution line3OtherOrder = generateLine(lineId1, "333333");
        line3OtherOrder.setCustomerOrderId(UUID.randomUUID().toString());

        List<LineExecution> bddLineExecutions = List.of(line1, line2);

        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLineExecutions, List.of(), List.of(), List.of()));
        lenient().when(ruleEngineService.lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        MonoMock<Void> runRuleEngineCall = MonoMock.empty();
        lenient().when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> runRuleEngineCall);

        StockValorizedInput input = StockValorizedInput.builder()
            .succeed(true)
            .buCode(BU_CODE)
            .deliveryLegacyNumber(DELIVERY_LEGACY_NUMBER)
            .storeCode(STORE_CODE)
            .productReferences(List.of("111111", "222222"))
            .build();

        List<LineExecution> deliveryLegacyNumberLines = List.of(line1, line2, line3OtherOrder);
        when(lineExecutionRepository.getByDeliveryLegacyNumber(input.getDeliveryLegacyNumber(), input.getBuCode(), input.getStoreCode()))
            .thenReturn(Flux.fromIterable(deliveryLegacyNumberLines));
        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        lockAndGetDataCall.expectHasNotBeenSubscribed();
        runRuleEngineCall.expectHasNotBeenSubscribed();

        verify(lineExecutionRepository).getByDeliveryLegacyNumber(DELIVERY_LEGACY_NUMBER, BU_CODE, STORE_CODE);

        bddLineExecutions.forEach(lineExecution -> assertThat(lineExecution.getDelivery().getStockValuationStatus() == StockValuationStatus.STOCK_VALUATION_REQUESTED).isTrue());
    }

    private static LineExecution generateLine(String lineId1, String number) {
        return LineExecution.builder()
            .lineId(lineId1)
            .customerOrderId(CUSTOMER_ORDER_ID)
            .composition(LineExecutionComposition.builder()
                .flags(new Flags<>(new Flag("", OffsetDateTime.now(), VALIDATED.name(), null)))
                .offer(Offer.builder()
                    .refLM(number)
                    .build())
                .build())
            .delivery(LineExecutionDelivery.builder()
                .deliveryType(DeliveryType.SFW)
                .deliveryLegacyNumber(DELIVERY_LEGACY_NUMBER)
                .stockValuationStatus(StockValuationStatus.STOCK_VALUATION_REQUESTED)
                .flags(new Flags<>(new Flag("", OffsetDateTime.now(), SHIPPED.name(), null)))
                .build())
            .build();
    }
}
