package com.adeo.sales.customerorder.tempoorchestrator.util;

import org.opentest4j.AssertionFailedError;
import reactor.core.CoreSubscriber;
import reactor.core.publisher.Flux;

public class FluxMock<T> extends Flux<T> {

    private final Flux<T> delegate;
    private boolean isSubscribed = false;

    public static <T> FluxMock<T> empty() {
        return new FluxMock<>(Flux.empty());
    }

    public static <T> FluxMock<T> fromIterable(Iterable<? extends T> iterable) {
        return new FluxMock<>(Flux.fromIterable(iterable));
    }

    private FluxMock(Flux<T> delegate) {
        this.delegate = delegate;
    }

    @Override
    public void subscribe(CoreSubscriber<? super T> actual) {
        this.isSubscribed = true;
        this.delegate.subscribe(actual);
    }

    public void expectHasBeenSubscribed() {
        if (!isSubscribed) {
            throw new AssertionFailedError("Mono should be subscribed");
        }
    }

    public void expectHasNotBeenSubscribed() {
        if (isSubscribed) {
            throw new AssertionFailedError("Mono should not be subscribed");
        }
    }
}
