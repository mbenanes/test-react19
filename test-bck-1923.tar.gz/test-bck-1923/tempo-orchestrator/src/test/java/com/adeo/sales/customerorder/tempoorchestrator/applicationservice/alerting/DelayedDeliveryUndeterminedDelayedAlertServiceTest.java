package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.alerting;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.RuleEngineService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.DelayedLine;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.delivery.input.FulfillmentMapExecutionDelayAlertInput;
import com.adeo.sales.customerorder.tempoorchestrator.model.alert.Alert;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.util.MonoMock;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DelayType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.LineExecutionDelivery;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;
import reactor.util.function.Tuple5;
import reactor.util.function.Tuples;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DelayedDeliveryUndeterminedDelayedAlertServiceTest {

    private DelayedDeliveryUndeterminedDelayedAlertService applicationService;

    @Mock
    private RuleEngineService ruleEngineService;

    @BeforeEach
    void setUp() {
        applicationService = new DelayedDeliveryUndeterminedDelayedAlertService(ruleEngineService);
    }


    @Test
    void shoud_set_delay_type_to_unknown_delay() {
        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .id(UUID.randomUUID().toString())
            .buCode("001")
            .build();
        String lineId = UUID.randomUUID().toString();
        List<LineExecution> bddLineExecutions = List.of(LineExecution.builder()
            .lineId(lineId)
            .build());

        List<Alert> bddAlerts = List.of();
        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLineExecutions, bddAlerts, List.of(), List.of()));
        when(ruleEngineService.lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        MonoMock<Void> runRuleEngineCall = MonoMock.empty();
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> runRuleEngineCall);

        FulfillmentMapExecutionDelayAlertInput input = FulfillmentMapExecutionDelayAlertInput.builder()
            .buCode(bddCustomerOrder.getBuCode())
            .customerOrderId(bddCustomerOrder.getId())
            .delayedLines(List.of(DelayedLine.builder()
                .code("015")
                .lineId(lineId)
                .build()))
            .build();

        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        lockAndGetDataCall.expectHasBeenSubscribed();
        runRuleEngineCall.expectHasBeenSubscribed();

        verify(ruleEngineService).lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode());
        verify(ruleEngineService).startRuleEngineAndUpdateLines();

        assertThat(bddLineExecutions.get(0).getDelivery().getDelayType()).isEqualTo(DelayType.UNKNOWN_DELAY);
    }

    @Test
    void shoud_set_delay_type_to_unknown_delay_event_if_already_have_delay_type() {
        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .id(UUID.randomUUID().toString())
            .buCode("001")
            .build();
        String lineId = UUID.randomUUID().toString();
        List<LineExecution> bddLineExecutions = List.of(LineExecution.builder()
            .lineId(lineId)
            .delivery(LineExecutionDelivery.builder()
                .delayType(DelayType.FORECASTED_LATE)
                .build())
            .build());

        List<Alert> bddAlerts = List.of();
        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLineExecutions, bddAlerts, List.of(), List.of()));
        when(ruleEngineService.lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        MonoMock<Void> runRuleEngineCall = MonoMock.empty();
        when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> runRuleEngineCall);

        FulfillmentMapExecutionDelayAlertInput input = FulfillmentMapExecutionDelayAlertInput.builder()
            .buCode(bddCustomerOrder.getBuCode())
            .customerOrderId(bddCustomerOrder.getId())
            .delayedLines(List.of(DelayedLine.builder()
                .code("015")
                .lineId(lineId)
                .build()))
            .build();

        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        lockAndGetDataCall.expectHasBeenSubscribed();
        runRuleEngineCall.expectHasBeenSubscribed();

        verify(ruleEngineService).lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode());
        verify(ruleEngineService).startRuleEngineAndUpdateLines();

        assertThat(bddLineExecutions.get(0).getDelivery().getDelayType()).isEqualTo(DelayType.UNKNOWN_DELAY);
    }

    @Test
    void shoud_do_nothing_because_alert_code_not_managed() {
        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .id(UUID.randomUUID().toString())
            .buCode("001")
            .build();
        String lineId = UUID.randomUUID().toString();
        List<LineExecution> bddLineExecutions = List.of(LineExecution.builder()
            .lineId(lineId)
            .delivery(LineExecutionDelivery.builder()
                .build())
            .build());

        List<Alert> bddAlerts = List.of();
        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLineExecutions, bddAlerts, List.of(), List.of()));
        lenient().when(ruleEngineService.lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        MonoMock<Void> runRuleEngineCall = MonoMock.empty();
        lenient().when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> runRuleEngineCall);

        FulfillmentMapExecutionDelayAlertInput input = FulfillmentMapExecutionDelayAlertInput.builder()
            .buCode(bddCustomerOrder.getBuCode())
            .customerOrderId(bddCustomerOrder.getId())
            .delayedLines(List.of(DelayedLine.builder()
                .code("012")
                .lineId(lineId)
                .build()))
            .build();

        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        lockAndGetDataCall.expectHasNotBeenSubscribed();
        runRuleEngineCall.expectHasNotBeenSubscribed();

        verify(ruleEngineService, never()).lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode());
        verify(ruleEngineService, never()).startRuleEngineAndUpdateLines();

        assertThat(bddLineExecutions.get(0).getDelivery().getDelayType()).isNull();
    }

    @Test
    void shoud_do_nothing_because_there_are_no_lines() {
        CustomerOrder bddCustomerOrder = CustomerOrder.builder()
            .id(UUID.randomUUID().toString())
            .buCode("001")
            .build();
        String lineId = UUID.randomUUID().toString();
        List<LineExecution> bddLineExecutions = List.of();

        List<Alert> bddAlerts = List.of();
        MonoMock<Tuple5<CustomerOrder, List<LineExecution>, List<Alert>, List<ExecutionAction>, List<Execution>>> lockAndGetDataCall = MonoMock.just(Tuples.of(bddCustomerOrder, bddLineExecutions, bddAlerts, List.of(), List.of()));
        lenient().when(ruleEngineService.lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode()))
            .thenReturn(lockAndGetDataCall);

        MonoMock<Void> runRuleEngineCall = MonoMock.empty();
        lenient().when(ruleEngineService.startRuleEngineAndUpdateLines()).thenReturn((customerOrder, lineExecutions, alerts, executionActions, executions) -> runRuleEngineCall);

        FulfillmentMapExecutionDelayAlertInput input = FulfillmentMapExecutionDelayAlertInput.builder()
            .buCode(bddCustomerOrder.getBuCode())
            .customerOrderId(bddCustomerOrder.getId())
            .delayedLines(List.of(DelayedLine.builder()
                .code("012")
                .lineId(lineId)
                .build()))
            .build();

        StepVerifier.create(applicationService.apply(input)).verifyComplete();

        lockAndGetDataCall.expectHasNotBeenSubscribed();
        runRuleEngineCall.expectHasNotBeenSubscribed();

        verify(ruleEngineService, never()).lockAndGetData(bddCustomerOrder.getId(), bddCustomerOrder.getBuCode());
        verify(ruleEngineService, never()).startRuleEngineAndUpdateLines();
    }

}
