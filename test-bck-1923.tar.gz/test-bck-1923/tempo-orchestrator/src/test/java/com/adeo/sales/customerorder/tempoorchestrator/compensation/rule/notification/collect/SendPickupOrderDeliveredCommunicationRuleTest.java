package com.adeo.sales.customerorder.tempoorchestrator.compensation.rule.notification.collect;

import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.RuleEngineContext;
import com.adeo.sales.customerorder.tempoorchestrator.compensation.engine.context.order.OrderData;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.customerorder.CustomerOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.CompositionOrderStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.delivery.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.service.OutgoingNotificationService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static com.adeo.sales.customerorder.tempoorchestrator.model.line.LineType.OFFER;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionReasonEnum.CANCELLATION;
import static com.adeo.sales.customerorder.tempoorchestrator.model.line.execution.ExecutionActionReasonEnum.REMAINING_COLLECT;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateALine;
import static com.adeo.sales.customerorder.tempoorchestrator.v3.rule.RuleTestUtils.generateActionExecutionFromLines;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@ExtendWith(MockitoExtension.class)
class SendPickupOrderDeliveredCommunicationRuleTest {

    @Mock
    private OutgoingNotificationService notificationService;

    private SendPickupOrderDeliveredCommunicationRule sendPickupOrderDeliveredCommunicationRule;

    @BeforeEach
    void setUp() {
        sendPickupOrderDeliveredCommunicationRule = new SendPickupOrderDeliveredCommunicationRule(notificationService);
    }

    @Test
    void shouldSendRightExecutionActionIdWithNotification() {
        RuleEngineContext context = new RuleEngineContext();
        final String executionId = UUID.randomUUID().toString();
        final String customerOrderId = UUID.randomUUID().toString();

        LineExecution orderAndCollectLine1 = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);
        orderAndCollectLine1.setCustomerOrderId(customerOrderId);
        orderAndCollectLine1.setExecutionId(executionId);
        orderAndCollectLine1.getDelivery().getCollect().getFlags().raiseFlagIfNot(CollectStatus.COLLECTED);
        LineExecution orderAndCollectLine2 = generateALine(false, null, true, true, true, true, CompositionOrderStatus.VALIDATED, DeliveryType.ORDER_AND_COLLECT, null, OFFER);
        orderAndCollectLine2.setExecutionId(executionId);
        orderAndCollectLine2.setCustomerOrderId(customerOrderId);
        orderAndCollectLine2.getDelivery().getCollect().getFlags().raiseFlagIfNot(CollectStatus.CANCELLED);


        ExecutionAction executionAction = generateActionExecutionFromLines(context.getCustomerOrderId(), List.of(orderAndCollectLine2), ExecutionActionType.SPLIT, REMAINING_COLLECT.name());
        ExecutionAction executionAction1 = generateActionExecutionFromLines(context.getCustomerOrderId(), List.of(orderAndCollectLine1), ExecutionActionType.SPLIT, CANCELLATION.name());
        ExecutionAction executionAction2 = generateActionExecutionFromLines(context.getCustomerOrderId(), List.of(orderAndCollectLine1), ExecutionActionType.DECREASE_QUANTITY, "CUSTOMER_REQUEST");

        executionAction.getFlags().raiseFlag(ExecutionActionStatus.PROCESSING);
        executionAction1.getFlags().raiseFlag(ExecutionActionStatus.CREATED);
            executionAction2.getFlags().raiseFlag(ExecutionActionStatus.COMPLETED);

        context.getOrderData().setExecutionActions(List.of(executionAction, executionAction1, executionAction2));

        context.setOrderData(OrderData.builder()
            .executionActions(List.of(executionAction))
            .existingLineExecutions(List.of(
                orderAndCollectLine1, orderAndCollectLine2
            ))
            .existingCustomerOrder(CustomerOrder.builder().id(customerOrderId).status(CustomerOrderStatus.VALIDATED).build())
            .build());

        Assertions.assertThat(this.sendPickupOrderDeliveredCommunicationRule.when(context)).isTrue();

        Mockito.when(this.notificationService.sendPickupInStoreOrderDeliveredNotificationRelatedToExecutionAction(any(), eq(List.of(orderAndCollectLine1)), eq(executionAction.getRequestId()))).thenReturn(Mono.empty());

        StepVerifier
            .create(this.sendPickupOrderDeliveredCommunicationRule.then(context))
            .verifyComplete();
    }
}
