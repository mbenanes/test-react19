# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.38.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.37.0...tempo-orchestrator-api@1.38.0) (2025-01-21)


### Features

* add feature flipping call ucc cookie ([5f1fd35](https://github.com/adeo/tempo-orchestrator--sources/commit/5f1fd35ca6ce469cfbd1950e7be9dfc819496627))





# [1.37.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.36.6...tempo-orchestrator-api@1.37.0) (2025-01-17)


### Features

* multi doc swagger ([6e7e160](https://github.com/adeo/tempo-orchestrator--sources/commit/6e7e1602e3ddc6313c6b9b725c5f5931fec32069))





## [1.36.6](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.36.5...tempo-orchestrator-api@1.36.6) (2025-01-15)


### Bug Fixes

* add endpoint to call a simulation requirement ([07d5bac](https://github.com/adeo/tempo-orchestrator--sources/commit/07d5bac17bdafd3160a91482af9619268a8454e9))





## [1.36.5](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.36.4...tempo-orchestrator-api@1.36.5) (2025-01-15)


### Bug Fixes

* add endpoint to call a simulation requirement ([b2cc6de](https://github.com/adeo/tempo-orchestrator--sources/commit/b2cc6de1b619491578fdef59534068589e9f2085))





## [1.36.4](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.36.3...tempo-orchestrator-api@1.36.4) (2025-01-15)


### Bug Fixes

* naming column on repository operator_type ([38566c8](https://github.com/adeo/tempo-orchestrator--sources/commit/38566c8b07937e729b61ff2c15da29bb1a85d695))





## [1.36.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.36.2...tempo-orchestrator-api@1.36.3) (2025-01-15)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.36.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.36.1...tempo-orchestrator-api@1.36.2) (2025-01-14)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.36.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.36.0...tempo-orchestrator-api@1.36.1) (2025-01-14)

**Note:** Version bump only for package tempo-orchestrator-api





# [1.36.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.35.5...tempo-orchestrator-api@1.36.0) (2025-01-13)


### Features

* call ucc cookie ([e890d5c](https://github.com/adeo/tempo-orchestrator--sources/commit/e890d5c1d4003a09137666c486224370e2a73b56))





## [1.35.5](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.35.4...tempo-orchestrator-api@1.35.5) (2025-01-09)


### Bug Fixes

* naming on tpp simulate call ([da9bce0](https://github.com/adeo/tempo-orchestrator--sources/commit/da9bce0bc6cfafa4d765d447f3837b83c51586c0))





## [1.35.4](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.35.3...tempo-orchestrator-api@1.35.4) (2025-01-08)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.35.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.35.2...tempo-orchestrator-api@1.35.3) (2025-01-06)


### Bug Fixes

* npe when Flags is empty ([5131701](https://github.com/adeo/tempo-orchestrator--sources/commit/5131701dfb0f808b4cd6fa41ffa6786a20d3ae3f))





## [1.35.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.35.1...tempo-orchestrator-api@1.35.2) (2025-01-06)


### Bug Fixes

* doc swagger ([d9ff179](https://github.com/adeo/tempo-orchestrator--sources/commit/d9ff179752ef512d18c0666f245c5cc9b8f1a86b))





## [1.35.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.32.0...tempo-orchestrator-api@1.35.1) (2025-01-03)

**Note:** Version bump only for package tempo-orchestrator-api





# 1.35.0 (2024-12-26)


### Bug Fixes

* add /operation endpoin in V2 of TOR-API  ([9558b6c](https://github.com/adeo/tempo-orchestrator--sources/commit/9558b6c318517d76725165d2bc147a21a6df27b6))
* add editable quantity line information ([8c3c3f0](https://github.com/adeo/tempo-orchestrator--sources/commit/8c3c3f0331562f11749ae299011a9b5d8664e173))
* add is paid ([e80aae2](https://github.com/adeo/tempo-orchestrator--sources/commit/e80aae27ad464b18f548ea8cdd7d12e6dd77458b))
* add list of executionaction on order info endpoint ([#4491](https://github.com/adeo/tempo-orchestrator--sources/issues/4491)) ([85421ce](https://github.com/adeo/tempo-orchestrator--sources/commit/85421ce3b28f9bc564db314de3ca1b1836d1eece))
* add Split enum ([ec64301](https://github.com/adeo/tempo-orchestrator--sources/commit/ec643011953df7410c381b8e2eb0b3553ef16cf2))
* add transactional ([f548abf](https://github.com/adeo/tempo-orchestrator--sources/commit/f548abfabb3d5e2f863598aa605318716c48e804))
* add value of type enum ImpactedLineStep to avoid deserialization error ([a492137](https://github.com/adeo/tempo-orchestrator--sources/commit/a492137ea69a6ac8ce3d1a4465d32735657c7dee))
* ass PSR system execution by default ([0392c1f](https://github.com/adeo/tempo-orchestrator--sources/commit/0392c1fe3023718dccb5943d948ed087adfeba6b))
* can not treat execution action request if reason is absent ([#4448](https://github.com/adeo/tempo-orchestrator--sources/issues/4448)) ([899a551](https://github.com/adeo/tempo-orchestrator--sources/commit/899a551aa6c2728e090e5225b7092914be7e7a13))
* cancel collect quantity line by collect ([#4607](https://github.com/adeo/tempo-orchestrator--sources/issues/4607)) ([967091b](https://github.com/adeo/tempo-orchestrator--sources/commit/967091b61a52297131721338f33b4456e9ea2596))
* case of delivery type is null ([9b70208](https://github.com/adeo/tempo-orchestrator--sources/commit/9b70208914b975ee4b41bf21948a0d8dda75be0a))
* change check of cancellable or force cancellable ([c571147](https://github.com/adeo/tempo-orchestrator--sources/commit/c57114794019bc152fca70550e7eefd367d4c8f5))
* change serializer ([cefbb6a](https://github.com/adeo/tempo-orchestrator--sources/commit/cefbb6a8e31f3990a34b024b64775616c51bd6a9))
* change to right transaction manager ([d64704c](https://github.com/adeo/tempo-orchestrator--sources/commit/d64704cd0e33a47a230d214619c8ca29d65c045d))
* change to right transaction manager ([#4432](https://github.com/adeo/tempo-orchestrator--sources/issues/4432)) ([09a5c41](https://github.com/adeo/tempo-orchestrator--sources/commit/09a5c41479a0c5f935786a108ce1a5a3a6c7511d))
* collect status ([a86a842](https://github.com/adeo/tempo-orchestrator--sources/commit/a86a842e59517824ba6deba8a1eac7f998217416))
* conf ([1e1a489](https://github.com/adeo/tempo-orchestrator--sources/commit/1e1a4898f2d11377c1c7fb320f21bb9f15199cd6))
* conf ([01508c2](https://github.com/adeo/tempo-orchestrator--sources/commit/01508c237dd07b8df584eec2d8923bb5b7be2097))
* conf kafka ([d9ab298](https://github.com/adeo/tempo-orchestrator--sources/commit/d9ab2986fff4b217736bd7db70de069ec30de09b))
* configure sandbox out ([ba1ba1b](https://github.com/adeo/tempo-orchestrator--sources/commit/ba1ba1ba3be9eaaf57cb63b5107f8856f68aa687))
* correctly managed payment operations deserialization ([#4355](https://github.com/adeo/tempo-orchestrator--sources/issues/4355)) ([b0a9592](https://github.com/adeo/tempo-orchestrator--sources/commit/b0a9592f42d570e58388fd299abb8bb75b6d4f43))
* could decrease quantiy when supply could or not created on supply ([268bee5](https://github.com/adeo/tempo-orchestrator--sources/commit/268bee537d47170e1ee91118d18e068fb63542a4))
* decrease quantity error managment ([a011172](https://github.com/adeo/tempo-orchestrator--sources/commit/a011172882706b216ea219ebd4137c49bfe39103))
* delete empty file ([182cc56](https://github.com/adeo/tempo-orchestrator--sources/commit/182cc56c7e5609aebaa22ad08e6e8c8a124421a6))
* deliveryType NPE ([f158fc6](https://github.com/adeo/tempo-orchestrator--sources/commit/f158fc691bee7c36be22969dc04eb6461170e9a9))
* error on decrease quantity ([e163f05](https://github.com/adeo/tempo-orchestrator--sources/commit/e163f050666b68b0a841c8102fbcfd1cb05d1c7b))
* etidateble quantity value ([63e984a](https://github.com/adeo/tempo-orchestrator--sources/commit/63e984aa242183facbd17f8dce4ea722b18e36ee))
* handle null check quantity  ([c1a4011](https://github.com/adeo/tempo-orchestrator--sources/commit/c1a4011f624cb1aa6832ad5b6a4c930550f116a3))
* handle ownership transfer in api ([cefe920](https://github.com/adeo/tempo-orchestrator--sources/commit/cefe920091a7d5d16b90655d12a7364663b8fc0f))
* map executionPlanStatus for PSR orders  ([668bcd6](https://github.com/adeo/tempo-orchestrator--sources/commit/668bcd6bca3b57c3dd84f474253c0fb60d895ebf))
* map SERVICE ([e8c7ded](https://github.com/adeo/tempo-orchestrator--sources/commit/e8c7dede09b3ba10cb44d81286cd7406e39c1bd2))
* missing swagger conf for V2 ([a69ab9c](https://github.com/adeo/tempo-orchestrator--sources/commit/a69ab9cba28fed0fed9c2f199f351114362e8e48))
* missing swagger config ([4ab536f](https://github.com/adeo/tempo-orchestrator--sources/commit/4ab536f3db8d97ecded18ca4bb3115e978c662d6))
* move action type enum COLLECT_SPLIT to SPLIT ([b1114e8](https://github.com/adeo/tempo-orchestrator--sources/commit/b1114e8e5858f698940928e9c968975f5b5691a7))
* npe on Boolean ([c99f457](https://github.com/adeo/tempo-orchestrator--sources/commit/c99f4573274abebc9308be2d14ef18a9abcce683))
* npe on non existing field on bdd ([#4468](https://github.com/adeo/tempo-orchestrator--sources/issues/4468)) ([eba0063](https://github.com/adeo/tempo-orchestrator--sources/commit/eba00634af91e50c7bc341a947c2171dc752c788))
* npe on order place type ([7362f76](https://github.com/adeo/tempo-orchestrator--sources/commit/7362f76483b35c7ded0180fa5aa77d36c172921b))
* NPE on value of ownershiptransfer ([01fc40f](https://github.com/adeo/tempo-orchestrator--sources/commit/01fc40f7166209a31d3bb25b2e1fda3074a249b3))
* NPE place type ([104ab8d](https://github.com/adeo/tempo-orchestrator--sources/commit/104ab8d8d4832cacc5c54761169e0883df3daaf4))
* null pointer on ExecutionAction last flag ([834afaa](https://github.com/adeo/tempo-orchestrator--sources/commit/834afaa5e90e0165166d66ed456a77135e30778d))
* null pointer on order info endpoint ([e6baeb0](https://github.com/adeo/tempo-orchestrator--sources/commit/e6baeb01cf6f4a3f4fa1d0ca07da27b622c5924e))
* null pointer on order info endpoint ([a42ceac](https://github.com/adeo/tempo-orchestrator--sources/commit/a42ceac6915af67e65c5fb376fc9c7a11deefb38))
* query created at ([e88a722](https://github.com/adeo/tempo-orchestrator--sources/commit/e88a7225e5e1b6289e99e46ba479099192a27c97))
* query executionAction ([b261681](https://github.com/adeo/tempo-orchestrator--sources/commit/b261681c74546ffe8fa38c9346b1b561d18dd0d7))
* refacto get Order info ([#4393](https://github.com/adeo/tempo-orchestrator--sources/issues/4393)) ([f1ecaf0](https://github.com/adeo/tempo-orchestrator--sources/commit/f1ecaf004338e27bbc4000b0c1039180763ddbbc))
* remove for update ([9ac094b](https://github.com/adeo/tempo-orchestrator--sources/commit/9ac094bc37ea33b672a8f685e3a9d347cab631fe))
* remove useless conf ([25448fb](https://github.com/adeo/tempo-orchestrator--sources/commit/25448fb64ea1955e9208028d06a7317c81a30434))
* retro compatibility of executionId field on ImapctedExecution class ([#4623](https://github.com/adeo/tempo-orchestrator--sources/issues/4623)) ([697fe8b](https://github.com/adeo/tempo-orchestrator--sources/commit/697fe8bfd8a41412e4d628d735559c902106de3a))
* return available action correctly ([#4497](https://github.com/adeo/tempo-orchestrator--sources/issues/4497)) ([defeb21](https://github.com/adeo/tempo-orchestrator--sources/commit/defeb21cff934e5549746e7ba04923a7b6c1bda5))
* return current step ([5767a06](https://github.com/adeo/tempo-orchestrator--sources/commit/5767a0667bb1f2606e0f4027e32f16a7c19c499d))
* return customer order line in v2 ([#4579](https://github.com/adeo/tempo-orchestrator--sources/issues/4579)) ([b712615](https://github.com/adeo/tempo-orchestrator--sources/commit/b7126158c3af822bcbc2023cdf49ef87b3bc3cc3))
* revert managed subjects ([ee99ae5](https://github.com/adeo/tempo-orchestrator--sources/commit/ee99ae504f0ae7c4c9171aa738cbcad4e5f27eaf))
* should return right value on editable quantity ([3cf5b7b](https://github.com/adeo/tempo-orchestrator--sources/commit/3cf5b7b4d3ffae98505ef072dd06e4dace9cc2ce))
* should return right value on editable quantity ([8ed38fe](https://github.com/adeo/tempo-orchestrator--sources/commit/8ed38fe5ddd2a52029c08e0d293ddb8df5fb2aef))
* sql query initial quantity ([2ab2f56](https://github.com/adeo/tempo-orchestrator--sources/commit/2ab2f5648dbdaf1930738b324e875ab77167a990))
* sslMode multi datasource ([f57f2a5](https://github.com/adeo/tempo-orchestrator--sources/commit/f57f2a5b4cc79f184559c4ba68242376b89b79f9))
* stop process when at least one call api failed ([9b321cb](https://github.com/adeo/tempo-orchestrator--sources/commit/9b321cb403c69b14774ffacc5fe853802490eecf))
* swagger format ([405714b](https://github.com/adeo/tempo-orchestrator--sources/commit/405714b1beefcfda439deb0d9d75beea6f6fdf33))
* take into account the operation status updating ([#4360](https://github.com/adeo/tempo-orchestrator--sources/issues/4360)) ([0d7273f](https://github.com/adeo/tempo-orchestrator--sources/commit/0d7273f05a75b62ee7315fc2b40b4800b341ed9e))
* torApi V1 retrocompatibility  ([2a902f1](https://github.com/adeo/tempo-orchestrator--sources/commit/2a902f1fd6765cddaa5c64828c955187969e0661))
* typo ([fc0cc67](https://github.com/adeo/tempo-orchestrator--sources/commit/fc0cc676d997783d3af478629b5f47dd6506c8bd))
* unit test ([0f65421](https://github.com/adeo/tempo-orchestrator--sources/commit/0f65421a413c4902d827300b91ca1aec1fa74536))
* update application.yml ([830de72](https://github.com/adeo/tempo-orchestrator--sources/commit/830de722b0a43c75e36b844b483b0bda90f347fc))
* update swagger.yml ([a086442](https://github.com/adeo/tempo-orchestrator--sources/commit/a0864427128fa1c2f1a667b34ea1f6ed2cea6bbb))
* use read or write datasource not just read by default ([707b768](https://github.com/adeo/tempo-orchestrator--sources/commit/707b76843dd412157c6b49182d96be4b0e8eb639))
* use read or write datasource not just read by default ([a3e3934](https://github.com/adeo/tempo-orchestrator--sources/commit/a3e3934d977ce0d7a181d4c770c0fd64b0eaebe8))
* wording exposed field ([a51ab76](https://github.com/adeo/tempo-orchestrator--sources/commit/a51ab76f8b141fd0ae9f9fd0ca951915d43ba7b3))


### Features

* add COMPLETED status on execution plan ([#4583](https://github.com/adeo/tempo-orchestrator--sources/issues/4583)) ([2ad33e4](https://github.com/adeo/tempo-orchestrator--sources/commit/2ad33e48eb9daed51bf406edc2f964d5bb6ac6c9))
* add in_store communication and autoCancellation  ([f071398](https://github.com/adeo/tempo-orchestrator--sources/commit/f0713985c9d865efb53f7b51a0ac591c7364b56e))
* add is paid information on get order info ([185bc31](https://github.com/adeo/tempo-orchestrator--sources/commit/185bc31c48969ad974be1e251a010b2a4e165206))
* add is paid information on get order info ([d64aa4b](https://github.com/adeo/tempo-orchestrator--sources/commit/d64aa4b50e77024eda044dee66197382134a5440))
* add is paid information on get order info ([c698590](https://github.com/adeo/tempo-orchestrator--sources/commit/c69859000a7d4df554de1c7871867775eb36b9cc))
* add is paid information on get order info ([#4392](https://github.com/adeo/tempo-orchestrator--sources/issues/4392)) ([e8b4587](https://github.com/adeo/tempo-orchestrator--sources/commit/e8b458754fbeb3434b19bcaa33dad16214cab36a))
* add quantity api ([3df12b6](https://github.com/adeo/tempo-orchestrator--sources/commit/3df12b62dac857181b1db9f2cd1a2ba0e75fd9a5))
* add rejected refund behaviour ([#4602](https://github.com/adeo/tempo-orchestrator--sources/issues/4602)) ([373c04d](https://github.com/adeo/tempo-orchestrator--sources/commit/373c04d5a5ced2bf72574979421aeaf3e0b3ada8))
* add rest proxy between tor-api and tor ([#4407](https://github.com/adeo/tempo-orchestrator--sources/issues/4407)) ([fccbb00](https://github.com/adeo/tempo-orchestrator--sources/commit/fccbb00ab68f75436fc3087aaad25b2ad4cdc6e5))
* add serviceLevelId on getOrderInfo endpoint ([9031008](https://github.com/adeo/tempo-orchestrator--sources/commit/9031008be398b3b1643834330dbe5b65d3c0b4b2))
* add status of last step execution for executionAction ([#4540](https://github.com/adeo/tempo-orchestrator--sources/issues/4540)) ([6fc89f9](https://github.com/adeo/tempo-orchestrator--sources/commit/6fc89f91825361ec019eb090202f5692fd221ea6))
* add tag to facilitate search analyse ([#4373](https://github.com/adeo/tempo-orchestrator--sources/issues/4373)) ([9af3492](https://github.com/adeo/tempo-orchestrator--sources/commit/9af3492138eec7946fb83504063c01fcb19e4b9d))
* add transactional ([8816f97](https://github.com/adeo/tempo-orchestrator--sources/commit/8816f978a255e84270170bd1d4302cda48e315a8))
* api add field for tofu on tpp behaviour ([#4352](https://github.com/adeo/tempo-orchestrator--sources/issues/4352)) ([8772f92](https://github.com/adeo/tempo-orchestrator--sources/commit/8772f9224be13161dea22c3a05106acd2f42ef1a))
* call check requirement tpp when needed  ([f5acd1f](https://github.com/adeo/tempo-orchestrator--sources/commit/f5acd1f147632b8acae73c64b77e7dd7a3ff1c69))
* call tco to retrieve multibanco payment data ([#4405](https://github.com/adeo/tempo-orchestrator--sources/issues/4405)) ([42d8bdd](https://github.com/adeo/tempo-orchestrator--sources/commit/42d8bdde99d0087910d954a0c861b3c1b1d62cab))
* change the default docker repo to adeo  ([ee1c1d2](https://github.com/adeo/tempo-orchestrator--sources/commit/ee1c1d26f12ee1a6703804cc754ff0fdf32e89d8))
* could not cancel store self service before payment when service is present on order ([#4698](https://github.com/adeo/tempo-orchestrator--sources/issues/4698)) ([69837f6](https://github.com/adeo/tempo-orchestrator--sources/commit/69837f6f323aaa7f28622dd8b7a12b70e31321ac))
* create udpate execution endpoint  ([e2c90a5](https://github.com/adeo/tempo-orchestrator--sources/commit/e2c90a51e44d7b61373cdff0172e66f3ed2085c2))
* decrease quantity workflow  ([f025b22](https://github.com/adeo/tempo-orchestrator--sources/commit/f025b221307f96f6b8d7956965db2974796e9031))
* disply the right appointment date of the current collect coupled with services ([#4667](https://github.com/adeo/tempo-orchestrator--sources/issues/4667)) ([719de36](https://github.com/adeo/tempo-orchestrator--sources/commit/719de3684a2c327416e0a5122779048d18b65589))
* expose api V2 and make some changes  ([8c4f157](https://github.com/adeo/tempo-orchestrator--sources/commit/8c4f157f2d8c6333526c329c3e1ccbbb6a91e036))
* expose execution actions on the getOrder api ([#4346](https://github.com/adeo/tempo-orchestrator--sources/issues/4346)) ([de8cab9](https://github.com/adeo/tempo-orchestrator--sources/commit/de8cab901cfc3d7da30351f9e801ac423a18833e))
* expose operations ([defebcc](https://github.com/adeo/tempo-orchestrator--sources/commit/defebcc283d2d6c184e1875ac92692d0af2e4df2))
* expose operations ([acf0b16](https://github.com/adeo/tempo-orchestrator--sources/commit/acf0b1618e4d4a7e8faa29a0dcc986048ba41c94))
* expose operations ([ee82eda](https://github.com/adeo/tempo-orchestrator--sources/commit/ee82edafe3329702662dcf7d55b53d075f594a90))
* expose operations ([9c1d319](https://github.com/adeo/tempo-orchestrator--sources/commit/9c1d3199a68a615e9619b61bd340dd0ed6a4c5ac))
* expose operations ([b6536c4](https://github.com/adeo/tempo-orchestrator--sources/commit/b6536c444254e06608880255ea419101be56a49c))
* generate swagger and use string types  ([3ca7ec4](https://github.com/adeo/tempo-orchestrator--sources/commit/3ca7ec43f4f23df198737c46c3e6198a3efa2525))
* init tempo-orchestrator-api  ([70e8bde](https://github.com/adeo/tempo-orchestrator--sources/commit/70e8bde787c054047439adf1a63b6ba936a6c157))
* map force editable quantity from force cancelable ([f3c23cd](https://github.com/adeo/tempo-orchestrator--sources/commit/f3c23cde8391ecd0f60df3aa449e7d6609292f8f))
* return tpp operations by default ([3f1465e](https://github.com/adeo/tempo-orchestrator--sources/commit/3f1465e0498f4a39870044a36bcb49f2cc91e35f))
* save and expose demat code and payment in store ([2adafe7](https://github.com/adeo/tempo-orchestrator--sources/commit/2adafe746814a05e5d01524fcd4dad712f0871d1))
* set line cancellable to false if pending decrease quantity ([b1fc93b](https://github.com/adeo/tempo-orchestrator--sources/commit/b1fc93b28b93576264d38f3984160b0b22970415))
* set quantity to 0 if canceled ([de87f8e](https://github.com/adeo/tempo-orchestrator--sources/commit/de87f8eeede35e889562f4ee9efe61fda1d24070))
* update operation api contract with the addition of payment external data ([#4365](https://github.com/adeo/tempo-orchestrator--sources/issues/4365)) ([2480f40](https://github.com/adeo/tempo-orchestrator--sources/commit/2480f406222df84f71c10dde9abc13eb08478ebd))





## [1.30.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.30.1...tempo-orchestrator-api@1.30.2) (2024-12-10)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.30.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.30.0...tempo-orchestrator-api@1.30.1) (2024-12-06)


### Bug Fixes

* collect status ([adea444](https://github.com/adeo/tempo-orchestrator--sources/commit/adea444e56101cd0638a4e1e66a41dd1c5afc0c4))





# [1.30.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.29.3...tempo-orchestrator-api@1.30.0) (2024-11-26)


### Features

* could not cancel store self service before payment when service is present on order ([#4698](https://github.com/adeo/tempo-orchestrator--sources/issues/4698)) ([ffb5c99](https://github.com/adeo/tempo-orchestrator--sources/commit/ffb5c99013f29c6d0f5a2a9ff6e1a1f24e404270))





## [1.29.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.29.2...tempo-orchestrator-api@1.29.3) (2024-11-20)


### Bug Fixes

* map executionPlanStatus for PSR orders  ([fddfa58](https://github.com/adeo/tempo-orchestrator--sources/commit/fddfa5825ba857c5a2aeefd1503a391b6ebe9a6c))





## [1.29.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.29.1...tempo-orchestrator-api@1.29.2) (2024-11-15)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.29.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.29.0...tempo-orchestrator-api@1.29.1) (2024-11-08)


### Bug Fixes

* deliveryType NPE ([dabbe63](https://github.com/adeo/tempo-orchestrator--sources/commit/dabbe633d8250800b56895bb0ec4634fdcc134ad))





# [1.29.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.28.1...tempo-orchestrator-api@1.29.0) (2024-11-08)


### Features

* disply the right appointment date of the current collect coupled with services ([#4667](https://github.com/adeo/tempo-orchestrator--sources/issues/4667)) ([32b78d2](https://github.com/adeo/tempo-orchestrator--sources/commit/32b78d24c51fccb93caf401b0465ded8e708784d))





## [1.28.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.28.0...tempo-orchestrator-api@1.28.1) (2024-11-04)


### Bug Fixes

* change serializer ([c3407ec](https://github.com/adeo/tempo-orchestrator--sources/commit/c3407ecb4239238969ac1acf97df0f6a240520e7))





# [1.28.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.27.0...tempo-orchestrator-api@1.28.0) (2024-10-31)


### Features

* generate swagger and use string types  ([e1987dd](https://github.com/adeo/tempo-orchestrator--sources/commit/e1987dd2c06d78dcb4cdb5cbd28a3624fa1e66dd))





# [1.27.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.26.7...tempo-orchestrator-api@1.27.0) (2024-10-21)


### Features

* change the default docker repo to adeo  ([9b6d05e](https://github.com/adeo/tempo-orchestrator--sources/commit/9b6d05e2bb481da4b3f7a17f70efe3c003460c2b))





## [1.26.7](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.26.6...tempo-orchestrator-api@1.26.7) (2024-10-18)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.26.6](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.26.5...tempo-orchestrator-api@1.26.6) (2024-10-10)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.26.5](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.26.4...tempo-orchestrator-api@1.26.5) (2024-10-08)


### Bug Fixes

* retro compatibility of executionId field on ImapctedExecution class ([#4623](https://github.com/adeo/tempo-orchestrator--sources/issues/4623)) ([7317faa](https://github.com/adeo/tempo-orchestrator--sources/commit/7317faac209b6ffc37db55866678e270b5a0226b))





## [1.26.4](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.26.3...tempo-orchestrator-api@1.26.4) (2024-10-08)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.26.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.26.2...tempo-orchestrator-api@1.26.3) (2024-10-01)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.26.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.26.1...tempo-orchestrator-api@1.26.2) (2024-10-01)


### Bug Fixes

* cancel collect quantity line by collect ([#4607](https://github.com/adeo/tempo-orchestrator--sources/issues/4607)) ([977fbc0](https://github.com/adeo/tempo-orchestrator--sources/commit/977fbc0c6bb2653b6ff4ba6fa159b3c9d622b788))





## [1.26.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.26.0...tempo-orchestrator-api@1.26.1) (2024-10-01)


### Bug Fixes

* map SERVICE ([76bbf59](https://github.com/adeo/tempo-orchestrator--sources/commit/76bbf59ad3eae75210fa47cb7df4aa13ddaefaca))





# [1.26.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.25.3...tempo-orchestrator-api@1.26.0) (2024-09-30)


### Features

* add rejected refund behaviour ([#4602](https://github.com/adeo/tempo-orchestrator--sources/issues/4602)) ([9687fc5](https://github.com/adeo/tempo-orchestrator--sources/commit/9687fc5c05dc6898f29c0df4026c108fa3d79581))





## [1.25.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.25.2...tempo-orchestrator-api@1.25.3) (2024-09-26)


### Bug Fixes

* return current step ([49498d1](https://github.com/adeo/tempo-orchestrator--sources/commit/49498d119bd087ef57ac2e450b318c9c8070cdca))





## [1.25.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.25.1...tempo-orchestrator-api@1.25.2) (2024-09-25)


### Bug Fixes

* NPE place type ([567d9ed](https://github.com/adeo/tempo-orchestrator--sources/commit/567d9eda5b64c22d9b28e6ec25cbe2d2c643b27a))





## [1.25.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.25.0...tempo-orchestrator-api@1.25.1) (2024-09-24)


### Bug Fixes

* change check of cancellable or force cancellable ([4e3a9bc](https://github.com/adeo/tempo-orchestrator--sources/commit/4e3a9bc62534479b5a8a8a3fa949aab782a89fa4))
* handle null check quantity  ([bce4050](https://github.com/adeo/tempo-orchestrator--sources/commit/bce4050106bb7de58c45b11108210bd91ae02334))





# [1.25.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.24.1...tempo-orchestrator-api@1.25.0) (2024-09-24)


### Features

* set line cancellable to false if pending decrease quantity ([92b31b8](https://github.com/adeo/tempo-orchestrator--sources/commit/92b31b8c740b0ac74464f374df85278519f8ae4e))





## [1.24.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.24.0...tempo-orchestrator-api@1.24.1) (2024-09-24)

**Note:** Version bump only for package tempo-orchestrator-api





# [1.24.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.23.0...tempo-orchestrator-api@1.24.0) (2024-09-23)


### Features

* map force editable quantity from force cancelable ([27d1f1e](https://github.com/adeo/tempo-orchestrator--sources/commit/27d1f1e2ffff545f6913d9a406047ea9ad081c3f))





# [1.23.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.22.2...tempo-orchestrator-api@1.23.0) (2024-09-19)


### Features

* set quantity to 0 if canceled ([51cf5d8](https://github.com/adeo/tempo-orchestrator--sources/commit/51cf5d80a01b95fa58f883a1efab18f7ec2dc79c))





## [1.22.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.22.1...tempo-orchestrator-api@1.22.2) (2024-09-17)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.22.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.22.0...tempo-orchestrator-api@1.22.1) (2024-09-17)


### Bug Fixes

* add transactional ([1c067d6](https://github.com/adeo/tempo-orchestrator--sources/commit/1c067d651996b537b3b7bca5c801e236e673be6f))





# [1.22.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.21.0...tempo-orchestrator-api@1.22.0) (2024-09-17)


### Features

* add transactional ([55c0def](https://github.com/adeo/tempo-orchestrator--sources/commit/55c0defa9b89c9fb43d91def82b1c17011919a88))





# [1.21.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.20.1...tempo-orchestrator-api@1.21.0) (2024-09-17)


### Features

* add quantity api ([0dda882](https://github.com/adeo/tempo-orchestrator--sources/commit/0dda8828307f2e17135809d755d22da74bc6313c))





## [1.20.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.20.0...tempo-orchestrator-api@1.20.1) (2024-09-12)


### Bug Fixes

* case of delivery type is null ([849ddb9](https://github.com/adeo/tempo-orchestrator--sources/commit/849ddb9a41d6c7a56a5b37f6335614e95a89ed1a))





# [1.20.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.19.9...tempo-orchestrator-api@1.20.0) (2024-09-11)


### Features

* add COMPLETED status on execution plan ([#4583](https://github.com/adeo/tempo-orchestrator--sources/issues/4583)) ([4a71b76](https://github.com/adeo/tempo-orchestrator--sources/commit/4a71b76ef607ee2bdb5114659eebc21b18d56421))





## [1.19.9](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.19.8...tempo-orchestrator-api@1.19.9) (2024-09-10)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.19.8](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.19.7...tempo-orchestrator-api@1.19.8) (2024-09-10)


### Bug Fixes

* NPE on value of ownershiptransfer ([6c5e352](https://github.com/adeo/tempo-orchestrator--sources/commit/6c5e3524564d67577fe4fc692931e7983896710c))





## [1.19.7](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.19.6...tempo-orchestrator-api@1.19.7) (2024-09-10)


### Bug Fixes

* return customer order line in v2 ([#4579](https://github.com/adeo/tempo-orchestrator--sources/issues/4579)) ([8ddb4fa](https://github.com/adeo/tempo-orchestrator--sources/commit/8ddb4fa23964e5807e69a7b465b8aa091c27110c))





## [1.19.6](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.19.5...tempo-orchestrator-api@1.19.6) (2024-09-09)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.19.5](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.19.4...tempo-orchestrator-api@1.19.5) (2024-09-02)


### Bug Fixes

* should return right value on editable quantity ([25ddfbb](https://github.com/adeo/tempo-orchestrator--sources/commit/25ddfbb1d42ac58dac1f0eee41cbc88b02494c51))





## [1.19.4](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.19.3...tempo-orchestrator-api@1.19.4) (2024-08-30)


### Bug Fixes

* should return right value on editable quantity ([3ae4520](https://github.com/adeo/tempo-orchestrator--sources/commit/3ae45202938f107a8568e82c37c79dbc26a490b7))





## [1.19.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.19.2...tempo-orchestrator-api@1.19.3) (2024-08-29)


### Bug Fixes

* add value of type enum ImpactedLineStep to avoid deserialization error ([2e61299](https://github.com/adeo/tempo-orchestrator--sources/commit/2e612995eda52c93800e5df8a2c1070808e02941))





## [1.19.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.19.1...tempo-orchestrator-api@1.19.2) (2024-08-12)


### Bug Fixes

* null pointer on order info endpoint ([8e8005d](https://github.com/adeo/tempo-orchestrator--sources/commit/8e8005d1229db32640e6083bdf30c0bee3cd79fb))





## [1.19.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.19.0...tempo-orchestrator-api@1.19.1) (2024-08-12)


### Bug Fixes

* null pointer on order info endpoint ([1705f2a](https://github.com/adeo/tempo-orchestrator--sources/commit/1705f2ab0d4cf22046c61becdd886c4b2ba93fd9))





# [1.19.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.18.1...tempo-orchestrator-api@1.19.0) (2024-08-09)


### Features

* add status of last step execution for executionAction ([#4540](https://github.com/adeo/tempo-orchestrator--sources/issues/4540)) ([6d66157](https://github.com/adeo/tempo-orchestrator--sources/commit/6d661579be11f26f1bd8786c3640ed91d7500858))





## [1.18.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.18.0...tempo-orchestrator-api@1.18.1) (2024-08-08)


### Bug Fixes

* unit test ([5a37a40](https://github.com/adeo/tempo-orchestrator--sources/commit/5a37a40750fa79dd49f4d266812171623552c1ef))





# [1.18.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.17.10...tempo-orchestrator-api@1.18.0) (2024-08-01)


### Features

* return tpp operations by default ([384b406](https://github.com/adeo/tempo-orchestrator--sources/commit/384b4060c8bab94a5b5e27ca7a196ff647bae9c1))





## [1.17.10](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.17.9...tempo-orchestrator-api@1.17.10) (2024-08-01)


### Bug Fixes

* handle ownership transfer in api ([e4e6a58](https://github.com/adeo/tempo-orchestrator--sources/commit/e4e6a581f4f27e8a23fe1ddbf69a26e9cc151125))





## [1.17.9](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.17.8...tempo-orchestrator-api@1.17.9) (2024-07-30)


### Bug Fixes

* return available action correctly ([#4497](https://github.com/adeo/tempo-orchestrator--sources/issues/4497)) ([7939877](https://github.com/adeo/tempo-orchestrator--sources/commit/793987754a6e7414c1a8fa7607f39cde7ec52207))





## [1.17.8](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.17.7...tempo-orchestrator-api@1.17.8) (2024-07-16)


### Bug Fixes

* stop process when at least one call api failed ([98831e8](https://github.com/adeo/tempo-orchestrator--sources/commit/98831e8f9fd474730c268f4264eb56aa43ba3faa))





## [1.17.7](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.17.6...tempo-orchestrator-api@1.17.7) (2024-07-12)


### Bug Fixes

* npe on Boolean ([decba08](https://github.com/adeo/tempo-orchestrator--sources/commit/decba0847d7df5ac513ff2597823e4576e55fac2))





## [1.17.6](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.17.5...tempo-orchestrator-api@1.17.6) (2024-07-11)


### Bug Fixes

* could decrease quantiy when supply could or not created on supply ([a02e7b2](https://github.com/adeo/tempo-orchestrator--sources/commit/a02e7b26a2eb83c7cb35c7f2404e3420bec045e0))





## [1.17.5](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.17.4...tempo-orchestrator-api@1.17.5) (2024-07-11)


### Bug Fixes

* etidateble quantity value ([0bf36e0](https://github.com/adeo/tempo-orchestrator--sources/commit/0bf36e01ec9e32307f6c3de866b714ceef89c6aa))





## [1.17.4](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.17.3...tempo-orchestrator-api@1.17.4) (2024-07-08)


### Bug Fixes

* add /operation endpoin in V2 of TOR-API  ([d560372](https://github.com/adeo/tempo-orchestrator--sources/commit/d5603721322649f96351fdc0cb254f71aba3d315))





## [1.17.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.17.2...tempo-orchestrator-api@1.17.3) (2024-07-05)


### Bug Fixes

* add editable quantity line information ([50e8743](https://github.com/adeo/tempo-orchestrator--sources/commit/50e87431a28231a31a89c949c41db85a1c0f732c))





## [1.17.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.17.1...tempo-orchestrator-api@1.17.2) (2024-07-04)


### Bug Fixes

* add list of executionaction on order info endpoint ([#4491](https://github.com/adeo/tempo-orchestrator--sources/issues/4491)) ([82e08b1](https://github.com/adeo/tempo-orchestrator--sources/commit/82e08b13bc4825c592d9d8020a68ee5754a7dbe6))





## [1.17.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.17.0...tempo-orchestrator-api@1.17.1) (2024-07-02)


### Bug Fixes

* wording exposed field ([1ce6bb5](https://github.com/adeo/tempo-orchestrator--sources/commit/1ce6bb55d785ee325a74c7077a98942f91152e27))





# [1.17.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.16.5...tempo-orchestrator-api@1.17.0) (2024-07-02)


### Features

* add serviceLevelId on getOrderInfo endpoint ([556f225](https://github.com/adeo/tempo-orchestrator--sources/commit/556f2254074defe3b1658e7a363bf568b466f722))





## [1.16.5](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.16.4...tempo-orchestrator-api@1.16.5) (2024-07-02)


### Bug Fixes

* null pointer on ExecutionAction last flag ([2905367](https://github.com/adeo/tempo-orchestrator--sources/commit/29053677b69e4fbf6e61cf79ddc641773f3f22be))





## [1.16.4](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.16.3...tempo-orchestrator-api@1.16.4) (2024-06-26)


### Bug Fixes

* add Split enum ([4dc10b4](https://github.com/adeo/tempo-orchestrator--sources/commit/4dc10b4cf87946924b6fdf72c1561483b6bf6954))





## [1.16.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.16.2...tempo-orchestrator-api@1.16.3) (2024-06-26)


### Bug Fixes

* swagger format ([d589f2d](https://github.com/adeo/tempo-orchestrator--sources/commit/d589f2d32e2f28ec86b90c3a7b71749cdc035e12))





## [1.16.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.16.1...tempo-orchestrator-api@1.16.2) (2024-06-26)


### Bug Fixes

* move action type enum COLLECT_SPLIT to SPLIT ([4d21bf1](https://github.com/adeo/tempo-orchestrator--sources/commit/4d21bf16fe2821e002bb8c22316da2d5a713d4b7))





## [1.16.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.16.0...tempo-orchestrator-api@1.16.1) (2024-06-26)


### Bug Fixes

* missing swagger conf for V2 ([37e8b3a](https://github.com/adeo/tempo-orchestrator--sources/commit/37e8b3a280fc8cc8da3904210476335ff91d9ff6))





# [1.16.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.17...tempo-orchestrator-api@1.16.0) (2024-06-26)


### Features

* expose api V2 and make some changes  ([aa77a62](https://github.com/adeo/tempo-orchestrator--sources/commit/aa77a62ceafec79943cd6d9928dbf72f943c8995))





## [1.15.17](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.16...tempo-orchestrator-api@1.15.17) (2024-06-21)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.15.16](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.15...tempo-orchestrator-api@1.15.16) (2024-06-21)


### Bug Fixes

* torApi V1 retrocompatibility  ([0b109bf](https://github.com/adeo/tempo-orchestrator--sources/commit/0b109bff05ecdb66a5b791e3fc74f577dc4cb7b8))





## [1.15.15](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.14...tempo-orchestrator-api@1.15.15) (2024-06-17)


### Bug Fixes

* npe on non existing field on bdd ([#4468](https://github.com/adeo/tempo-orchestrator--sources/issues/4468)) ([1498168](https://github.com/adeo/tempo-orchestrator--sources/commit/14981689b566efc6de38b65c441e162e75761efd))





## [1.15.14](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.13...tempo-orchestrator-api@1.15.14) (2024-06-14)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.15.13](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.12...tempo-orchestrator-api@1.15.13) (2024-05-29)


### Bug Fixes

* can not treat execution action request if reason is absent ([#4448](https://github.com/adeo/tempo-orchestrator--sources/issues/4448)) ([84b00c3](https://github.com/adeo/tempo-orchestrator--sources/commit/84b00c35dfa445855bb11eef4e547168c3d1d7cb))





## [1.15.12](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.11...tempo-orchestrator-api@1.15.12) (2024-05-27)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.15.11](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.10...tempo-orchestrator-api@1.15.11) (2024-04-30)


### Bug Fixes

* use read or write datasource not just read by default ([e9dc096](https://github.com/adeo/tempo-orchestrator--sources/commit/e9dc0965b1840cf029903b84dbcba9601eb5928a))
* use read or write datasource not just read by default ([763f610](https://github.com/adeo/tempo-orchestrator--sources/commit/763f61033427dc672bd9f862dc1522aefdee467b))





## [1.15.10](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.9...tempo-orchestrator-api@1.15.10) (2024-04-29)


### Bug Fixes

* change to right transaction manager ([419b664](https://github.com/adeo/tempo-orchestrator--sources/commit/419b6642c01cb851d32bd80c95ffa1b694efeaf6))





## [1.15.9](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.8...tempo-orchestrator-api@1.15.9) (2024-04-26)


### Bug Fixes

* change to right transaction manager ([#4432](https://github.com/adeo/tempo-orchestrator--sources/issues/4432)) ([052fd87](https://github.com/adeo/tempo-orchestrator--sources/commit/052fd87328b25e217fba98088d5c1cdef5643af4))





## [1.15.8](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.7...tempo-orchestrator-api@1.15.8) (2024-04-24)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.15.7](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.6...tempo-orchestrator-api@1.15.7) (2024-04-18)


### Bug Fixes

* npe on order place type ([7796a76](https://github.com/adeo/tempo-orchestrator--sources/commit/7796a76e8f2aa2535d45cfa22a2bcfbac4313333))





## [1.15.6](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.5...tempo-orchestrator-api@1.15.6) (2024-04-18)


### Bug Fixes

* ass PSR system execution by default ([37237eb](https://github.com/adeo/tempo-orchestrator--sources/commit/37237eba327db61efe7e4b95f3207d4e99af7f49))





## [1.15.5](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.4...tempo-orchestrator-api@1.15.5) (2024-04-17)


### Bug Fixes

* remove for update ([4d27f0a](https://github.com/adeo/tempo-orchestrator--sources/commit/4d27f0ae3be9318f4af84b200d4d0bf21594cb90))





## [1.15.4](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.3...tempo-orchestrator-api@1.15.4) (2024-04-16)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.15.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.2...tempo-orchestrator-api@1.15.3) (2024-04-16)


### Bug Fixes

* sslMode multi datasource ([514eef1](https://github.com/adeo/tempo-orchestrator--sources/commit/514eef1fdd2f3874349b0a7c1d10d73e20df8d5e))





## [1.15.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.1...tempo-orchestrator-api@1.15.2) (2024-04-16)

**Note:** Version bump only for package tempo-orchestrator-api





## [1.15.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.15.0...tempo-orchestrator-api@1.15.1) (2024-04-16)


### Bug Fixes

* delete empty file ([f246fca](https://github.com/adeo/tempo-orchestrator--sources/commit/f246fca89c7f6453b83cc73dd5464fb543985065))





# [1.15.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.14.1...tempo-orchestrator-api@1.15.0) (2024-04-15)


### Features

* add rest proxy between tor-api and tor ([#4407](https://github.com/adeo/tempo-orchestrator--sources/issues/4407)) ([5616cac](https://github.com/adeo/tempo-orchestrator--sources/commit/5616cacb92ac73db34f13b5f1d9976f5bb77ebba))





## [1.14.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.14.0...tempo-orchestrator-api@1.14.1) (2024-04-15)

**Note:** Version bump only for package tempo-orchestrator-api





# [1.14.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.13.8...tempo-orchestrator-api@1.14.0) (2024-04-15)


### Features

* call tco to retrieve multibanco payment data ([#4405](https://github.com/adeo/tempo-orchestrator--sources/issues/4405)) ([1bb31a7](https://github.com/adeo/tempo-orchestrator--sources/commit/1bb31a779d7509a5754629376210a88b71a150d4))





## [1.13.8](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.13.7...tempo-orchestrator-api@1.13.8) (2024-04-09)


### Bug Fixes

* decrease quantity error managment ([ccf54a0](https://github.com/adeo/tempo-orchestrator--sources/commit/ccf54a09e7ebcb61527ed36f2a8474ab12e6cfb8))





## [1.13.7](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.13.6...tempo-orchestrator-api@1.13.7) (2024-04-09)


### Bug Fixes

* error on decrease quantity ([abc0bc4](https://github.com/adeo/tempo-orchestrator--sources/commit/abc0bc47665eb8556dd7e86126c30249d77d271e))





## [1.13.6](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.13.5...tempo-orchestrator-api@1.13.6) (2024-04-09)


### Bug Fixes

* query created at ([bbe46d3](https://github.com/adeo/tempo-orchestrator--sources/commit/bbe46d3bb41087541d974b637939cd4be6c3dedd))





## [1.13.5](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.13.4...tempo-orchestrator-api@1.13.5) (2024-04-09)


### Bug Fixes

* query executionAction ([f269263](https://github.com/adeo/tempo-orchestrator--sources/commit/f269263595daa7a57c7c3ff7a3d750bbd680dbc8))





## [1.13.4](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.13.3...tempo-orchestrator-api@1.13.4) (2024-04-04)


### Bug Fixes

* refacto get Order info ([#4393](https://github.com/adeo/tempo-orchestrator--sources/issues/4393)) ([104cd27](https://github.com/adeo/tempo-orchestrator--sources/commit/104cd278706ccbc8aec63e82cd186e3194526d11))





## [1.13.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.13.2...tempo-orchestrator-api@1.13.3) (2024-04-03)


### Bug Fixes

* revert managed subjects ([6831733](https://github.com/adeo/tempo-orchestrator--sources/commit/68317338c67d1b6451fe39638583f73a10061773))





## [1.13.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.13.1...tempo-orchestrator-api@1.13.2) (2024-04-03)


### Bug Fixes

* configure sandbox out ([52a8121](https://github.com/adeo/tempo-orchestrator--sources/commit/52a812176a8eb03b73c8d79c7ab3cb4bbd601dd5))





## [1.13.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.13.0...tempo-orchestrator-api@1.13.1) (2024-04-03)


### Bug Fixes

* sql query initial quantity ([40e52ca](https://github.com/adeo/tempo-orchestrator--sources/commit/40e52ca2bf6fbdc22e37f1fe4c6ddc42ca2f1f10))





# [1.13.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.12.1...tempo-orchestrator-api@1.13.0) (2024-04-03)


### Features

* call check requirement tpp when needed  ([13cb94b](https://github.com/adeo/tempo-orchestrator--sources/commit/13cb94bc0613918e15f345adb830ac02b4030c0b))





## [1.12.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.12.0...tempo-orchestrator-api@1.12.1) (2024-04-02)


### Bug Fixes

* add is paid ([3784883](https://github.com/adeo/tempo-orchestrator--sources/commit/37848833a63cff6e2a7910f16ffc3f5294f58d71))





# [1.12.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.11.0...tempo-orchestrator-api@1.12.0) (2024-03-29)


### Features

* add is paid information on get order info ([a47ef33](https://github.com/adeo/tempo-orchestrator--sources/commit/a47ef33a8b6ada1e9038cbebd363c44df11b1adb))
* add is paid information on get order info ([fd791be](https://github.com/adeo/tempo-orchestrator--sources/commit/fd791be5643778d8a78a20e76077847b687f60cb))
* add is paid information on get order info ([f08bf37](https://github.com/adeo/tempo-orchestrator--sources/commit/f08bf3779fbbb2949b04126e9e238bd2a6afe28a))





# [1.11.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.10.1...tempo-orchestrator-api@1.11.0) (2024-03-29)


### Features

* add is paid information on get order info ([#4392](https://github.com/adeo/tempo-orchestrator--sources/issues/4392)) ([845ba87](https://github.com/adeo/tempo-orchestrator--sources/commit/845ba87c670c28024830a24b43d155c413b0f469))





## [1.10.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.10.0...tempo-orchestrator-api@1.10.1) (2024-03-26)

**Note:** Version bump only for package tempo-orchestrator-api





# [1.10.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.9.0...tempo-orchestrator-api@1.10.0) (2024-03-19)


### Features

* add tag to facilitate search analyse ([#4373](https://github.com/adeo/tempo-orchestrator--sources/issues/4373)) ([4f28adf](https://github.com/adeo/tempo-orchestrator--sources/commit/4f28adfe423af22c5149f3f6a8b18ccb56b1778f))





# [1.9.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.8.2...tempo-orchestrator-api@1.9.0) (2024-03-14)


### Features

* update operation api contract with the addition of payment external data ([#4365](https://github.com/adeo/tempo-orchestrator--sources/issues/4365)) ([87ae8fc](https://github.com/adeo/tempo-orchestrator--sources/commit/87ae8fc4fecb0e2914c94b25d9b24731d2802c3c))





## [1.8.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.8.1...tempo-orchestrator-api@1.8.2) (2024-03-13)


### Bug Fixes

* take into account the operation status updating ([#4360](https://github.com/adeo/tempo-orchestrator--sources/issues/4360)) ([be4bf92](https://github.com/adeo/tempo-orchestrator--sources/commit/be4bf92f38e0f65075d2201ed3ef4106337bcaea))





## [1.8.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.8.0...tempo-orchestrator-api@1.8.1) (2024-03-08)


### Bug Fixes

* correctly managed payment operations deserialization ([#4355](https://github.com/adeo/tempo-orchestrator--sources/issues/4355)) ([cdb2321](https://github.com/adeo/tempo-orchestrator--sources/commit/cdb2321a257b1f6c9dd1f68b057eee098981011c))





# [1.8.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.7.0...tempo-orchestrator-api@1.8.0) (2024-03-08)


### Features

* add in_store communication and autoCancellation  ([75d7ee6](https://github.com/adeo/tempo-orchestrator--sources/commit/75d7ee632bb6468fda0e5f7092498dfc49573bf3))





# [1.7.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.6.3...tempo-orchestrator-api@1.7.0) (2024-03-08)


### Features

* expose execution actions on the getOrder api ([#4346](https://github.com/adeo/tempo-orchestrator--sources/issues/4346)) ([3f5cd65](https://github.com/adeo/tempo-orchestrator--sources/commit/3f5cd65c126ad17258b0d45c0e026a9ba02b4958))





## [1.6.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.6.2...tempo-orchestrator-api@1.6.3) (2024-03-08)


### Bug Fixes

* conf ([07af4d3](https://github.com/adeo/tempo-orchestrator--sources/commit/07af4d316e9289e54b0fcf0847cf24d753a33099))





## [1.6.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.6.1...tempo-orchestrator-api@1.6.2) (2024-03-08)


### Bug Fixes

* conf ([7058af5](https://github.com/adeo/tempo-orchestrator--sources/commit/7058af560ec2d0ce736d4cc8f49d3e63b446b69e))





## [1.6.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.6.0...tempo-orchestrator-api@1.6.1) (2024-03-08)


### Bug Fixes

* conf kafka ([23a2d23](https://github.com/adeo/tempo-orchestrator--sources/commit/23a2d23b2063dd888f277c7b2ee9b1957a32bba5))





# [1.6.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.5.0...tempo-orchestrator-api@1.6.0) (2024-03-08)


### Features

* decrease quantity workflow  ([5b7fa85](https://github.com/adeo/tempo-orchestrator--sources/commit/5b7fa8552c45891804005dcc773b3f80960495f2))





# [1.5.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.4.1...tempo-orchestrator-api@1.5.0) (2024-03-06)


### Features

* api add field for tofu on tpp behaviour ([#4352](https://github.com/adeo/tempo-orchestrator--sources/issues/4352)) ([9f626a5](https://github.com/adeo/tempo-orchestrator--sources/commit/9f626a5e883cb519d8c4ea49f733e23ea2a366f5))





## [1.4.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.4.0...tempo-orchestrator-api@1.4.1) (2024-03-04)

**Note:** Version bump only for package tempo-orchestrator-api





# [1.4.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.3.0...tempo-orchestrator-api@1.4.0) (2024-02-28)


### Features

* save and expose demat code and payment in store ([509da30](https://github.com/adeo/tempo-orchestrator--sources/commit/509da30db44a84f4f7b30632c21d625254e5a98a))





# [1.3.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.2.3...tempo-orchestrator-api@1.3.0) (2024-02-26)


### Features

* expose operations ([53c76d7](https://github.com/adeo/tempo-orchestrator--sources/commit/53c76d7c65998d6e72d792eec80d24bef8584139))
* expose operations ([d7e2abd](https://github.com/adeo/tempo-orchestrator--sources/commit/d7e2abdaf12d7583cb03847fc9da95cbf959f9ef))
* expose operations ([59916cb](https://github.com/adeo/tempo-orchestrator--sources/commit/59916cb255f497309de0a5e403cf30c562fea522))
* expose operations ([1b79db6](https://github.com/adeo/tempo-orchestrator--sources/commit/1b79db6511e2306d72e19e8f3457dbf7cb950abf))
* expose operations ([384e642](https://github.com/adeo/tempo-orchestrator--sources/commit/384e64273c0110171100f3cfe3eb1b879409da45))





## [1.2.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.2.2...tempo-orchestrator-api@1.2.3) (2024-02-23)


### Bug Fixes

* typo ([38dc2d0](https://github.com/adeo/tempo-orchestrator--sources/commit/38dc2d0f5680148fb15649adc15f5ed058d2ea6a))





## [1.2.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.2.1...tempo-orchestrator-api@1.2.2) (2024-02-23)


### Bug Fixes

* missing swagger config ([39e5410](https://github.com/adeo/tempo-orchestrator--sources/commit/39e5410e287baf2fd9c9daf97cbf8eae0fbfa986))





## [1.2.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.2.0...tempo-orchestrator-api@1.2.1) (2024-02-22)


### Bug Fixes

* update swagger.yml ([22a3fe4](https://github.com/adeo/tempo-orchestrator--sources/commit/22a3fe4be44fead9b3b49b1c45b9da2811284f63))





# [1.2.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.1.2...tempo-orchestrator-api@1.2.0) (2024-02-22)


### Features

* create udpate execution endpoint  ([f7d1a86](https://github.com/adeo/tempo-orchestrator--sources/commit/f7d1a86311fc57a121b4f1f0c97f6aabedb4f865))





## [1.1.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.1.1...tempo-orchestrator-api@1.1.2) (2024-02-21)


### Bug Fixes

* remove useless conf ([b749b34](https://github.com/adeo/tempo-orchestrator--sources/commit/b749b348a232ad1a4a7ff117d1731111ebe2346d))





## [1.1.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-api@1.1.0...tempo-orchestrator-api@1.1.1) (2024-02-21)


### Bug Fixes

* update application.yml ([74cffa6](https://github.com/adeo/tempo-orchestrator--sources/commit/74cffa62608374dd0fcf699ea21539f994a6f384))





# 1.1.0 (2024-02-20)


### Features

* init tempo-orchestrator-api  ([0a87306](https://github.com/adeo/tempo-orchestrator--sources/commit/0a873060957eeb5c68b80881aa741844d4d2fcc1))
