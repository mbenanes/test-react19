package com.adeo.sales.customerorder.tempoorchestrator.applicationservice;

import com.adeo.sales.customerorder.external.api.client.psr.dto.OrderPaymentOperation;
import com.adeo.sales.customerorder.external.api.client.psr.dto.OrderPaymentOperations;
import com.adeo.sales.customerorder.external.api.client.tco.dto.Payment;
import com.adeo.sales.customerorder.external.api.client.tco.dto.TempoConsolidatedOrder;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.paymentoperations.Meta;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.paymentoperations.MetaPagination;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.paymentoperations.Operation;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.paymentoperations.Operations;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.paymentoperations.OrderLine;
import com.adeo.sales.customerorder.tempoorchestrator.converter.PaymentConverter;
import com.adeo.sales.customerorder.tempoorchestrator.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.exception.PaymentOperationsNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.exception.PaymentOperationsNotFoundForPaymentScheduleId;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecutionPayment;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperation;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LineExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;


@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentOperationApplicationService {
    public static final String PAYMENT_MEAN_MULTIBANCO = "MULTIBANCO";
    public static final String PAYMENT_EXTERNAL_DATA_ENTITY = "ENTITY";
    public static final String PAYMENT_EXTERNAL_DATA_EXPIRATION_DATE = "EXPIRATION_DATE";
    public static final String PAYMENT_EXTERNAL_DATA_PAYMENT_REFERENCE = "PAYMENT_REFERENCE";
    private static final Predicate<OrderPaymentOperation> IS_PAYMENT_MULTIBANCO = orderPaymentOperation -> PAYMENT_MEAN_MULTIBANCO.equals(orderPaymentOperation.getPaymentMean());

    private final PaymentConverter paymentConverter;
    private final PaymentRepository paymentRepository;
    private final LineExecutionRepository lineExecutionRepository;
    private final CustomerOrderRepository customerOrderRepository;
    private final PaymentSchedulerService paymentSchedulerService;
    private final TempoConsolidatedOrderService tempoConsolidatedOrderService;
    private final UccCookieTransactionService uccCookieTransactionService;


    public Mono<Operations> apply(String customerOrderId, String buCode, List<String> operationIds, Integer page, Integer perPage, boolean useLegacyData) {
        return lineExecutionRepository.getByCustomerOrderId(customerOrderId, buCode)
            .collectList()
            .map(PaymentOperationApplicationService::getPaymentExecutionSystem)
            .flatMap(paymentExecutionSystem -> {
                if (LineExecutionPayment.PaymentExecutionSystem.PSR.name().equals(paymentExecutionSystem)) {
                    return this.getPaymentOperationsFromPSR(customerOrderId, buCode, operationIds, page, perPage);
                }
                if (useLegacyData) {
                    return this.getPaymentOperationsFromUlys(customerOrderId, buCode, operationIds, page, perPage);
                } else {
                    return this.getPaymentOperationsFromCookie(customerOrderId, buCode, operationIds, page, perPage);
                }
            });
    }

    private Mono<Operations> getPaymentOperationsFromUlys(String customerOrderId, String buCode, List<String> operationIds, Integer page, Integer perPage) {
        Flux<PaymentOperation> paymentOperationFlux;
        if (CollectionUtils.isEmpty(operationIds)) {
            paymentOperationFlux = this.paymentRepository.getByCustomerOrderId(customerOrderId, buCode);
        } else {
            paymentOperationFlux = this.paymentRepository.getByCustomerOrderIdAndOperationId(customerOrderId, buCode, operationIds);
        }
        return paymentOperationFlux
            .switchIfEmpty(Mono.error(new PaymentOperationsNotFound(customerOrderId, buCode)))
            .collectList()
            .map(paymentOperations -> new Operations(paymentConverter.convert(paymentOperations), page, perPage));
    }

    private Mono<Operations> getPaymentOperationsFromCookie(String customerOrderId, String buCode, List<String> operationIds, Integer page, Integer perPage) {
        return this.uccCookieTransactionService.getPaymentOperations(customerOrderId, operationIds, buCode)
            .switchIfEmpty(Mono.error(new PaymentOperationsNotFound(customerOrderId, buCode)))
            .collectList()
            .map(paymentOperations -> new Operations(this.paymentConverter.convert(paymentOperations), page, perPage));
    }

    private Mono<Operations> getPaymentOperationsFromPSR(String customerOrderId, String buCode, List<String> operationIds, Integer page, Integer perPage) {
        return customerOrderRepository.getById(customerOrderId, buCode)
            .flatMap(customerOrder -> {
                String paymentScheduleId = customerOrder.getPaymentSchedule().getId();
                return paymentSchedulerService.getPageOfPaymentOperation(paymentScheduleId, operationIds, buCode, page, perPage)
                    .flatMap(orderPaymentOperations -> mapPaymentOperationFromPSR(orderPaymentOperations, customerOrderId, buCode))
                    .switchIfEmpty(Mono.error(new PaymentOperationsNotFoundForPaymentScheduleId(customerOrderId, buCode, paymentScheduleId)));
            })
            .switchIfEmpty(Mono.error(new CustomerOrderNotFound(customerOrderId, buCode)));
    }

    private Mono<Operations> mapPaymentOperationFromPSR(OrderPaymentOperations orderPaymentOperations, String customerOrderId, String buCode) {

        return this.paymentRepository.getByCustomerOrderId(customerOrderId, buCode)
            .switchIfEmpty(Mono.error(new PaymentOperationsNotFound(customerOrderId, buCode)))
            .collectList()
            .map(paymentOperations -> buildPaymentOperationsWithTorData(orderPaymentOperations, paymentOperations))
            .onErrorResume(PaymentOperationsNotFound.class, error -> {
                if (orderPaymentOperations.getData().stream().anyMatch(IS_PAYMENT_MULTIBANCO)) {
                    return buildPaymentOperationsWithTcoData(orderPaymentOperations, customerOrderId, buCode);
                } else {
                    List<Operation> operations = mapPaymentOperation(orderPaymentOperations);
                    Meta meta = Meta.builder()
                        .pagination(MetaPagination.builder()
                            .count(orderPaymentOperations.getMeta().getPagination().getCount())
                            .totalPageCount(orderPaymentOperations.getMeta().getPagination().getTotalPageCount())
                            .build())
                        .build();
                    return Mono.just(Operations.builder()
                        .data(operations)
                        .meta(meta)
                        .build());
                }
            });
    }

    private Mono<Operations> buildPaymentOperationsWithTcoData(OrderPaymentOperations orderPaymentOperations, String customerOrderId, String buCode) {
        return this.tempoConsolidatedOrderService.getTempoConsolidatedOrder(customerOrderId, buCode)
            .map(tempoConsolidatedOrder -> {
                List<Operation> operations = mapPaymentOperation(orderPaymentOperations);
                operations.forEach(operation -> operation.setPaymentExternalData(mapExternalData(tempoConsolidatedOrder)));

                Meta meta = Meta.builder()
                    .pagination(MetaPagination.builder()
                        .count(orderPaymentOperations.getMeta().getPagination().getCount())
                        .totalPageCount(orderPaymentOperations.getMeta().getPagination().getTotalPageCount())
                        .build())
                    .build();

                return Operations.builder()
                    .data(operations)
                    .meta(meta)
                    .build();
            });
    }

    private Operations buildPaymentOperationsWithTorData(OrderPaymentOperations orderPaymentOperations, List<PaymentOperation> paymentOperations) {
        List<Operation> operations = mapPaymentOperation(orderPaymentOperations);
        operations.forEach(operation -> operation.setPaymentExternalData(mapExternalData(paymentOperations, operation.getTransactionId())));

        Meta meta = Meta.builder()
            .pagination(MetaPagination.builder()
                .count(orderPaymentOperations.getMeta().getPagination().getCount())
                .totalPageCount(orderPaymentOperations.getMeta().getPagination().getTotalPageCount())
                .build())
            .build();

        return Operations.builder()
            .data(operations)
            .meta(meta)
            .build();
    }

    private Map<String, String> mapExternalData(TempoConsolidatedOrder tempoConsolidatedOrder) {
        return Optional.ofNullable(tempoConsolidatedOrder.getPayment())
            .map(Payment::getPaymentTransactions)
            .map(paymentTransactions -> paymentTransactions.stream()
                .filter(paymentTransaction -> PAYMENT_MEAN_MULTIBANCO.equals(paymentTransaction.getPaymentMethodType()))
                .findFirst()
                .map(paymentTransaction -> Map.of(PAYMENT_EXTERNAL_DATA_ENTITY, paymentTransaction.getPaymentEntity(),
                    PAYMENT_EXTERNAL_DATA_EXPIRATION_DATE, paymentTransaction.getPaymentExpirationDate() != null ? paymentTransaction.getPaymentExpirationDate().toString() : null,
                    PAYMENT_EXTERNAL_DATA_PAYMENT_REFERENCE, paymentTransaction.getPaymentReference()))
                .orElse(Collections.emptyMap()))
            .orElse(Collections.emptyMap());
    }

    private static List<Operation> mapPaymentOperation(OrderPaymentOperations orderPaymentOperations) {
        return orderPaymentOperations.getData().stream().map(paymentOperation -> Operation.builder()
            .operationId(paymentOperation.getOperationId())
            .amount(paymentOperation.getAmount())
            .appliedAt(paymentOperation.getAppliedAt())
            .type(paymentOperation.getType())
            .paymentMean(paymentOperation.getPaymentMean())
            .transactionId(paymentOperation.getTransactionId())
            .status(paymentOperation.getStatus())
            .lines(Optional.ofNullable(paymentOperation.getLines())
                .orElse(Collections.emptyList())
                .stream()
                .map(orderLine -> OrderLine.builder()
                    .id(orderLine.getId())
                    .type(orderLine.getType())
                    .build())
                .toList())
            .paymentExternalData(Collections.emptyMap())
            .build()).toList();
    }

    private Map<String, String> mapExternalData(List<PaymentOperation> paymentOperations, String transactionId) {
        return paymentOperations.stream().filter(paymentOperation -> transactionId.equals(paymentOperation.getTransactionId()))
            .findFirst().map(PaymentOperation::getPaymentExternalData).orElse(Collections.emptyMap());
    }

    private static String getPaymentExecutionSystem(List<LineExecution> lineExecutions) {
        if (lineExecutions.isEmpty()) {
            return LineExecutionPayment.PaymentExecutionSystem.TPP.name();
        }
        return lineExecutions.get(0).getPayment().getPaymentExecutionSystem().name();
    }
}
