package com.adeo.sales.customerorder.tempoorchestrator.model.executionaction;

import com.adeo.sales.customerorder.tempoorchestrator.model.Flags;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@Data
@NoArgsConstructor
public class ImpactedLineStep {
    private Integer position;
    private Flags<Status> flags;
    private Type type;
    private boolean isBlocking;

    public enum Status {
        CREATED, PROCESSING, COMPLETED, FAILED
    }

    public static Flags<Status> initializeFlags() {
        Flags<Status> flags = new Flags<>();
        flags.raiseFlag(Status.CREATED);
        return flags;
    }

    public enum Type {
        DECREASE_QUANTITY_DELIVERY,
        ABORT_DELIVERY_3P,
        DECREASE_QUANTITY_COLLECT,
        DECREASE_QUANTITY_COMPOSITION,
        UNEXEC_REQUIREMENT_TPP,
        SPLIT_LINE_EXECUTION,
        ASK_PREPARATION_REQUIREMENT_TPP,
        CREATE_COLLECT,
        READ_ADJUSTMENT_TPP,
        EXECUTE_ADJUSTMENT_TPP,
        SEND_CANCELLATION_NOTIFICATION,
        SEND_CANCELLATION_BY_VENDOR_NOTIFICATION,
        SEND_PAYMENT_REFUSED_NOTIFICATION
    }
}
