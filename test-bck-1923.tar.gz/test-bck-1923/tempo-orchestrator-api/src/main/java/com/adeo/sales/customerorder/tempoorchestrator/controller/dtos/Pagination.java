package com.adeo.sales.customerorder.tempoorchestrator.controller.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Pagination {

    private Integer count;
    private Integer totalPageCount;
}