package com.adeo.sales.customerorder.tempoorchestrator.converter;

import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.paymentoperations.Operation;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.paymentoperations.OrderLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;


@Component
public class PaymentConverter implements Converter<List<PaymentOperation>, List<Operation>> {
    @Override
    public List<Operation> convert(List<PaymentOperation> paymentOperations) {
        if (CollectionUtils.isEmpty(paymentOperations)) {
            return Collections.emptyList();
        }

        return paymentOperations.stream().map(paymentOperation ->
                Operation.builder()
                    .type(paymentOperation.getOperation().name())
                    .amount(paymentOperation.getAmount())
                    .paymentMean(paymentOperation.getPaymentMean())
                    .transactionId(paymentOperation.getTransactionId())
                    .appliedAt(paymentOperation.getOperationDate())
                    .operationId(paymentOperation.getId())
                    .status(paymentOperation.getStatus().name())
                    .lines(paymentOperation.getLines().stream().map(line -> OrderLine.builder()
                        .id(line.getId())
                        .type(line.getType().name())
                        .build()).toList())
                    .paymentExternalData(paymentOperation.getPaymentExternalData())
                    .build())
            .sorted(Comparator.comparing(Operation::getAppliedAt))
            .toList();
    }
}
