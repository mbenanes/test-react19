package com.adeo.sales.customerorder.tempoorchestrator.model.tpp.simulation;

import com.adeo.sales.customerorder.external.api.client.tpp.model.SimulatePaymentRequirementActionType;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Builder
@AllArgsConstructor
@Data
@NoArgsConstructor
@ApiModel(description = "A SimulationRequirement request")
public class SimulationRequirementRequest {

    @ApiModelProperty(notes = "The requirement action type")
    @NotNull
    private SimulatePaymentRequirementActionType paymentRequirementActionType;

    @ApiModelProperty(notes = "The list of items to simulate a requirement action type")
    @NotEmpty
    @Valid
    private List<SimulationRequirementRequestItem> simulationRequirementRequestItems;

}
