package com.adeo.sales.customerorder.tempoorchestrator.model;

import java.util.Arrays;

public enum CollectStatus {
    REQUESTED,
    CREATED,
    PLANNED,
    EXPECTED,
    TAKEN_IN_CHARGE,
    WAITING_FOR_EXECUTION,
    COLLECTED,
    NOT_COLLECTED,
    PARTIALLY_COLLECTED,
    CANCEL_REQUESTED,
    CANCELLED,
    EXECUTED,
    REJECTED,
    UNKNOWN;

    public static CollectStatus fromString(String value) {
        return Arrays.stream(CollectStatus.values()).filter(enumValue -> enumValue.name().equals(value)).findFirst().orElse(UNKNOWN);
    }
}
