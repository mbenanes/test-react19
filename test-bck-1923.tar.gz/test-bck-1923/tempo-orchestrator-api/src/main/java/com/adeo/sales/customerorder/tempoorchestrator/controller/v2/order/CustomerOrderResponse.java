package com.adeo.sales.customerorder.tempoorchestrator.controller.v2.order;

import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.ExecutionAction;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@ApiModel(description = "The customer order")
public class CustomerOrderResponse {
    @ApiModelProperty(notes = "Unique identifier of the customer order", example = "5ac78ffe-858c-4908-913e-2082c89b0fe5")
    private String id;
    @ApiModelProperty(notes = "the customer order place type.", example = "IN_STORE | ONLINE")
    private String placeType;
    @ApiModelProperty(notes = "the customer order payment place type.", example = "IN_STORE | ONLINE")
    private String paymentPlaceType;
    @ApiModelProperty(notes = "the customer order dematerialized cashing code to pay in store.", example = "1111")
    private String dematCode;
    @ApiModelProperty(notes = "List of execution plan.")
    private List<ExecutionPlan> executionPlans;
    @ApiModelProperty(notes = "list of customer order execution actions")
    private List<ExecutionAction> updateExecutionActions;
    @ApiModelProperty(notes = "indicate if a payment has been processed on the order or not")
    private boolean paid;
}
