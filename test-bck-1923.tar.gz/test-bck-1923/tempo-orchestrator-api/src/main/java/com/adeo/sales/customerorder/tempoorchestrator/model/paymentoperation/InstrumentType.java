package com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation;

public enum InstrumentType {
    PAYPAL_WEB,
    FINANCE_OFFER_WEB,
    BANK_TRANSFER_WEB,
    FINANCE_ONEY_WEB,
    BIZUM,
    MULTIBANCO,
    MBWAY,
    BLIK,
    FAST_BANK_TRANSFER,
    MANUAL_BANK_TRANSFER,
    PAYPO,
    ONEY_RATY,
    PAYMENT_CARD_WEB
}
