package com.adeo.sales.customerorder.tempoorchestrator.applicationservice;

import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.UpdateEstimatedDeliveryDateBody;
import com.adeo.sales.customerorder.tempoorchestrator.webclient.TempoOrchestratorApiClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Slf4j
@RequiredArgsConstructor
@Component
public class TempoOrchestratorService {

    private final TempoOrchestratorApiClient tempoOrchestratorApiClient;

    public Mono<ResponseEntity<Void>> updateEstimatedDeliveryDate(String buCode, UpdateEstimatedDeliveryDateBody updateEstimatedDeliveryDateBody) {
        return tempoOrchestratorApiClient.updateEstimatedDeliveryDate(buCode, updateEstimatedDeliveryDateBody);
    }
}
