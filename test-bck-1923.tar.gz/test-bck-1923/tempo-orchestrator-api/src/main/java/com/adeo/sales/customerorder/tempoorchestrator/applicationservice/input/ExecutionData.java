package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.input;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class ExecutionData {
    private String executionId;
    private List<LineData> lineData;
}
