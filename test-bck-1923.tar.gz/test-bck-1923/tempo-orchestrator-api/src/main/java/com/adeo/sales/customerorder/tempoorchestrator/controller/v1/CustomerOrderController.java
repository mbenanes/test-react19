package com.adeo.sales.customerorder.tempoorchestrator.controller.v1;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.GetCustomerOrderApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.UpdateExecutionApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.controller.AbstractBaseController;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.CustomerOrderResponse;
import com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions.CustomerOrderNotFoundError;
import com.adeo.sales.customerorder.tempoorchestrator.controller.v2.order.ExecutionUpdateRequest;
import com.adeo.sales.customerorder.tempoorchestrator.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import javax.validation.Valid;


@RestController
@Slf4j
@RequiredArgsConstructor
public class CustomerOrderController extends AbstractBaseController {

    private static final String GET_EXECUTION_END_POINT = "/customer-orders/{customerOrderId}";
    private static final String UPDATE_EXECUTION_END_POINT = "/customer-orders/{customerOrderId}/executionUpdateRequest";

    private static final String BU_CODE = "Adeo-Bu-Code";
    private static final String APP_SOURCE = "Adeo-App-Source";

    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final GetCustomerOrderApplicationService getCustomerOrderApplicationService;
    private final UpdateExecutionApplicationService updateExecutionApplicationService;

    @GetMapping(value = GET_EXECUTION_END_POINT, headers = "X-API-Version=1")
    public Mono<CustomerOrderResponse> get(
        @PathVariable(value = "customerOrderId") String customerOrderId,
        @RequestHeader(BU_CODE) final String buCode
    ) {
        this.mappedDiagnosticContext.injectRestData(buCode, GET_EXECUTION_END_POINT, customerOrderId);

        return this.getCustomerOrderApplicationService.apply(customerOrderId, buCode)
            .onErrorResume(CustomerOrderNotFound.class, error -> Mono.error(new CustomerOrderNotFoundError(error)));
    }

    @PostMapping(value = UPDATE_EXECUTION_END_POINT, headers = "X-API-Version=1")
    public Mono<ResponseEntity<Void>> post(
        @RequestHeader(BU_CODE) final String buCode,
        @RequestHeader(APP_SOURCE) final String appSource,
        @PathVariable(value = "customerOrderId") String customerOrderId,
        @Valid @RequestBody final Mono<ExecutionUpdateRequest> bodyMono

    ) {
        this.mappedDiagnosticContext.injectRestData(buCode, UPDATE_EXECUTION_END_POINT, customerOrderId);

        return bodyMono
            .flatMap(body -> {
                if (body.getImpactedExecutions().get(0).getExecutionId().equals(customerOrderId)) {
                    return updateExecutionApplicationService.applyV1(toInput(body, customerOrderId, buCode, appSource));
                } else {
                    return updateExecutionApplicationService.apply(toInput(body, customerOrderId, buCode, appSource));
                }
            })
            .then(Mono.fromCallable(() -> ResponseEntity.status(HttpStatus.CREATED).build()));
    }

}
