package com.adeo.sales.customerorder.tempoorchestrator.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Flag {
    private String operationId;
    private OffsetDateTime dateTime;
    private String type;
    private String failedReason;
}
