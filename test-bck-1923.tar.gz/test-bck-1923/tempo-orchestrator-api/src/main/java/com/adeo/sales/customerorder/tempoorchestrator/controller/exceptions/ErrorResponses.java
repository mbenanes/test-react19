package com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.Collection;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponses {

    private Collection<ErrorResponse> errors;

    public ErrorResponses(ErrorResponse... response) {
        this.errors = Arrays.asList(response);
    }
}