package com.adeo.sales.customerorder.tempoorchestrator.repository;

import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionActionType;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface ExecutionActionRepository {
    Flux<ExecutionAction> getExecutionActionsFromOrder(String customerOrderId, String buCode, ExecutionActionType executionActionType);
    Flux<ExecutionAction> getExecutionActionsFromOrder(String customerOrderId, String buCode);
}
