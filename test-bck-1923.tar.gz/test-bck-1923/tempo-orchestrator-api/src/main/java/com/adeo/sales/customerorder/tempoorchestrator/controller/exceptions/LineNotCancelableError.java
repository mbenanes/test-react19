package com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions;

public class LineNotCancelableError extends HttpConvertibleException {

    private static final long serialVersionUID = 1L;

    public LineNotCancelableError(String error) {
        super(error);
    }

    @Override
    public ErrorResponse toError() {
        return ErrorResponse.builder()
            .code("LINE_EXECUTION_NOT_CANCELABLE_ISSUE")
            .title("the decrease quantity action on some line(s) is forbidden.")
            .detail(this.getMessage())
            .build();
    }
}
