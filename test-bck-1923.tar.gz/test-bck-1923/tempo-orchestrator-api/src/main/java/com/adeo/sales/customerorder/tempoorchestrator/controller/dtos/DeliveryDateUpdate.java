package com.adeo.sales.customerorder.tempoorchestrator.controller.dtos;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class DeliveryDateUpdate {
    private List<String> customerLineIds;
    private DeliveryDateResponseAndRequest estimatedDeliveryDate;
}
