package com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation;

public enum LineType {
    OFFER_LINE, DELIVERY_LINE, SERVICE, UNKNOWN
}
