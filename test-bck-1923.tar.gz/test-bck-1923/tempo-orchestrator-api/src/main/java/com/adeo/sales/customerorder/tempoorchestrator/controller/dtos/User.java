package com.adeo.sales.customerorder.tempoorchestrator.controller.dtos;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class User {

    @Deprecated
    private String customerIdentifier;

    @Deprecated
    private String ldap;
}
