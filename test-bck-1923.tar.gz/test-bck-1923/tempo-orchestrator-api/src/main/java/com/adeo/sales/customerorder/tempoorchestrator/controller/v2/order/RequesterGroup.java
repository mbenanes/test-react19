package com.adeo.sales.customerorder.tempoorchestrator.controller.v2.order;

public interface RequesterGroup {
}
