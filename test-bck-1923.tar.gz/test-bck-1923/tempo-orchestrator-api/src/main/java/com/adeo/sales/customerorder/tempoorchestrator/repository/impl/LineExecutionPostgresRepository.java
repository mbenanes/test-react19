package com.adeo.sales.customerorder.tempoorchestrator.repository.impl;

import com.adeo.sales.customerorder.tempoorchestrator.controller.v2.availableaction.AvailableActionsRequest;
import com.adeo.sales.customerorder.tempoorchestrator.model.ConfigurationService;
import com.adeo.sales.customerorder.tempoorchestrator.model.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecutionComposition;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecutionPayment;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecutionPaymentRequirements;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineType;
import com.adeo.sales.customerorder.tempoorchestrator.model.Page;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LineExecutionRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.r2dbc.spi.Row;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.BU_CODE;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.CUSTOMER_ORDER_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.ID;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.IDS;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.LINES_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.OFFSET;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.PER_PAGE;

@Slf4j
@Component
@RequiredArgsConstructor
public class LineExecutionPostgresRepository implements LineExecutionRepository {

    private final ObjectMapper objectMapper;

    private final DatabaseClient readerDatabaseClient;

    @Override
    public Flux<LineExecution> getFromExecutionAndLine(String executionId, String lineId) {
        var select = "select le.execution_id, le.id, le.customer_order_id, le.version, le.line_type, le.bu_code, le.payment, le.is_sold_by_a_third_party_vendor, le.delivery, le.composition, le.external_system, le.sent_mails, le.configuration_service, le.quantity, co.data->'paymentSchedule'->>'id' as paymentScheduleId, le.initial_quantity " +
            " from line_execution le" +
            " inner join customer_order co on co.id = le.customer_order_id " +
            " where le.id = :id" +
            " and le.execution_id = :executionId";

        return this.readerDatabaseClient
            .sql(select)
            .bind("id", lineId)
            .bind("executionId", executionId)
            .map(this::deserializeLineExecutionWithCustomerOrder)
            .all();
    }

    @Override
    public Flux<LineExecution> getByCustomerOrderId(String customerOrderId, String buCode) {
        var select = "select execution_id, id, quantity, customer_order_id, version, line_type, bu_code, payment, is_sold_by_a_third_party_vendor, delivery, composition, external_system, sent_mails, configuration_service, payment_requirements, initial_quantity " +
            "from line_execution " +
            "where customer_order_id = :customerOrderId and bu_code = :buCode";

        return this.readerDatabaseClient.sql(select)
            .bind(CUSTOMER_ORDER_ID, customerOrderId)
            .bind(BU_CODE, buCode)
            .map(this::deserializeLineExecution)
            .all();
    }

    @Override
    public Flux<LineExecution> getByLinesId(List<String> linesId, String buCode) {
        var select = "select execution_id, id, quantity, customer_order_id, version, line_type, bu_code, payment, is_sold_by_a_third_party_vendor, delivery, composition, external_system, sent_mails, configuration_service, payment_requirements, initial_quantity " +
            "from line_execution " +
            "where id in (:linesId) and bu_code = :buCode";

        return this.readerDatabaseClient.sql(select)
            .bind(LINES_ID, linesId)
            .bind(BU_CODE, buCode)
            .map(this::deserializeLineExecution)
            .all();
    }

    @Override
    public Mono<Page<LineExecution>> getPageOfLinesByLineId(final List<String> ids, String buCode, final int page, final int perPage) {
        final var count = this.readerDatabaseClient
            .sql("select count(1) from line_execution where id in (:ids) and bu_code = :buCode")
            .bind(IDS, ids)
            .bind(BU_CODE, buCode)
            .map(row -> row.get(0, Integer.class))
            .one();

        final var lines = this.readerDatabaseClient
            .sql("select id, customer_order_id, version, line_type, bu_code, payment, is_sold_by_a_third_party_vendor, delivery, composition, external_system, sent_mails, configuration_service, execution_id, quantity, payment_requirements, initial_quantity " +
                " from line_execution where id in (:id) and bu_code = :buCode " +
                " order by customer_order_id,(composition->>'position')::integer" +
                " OFFSET :offset LIMIT :perPage"
            )
            .bind(ID, ids)
            .bind(BU_CODE, buCode)
            .bind(PER_PAGE, perPage)
            .bind(OFFSET, (page - 1) * perPage)
            .map(this::deserializeLineExecution)
            .all();

        return lines.collectList().zipWith(count)
            .map(tuple -> Page.page(tuple.getT2(), perPage, tuple.getT1()));
    }

    @Override
    public Mono<Page<LineExecution>> getPageOfLinesByLineIdAndExecutionId(final List<AvailableActionsRequest> availableActionsRequests, String buCode, final int page, final int perPage) {
        final String countSql = "select count(1) from line_execution WHERE (id, execution_id) IN ( VALUES :coupleLineExecution )  and bu_code = :buCode";

        final List<Object[]> stringStringMap = availableActionsRequests.stream()
            .map(availableActionsRequest -> new Object[]{availableActionsRequest.getCustomerOrderCartItemId(), availableActionsRequest.getExecutionPlanId()})
            .toList();

        final var count = this.readerDatabaseClient
            .sql(countSql)
            .bind("coupleLineExecution", stringStringMap)
            .bind(BU_CODE, buCode)
            .map(row -> row.get(0, Integer.class))
            .one();

        final String selectSql = "select id, customer_order_id, version, line_type, bu_code, payment, is_sold_by_a_third_party_vendor, delivery, composition, external_system, sent_mails, configuration_service, execution_id, quantity, payment_requirements, initial_quantity from line_execution WHERE (id, execution_id) IN ( VALUES :coupleLineExecution ) and bu_code = :buCode order by customer_order_id,(composition->>'position')::integer  OFFSET :offset LIMIT :perPage";

        final var lines = this.readerDatabaseClient
            .sql(selectSql)
            .bind("coupleLineExecution", stringStringMap)
            .bind(BU_CODE, buCode)
            .bind(PER_PAGE, perPage)
            .bind(OFFSET, (page - 1) * perPage)
            .map(this::deserializeLineExecution)
            .all();

        return lines.collectList().zipWith(count)
            .map(tuple -> Page.page(tuple.getT2(), perPage, tuple.getT1()));
    }

    /**
     * Fix paymentScheduleId absent on lineExecution on V3 migration. We can refacto this code after 2 month.
     *
     * @param row
     * @return
     */
    private LineExecution deserializeLineExecutionWithCustomerOrder(Row row) {
        try {
            final String paymentscheduleid = row.get("paymentscheduleid", String.class);
            Integer version = row.get("version", Integer.class);
            final LineExecution lineExecution = LineExecution.builder()
                .executionId(row.get("execution_id", String.class))
                .lineId(row.get("id", String.class))
                .lineType(LineType.valueOf(row.get("line_type", String.class)))
                .version(version != null ? version : 1)
                .customerOrderId(row.get("customer_order_id", String.class))
                .buCode(row.get("bu_code", String.class))
                .payment(deserialize(row.get("payment", String.class), LineExecutionPayment.class))
                .delivery(deserialize(row.get("delivery", String.class), LineExecutionDelivery.class))
                .composition(deserialize(row.get("composition", String.class), LineExecutionComposition.class))
                .configurationService(deserialize(row.get("configuration_service", String.class), ConfigurationService.class))
                .externalSystem(deserialize(row.get("external_system", String.class), ExternalSystem.class))
                .sentMails(deserializeStringArray("sent_mails", row))
                .isSoldByAThirdPartyVendor(BooleanUtils.isTrue(row.get("is_sold_by_a_third_party_vendor", Boolean.class)))
                .quantity(row.get("quantity", BigDecimal.class))
                .initialQuantity(row.get("initial_quantity", BigDecimal.class))
                .build();

            lineExecution.getPayment().setPaymentScheduleId(paymentscheduleid);

            return lineExecution;
        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }

    private LineExecution deserializeLineExecution(Row row) {
        try {
            Integer version = row.get("version", Integer.class);
            final LineExecution lineExecution = LineExecution.builder()
                .executionId(row.get("execution_id", String.class))
                .lineId(row.get("id", String.class))
                .lineType(LineType.valueOf(row.get("line_type", String.class)))
                .version(version != null ? version : 1)
                .customerOrderId(row.get("customer_order_id", String.class))
                .buCode(row.get("bu_code", String.class))
                .payment(deserialize(row.get("payment", String.class), LineExecutionPayment.class))
                .delivery(deserialize(row.get("delivery", String.class), LineExecutionDelivery.class))
                .composition(deserialize(row.get("composition", String.class), LineExecutionComposition.class))
                .configurationService(deserialize(row.get("configuration_service", String.class), ConfigurationService.class))
                .paymentRequirements(deserialize(row.get("payment_requirements", String.class), LineExecutionPaymentRequirements.class))
                .externalSystem(deserialize(row.get("external_system", String.class), ExternalSystem.class))
                .sentMails(deserializeStringArray("sent_mails", row))
                .isSoldByAThirdPartyVendor(BooleanUtils.isTrue(row.get("is_sold_by_a_third_party_vendor", Boolean.class)))
                .quantity(row.get("quantity", BigDecimal.class))
                .initialQuantity(row.get("initial_quantity", BigDecimal.class))

                .build();

            if (lineExecution.getPayment().getPaymentExecutionSystem() == null) {
                lineExecution.getPayment().setPaymentExecutionSystem(LineExecutionPayment.PaymentExecutionSystem.PSR);
            }
            return lineExecution;
        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }

    private List<String> deserializeStringArray(String columnName, Row row) {
        final var array = row.get(columnName, String[].class);
        return array != null ? Arrays.stream(array).collect(Collectors.toList()) : new ArrayList<>();
    }

    private <T> T deserialize(String json, Class<T> clazz) {
        if (json == null) {
            return null;
        }
        try {
            return objectMapper.readValue(json, clazz);
        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }

}
