package com.adeo.sales.customerorder.tempoorchestrator.model.tpp.simulation;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Builder
@Data
@ApiModel(description = "List of items to ask a simulation")
@NoArgsConstructor
@AllArgsConstructor
public class SimulationRequirementRequestItem {

    @ApiModelProperty(notes = "The tempo line id")
    @NotNull
    private String lineId;

    @ApiModelProperty(notes = "Quantity of line to ask a simulation")
    @NotNull
    @DecimalMin(value = "1.0")
    private BigDecimal quantity;

}
