package com.adeo.sales.customerorder.tempoorchestrator.repository;

import com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrder;
import reactor.core.publisher.Mono;

public interface CustomerOrderRepository {
    Mono<CustomerOrder> getById( final String id, String buCode);
}
