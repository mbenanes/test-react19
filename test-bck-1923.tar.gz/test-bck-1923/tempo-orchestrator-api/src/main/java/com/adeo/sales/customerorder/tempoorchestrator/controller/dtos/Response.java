package com.adeo.sales.customerorder.tempoorchestrator.controller.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Response<T> {

    private T data;
    private Pagination pagination;

}
