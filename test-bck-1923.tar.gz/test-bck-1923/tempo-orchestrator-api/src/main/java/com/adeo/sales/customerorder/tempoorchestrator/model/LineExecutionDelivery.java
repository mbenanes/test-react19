package com.adeo.sales.customerorder.tempoorchestrator.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLineDeliveryStatus.ABORT_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLineDeliveryStatus.ACCEPTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLineDeliveryStatus.CLOSED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLineDeliveryStatus.CREATED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLineDeliveryStatus.CREATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLineDeliveryStatus.PREPARATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLineDeliveryStatus.REJECTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLineDeliveryStatus.RESERVATION_REQUESTED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLineDeliveryStatus.RESERVED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLineDeliveryStatus.SHIPPING_REQUESTED;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LineExecutionDelivery {

    private static final List<CustomerOrderLineDeliveryStatus> TO_3P_ACCEPTED_CURRENT_DELIVERY_STATUS = List.of(CREATION_REQUESTED, RESERVED, PREPARATION_REQUESTED, RESERVATION_REQUESTED, CREATED);
    private static final List<CustomerOrderLineDeliveryStatus> TO_3P_CREATED_CURRENT_DELIVERY_STATUS = List.of(CREATION_REQUESTED, RESERVED, PREPARATION_REQUESTED, RESERVATION_REQUESTED);
    private static final List<CustomerOrderLineDeliveryStatus> TO_3P_REJECTED_CURRENT_DELIVERY_STATUS = List.of(ACCEPTED, SHIPPING_REQUESTED, CREATION_REQUESTED, CREATED, ABORT_REQUESTED, CLOSED);

    private String deliveryLegacyNumber;
    private DeliveryDate customerKnownDeliveryDate;
    private DeliveryDate estimatedDeliveryDate;
    private DeliveryDate newDeliveryDate;
    private DeliveryDate initialPromiseDate;
    private DelayType delayType;
    private DeliveryDateUpdater estimatedDeliveryDateUpdatedBy;
    private String incoterm;
    private boolean declaredDelivered;
    private ShippingPoint shippingPoint;
    private String idDelivery;
    private StockValuationStatus stockValuationStatus;
    private DeliveryType deliveryType;
    private Boolean forceCancelable;
    private Boolean cancelable;
    private Boolean isDeliveryDateUpdatable;
    private OffsetDateTime appointmentDate;
    private LineExecutionDeliveryCollect collect;
    private Flags<CustomerOrderLineDeliveryStatus> flags = new Flags<>();

    public static final List<DeliveryType> PIXYS_DELIVERY_TYPES = List.of(
        DeliveryType.ORDER_AND_COLLECT,
        DeliveryType.RESERVE_AND_COLLECT,
        DeliveryType.SFS
    );


    public boolean isShippedFromWarehouse() {
        return DeliveryType.SFW == this.deliveryType;
    }

    public boolean isShippedByPartner() {
        return DeliveryType.SFP == this.deliveryType;
    }


    public boolean canBeUpdatedTo(CustomerOrderLineDeliveryStatus status) {
        if (status == ACCEPTED) {
            return this.flags.lastFlagIsOneOf(TO_3P_ACCEPTED_CURRENT_DELIVERY_STATUS);
        } else if (status == CREATED) {
            return this.flags.lastFlagIsOneOf(TO_3P_CREATED_CURRENT_DELIVERY_STATUS);
        } else if (status == REJECTED) {
            return this.flags.lastFlagIsOneOf(TO_3P_REJECTED_CURRENT_DELIVERY_STATUS);
        }
        return false;
    }

    public boolean canBeCreatedByVendor() {
        return this.canBeUpdatedTo(CREATED) && this.deliveryType == DeliveryType.THIRD_PARTY;
    }

    public boolean canBeConfirmedByVendor() {
        return this.canBeUpdatedTo(ACCEPTED) && this.deliveryType == DeliveryType.THIRD_PARTY;
    }

    public boolean canBeRejectedByVendor() {
        return this.canBeUpdatedTo(REJECTED) && this.deliveryType == DeliveryType.THIRD_PARTY;
    }

    public Flags<CustomerOrderLineDeliveryStatus> getFlags() {
        if (this.flags == null) {
            this.flags = new Flags<>();
        }
        return flags;
    }

    public LineExecutionDeliveryCollect getCollect() {
        if (this.collect == null) {
            this.collect = new LineExecutionDeliveryCollect();
        }
        return this.collect;
    }

    public CustomerOrderLineDeliveryStatus getLastFlag() {
        Flag lastFlag = this.getFlags().getLastFlag();
        if (lastFlag != null) {
            final var lastFlagType = lastFlag.getType();
            return CustomerOrderLineDeliveryStatus.valueOf(lastFlagType);
        }
        return null;
    }

    public boolean isPyxisDeliveryType() {
        return this.deliveryType != null && PIXYS_DELIVERY_TYPES.contains(this.deliveryType);
    }
}
