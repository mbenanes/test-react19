package com.adeo.sales.customerorder.tempoorchestrator.model;

public enum RequirementStatus {
    COMPLIANT, NOT_COMPLIANT, REQUESTED, COMPLETED, REJECTED;

    public static RequirementStatus getStatusByBoolean(boolean compliant) {
        return compliant ? COMPLIANT : NOT_COMPLIANT;
    }
}
