package com.adeo.sales.customerorder.tempoorchestrator.controller.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class IsContainedInEnumValidator implements ConstraintValidator<IsContainedInEnum, CharSequence> {

    private List<String> acceptedValues;

    @Override
    public void initialize(IsContainedInEnum annotation) {
        acceptedValues = Stream.of(annotation.enumClass().getEnumConstants())
            .map(Enum::name)
            .collect(Collectors.toList());
    }

    @Override
    public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }
        final String authorizedValues = String.join(", ", acceptedValues);
        if(acceptedValues.contains(value.toString())) {
            return true;
        } else {
            context.buildConstraintViolationWithTemplate("Must be one of " + authorizedValues).addConstraintViolation();
            return false;
        }
    }
}
