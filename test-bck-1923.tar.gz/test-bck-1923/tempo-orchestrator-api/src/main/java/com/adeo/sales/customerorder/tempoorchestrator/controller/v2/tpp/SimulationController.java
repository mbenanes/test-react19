package com.adeo.sales.customerorder.tempoorchestrator.controller.v2.tpp;

import com.adeo.sales.customerorder.external.api.client.tpp.model.SimulatePaymentRequirementActionExecutionResponse;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.v2.tpp.SimulationRequirementApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.exception.LineExecutionsDoesNotExist;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import com.adeo.sales.customerorder.tempoorchestrator.model.Error;
import com.adeo.sales.customerorder.tempoorchestrator.model.tpp.simulation.SimulationRequirementRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.support.WebExchangeBindException;
import reactor.core.publisher.Mono;

import javax.validation.Valid;
import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.controller.v2.HeadersConst.BU_CODE;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.NOT_FOUND;

@RestController
@Slf4j
@RequiredArgsConstructor
public class SimulationController {

    private static final String POST_SIMULATION_TPP_REQUIREMNET = "/simulate-requirement/{customerOrderId}";
    private final SimulationRequirementApplicationService simulationRequirementApplicationService;
    private final MappedDiagnosticContext mappedDiagnosticContext;

    @Operation(
        summary = "Simulate a payment requirement action execution",
        description = "This endpoint allows you to simulate a payment requirement action execution."
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "OK", content = {
            @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = SimulatePaymentRequirementActionExecutionResponse.class)
            )
        }),
        @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json")),
        @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(mediaType = "application/json"))
    })
    @PostMapping(value = POST_SIMULATION_TPP_REQUIREMNET, headers = "X-API-Version=2")
    public Mono<ResponseEntity<Object>> simulatePaymentRequirementActionExecution(
            @PathVariable(value = "customerOrderId") String customerOrderId,
        @RequestHeader(name = BU_CODE) String buCode,
        @Valid @RequestBody final SimulationRequirementRequest simulationRequirementRequest
        ) {

        this.mappedDiagnosticContext.injectRestData(buCode, POST_SIMULATION_TPP_REQUIREMNET, customerOrderId);

        return simulationRequirementApplicationService.simulateRequirementActionExecution(buCode, customerOrderId, simulationRequirementRequest)
            .map(simulatePaymentRequirementActionExecutionResponse ->  ResponseEntity.ok().body(simulatePaymentRequirementActionExecutionResponse));
    }

    @ExceptionHandler({LineExecutionsDoesNotExist.class, CustomerOrderNotFound.class})
    public Mono<ResponseEntity<String>> notFound(Exception ex) {
        return Mono.just(ResponseEntity.status(NOT_FOUND).body(ex.getMessage()));
    }

    @ExceptionHandler(WebExchangeBindException.class)
    public Mono<ResponseEntity<List<Error>>> catchConstraintViolation(WebExchangeBindException ex) {

        return Mono.just(ResponseEntity
            .status(BAD_REQUEST)
            .body(ex.getFieldErrors().stream()
                .map(fieldError -> Error.builder().message(fieldError.getDefaultMessage()).code(fieldError.getField()).build())
                .toList()));

    }

}
