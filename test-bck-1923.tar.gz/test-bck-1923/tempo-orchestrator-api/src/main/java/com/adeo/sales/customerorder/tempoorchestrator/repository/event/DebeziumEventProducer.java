package com.adeo.sales.customerorder.tempoorchestrator.repository.event;

import brave.propagation.B3SingleFormat;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.opentracing.Span;
import io.opentracing.SpanContext;
import io.opentracing.util.GlobalTracer;
import io.r2dbc.spi.Statement;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.specific.SpecificRecord;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.cloud.sleuth.brave.bridge.BraveTraceContext;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@Slf4j
public class DebeziumEventProducer implements EventProducer {
    private static final String UNKNOWN_CREATOR = "unknown";
    private final KafkaAvroSerializer kafkaAvroSerializerEventSerializer;
    private final Tracer tracer;
    private final MeterRegistry meterRegistry;
    private final String applicationName;
    private final DatabaseClient writerDatabaseClient;


    public DebeziumEventProducer(
        KafkaAvroSerializer kafkaAvroSerializerEventSerializer,
        Tracer tracer,
        MeterRegistry meterRegistry,
        DatabaseClient writerDatabaseClient,
        @Value("${spring.application.name}") String applicationName) {
        this.tracer = tracer;
        this.meterRegistry = meterRegistry;
        this.applicationName = applicationName;
        this.kafkaAvroSerializerEventSerializer = kafkaAvroSerializerEventSerializer;
        this.writerDatabaseClient = writerDatabaseClient;
    }

    @Override
    public <T extends SpecificRecord & GenericRecord> Mono<Void> sendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord) {
        return this.buildAndSendEvents(topics, customerOrderId, buCode, genericRecord);
    }

    private <T extends GenericRecord> Mono<Void> buildAndSendEvents(List<String> topics, String customerOrderId, String buCode, T genericRecord) {
        final var events = this.buildEvents(customerOrderId, buCode, genericRecord, topics);

        final var currentOpentracingContext = Optional.ofNullable(GlobalTracer.get())
            .map(io.opentracing.Tracer::activeSpan)
            .map(Span::context);

        return sendEvent(events, buCode, currentOpentracingContext);

    }

    private Mono<Void> sendEvent(List<TempoOrchestratorEvent<GenericRecord>> events, String buCode, Optional<SpanContext> currentOpentracingContext) {
        final var insert = "insert into tempo_orchestrator_event(id, customer_order_id, event_type, topic, correlation_id, created_at, created_by, event, bu_code, app_source, x_datadog_trace_id, x_datadog_parent_id, x_datadog_sampling_priority, bu_id)" +
            " values ($1, $2,  $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)";

        return this.writerDatabaseClient.inConnection(it -> {
            final var statement = it.createStatement(insert);
            events.forEach(event -> {
                log.info("{} Sent to repository - topic {} - event id {}", event.getEventType(), event.getTopic(), event.getId());
                statement
                    .bind(0, event.getId())
                    .bind(1, event.getCustomerOrderId())
                    .bind(2, event.getEventType())
                    .bind(3, event.getTopic())
                    .bind(4, B3SingleFormat.writeB3SingleFormat(BraveTraceContext.toBrave(Objects.requireNonNull(tracer.currentSpan()).context())))
                    .bind(5, event.getCreatedAt())
                    .bind(6, event.getCreatedBy())
                    .bind(7, serializeEvent(event.getTopic(), event.getEvent()))
                    .bind(8, event.getBuCode())
                    .bind(9, applicationName)
                    .bind(12, "1")
                    .bind(13, StringUtils.stripStart(buCode, "0"))
                ;

                bindNullable(10, statement, currentOpentracingContext.map(SpanContext::toTraceId).orElse(null));
                bindNullable(11, statement, currentOpentracingContext.map(SpanContext::toSpanId).orElse(null));
                statement.add();
            });

            return Flux.from(statement.execute())
                .flatMap(result -> Mono.from(result.getRowsUpdated()))
                .doOnNext(updatedRow -> log.debug("inserting TempoOrchestratorEvent, {} row updated", updatedRow))
                .then();
        }).doOnSuccess(it -> events.forEach(event -> this.addEventCount(event.getEventType(), event.getTopic())));
    }

    private byte[] serializeEvent(String topic, GenericRecord event) {
        return this.kafkaAvroSerializerEventSerializer.serialize(topic, event);
    }

    private void bindNullable(int index, Statement statement, String value) {
        if (value == null) {
            statement.bindNull(index, String.class);
        } else {
            statement.bind(index, value);
        }
    }

    private void addEventCount(String eventType, String topic) {
        Counter.builder("persisted_events_to_sent")
            .description("number of events persisted on database")
            .tag("event_type", eventType)
            .tag("topic", topic)
            .register(this.meterRegistry)
            .increment();
    }

    private List<TempoOrchestratorEvent<GenericRecord>> buildEvents(String customerOrderId, String buCode, GenericRecord genericRecord, List<String> topics) {
        final UUID eventId = UUID.randomUUID();

        return topics.stream()
            .map(topic -> TempoOrchestratorEvent.builder()
                .id(eventId)
                .customerOrderId(customerOrderId)
                .createdAt(OffsetDateTime.now())
                .createdBy(DebeziumEventProducer.UNKNOWN_CREATOR)
                .topic(topic)
                .event(genericRecord)
                .eventType(genericRecord.getClass().getSimpleName())
                .buCode(buCode)
                .build()).collect(Collectors.toList());
    }

}
