package com.adeo.sales.customerorder.tempoorchestrator.controller.dtos;

import com.adeo.sales.customerorder.tempoorchestrator.model.CollectStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class DeliveryResponse {
    private DeliveryDateResponseAndRequest initialPromiseDate;
    private DeliveryDateResponseAndRequest customerKnownDeliveryDate;
    private DeliveryDateResponseAndRequest estimatedDeliveryDate;
    private CollectStatus collectStatus;
    private OffsetDateTime collectAppointmentDate;
    private String collectId;
    private OffsetDateTime lastModifiedCollectStatusDate;

    private ShippingPoint shippingPoint;


    public enum  ShippingPoint {

        STORE,
        WAREHOUSE,
        SUPPLIER;
    }
}
