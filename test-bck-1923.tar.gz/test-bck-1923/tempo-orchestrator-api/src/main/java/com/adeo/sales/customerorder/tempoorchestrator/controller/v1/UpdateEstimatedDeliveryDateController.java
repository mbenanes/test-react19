package com.adeo.sales.customerorder.tempoorchestrator.controller.v1;


import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.TempoOrchestratorService;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.UpdateEstimatedDeliveryDateBody;
import com.adeo.sales.customerorder.tempoorchestrator.mdc.MappedDiagnosticContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;


@RestController
@Slf4j
public class UpdateEstimatedDeliveryDateController {

    private static final String END_POINT = "/update-estimated-delivery-date";
    private static final String BU_CODE = "Adeo-Bu-Code";

    private final MappedDiagnosticContext mappedDiagnosticContext;
    private final TempoOrchestratorService tempoOrchestratorService;

    public UpdateEstimatedDeliveryDateController(MappedDiagnosticContext mappedDiagnosticContext,
                                                 TempoOrchestratorService tempoOrchestratorService) {
        super();
        this.mappedDiagnosticContext = mappedDiagnosticContext;
        this.tempoOrchestratorService = tempoOrchestratorService;
    }

    @Transactional(transactionManager = "writerTransactionManager")
    @PostMapping(value = END_POINT, headers = "X-API-Version=1")
    public Mono<ResponseEntity<Void>> post(
        @RequestHeader(BU_CODE) final String buCode,
        @RequestBody final UpdateEstimatedDeliveryDateBody bodyMono
    ) {
        mappedDiagnosticContext.injectRestBU(buCode, END_POINT);
        return this.tempoOrchestratorService.updateEstimatedDeliveryDate(buCode, bodyMono);
    }
}
