package com.adeo.sales.customerorder.tempoorchestrator.repository.impl;

import com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.BU_CODE;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.ID;

@Slf4j
@Component
@RequiredArgsConstructor
public class CustomerOrderPostgresRepository implements CustomerOrderRepository {
    private final ObjectMapper objectMapper;
    private final DatabaseClient readerDatabaseClient;

    @Override
    public Mono<CustomerOrder> getById(String id, String buCode) {
        final var select = "select id, version, data from customer_order where id = :id and data->>'buCode' = :buCode";

        return this.readerDatabaseClient
            .sql(select)
            .bind(ID, id)
            .bind(BU_CODE, buCode)
            .map(row -> deserialize(id, row.get("version", Integer.class), row.get("data", String.class)))
            .one();
    }

    private CustomerOrder deserialize(String id, Integer version, String data) {
        if (data == null) {
            final var customerOrder = new CustomerOrder();
            customerOrder.setId(id);
            customerOrder.setVersion(version);
            return customerOrder;
        }
        try {
            return objectMapper.readValue(data, CustomerOrder.class);
        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }
}
