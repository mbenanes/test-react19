package com.adeo.sales.customerorder.tempoorchestrator.exception;

import java.util.List;

public class LineExecutionsDoesNotExist extends RuntimeException {
    public LineExecutionsDoesNotExist(List<String> linesMissing) {
        super("some customer order lines don't exist: " + String.join(", ", linesMissing));
    }

    public LineExecutionsDoesNotExist(String customerOrderId) {
        super("some V2 line execution don't exist: for customer order id " + customerOrderId);
    }
}
