package com.adeo.sales.customerorder.tempoorchestrator.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.beans.Transient;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class ExternalSystem {
    private SystemName origin;
    private SystemName name;
    private String id;
    private String storeCode;

    public enum SystemName {
        TEMPO,
        PYXIS,
        BOMP
    }

    @Transient
    public boolean isBomp() {
        return SystemName.BOMP == name;
    }

    @Transient
    public boolean isTempo() {
        return SystemName.TEMPO == name;
    }

    @Transient
    public boolean isPyxis() {
        return SystemName.PYXIS == name;
    }

    @Transient
    public boolean isOriginPyxis() {
        return SystemName.PYXIS.equals(origin);
    }

}
