package com.adeo.sales.customerorder.tempoorchestrator.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LineExecution {
    private String executionId;
    private String lineId;
    private String customerOrderId;
    private LineType lineType;
    private String buCode;
    private boolean isSoldByAThirdPartyVendor;
    private List<String> sentMails;
    private int version;
    private BigDecimal quantity;
    private BigDecimal initialQuantity;

    @JsonIgnore
    private boolean versionIncreased;
    private ExternalSystem externalSystem;
    private LineExecutionPayment payment;
    private LineExecutionDelivery delivery;
    private LineExecutionComposition composition;
    private ConfigurationService configurationService;
    private LineExecutionPaymentRequirements paymentRequirements;


    public BigDecimal getQuantity() {
        if (this.quantity != null) {
            return this.quantity;
        } else if (this.getComposition().getQuantity() != null) {
            return this.getComposition().getQuantity();
        }
        return null;
    }

    public BigDecimal getInitialQuantity() {
        if (this.initialQuantity != null) {
            return this.initialQuantity;
        } else if (this.getComposition().getQuantity() != null) {
            return this.getComposition().getQuantity();
        }
        return null;
    }

    public LineExecutionPayment getPayment() {
        if (payment == null) {
            this.payment = new LineExecutionPayment();

        }
        return payment;
    }

    public LineExecutionDelivery getDelivery() {
        if (this.delivery == null) {
            this.delivery = new LineExecutionDelivery();
        }
        return delivery;
    }

    public LineExecutionComposition getComposition() {
        if (this.composition == null) {
            this.composition = new LineExecutionComposition();
        }
        return composition;
    }

    public LineExecutionPaymentRequirements getPaymentRequirements() {
        if (paymentRequirements == null) {
            paymentRequirements = new LineExecutionPaymentRequirements();
        }
        return paymentRequirements;
    }

}
