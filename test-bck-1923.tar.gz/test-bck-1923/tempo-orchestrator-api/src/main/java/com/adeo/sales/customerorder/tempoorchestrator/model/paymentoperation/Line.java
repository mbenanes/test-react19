package com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Line {
    private String id;
    private LineType type;
}
