package com.adeo.sales.customerorder.tempoorchestrator.model;

import java.util.EnumSet;
import java.util.Set;

public enum CustomerOrderLineCompositionOrderStatus {
    PENDING,
    VALIDATED,
    CANCELED_REQUESTED,
    CANCELED,
    UNKNOWN;

    public static final Set<CustomerOrderLineCompositionOrderStatus> CANCELABLE_STATUSES = EnumSet.of(UNKNOWN, PENDING, VALIDATED);

    public static final Set<CustomerOrderLineCompositionOrderStatus> STATUS_ACCEPTING_CAPTURE = EnumSet.of(VALIDATED);
}
