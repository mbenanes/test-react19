package com.adeo.sales.customerorder.tempoorchestrator.exception;

public class CustomerOrderNotFound extends RuntimeException {

    public CustomerOrderNotFound(String message) {
        super(message);
    }

    public CustomerOrderNotFound(String customerOrderId, String buCode) {
        super("the customer order " + customerOrderId + " for bu " + buCode + " doesn't exists");
    }
}
