package com.adeo.sales.customerorder.tempoorchestrator.model;

public enum DelayType {
    LATE, FORECASTED_LATE, FORECASTED_LATE_ON_SHIPPED, UNKNOWN_DELAY
}
