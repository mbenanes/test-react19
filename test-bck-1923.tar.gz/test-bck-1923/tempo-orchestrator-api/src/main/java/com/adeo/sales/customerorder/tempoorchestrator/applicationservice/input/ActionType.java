package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.input;

public enum ActionType {
    DECREASE_QUANTITY, SPLIT

}
