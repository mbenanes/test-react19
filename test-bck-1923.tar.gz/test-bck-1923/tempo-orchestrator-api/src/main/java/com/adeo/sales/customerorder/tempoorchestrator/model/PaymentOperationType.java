package com.adeo.sales.customerorder.tempoorchestrator.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Optional;
import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public enum PaymentOperationType {
    CANCEL_AUTHORIZATION_REQUESTED(CustomerOrderLinePaymentExecutionStatus.CANCEL_AUTHORIZATION_REQUESTED),
    AUTHORIZATION_PENDING(null),
    AUTHORIZATION_DELAYED(null),
    AUTHORIZATION_REJECTED(null),
    AUTHORIZED(null),
    AUTHORIZATION_CANCELED(CustomerOrderLinePaymentExecutionStatus.CANCELED_AUTHORIZATION),
    AUTHORIZATION_CANCEL_FAILED(CustomerOrderLinePaymentExecutionStatus.CANCEL_AUTHORIZATION_FAILED),
    CAPTURED(CustomerOrderLinePaymentExecutionStatus.CAPTURED),
    CAPTURE_REQUESTED(CustomerOrderLinePaymentExecutionStatus.CAPTURE_REQUESTED),
    CAPTURE_FAILED(CustomerOrderLinePaymentExecutionStatus.CAPTURE_FAILED),
    CANCEL_CAPTURE_REQUESTED(CustomerOrderLinePaymentExecutionStatus.CANCEL_CAPTURE_REQUESTED),
    CANCEL_CAPTURE_FAILED(CustomerOrderLinePaymentExecutionStatus.CANCEL_CAPTURE_FAILED),
    REFUND_DELAYED(CustomerOrderLinePaymentExecutionStatus.REFUND_DELAYED),
    REFUND_FAILED(CustomerOrderLinePaymentExecutionStatus.REFUND_FAILED),
    CAPTURE_CANCELED(CustomerOrderLinePaymentExecutionStatus.CAPTURE_CANCELED);

    private CustomerOrderLinePaymentExecutionStatus legacyStatus;

    public static final Set<PaymentOperationType> STATUS_ACCEPTING_CAPTURE = EnumSet.of(
        AUTHORIZED, AUTHORIZATION_CANCEL_FAILED, CAPTURE_FAILED
    );

    public static Optional<PaymentOperationType> getByLegacyStatus(CustomerOrderLinePaymentExecutionStatus legacyStatus) {
        return Arrays.stream(PaymentOperationType.values())
            .filter(status -> status.getLegacyStatus() == legacyStatus)
            .findFirst();
    }
}
