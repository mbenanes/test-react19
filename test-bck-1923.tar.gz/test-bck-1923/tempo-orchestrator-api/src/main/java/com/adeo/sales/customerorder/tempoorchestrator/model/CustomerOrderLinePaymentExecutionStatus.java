package com.adeo.sales.customerorder.tempoorchestrator.model;

import java.util.EnumSet;
import java.util.Set;

public enum CustomerOrderLinePaymentExecutionStatus {
    CAPTURE_REQUESTED,
    CAPTURED,
    REFUND_DELAYED,
    REFUND_FAILED,
    CAPTURE_FAILED,
    CANCEL_AUTHORIZATION_REQUESTED,
    CANCELED_AUTHORIZATION,
    CANCEL_AUTHORIZATION_FAILED,
    CANCEL_CAPTURE_REQUESTED,
    CANCEL_CAPTURE_FAILED,
    CAPTURE_CANCELED,
    NONE,
    UNKNOWN;

    public static final Set<CustomerOrderLinePaymentExecutionStatus> STATUS_ACCEPTING_CAPTURE = EnumSet.of(
        CustomerOrderLinePaymentExecutionStatus.NONE, CustomerOrderLinePaymentExecutionStatus.UNKNOWN
    );

    public static boolean acceptCancelAuthorization(CustomerOrderLinePaymentExecutionStatus status) {
        return CustomerOrderLinePaymentExecutionStatus.NONE == status;
    }

    public static boolean acceptCancelCapture(CustomerOrderLinePaymentExecutionStatus status) {
        return CustomerOrderLinePaymentExecutionStatus.CAPTURED == status;
    }
}
