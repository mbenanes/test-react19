package com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions;


import com.adeo.sales.customerorder.tempoorchestrator.exception.CustomerOrderNotFound;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.support.WebExchangeBindException;
import org.springframework.web.server.ServerWebInputException;
import reactor.core.publisher.Mono;

import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@Slf4j
@RestControllerAdvice
public class ExceptionHandling {

    @ExceptionHandler(ConstraintViolationException.class)
    protected ResponseEntity<?> handleConstraintViolationException(ConstraintViolationException ex) {
        try {

            final List<ErrorResponse> errorResponses = ex.getConstraintViolations().stream().map(constraintViolation -> ErrorResponse.builder().code(HttpStatus.BAD_REQUEST.name()).title(constraintViolation.getPropertyPath().toString()).detail(constraintViolation.getMessage()).build()).toList();
            final var body = ErrorResponses.builder()
                .errors(errorResponses)
                .build();
            return ResponseEntity.badRequest().body(body);
        } catch (Exception e) {
            final ErrorResponse body = ErrorResponse.builder().detail(ex.getMessage()).title(ex.getMessage()).build();
            return ResponseEntity.internalServerError().body(body);
        }

    }

    @ExceptionHandler(ServerWebInputException.class)
    public ResponseEntity<ErrorResponses> handleInputException(ServerWebInputException exception) {
        final var error = ErrorResponse.builder()
                .code("BAD_REQUEST")
                .detail(exception.getReason())
                .title(exception.getReason())
                .build();

        final var body = ErrorResponses.builder()
            .errors(List.of(error))
            .build();

        return ResponseEntity.badRequest().body(body);
    }

    @ExceptionHandler(WebExchangeBindException.class)
    public ResponseEntity<ErrorResponses> handleValidationError(WebExchangeBindException exception) {
        final var validationException = exception.getAllErrors();

        final var errors = validationException.stream()
                .map(this::convertToErrorResponse)
                .collect(Collectors.toList());

        final var body = ErrorResponses.builder()
            .errors(errors)
            .build();

        return ResponseEntity.badRequest().body(body);
    }

    @ExceptionHandler(HttpConvertibleException.class)
    public ResponseEntity<ErrorResponses> handlerHttpConvertibleException(HttpConvertibleException exception) {
        log.warn("http response error - {}" ,exception.getMessage(), exception);
        final var errors = exception.toErrors();

        return ResponseEntity.badRequest().body(errors);
    }

    @ExceptionHandler({CustomerOrderNotFound.class})
    public Mono<ResponseEntity<String>> customerOrderNotFound(Exception ex) {
        return Mono.just(ResponseEntity.status(NOT_FOUND).body(ex.getMessage()));
    }

    @ExceptionHandler(CallNotPermittedException.class)
    public ResponseEntity<ErrorResponses> handlerCallNotPermittedException(CallNotPermittedException exception) {
        log.error("http response error - circuit breaker is open: {}", exception.getMessage());
        final var error = ErrorResponse.builder()
            .code("DEPENDENT_SERVER_UNREACHABLE")
            .title("can not contact dependent server because circuit breaker is open")
            .detail(exception.getMessage())
            .build();

        final var body = ErrorResponses.builder()
            .errors(List.of(error))
            .build();

        return ResponseEntity.internalServerError().body(body);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponses> handleUnknownError(Throwable exception) {
        log.error(exception.getMessage(), exception);
        final var error = ErrorResponse.builder()
            .title("Internal error")
            .code("INTERNAL_ERROR")
            .build();

        final var body = ErrorResponses.builder()
            .errors(List.of(error))
            .build();

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
    }

    public ErrorResponse convertToErrorResponse(ObjectError objectError) {
        try {
        String code = objectError.getCode();
        String message;
        if (objectError instanceof FieldError) {
            message = ((FieldError) objectError).getField() + " " + objectError.getDefaultMessage();
        } else {
            message = objectError.getDefaultMessage();
        }

            return ErrorResponse.builder()
                .detail(message)
                .code(code)
                .build();
        } catch (IllegalArgumentException ie) {
            // do nothing, because this error will append
            // when the source of the object error is not related to our usecase
            // and it's don't mean anything
        }
        return ErrorResponse.builder().build();
    }
}
