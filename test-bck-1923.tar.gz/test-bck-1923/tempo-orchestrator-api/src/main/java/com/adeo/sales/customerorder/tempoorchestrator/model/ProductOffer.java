package com.adeo.sales.customerorder.tempoorchestrator.model;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductOffer {
    @Getter
    private String id;
    @Getter
    private Integer version;
    @Getter
    public List<ProductOfferLine> items;

    public Optional<ProductOfferLine> getOfferLineById(String id) {
        return this.items.stream().filter(offerLine -> offerLine.getId().equals(id)).findFirst();
    }

    /**
     * properties not used now, but persisted on database
     * This is use by Jackson to serialize/deserialize properties not mapped on Java class
     */
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private Map<String, Object> ignoredProperties = new HashMap<>();

    @JsonAnyGetter
    public Map<String, Object> any() {
        return ignoredProperties;
    }

    @JsonAnySetter
    public void set(String name, Object value) {
        ignoredProperties.put(name, value);
    }

}
