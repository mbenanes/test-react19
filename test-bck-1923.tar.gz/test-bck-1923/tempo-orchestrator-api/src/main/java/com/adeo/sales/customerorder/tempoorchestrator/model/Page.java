package com.adeo.sales.customerorder.tempoorchestrator.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class Page<T> {

    private int count;
    private int totalPageCount;
    private List<T> items;

    public static <T> Page<T> page(int count, int perPage, List<T> items) {
        return new Page<>(count, (int) Math.ceil((double) count / (double) perPage), items);
    }
}
