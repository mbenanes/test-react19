package com.adeo.sales.customerorder.tempoorchestrator.repository.impl;

import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.Line;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperation;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation.PaymentOperationType;
import com.adeo.sales.customerorder.tempoorchestrator.repository.PaymentRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.r2dbc.spi.Row;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Map;


@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentPostgresRepository implements PaymentRepository {
    private final DatabaseClient readerDatabaseClient;
    private final ObjectMapper objectMapper;

    @Override
    public Flux<PaymentOperation> getByCustomerOrderId(String customerOrderId, String buCode) {
        final var select = "select id, bu_code, customer_order_id, customer_order_version, transaction_id, operation, " +
            "payment_mean, amount, status, operation_date, lines, payment_external_data " +
            "from payment_operation " +
            "where payment_operation.customer_order_id = :customerOrderId and payment_operation.bu_code = :buCode";

        return this.readerDatabaseClient
            .sql(select)
            .bind("customerOrderId", customerOrderId)
            .bind("buCode", buCode)
            .map(this::mapPaymentOperation)
            .all();
    }

    @Override
    public Flux<PaymentOperation> getByCustomerOrderIdAndOperationId(String customerOrderId, String buCode, final List<String> operationIds) {
        final var select = "select id, bu_code, customer_order_id, customer_order_version, transaction_id, operation, " +
            "payment_mean, amount, status, operation_date, lines, payment_external_data " +
            "from payment_operation " +
            "where customer_order_id = :customerOrderId and bu_code = :buCode and id in (:operationIds)";

        return this.readerDatabaseClient
            .sql(select)
            .bind("customerOrderId", customerOrderId)
            .bind("buCode", buCode)
            .bind("operationIds", operationIds)
            .map(this::mapPaymentOperation)
            .all();
    }

    private PaymentOperation mapPaymentOperation(Row row) {
        return PaymentOperation.builder()
            .id(row.get("id", String.class))
            .buCode(row.get("bu_code", String.class))
            .customerOrderId(row.get("customer_order_id", String.class))
            .customerOrderVersion(row.get("customer_order_version", Integer.class))
            .transactionId(row.get("transaction_id", String.class))
            .operation(PaymentOperationType.valueOf(row.get("operation", String.class)))
            .paymentMean(row.get("payment_mean", String.class))
            .amount(row.get("amount", BigDecimal.class))
            .status(PaymentOperationStatus.valueOf(row.get("status", String.class)))
            .operationDate(row.get("operation_date", Instant.class))
            .lines(deserialize(row.get("lines", String.class)))
            .paymentExternalData(deserializePaymentExternalData(row.get("payment_external_data", String.class)))
            .build();
    }

    private Map<String, String> deserializePaymentExternalData(String paymentExternalData) {
        try {
            if (StringUtils.isEmpty(paymentExternalData)) {
                return Collections.emptyMap();
            }
            return objectMapper.readValue(paymentExternalData, new TypeReference<>() {
            });
        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }

    private List<Line> deserialize(String lines) {
        try {
            return objectMapper.readValue(lines, new TypeReference<>() {
            });
        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }
}
