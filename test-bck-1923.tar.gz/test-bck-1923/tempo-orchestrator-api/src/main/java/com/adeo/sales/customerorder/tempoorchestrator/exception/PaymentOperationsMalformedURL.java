package com.adeo.sales.customerorder.tempoorchestrator.exception;

import org.apache.commons.lang3.StringUtils;

import java.util.List;

public class PaymentOperationsMalformedURL extends RuntimeException {

    public PaymentOperationsMalformedURL(String message) {
        super(message);
    }

    public PaymentOperationsMalformedURL(String customerOrderId, String buCode, List<String> operationIds) {
        super(String.format("data used to retrieve payment operations are inconsistent : bu_code [%s], customer_order_id [%s], operation_ids [%s]",
            buCode, customerOrderId, StringUtils.join(operationIds, "-")));
    }
}
