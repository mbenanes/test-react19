package com.adeo.sales.customerorder.tempoorchestrator.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.Objects;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class LinePaymentOperationHistory {
    private String operationId;
    private PaymentOperationType operationType;
    private PaymentOperationStatus status;
    private String lineId;
    private String customerOrderId;
    private String transactionId;
    private String buCode;
    private OffsetDateTime captureAllowedBefore;
    private Boolean isCaptureGuarantee;
    private Boolean alertRequested;
    private String paymentMean;

    private LocalDateTime createdAt;

    @JsonIgnore
    public boolean isCaptureNotGuarantee() {
        return !this.isCaptureGuarantee;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LinePaymentOperationHistory that = (LinePaymentOperationHistory) o;
        return (Objects.equals(operationId, that.operationId)
            || Objects.equals(operationId, transactionId)
            || Objects.equals(that.operationId, that.transactionId))
            && operationType == that.operationType
            && status == that.status
            && Objects.equals(lineId, that.lineId)
            && Objects.equals(customerOrderId, that.customerOrderId)
            && Objects.equals(transactionId, that.transactionId)
            && Objects.equals(buCode, that.buCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(operationId, operationType, lineId, customerOrderId, transactionId, status, buCode);
    }
}
