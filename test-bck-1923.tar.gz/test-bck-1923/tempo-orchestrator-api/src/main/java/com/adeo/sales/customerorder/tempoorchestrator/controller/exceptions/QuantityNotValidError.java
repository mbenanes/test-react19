package com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions;

public class QuantityNotValidError extends HttpConvertibleException {

    private static final long serialVersionUID = 1L;

    public QuantityNotValidError(String error) {
        super(error);
    }

    @Override
    public ErrorResponse toError() {
        return ErrorResponse.builder()
            .code("QUANTITY_NOT_VALID_ISSUE")
            .title("The quantity requested is more than the executed quantity.")
            .detail(this.getMessage())
            .build();
    }
}
