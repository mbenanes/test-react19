package com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation;


public enum PaymentOperationStatus {
    REGISTERED, PENDING, ACCEPTED, REJECTED, TECHNICALLY_FAILED, NOT_MANAGED
}
