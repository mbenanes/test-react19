package com.adeo.sales.customerorder.tempoorchestrator.model;

public enum CustomerOrderPlaceType {
    ONLINE,
    IN_STORE;
}
