package com.adeo.sales.customerorder.tempoorchestrator.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class ProductOfferLine {
    private String id;
    private int position;
    private Offer offer;
    private BigDecimal quantity;
    private BigDecimal initialOrderedQuantity;
    private String status;
    private String cancelationReason;
}
