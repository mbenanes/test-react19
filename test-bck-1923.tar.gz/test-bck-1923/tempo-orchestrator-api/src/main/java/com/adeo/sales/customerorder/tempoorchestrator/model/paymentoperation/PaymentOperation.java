package com.adeo.sales.customerorder.tempoorchestrator.model.paymentoperation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentOperation {
    private String id;
    private String buCode;
    private String customerOrderId;
    private Integer customerOrderVersion;
    private List<Line> lines = new ArrayList<>();
    private String transactionId;
    private PaymentOperationType operation;
    private String paymentMean;
    private BigDecimal amount;
    private PaymentOperationStatus status;
    private Instant operationDate;
    private Map<String, String> paymentExternalData;
}
