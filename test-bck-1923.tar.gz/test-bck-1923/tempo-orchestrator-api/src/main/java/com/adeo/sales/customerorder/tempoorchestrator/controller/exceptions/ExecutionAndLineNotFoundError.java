package com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions;


public class ExecutionAndLineNotFoundError extends HttpConvertibleException {

    private static final long serialVersionUID = 1L;

    public ExecutionAndLineNotFoundError(String error) {
        super(error);
    }

    @Override
    public ErrorResponse toError() {
        return ErrorResponse.builder()
            .code("EXECUTION_AND_LINE_NOT_FOUND_ISSUE")
            .title("The execution and line cannot be found.")
            .detail(this.getMessage())
            .build();
    }
}
