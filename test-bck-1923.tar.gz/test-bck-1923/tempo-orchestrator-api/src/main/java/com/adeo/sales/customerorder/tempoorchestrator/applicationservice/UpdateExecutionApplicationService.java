package com.adeo.sales.customerorder.tempoorchestrator.applicationservice;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.input.ExecutionData;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.input.LineData;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.input.UpdateExecutionInput;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions.ExecutionAndLineNotFoundError;
import com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions.LineNotCancelableError;
import com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions.QuantityNotValidError;
import com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions.SplittedExecutionNotManagedError;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.ExecutionToUpdate;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.UpdateExecution;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.UserOrLdap;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionActionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LineExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.encoder.org.apache.commons.lang3.BooleanUtils;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@AllArgsConstructor
@Slf4j
public class UpdateExecutionApplicationService {

    private final EventProducer eventProducer;
    private final LineExecutionRepository lineExecutionRepository;
    private final ExecutionActionRepository executionActionRepository;
    private final TopicsProperties topicsProperties;

    public Mono<Void> applyV1(UpdateExecutionInput input) {
        return lineExecutionRepository.getByCustomerOrderId(input.getCustomerOrderId(), input.getBuCode())
            .filter(lineExecution -> input.getExecutionsToUpdate().stream().anyMatch(
                executionData -> executionData.getLineData().stream().anyMatch(
                    lineData -> lineData.getLineId().equals(lineExecution.getLineId())
                )))
            .collect(Collectors.groupingBy(LineExecution::getExecutionId))
            .flatMap(this::checkNoSplittedExecutionForImpactedLines)
            .flatMap(updatedLinesByExecution -> {
                input.setExecutionsToUpdate(mapExecutionWithExecutionId(updatedLinesByExecution, input));
                return Mono.just(input);
            })
            .flatMap(this::apply);
    }

    //FIXME .get() on optional.
    private List<ExecutionData> mapExecutionWithExecutionId(Map<String, List<LineExecution>> updatedLinesByExecution, UpdateExecutionInput input) {
        return updatedLinesByExecution.entrySet().stream().map(
                linesByExecution -> ExecutionData.builder()
                    .executionId(linesByExecution.getKey())
                    .lineData(linesByExecution.getValue().stream().map(lineExecution -> input.getExecutionsToUpdate().get(0).getLineData()
                            .stream()
                            .filter(lineData -> lineData.getLineId().equals(lineExecution.getLineId()))
                            .findFirst()
                            .map(inputLine -> LineData.builder()
                                .lineId(lineExecution.getLineId())
                                .quantity(inputLine.getQuantity())
                                .reason(inputLine.getReason())
                                .build())
                            .orElse(LineData.builder()
                                .lineId(lineExecution.getLineId())
                                .build()))
                        .collect(Collectors.toList()))
                    .build())
            .collect(Collectors.toList());
    }

    private Mono<Map<String, List<LineExecution>>> checkNoSplittedExecutionForImpactedLines(Map<String, List<LineExecution>> updatedLinesByExecution) {
        return Mono.just(updatedLinesByExecution.values().stream().flatMap(List::stream).collect(Collectors.toList()))
            .filter(lineExecutions -> lineExecutions.stream().map(LineExecution::getLineId).distinct().count() == lineExecutions.size())
            .flatMap(lineExecutions -> Mono.just(updatedLinesByExecution))
            .switchIfEmpty(Mono.error(new SplittedExecutionNotManagedError("Splitted execution found")));
    }

    public Mono<Void> apply(UpdateExecutionInput input) {
        return Flux.fromIterable(input.getExecutionsToUpdate())
            .flatMap(executionData -> Flux.fromIterable(executionData.getLineData())
                .flatMap(lineData -> Mono.zip(executionActionRepository.getExecutionActionsFromOrder(executionData.getExecutionId(), lineData.getLineId(), ExecutionActionType.valueOf(input.getAction().name()))
                            .filter(executionAction -> executionAction.getImpactedExecutions().stream()
                                .filter(impactedExecution -> impactedExecution.getInitialExecutionId().equals(executionData.getExecutionId()))
                                .anyMatch(impactedExecution -> impactedExecution.getImpactedLines().stream()
                                    .anyMatch(impactedLineAndQuantity -> impactedLineAndQuantity.getLineId().equals(lineData.getLineId()))
                                )
                            )
                            .collectList(),
                        lineExecutionRepository.getFromExecutionAndLine(executionData.getExecutionId(), lineData.getLineId()).collectList())
                    .filter(tuple2 -> !tuple2.getT2().isEmpty())
                    .switchIfEmpty(Mono.error(new ExecutionAndLineNotFoundError("No data found for execution " + executionData.getExecutionId() + " and  line " + lineData.getLineId())))
                    .filter(tuple2 -> tuple2.getT2().get(0).getInitialQuantity().compareTo(getSumOfQuantityDecreaseRequestedForLineId(tuple2.getT1(), lineData)) >= 0)
                    .switchIfEmpty(Mono.error(new QuantityNotValidError("Decrease quantity requested is more than executed quantity for execution " + executionData.getExecutionId() + " and  line " + lineData.getLineId())))
                    .filter(tuple2 -> tuple2.getT2().stream().allMatch(lineExecution -> lineExecution.getComposition().isCancelable() || BooleanUtils.isTrue(lineExecution.getDelivery().getForceCancelable())))
                    .switchIfEmpty(Mono.error(new LineNotCancelableError("Decrease quantity is forbidden for execution " + executionData.getExecutionId() + " and  line " + lineData.getLineId())))
                    .thenReturn(lineData)
                ))
            .collect(Collectors.toList())
            .flatMap(stringListEntry -> sendActionCommand(input))
            .then();
    }

    private Mono<Void> sendActionCommand(UpdateExecutionInput input) {
        final var event = UpdateExecution.newBuilder()
            .setRequestSourceId(input.getRequestId())
            .setCustomerOrderId(input.getCustomerOrderId())
            .setBuCode(input.getBuCode())
            .setAppSource(input.getAppSource())
            .setActionType(input.getAction().name())
            .setRequestedBy(UserOrLdap.newBuilder()
                .setIdentifier(input.getOwnerRequest().getIdentifier())
                .setUserType(input.getOwnerRequest().getOperatorType().name())
                .build())
            .setExecutionToUpdate(input.getExecutionsToUpdate().stream()
                .map(executionData -> ExecutionToUpdate.newBuilder()
                    .setExecutionPlanId(executionData.getExecutionId())
                    .setImpactedLines(executionData.getLineData().stream()
                        .map(lineData -> com.adeo.sales.customerorder.tempoorchestrator.event.command.ImpactedLine.newBuilder()
                            .setLineId(lineData.getLineId())
                            .setQuantity(lineData.getQuantity())
                            .setReason(lineData.getReason())
                            .build())
                        .collect(Collectors.toList())
                    )
                    .build()).collect(Collectors.toList())
            )
            .build();
        return eventProducer.sendEvents(topicsProperties.getUdpateExecutionCommand(), input.getCustomerOrderId(), input.getBuCode(), event);
    }

    private BigDecimal getSumOfQuantityDecreaseRequestedForLineId(List<ExecutionAction> executionActions, LineData line) {
        BigDecimal lineQuantity = line.getQuantity();
        BigDecimal sumOfQuantityDecrease = executionActions.stream()
            .flatMap(executionAction -> executionAction.getImpactedExecutions().stream())
            .flatMap(impactedExecution -> impactedExecution.getImpactedLines().stream())
            .filter(actionLineData -> actionLineData.getLineId().equals(line.getLineId()))
            .map(ImpactedLine::getQuantity)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        return lineQuantity.add(sumOfQuantityDecrease);
    }
}
