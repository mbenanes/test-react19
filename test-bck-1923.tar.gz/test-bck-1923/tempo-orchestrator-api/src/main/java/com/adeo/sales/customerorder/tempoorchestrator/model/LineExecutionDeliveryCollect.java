package com.adeo.sales.customerorder.tempoorchestrator.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LineExecutionDeliveryCollect {
    private String collectId;
    private Flags<CollectStatus> flags = new Flags<>();
    private OffsetDateTime appointmentDate;
    private OffsetDateTime newAppointmentDate;
    private String collectLineIdentifier;
    private NotificationStatus appointmentReminderNotificationStatus;
    private NotificationStatus pickupDeliveredNotificationStatus;
    private NotificationStatus appointmentExpiredNotificationStatus;
    private BigDecimal deliveredQuantity;
    private CollectStatus globalCollectStatus;


    public Flags<CollectStatus> getFlags() {
        if(this.flags == null) {
            this.flags = new Flags<>();
        }
        return flags;
    }

    public String getCollectId(){
        if(this.collectId != null) {
            return this.collectId;
        } else if (this.getFlags().getLastFlag() != null && this.getFlags().getLastFlag().getOperationId() != null) {
            return this.getFlags().getLastFlag().getOperationId();
        }

        return null;
    }
}
