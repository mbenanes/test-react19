package com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.paymentoperations;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderLine {
    private String id;
    private String type;
}
