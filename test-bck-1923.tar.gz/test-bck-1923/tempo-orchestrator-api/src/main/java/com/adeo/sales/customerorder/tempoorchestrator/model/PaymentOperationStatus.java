package com.adeo.sales.customerorder.tempoorchestrator.model;

public enum PaymentOperationStatus {
    SUCCEED,
    REJECTED,
    TECHNICALLY_FAILED,
    DELAYED,
    PENDING;

    public static PaymentOperationStatus mapFromString(String value) {
        if("ACCEPTED".equals(value)) {
            return SUCCEED;
        } else {
            return PaymentOperationStatus.valueOf(value);
        }
    }
}
