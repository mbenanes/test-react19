package com.adeo.sales.customerorder.tempoorchestrator.configuration.database;

import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.pool.ConnectionPoolConfiguration;
import io.r2dbc.spi.ConnectionFactories;
import io.r2dbc.spi.ConnectionFactory;
import io.r2dbc.spi.ConnectionFactoryOptions;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.r2dbc.core.DefaultReactiveDataAccessStrategy;
import org.springframework.data.r2dbc.core.R2dbcEntityOperations;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.data.r2dbc.dialect.MySqlDialect;
import org.springframework.r2dbc.connection.R2dbcTransactionManager;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.transaction.ReactiveTransactionManager;

@Configuration
public class WriterDatabaseConfig {
    @Bean
    @Qualifier("writerConnectionFactory")
    public ConnectionFactory writerConnectionFactory(@Value("${spring.r2dbc.writer.url}") String url,
                                                     @Value("${spring.r2dbc.writer.username}") String user,
                                                     @Value("${spring.r2dbc.writer.password}") String password,
                                                     @Value("${spring.r2dbc.writer.sslRequired:false}") boolean sslRequired,
                                                      @Value("${spring.r2dbc.writer.sslMode:disable}") String sslMode
    ) {

        return ConnectionFactories.get(ConnectionFactoryOptions.parse(url)
            .mutate()
            .option(ConnectionFactoryOptions.USER, user)
            .option(ConnectionFactoryOptions.PASSWORD, password)
            .option(ConnectionFactoryOptions.SSL, sslRequired)
            .option(ConnectionFactoryOptions.DRIVER, "postgresql")
            .option(io.r2dbc.spi.Option.valueOf("sslMode"), sslMode)
            .build());
    }

    @Bean
    public R2dbcEntityOperations writerEntityOperations(@Qualifier("writerConnectionFactory") ConnectionFactory connectionFactory) {

        DefaultReactiveDataAccessStrategy strategy = new DefaultReactiveDataAccessStrategy(MySqlDialect.INSTANCE);

        DatabaseClient databaseClient = DatabaseClient.builder()
            .connectionFactory(connectionFactory)
            .build();

        return new R2dbcEntityTemplate(databaseClient, strategy);
    }

    @Bean
    public DatabaseClient writerDatabaseClient(@Qualifier("writerConnectionFactory") ConnectionFactory connectionFactory) {
        return DatabaseClient.create(connectionFactory);
    }

    @Primary
    @Bean
    public ConnectionPool writerConnectionPool(@Qualifier("writerConnectionFactory") ConnectionFactory connectionFactory,
                                               @Value("${spring.r2dbc.writer.pool.initialSize:10}") int initialSize,
                                               @Value("${spring.r2dbc.writer.pool.maxSize:10}") int maxSize) {
        ConnectionPoolConfiguration configuration = ConnectionPoolConfiguration.builder(connectionFactory)
            .initialSize(initialSize)
            .maxSize(maxSize)
            .build();

        return new ConnectionPool(configuration);
    }

    @Bean
    public ReactiveTransactionManager writerTransactionManager(@Qualifier("writerConnectionFactory") ConnectionFactory connectionFactory) {

        return new R2dbcTransactionManager(connectionFactory);
    }
}
