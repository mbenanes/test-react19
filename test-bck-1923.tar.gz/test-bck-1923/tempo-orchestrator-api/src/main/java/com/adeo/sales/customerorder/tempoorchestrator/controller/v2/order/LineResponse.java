package com.adeo.sales.customerorder.tempoorchestrator.controller.v2.order;

import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.CashingResponse;
import com.adeo.sales.customerorder.tempoorchestrator.model.CollectStatus;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class LineResponse {

    @ApiModelProperty(notes = "the unique identifier of the customer order line.", example = "f8ba3b85-3e5d-475c-a952-a0a2e5f856ba")
    private String id;
    @ApiModelProperty(notes = "Represents the state of the delivery.")
    private DeliveryResponse delivery;
    @ApiModelProperty(notes = "Represents the state of payment.")
    private CashingResponse cashing;
    @ApiModelProperty(notes = "A list of action execution id, related to this line.", example = "{f8ba3b85-3e5d-475c-a952-a0a2e5f856ba, 21bc6b54-799f-46bb-b107-e3c920df7567}")
    private List<String> updateExecutionActionIds;
    @ApiModelProperty(notes = "The initial ordered quantity.", example = "2.0")
    private BigDecimal initialQuantity;
    @ApiModelProperty(notes = "The current remaining quantity.", example = "1.0")
    private BigDecimal quantity;
    @ApiModelProperty(notes = "The already executed quantity (collected, shipped or delivered).", example = "1.0")
    private BigDecimal executedQuantity;
    @ApiModelProperty(notes = "The cancelled quantity.", example = "1.0")
    private BigDecimal canceledQuantity;
    @ApiModelProperty(notes = "The pending cancellation quantity.", example = "1.0")
    private BigDecimal pendingCancellationQuantity;
    @ApiModelProperty(notes = "If true, the line accept a regular quantity decrease request.")
    private boolean editableQuantity;
    @ApiModelProperty(notes = "If true, the line accept a forced quantity decrease request.", example = "f8ba3b85-3e5d-475c-a952-a0a2e5f856ba")
    private boolean forceEditableQuantity;
    @ApiModelProperty(notes = "The COC collect status for this line.")
    private CollectStatus collectLineStatus;

}
