package com.adeo.sales.customerorder.tempoorchestrator.controller.dtos;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
@NoArgsConstructor
public class UpdateEstimatedDeliveryDateBody {
    @NotEmpty
    private String customerOrderId;

    @NotEmpty
    private List<DeliveryDateUpdate> deliveryDates;
}
