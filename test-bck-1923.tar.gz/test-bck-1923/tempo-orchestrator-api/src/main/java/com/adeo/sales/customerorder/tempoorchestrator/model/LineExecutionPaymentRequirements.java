package com.adeo.sales.customerorder.tempoorchestrator.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LineExecutionPaymentRequirements {

    private Flags<RequirementStatus> validationFlags;
    private Flags<RequirementStatus> stockReservationFlags;
    private Flags<RequirementStatus> confirmationFlags;
    private Flags<RequirementStatus> vendorOrderCreationFlags;
    private Flags<RequirementStatus> preparationFlags;
    private Flags<RequirementStatus> shippingFlags;
    private Flags<RequirementStatus> deliveryFlags;
    private Flags<RequirementStatus> ownerShippedTransfertFlags;
    private String amount;


    public Flags<RequirementStatus> getValidationFlags() {
        if (this.validationFlags == null) {
            this.validationFlags = new Flags<>();
        }
        return validationFlags;
    }

    public Flags<RequirementStatus> getStockReservationFlags() {
        if (this.stockReservationFlags == null) {
            this.stockReservationFlags = new Flags<>();
        }
        return stockReservationFlags;
    }

    public Flags<RequirementStatus> getConfirmationFlags() {
        if (this.confirmationFlags == null) {
            this.confirmationFlags = new Flags<>();
        }
        return confirmationFlags;
    }

    public Flags<RequirementStatus> getVendorOrderCreationFlags() {
        if (this.vendorOrderCreationFlags == null) {
            this.vendorOrderCreationFlags = new Flags<>();
        }
        return vendorOrderCreationFlags;
    }

    public Flags<RequirementStatus> getPreparationFlags() {
        if (this.preparationFlags == null) {
            this.preparationFlags = new Flags<>();
        }
        return preparationFlags;
    }

    public Flags<RequirementStatus> getShippingFlags() {
        if (this.shippingFlags == null) {
            this.shippingFlags = new Flags<>();
        }
        return shippingFlags;
    }

    public Flags<RequirementStatus> getDeliveryFlags() {
        if (this.deliveryFlags == null) {
            this.deliveryFlags = new Flags<>();
        }
        return deliveryFlags;
    }

    public Flags<RequirementStatus> getOwnerShippedTransfertFlags() {
        if (this.ownerShippedTransfertFlags == null) {
            this.ownerShippedTransfertFlags = new Flags<>();
        }
        return ownerShippedTransfertFlags;
    }
}
