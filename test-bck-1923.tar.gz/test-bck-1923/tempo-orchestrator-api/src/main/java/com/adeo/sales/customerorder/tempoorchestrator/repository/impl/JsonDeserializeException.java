package com.adeo.sales.customerorder.tempoorchestrator.repository.impl;

public class JsonDeserializeException extends RuntimeException {
    public JsonDeserializeException(Throwable cause) {
        super("Error deserializing entity to json from database.", cause);
    }
}
