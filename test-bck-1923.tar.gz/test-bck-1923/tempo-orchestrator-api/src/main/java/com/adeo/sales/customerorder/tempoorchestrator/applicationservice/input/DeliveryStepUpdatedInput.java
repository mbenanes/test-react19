package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.input;

import com.adeo.sales.customerorder.tempoorchestrator.model.DeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.model.ShippingPoint;
import lombok.Builder;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Builder
@Getter
public class DeliveryStepUpdatedInput {
    private final List<Line> lines;
    private final String customerOrderId;
    private final String buCode;

    public Optional<Line> getLine(String lineId) {
        return lines.stream()
            .filter(line -> line.lineId.equals(lineId))
            .findFirst();
    }

    public List<String> lineIds() {
        return this.lines.stream()
            .map(line -> line.lineId)
            .collect(Collectors.toList());
    }

    @Builder
    @Getter
    public static class Line {
        private final String lineId;
        private final Boolean isCancelable;
        private final StepStatus status;
        private final String storeCode;
        private final String incoterm;
        private final ShippingPoint shippingPoint;
        private final DeliveryDate estimatedDeliveryDate;
        private final String legacyOrderNumber;
    }

}
