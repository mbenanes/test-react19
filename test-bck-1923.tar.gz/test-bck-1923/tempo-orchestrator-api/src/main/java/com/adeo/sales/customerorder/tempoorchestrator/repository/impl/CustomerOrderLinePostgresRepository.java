package com.adeo.sales.customerorder.tempoorchestrator.repository.impl;

import com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLineStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.Page;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderLineRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.BU_CODE;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.CUSTOMER_ORDER_ID;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.ID;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.IDS;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.OFFSET;
import static com.adeo.sales.customerorder.tempoorchestrator.repository.RepositoryConstants.PER_PAGE;

@Slf4j
@Component
@RequiredArgsConstructor
public class CustomerOrderLinePostgresRepository implements CustomerOrderLineRepository {

    private final ObjectMapper objectMapper;
    private final DatabaseClient readerDatabaseClient;

    @Override
    public Mono<Page<CustomerOrderLine>> getPageOfCustomerOrderLines(final List<String> ids, String buCode, final int page, final int perPage) {
        final var count = this.readerDatabaseClient
            .sql("select count(1) from customer_order_line where id in (:ids) and data->>'buCode' = :buCode")
            .bind(IDS, ids)
            .bind(BU_CODE, buCode)
            .map(row -> row.get(0, Integer.class))
            .one();

        final var lines = this.readerDatabaseClient
            .sql("select data, customer_order_id, customer_order_version " +
                " from customer_order_line where id in (:id) and data->>'buCode' = :buCode " +
                " order by customer_order_id,(data->>'position')::integer" +
                " OFFSET :offset LIMIT :perPage"
            )
            .bind(ID, ids)
            .bind(BU_CODE, buCode)
            .bind(PER_PAGE, perPage)
            .bind(OFFSET, (page - 1) * perPage)
            .map(row -> deserialize(
                row.get("data", String.class),
                row.get("customer_order_id", String.class),
                row.get("customer_order_version", Integer.class)
            ))
            .all()
            .doOnNext(CustomerOrderLineStatus::cleanUpStatus);

        return lines.collectList().zipWith(count)
            .map(tuple -> Page.page(tuple.getT2(), perPage, tuple.getT1()));
    }

    @Override
    public Flux<CustomerOrderLine> getByCustomerOrderId(String customerOrderId, String buCode) {
        var select = "select data, customer_order_id, customer_order_version from customer_order_line " +
            "where customer_order_id = :customerOrderId and data->>'buCode' = :buCode";

        return this.readerDatabaseClient
            .sql(select)
            .bind(CUSTOMER_ORDER_ID, customerOrderId)
            .bind(BU_CODE, buCode)
            .map(row -> deserialize(
                row.get("data", String.class),
                row.get("customer_order_id", String.class),
                row.get("customer_order_version", Integer.class)
            ))
            .all()
            .doOnNext(CustomerOrderLineStatus::cleanUpStatus);
    }

    private CustomerOrderLine deserialize(String data, String customerOrderId, Integer customerOrderVersion) {
        try {
            final var customerOrderLine = objectMapper.readValue(data, CustomerOrderLine.class);
            customerOrderLine.setCustomerOrder(
                CustomerOrder.builder()
                    .id(customerOrderId)
                    .version(customerOrderVersion)
                    .buCode(customerOrderLine.getBuCode())
                    .build()
            );
            return customerOrderLine;
        } catch (Exception exception) {
            throw new JsonDeserializeException(exception);
        }
    }
}
