package com.adeo.sales.customerorder.tempoorchestrator.model;

public enum LineType {
    OFFER, LOYALTY_FEE, SERVICE
}
