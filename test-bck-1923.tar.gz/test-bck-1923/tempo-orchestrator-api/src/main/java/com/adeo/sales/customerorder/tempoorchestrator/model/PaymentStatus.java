package com.adeo.sales.customerorder.tempoorchestrator.model;

public enum PaymentStatus {
    OWNERSHIP_TRANSFER_REQUESTED,
    OWNERSHIP_TRANSFER_REJECTED,
    OWNERSHIP_TRANSFERRED,
    DEPOSIT_CANCELED,
    REFUND_FAILED,
    NONE;

    public static boolean acceptOwnershipTransfer(PaymentStatus status) {
        return NONE == status || status == null;
    }

    public static boolean ownershipTransferStartedOrDone(PaymentStatus status) {
        return OWNERSHIP_TRANSFER_REQUESTED == status || OWNERSHIP_TRANSFERRED == status;
    }
}
