package com.adeo.sales.customerorder.tempoorchestrator.model;

public enum PaymentPlaceType {
    ONLINE,
    IN_STORE;
}
