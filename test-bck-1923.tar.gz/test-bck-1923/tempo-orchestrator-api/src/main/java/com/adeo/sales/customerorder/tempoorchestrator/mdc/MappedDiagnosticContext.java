package com.adeo.sales.customerorder.tempoorchestrator.mdc;

import brave.Span;
import brave.Tracer;
import brave.Tracing;
import brave.propagation.ExtraFieldPropagation;
import brave.propagation.TraceContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@Component
public class MappedDiagnosticContext {

    public static final String SOURCE_ID_KEY = "source_id";
    public static final String SOURCE_TYPE_KEY = "source_type";
    public static final String SOURCE_CONTEXT_KEY = "source_context";
    public static final String CUSTOMER_ORDER_ID_KEY = "customer_order_id";
    public static final String CUSTOMER_ORDER_VERSION_KEY = "customer_order_version";
    public static final String CUSTOMER_ID_KEY = "customer_id";
    public static final String BU_CODE_KEY = "bu_code";

    public static final String RULE_ENGINE_CURRENT_RULE_KEY = "rule_engine_current_rule";

    private static final String SOURCE_TYPE_EVENT_VALUE = "event";
    private static final String SOURCE_TYPE_REST_VALUE = "rest";

    private static final String NONE_VALUE = "none";
    private static final String MISSING_VALUE = "missing";

    private final Tracing tracing;

    private final Tracer tracer;

    public MappedDiagnosticContext(Tracing tracing, Tracer tracer) {
        this.tracing = tracing;
        this.tracer = tracer;
    }

    public void injectRestBU(String buCode, String endpoint) {
        enrichCurrentSpan(Map.of(
            SOURCE_ID_KEY, UUID.randomUUID().toString(),
            SOURCE_TYPE_KEY, SOURCE_TYPE_REST_VALUE,
            SOURCE_CONTEXT_KEY, stringOrMissing(endpoint),
            BU_CODE_KEY, stringOrMissing(buCode)
        ));
    }
    public void injectRestData(String buCode, String endpoint, String customerOrderId) {
        enrichCurrentSpan(Map.of(
            SOURCE_ID_KEY, UUID.randomUUID().toString(),
            SOURCE_TYPE_KEY, SOURCE_TYPE_REST_VALUE,
            SOURCE_CONTEXT_KEY, stringOrMissing(endpoint),
            CUSTOMER_ORDER_ID_KEY, stringOrMissing(customerOrderId),
            BU_CODE_KEY, stringOrMissing(buCode)
        ));
    }

    public void enrichCurrentSpan(String key, String value) {
        this.enrichCurrentSpan(Map.of(key, value));
    }
    private void enrichCurrentSpan(Map<String, String> data) {
        if (tracer != null
            && tracer.currentSpan() != null
            && tracing.currentTraceContext() != null) {
            Span currentSpan = tracer.currentSpan();
            enrichSpan(currentSpan, data);
            tracing.currentTraceContext().newScope(currentSpan.context());
        }
    }

    private void enrichSpan(Span span, Map<String, String> data) {
        TraceContext currentSpanContext = span.context();
        data.forEach((key, value) -> {
            if (!NONE_VALUE.equals(value)) {
                ExtraFieldPropagation.set(currentSpanContext, key, value);
                span.tag(key, value);
            }
        });
    }

    public static String stringOrNone(String data) {
        return Optional.ofNullable(data).orElse(NONE_VALUE);
    }

    public static String objectStringOrNone(Object data) {
        if (data == null) {
            return NONE_VALUE;
        }
        return data.toString();
    }

    public static String stringOrMissing(String data) {
        return stringOrMissing(Optional.ofNullable(data));
    }

    public static String stringOrMissing(Optional<String> data) {
        return data.orElse(MISSING_VALUE);
    }

    public static String objectStringOrMissing(Object data) {
        if (data == null) {
            return MISSING_VALUE;
        }
        return data.toString();
    }
}
