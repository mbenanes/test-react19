package com.adeo.sales.customerorder.tempoorchestrator.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LineExecutionPayment {

    public enum PaymentExecutionSystem {
        TPP, PSR
    }

    private String depositLegacyNumber;
    private String cashierLegacyNumber;
    private String paymentScheduleId;
    private String storeId;
    private Boolean isCaptureGuarantee;
    private boolean isOwnershipTransferred;
    private OffsetDateTime captureAllowedBefore;
    private LegacyNumbersStatus legacyNumbersStatus;

    private LineExecutionPaymentExecution paymentExecution;
    private PaymentExecutionSystem paymentExecutionSystem;

    private Flags<PaymentStatus> flags = new Flags<>();

    public LineExecutionPaymentExecution getPaymentExecution() {
        if (this.paymentExecution == null) {
            this.paymentExecution = new LineExecutionPaymentExecution();
        }
        return paymentExecution;
    }

    private boolean isDelayedPayment;
    private boolean isDepositLegacyNumberNotOwnedByTor;

    public Flags<PaymentStatus> getFlags() {
        if (this.flags == null) {
            this.flags = new Flags<>();
        }
        return flags;
    }
}
