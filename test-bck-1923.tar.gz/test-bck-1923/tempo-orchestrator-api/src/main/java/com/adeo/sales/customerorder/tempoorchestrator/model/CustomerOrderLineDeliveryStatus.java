package com.adeo.sales.customerorder.tempoorchestrator.model;

public enum CustomerOrderLineDeliveryStatus {
    RESERVATION_REQUESTED,
    PREPARATION_REQUESTED,
    CREATION_REQUESTED,
    CREATION_FAILED,
    HANDOVER_STARTED,
    RESERVED,
    CREATED,
    ACCEPTED,
    RELEASED,
    SHIPPING_REQUESTED,
    SHIPPED,
    ABORT_REQUESTED,
    ABORT_FAILED,
    REJECTED,
    CANCELED,
    ABORTED,
    PENDING_CANCELLATION,
    RECEIVED,
    CLOSED;
}
