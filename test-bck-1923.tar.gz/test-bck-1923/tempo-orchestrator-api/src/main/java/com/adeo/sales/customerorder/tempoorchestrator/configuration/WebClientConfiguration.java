package com.adeo.sales.customerorder.tempoorchestrator.configuration;

import com.adeo.sales.customerorder.external.api.client.configuration.api.ApiProperty;
import com.adeo.sales.customerorder.external.api.client.configuration.api.ExternalApiProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
@RequiredArgsConstructor
public class WebClientConfiguration {
    private final WebClient.Builder defaultBuilder;
    private final ExternalApiProperties apiProperties;

    @Bean
    public WebClient tempoOrchestratorWebClient() {
        return fillWebClientBuilderWithApiData(apiProperties.getTempoOrchestrator());
    }

    private WebClient fillWebClientBuilderWithApiData(ApiProperty apiProperty) {
        WebClient.Builder innerBuilder = defaultBuilder.clone()
            .baseUrl(apiProperty.getUrl())
            .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);

        return innerBuilder.build();
    }
}
