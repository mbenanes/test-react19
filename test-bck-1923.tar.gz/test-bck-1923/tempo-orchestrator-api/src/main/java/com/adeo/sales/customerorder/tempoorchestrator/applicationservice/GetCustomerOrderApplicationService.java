package com.adeo.sales.customerorder.tempoorchestrator.applicationservice;

import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.CashingResponse;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.CustomerOrderLineResponse;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.CustomerOrderResponse;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.DeliveryDateResponseAndRequest;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.DeliveryResponse;
import com.adeo.sales.customerorder.tempoorchestrator.controller.v2.order.OwnerRequest;
import com.adeo.sales.customerorder.tempoorchestrator.exception.CustomerOrderNotFound;
import com.adeo.sales.customerorder.tempoorchestrator.exception.LineExecutionsDoesNotExist;
import com.adeo.sales.customerorder.tempoorchestrator.model.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLine;
import com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrderLinePaymentStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.DeliveryDate;
import com.adeo.sales.customerorder.tempoorchestrator.model.Flag;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecutionPayment;
import com.adeo.sales.customerorder.tempoorchestrator.model.PaymentStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.RequirementStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.ShippingPoint;
import com.adeo.sales.customerorder.tempoorchestrator.model.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderLineRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionActionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LineExecutionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;

import static com.adeo.sales.customerorder.tempoorchestrator.model.PaymentOperationType.AUTHORIZED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.PaymentOperationType.CAPTURED;
import static com.adeo.sales.customerorder.tempoorchestrator.model.PaymentOperationType.CAPTURE_REQUESTED;

@Component
@RequiredArgsConstructor
@Slf4j
public class GetCustomerOrderApplicationService {

    public static final Predicate<LineExecution> IS_AT_LEAST_AUTHORIZED = lineExecution -> lineExecution.getPayment().getPaymentExecution().getFlags().hasFlagIsOneOf(List.of(AUTHORIZED, CAPTURE_REQUESTED, CAPTURED));
    public static final Predicate<LineExecution> IS_CONFIRMED_REQUIREMENT_COMPLIANT = lineExecution -> lineExecution.getPaymentRequirements().getConfirmationFlags().lastFlagIs(RequirementStatus.COMPLIANT);
    public static final Predicate<LineExecution> IS_OWNERSHIP_TRANSFERED = lineExecution -> lineExecution.getPayment().getFlags().hasFlag(PaymentStatus.OWNERSHIP_TRANSFERRED);

    private final CustomerOrderLineRepository customerOrderLineRepository;
    private final CustomerOrderRepository customerOrderRepository;
    private final LineExecutionRepository lineExecutionRepository;
    private final ExecutionActionRepository executionActionRepository;
    private final ExecutionRepository executionRepository;

    public Mono<CustomerOrderResponse> apply(String customerOrderId, String buCode) {
        return this.customerOrderRepository.getById(customerOrderId, buCode)
            .switchIfEmpty(Mono.error(new CustomerOrderNotFound(customerOrderId, buCode)))
            .flatMap(customerOrder -> Mono.zip(
                    this.lineExecutionRepository.getByCustomerOrderId(customerOrderId, buCode)
                        .switchIfEmpty(Mono.error(new LineExecutionsDoesNotExist(customerOrderId)))
                        .collectList(),
                    this.executionActionRepository.getExecutionActionsFromOrder(customerOrderId, buCode)
                        .collectList(),
                    this.executionRepository.getExecutionFromOrder(customerOrderId, buCode)
                        .collectList()
                )
                .map(tuple -> buildCustomerOrderResponseFromLineExecutions(customerOrder, tuple.getT1(), tuple.getT2(), tuple.getT3())))
            .onErrorResume(LineExecutionsDoesNotExist.class, lineExecutionsDoesNotExist -> {
                log.info("V2 line not found for customer order {}", customerOrderId);
                return this.customerOrderLineRepository.getByCustomerOrderId(customerOrderId, buCode)
                    .switchIfEmpty(Mono.error(new CustomerOrderNotFound(customerOrderId, buCode)))
                    .collectList()
                    .map(customerOrderLines -> buildCustomerOrderResponseFromCustomerOrderLines(customerOrderId, customerOrderLines));
            });
    }

    private boolean isPaid(final LineExecution lineExecution) {
        if (LineExecutionPayment.PaymentExecutionSystem.PSR.equals(lineExecution.getPayment().getPaymentExecutionSystem())) {
            return IS_AT_LEAST_AUTHORIZED.test(lineExecution);
        } else {
            return IS_CONFIRMED_REQUIREMENT_COMPLIANT.test(lineExecution) || IS_OWNERSHIP_TRANSFERED.test(lineExecution);
        }
    }

    private CustomerOrderResponse buildCustomerOrderResponseFromCustomerOrderLines(String customerOrderId, List<CustomerOrderLine> customerOrderLines) {
        return CustomerOrderResponse.builder()
            .id(customerOrderId)
            .customerOrderLines(customerOrderLines.stream()
                .map(customerOrderLine -> CustomerOrderLineResponse.builder()
                    .id(customerOrderLine.getId())
                    .delivery(DeliveryResponse.builder()
                        .initialPromiseDate(toDeliveryDateResponse(customerOrderLine.getInitialPromiseDate()))
                        .customerKnownDeliveryDate(toDeliveryDateResponse(customerOrderLine.getCustomerKnownDeliveryDate()))
                        .estimatedDeliveryDate(toDeliveryDateResponse(customerOrderLine.getEstimatedDeliveryDate()))
                        .shippingPoint(mapShippingPoint(customerOrderLine.getId(), customerOrderLine.getShippingPoint()))
                        .build())
                    .cashing(CashingResponse.builder()
                        .ownershipTransferred(CustomerOrderLinePaymentStatus.OWNERSHIP_TRANSFERRED.name().equals(customerOrderLine.getPaymentStatus()))
                        .build())
                    .build())
                .toList())
            .build();
    }


    private CustomerOrderResponse buildCustomerOrderResponseFromLineExecutions(CustomerOrder customerOrder, List<LineExecution> lineExecutions, List<ExecutionAction> executionActions, List<Execution> executions) {

        return CustomerOrderResponse.builder()
            .id(customerOrder.getId())
            .dematCode(customerOrder.getDematCode())
            .placeType(customerOrder.getOrderPlaceType() != null ? customerOrder.getOrderPlaceType().name() : null)
            .paymentPlaceType(customerOrder.getPaymentPlaceType())
            .executionPlanId(!executions.isEmpty() ? executions.get(0).getId() : null)
            .executionPlanStatus(!executions.isEmpty() && executions.get(0).getExecutionStatus().getLastFlag() != null ? executions.get(0).getExecutionStatus().getLastFlag().getType() : null)
            .paid(isPaid(lineExecutions.get(0)))
            .collectStatus(CollectStatus.fromString(customerOrder.getCollectStatus()))
            .customerOrderLines(lineExecutions.stream()
                .map(lineExecution -> CustomerOrderLineResponse.builder()
                    .id(lineExecution.getLineId())
                    .delivery(buildDeliveryResponseFromLineExecution(lineExecution))
                    .cashing(CashingResponse.builder()
                        .ownershipTransferred(lineExecution.getPayment().isOwnershipTransferred())
                        .build())
                    .updateExecutionActionIds(!executionActions.isEmpty() ? extractListOfExecutionRequestId(executionActions, lineExecution) : null
                    )
                    .build())
                .toList())
            .updateExecutionActions(!executionActions.isEmpty() ? mapExecutionAction(executionActions) : null)
            .build();
    }

    @NotNull
    private static List<String> extractListOfExecutionRequestId(List<ExecutionAction> executionActions, LineExecution lineExecution) {
        return executionActions.stream()
            .filter(executionAction -> executionAction.getImpactedExecutions().stream()
                .anyMatch(impactedExecution -> impactedExecution.getImpactedLines().stream()
                    .anyMatch(impactedLine -> Objects.equals(impactedLine.getLineId(), lineExecution.getLineId()))
                )
            ).map(ExecutionAction::getRequestId).toList();
    }

    private List<com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.ExecutionAction> mapExecutionAction(List<ExecutionAction> executionActions) {
        return executionActions.stream().map(executionAction -> {
            final OwnerRequest ownerRequest = executionAction.getOwnerRequest();

            String ldap = OwnerRequest.OperatorType.COLLABORATOR.equals(ownerRequest.getOperatorType()) ? ownerRequest.getIdentifier(): null;
            String userId = OwnerRequest.OperatorType.CUSTOMER.equals(ownerRequest.getOperatorType()) ? ownerRequest.getIdentifier(): null;

            return com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.ExecutionAction.builder()
                .ldap(ldap)
                .userId(userId)
                .ownerRequest(executionAction.getOwnerRequest())
                .createdAt(executionAction.getCreatedAt())
                .lastFlag(executionAction.getLastFlag())
                .flags(executionAction.getFlags())
                .requestId(executionAction.getRequestId())
                .actionType(executionAction.getActionType() != null ? ExecutionActionType.fromString(executionAction.getActionType()) : null)
                .impactedExecutions(mapImpactedExecutions(executionAction.getImpactedExecutions()))
                .build();
        }).toList();
    }

    private List<com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.customerorderinfo.ImpactedExecution> mapImpactedExecutions(List<ImpactedExecution> impactedExecutions) {
        return Optional.ofNullable(impactedExecutions).orElse(Collections.emptyList()).stream().map(impactedExecution -> com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.customerorderinfo.ImpactedExecution.builder()
            .executionPlanId(impactedExecution.getInitialExecutionId())
            .impactedLines(mapImpactedLines(impactedExecution.getImpactedLines()))
            .build()).toList();
    }

    private List<com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.ImpactedLine> mapImpactedLines(List<ImpactedLine> impactedLineAndQuantities) {
        return Optional.ofNullable(impactedLineAndQuantities).orElse(Collections.emptyList()).stream().map(impactedLineAndQuantity -> com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.ImpactedLine.builder()
                .lineId(impactedLineAndQuantity.getLineId())
                .quantity(impactedLineAndQuantity.getQuantity())
                .reason(impactedLineAndQuantity.getReason())
                .build())
            .toList();
    }

    private DeliveryResponse buildDeliveryResponseFromLineExecution(LineExecution lineExecution) {
        final DeliveryResponse.DeliveryResponseBuilder deliveryResponseBuilder = DeliveryResponse.builder()
            .shippingPoint(mapShippingPoint(lineExecution.getLineId(), lineExecution.getDelivery().getShippingPoint()));

        if (lineExecution.getDelivery().getCollect().getFlags().hasFlags()) {
            final Flag lastFlag = lineExecution.getDelivery().getCollect().getFlags().getLastFlag();
            OffsetDateTime lastModifiedCollectStatusDateTime = lastFlag.getDateTime();
            deliveryResponseBuilder.collectId(lastFlag.getOperationId())
                .collectStatus(CollectStatus.valueOf(lastFlag.getType()))
                .lastModifiedCollectStatusDate(lastModifiedCollectStatusDateTime)
                .collectAppointmentDate(lineExecution.getDelivery().getCollect().getAppointmentDate());
        }

        deliveryResponseBuilder.initialPromiseDate(toDeliveryDateResponse(lineExecution.getDelivery().getInitialPromiseDate()))
            .customerKnownDeliveryDate(toDeliveryDateResponse(lineExecution.getDelivery().getCustomerKnownDeliveryDate()))
            .estimatedDeliveryDate(toDeliveryDateResponse(lineExecution.getDelivery().getEstimatedDeliveryDate()));

        return deliveryResponseBuilder.build();
    }


    private DeliveryResponse.ShippingPoint mapShippingPoint(String orderLine, ShippingPoint shippingPoint) {
        if (shippingPoint != null) {
            try {
                return DeliveryResponse.ShippingPoint.valueOf(shippingPoint.name());
            } catch (IllegalArgumentException illegalArgumentException) {
                log.error("Error when map shipping point {} from customer order line {} ", orderLine, shippingPoint.name());
            }
        }
        return null;
    }

    private DeliveryDateResponseAndRequest toDeliveryDateResponse(DeliveryDate deliveryDate) {
        if (deliveryDate == null) {
            return null;
        }
        return new DeliveryDateResponseAndRequest(deliveryDate);
    }
}
