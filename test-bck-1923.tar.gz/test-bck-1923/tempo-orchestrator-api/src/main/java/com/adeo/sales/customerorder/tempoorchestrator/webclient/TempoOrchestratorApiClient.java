package com.adeo.sales.customerorder.tempoorchestrator.webclient;

import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.UpdateEstimatedDeliveryDateBody;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Mono;

public interface TempoOrchestratorApiClient {
    Mono<ResponseEntity<Void>> updateEstimatedDeliveryDate(String buCode, UpdateEstimatedDeliveryDateBody updateEstimatedDeliveryDateBody);
}
