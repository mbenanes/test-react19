package com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions;


public class SplittedExecutionNotManagedError extends HttpConvertibleException {

    private static final long serialVersionUID = 1L;

    public SplittedExecutionNotManagedError(String error) {
        super(error);
    }

    @Override
    public ErrorResponse toError() {
        return ErrorResponse.builder()
            .code("SPLITTED_EXECUTION_NOT_MANAGED_IN_V1")
            .title("More than one execution found for a line.")
            .detail(this.getMessage())
            .build();
    }
}
