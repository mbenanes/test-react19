package com.adeo.sales.customerorder.tempoorchestrator.webclient;

import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.UpdateEstimatedDeliveryDateBody;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import static com.adeo.sales.customerorder.external.api.client.HeaderNames.BU_CODE;

@Slf4j
@Component
@RequiredArgsConstructor
public class TempoOrchestratorApiWebClient implements TempoOrchestratorApiClient {

    public static final String API_NAME = "tempo-orchestrator";

    private final WebClient tempoOrchestratorWebClient;

    @Override
    @CircuitBreaker(name = API_NAME)
    @Retry(name = API_NAME)
    public Mono<ResponseEntity<Void>> updateEstimatedDeliveryDate(String buCode, UpdateEstimatedDeliveryDateBody updateEstimatedDeliveryDateBody) {
        return tempoOrchestratorWebClient.post()
            .uri("/update-estimated-delivery-date")
            .header(BU_CODE, buCode)
            .bodyValue(updateEstimatedDeliveryDateBody)
            .retrieve()
            .toBodilessEntity();
    }
}
