package com.adeo.sales.customerorder.tempoorchestrator.model;

public enum  CustomerOrderLinePaymentStatus {
    OWNERSHIP_TRANSFER_REQUESTED,
    OWNERSHIP_TRANSFERRED,
    DEPOSIT_CANCELED,
    REFUND_FAILED,
    NONE;

    public static boolean acceptOwnershipTransfer(CustomerOrderLinePaymentStatus status) {
        return CustomerOrderLinePaymentStatus.NONE == status || status == null;
    }

    public static boolean ownershipTransferStartedOrDone(CustomerOrderLinePaymentStatus status) {
        return CustomerOrderLinePaymentStatus.OWNERSHIP_TRANSFER_REQUESTED == status || CustomerOrderLinePaymentStatus.OWNERSHIP_TRANSFERRED == status;
    }
}
