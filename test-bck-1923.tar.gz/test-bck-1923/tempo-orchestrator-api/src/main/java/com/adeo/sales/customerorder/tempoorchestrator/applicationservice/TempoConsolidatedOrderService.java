package com.adeo.sales.customerorder.tempoorchestrator.applicationservice;

import com.adeo.sales.customerorder.external.api.client.tco.TcoApiClient;
import com.adeo.sales.customerorder.external.api.client.tco.dto.TempoConsolidatedOrder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Slf4j
@RequiredArgsConstructor
@Component
public class TempoConsolidatedOrderService {
    private final TcoApiClient tcoApiClient;

    public Mono<TempoConsolidatedOrder> getTempoConsolidatedOrder(String customerOrderId, String buCode) {
        return tcoApiClient.getTempoConsolidatedOrder(customerOrderId, buCode);
    }
}
