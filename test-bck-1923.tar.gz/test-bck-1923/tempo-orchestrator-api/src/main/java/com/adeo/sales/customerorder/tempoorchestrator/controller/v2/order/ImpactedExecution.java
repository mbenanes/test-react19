package com.adeo.sales.customerorder.tempoorchestrator.controller.v2.order;

import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.ImpactedLine;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@NoArgsConstructor
public class ImpactedExecution {
    @NotNull
    private String executionId;
    @NotEmpty
    private List<ImpactedLine> impactedLines;
}
