package com.adeo.sales.customerorder.tempoorchestrator.model.executionaction;

public enum ExecutionActionStatus {
    CREATED, PENDING, PROCESSING, COMPLETED, CANCELED
}
