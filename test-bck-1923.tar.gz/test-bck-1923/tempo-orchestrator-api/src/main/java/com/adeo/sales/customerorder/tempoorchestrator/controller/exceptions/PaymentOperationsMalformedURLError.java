package com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions;


import com.adeo.sales.customerorder.tempoorchestrator.exception.PaymentOperationsMalformedURL;

public class PaymentOperationsMalformedURLError extends HttpConvertibleException {

    private static final long serialVersionUID = 1L;

    public PaymentOperationsMalformedURLError(PaymentOperationsMalformedURL error) {
        super(error.getMessage());
    }

    @Override
    public ErrorResponse toError() {
        return ErrorResponse.builder()
            .code("PAYMENT_OPERATIONS_ISSUE")
            .title("The payment operations cannot be found")
            .detail(this.getMessage())
            .build();
    }
}
