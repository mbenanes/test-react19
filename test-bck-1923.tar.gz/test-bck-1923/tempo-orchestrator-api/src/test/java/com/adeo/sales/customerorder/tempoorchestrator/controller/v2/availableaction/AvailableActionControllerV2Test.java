package com.adeo.sales.customerorder.tempoorchestrator.controller.v2.availableaction;

import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.AvailableActions;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.Pagination;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.Response;
import com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.ExternalSystem;
import com.adeo.sales.customerorder.tempoorchestrator.model.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.Page;
import com.adeo.sales.customerorder.tempoorchestrator.model.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.execution.ExecutionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionActionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LineExecutionRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

@SpringBootTest
@AutoConfigureWebTestClient
class AvailableActionControllerV2Test {

    private static final String CUSTOMER_ORDER_ID = UUID.randomUUID().toString();
    private static final String ADEO_BU_CODE = "001";

    private final ObjectMapper objectMapper = new ObjectMapper();

    List<LineExecution> lineExecutions;

    @MockBean
    private LineExecutionRepository lineExecutionRepository;
    @MockBean
    private ExecutionActionRepository executionActionRepository;
    @MockBean
    private CustomerOrderRepository customerOrderRepository;
    @MockBean
    private ExecutionRepository executionRepository;
    @Autowired
    private WebTestClient webClient;


    @BeforeEach
    void setUp() throws IOException {
        objectMapper.registerModule(new Jdk8Module());
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.registerModule(new ParameterNamesModule());
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        this.lineExecutions = objectMapper.readValue(this.getClass().getResource("/data/customerorder/line-execution.json"), new TypeReference<>(){});

        final Flags<ExecutionStatus> executionStatusFlags = new Flags<>();
        executionStatusFlags.raiseFlag(ExecutionStatus.CREATED);

        final List<Execution> executions = lineExecutions.stream().map(LineExecution::getExecutionId).distinct()
            .map(executionId -> Execution.builder().customerOrderId(CUSTOMER_ORDER_ID).executionStatus(executionStatusFlags).id(executionId).build()).toList();

        CustomerOrder customerOrder = objectMapper.readValue(this.getClass().getResource("/data/customerorder/customer-order.json"), CustomerOrder.class);

        Mockito.when(lineExecutionRepository.getByCustomerOrderId(CUSTOMER_ORDER_ID, ADEO_BU_CODE)).thenReturn(Flux.fromIterable(lineExecutions));
        Mockito.when(executionActionRepository.getExecutionActionsFromOrder(CUSTOMER_ORDER_ID, ADEO_BU_CODE)).thenReturn(Flux.empty());
        Mockito.when(customerOrderRepository.getById(CUSTOMER_ORDER_ID, ADEO_BU_CODE)).thenReturn(Mono.just(customerOrder));
        Mockito.when(executionRepository.getExecutionFromOrder(CUSTOMER_ORDER_ID, ADEO_BU_CODE)).thenReturn(Flux.fromIterable(executions));
    }

    @Test
    void getAvailableActions() throws JsonProcessingException {
        String executionId = this.lineExecutions.get(0).getExecutionId() ;
        String lineId = this.lineExecutions.get(0).getLineId() ;
        AvailableActionsRequest availableActionsRequest = new AvailableActionsRequest();
        availableActionsRequest.setExecutionPlanId(executionId);
        availableActionsRequest.setCustomerOrderCartItemId(lineId);

        final Page<LineExecution> page = Page.page(1, 20, List.of(lineExecutions.get(0)));

        Mockito.when(lineExecutionRepository.getPageOfLinesByLineIdAndExecutionId(List.of(availableActionsRequest), ADEO_BU_CODE, 1, 20)).thenReturn(Mono.just(page));

        AvailableActions availableActions = AvailableActions.builder()
                .customerOrderLineId(lineId)
                .executionPlanId(executionId)
                .isCancelable(false)
                .isDeliveryDateUpdatable(false)
                .isForceCancelable(false)
                .isUpdatable(false)
                .system(AvailableActions.System.builder()
                        .name(ExternalSystem.SystemName.BOMP.name())
                        .reference(ADEO_BU_CODE+"-"+lineExecutions.get(0).getComposition().getOrderPartNumber())
                        .build())
                .build();

        final Response<List<AvailableActions>> listResponse = new Response<>(List.of(availableActions), new Pagination(1, 1));

        webClient.post().uri("/available-actions")
            .header("Adeo-Bu-Code", ADEO_BU_CODE)
            .header("X-API-Version", "2")
            .body(BodyInserters.fromObject(List.of(availableActionsRequest)))
            .exchange()
            .expectStatus().isOk()
                .expectBody().json(objectMapper.writeValueAsString(listResponse));
    }
}
