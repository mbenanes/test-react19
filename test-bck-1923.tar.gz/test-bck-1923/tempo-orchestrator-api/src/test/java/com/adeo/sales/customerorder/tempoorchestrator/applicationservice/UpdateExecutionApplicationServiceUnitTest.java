package com.adeo.sales.customerorder.tempoorchestrator.applicationservice;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.input.ActionType;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.input.ExecutionData;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.input.LineData;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.input.UpdateExecutionInput;
import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions.ExecutionAndLineNotFoundError;
import com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions.QuantityNotValidError;
import com.adeo.sales.customerorder.tempoorchestrator.controller.exceptions.SplittedExecutionNotManagedError;
import com.adeo.sales.customerorder.tempoorchestrator.controller.v2.order.OwnerRequest;
import com.adeo.sales.customerorder.tempoorchestrator.event.command.UpdateExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecutionComposition;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ImpactedLine;
import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionActionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LineExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.event.EventProducer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;
import util.FluxMock;
import util.MonoMock;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.adeo.sales.customerorder.tempoorchestrator.controller.v2.order.OwnerRequest.OperatorType.CUSTOMER;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UpdateExecutionApplicationServiceUnitTest {
    @Mock
    private LineExecutionRepository lineExecutionRepository;

    @Mock
    private ExecutionActionRepository executionActionRepository;

    @Mock
    private EventProducer eventProducer;

    private UpdateExecutionApplicationService updateExecutionApplicationService;
    private final TopicsProperties topicsProperties = new TopicsProperties();

    @BeforeEach
    void setUp() {
        topicsProperties.setUdpateExecutionCommand(List.of("test"));
        updateExecutionApplicationService = new UpdateExecutionApplicationService(eventProducer, lineExecutionRepository, executionActionRepository, topicsProperties);
    }

    @Test
    void should_send_event_when_all_is_OK() {

        final var executionData = Map.of("order1", Map.of("exec1", Map.of(1, List.of("line1", "line2")), "exec2", Map.of(1, List.of("line3", "line4"))));
        final var allLines = generateLines(executionData);
        FluxMock<LineExecution> existingExec1Line1 = FluxMock.fromIterable(allLines.stream().filter(lineExecution -> lineExecution.getExecutionId().equals("exec1") && lineExecution.getLineId().equals("line1")).collect(Collectors.toList()));

        FluxMock<ExecutionAction> existingAction = FluxMock.empty();
        MonoMock<Void> savedEvent = MonoMock.empty();

        when(lineExecutionRepository.getFromExecutionAndLine("exec1", "line1"))
            .thenReturn(existingExec1Line1);
        when(executionActionRepository.getExecutionActionsFromOrder(anyString(), anyString(), any(ExecutionActionType.class)))
            .thenReturn(existingAction);
        when(eventProducer.sendEvents(anyList(), anyString(), anyString(), any(UpdateExecution.class)))
            .thenReturn(savedEvent);

        final var input = UpdateExecutionInput.builder()
            .action(ActionType.DECREASE_QUANTITY)
            .customerOrderId("order1")
            .buCode("001")
            .appSource("TEST")
            .requestId("request1")
            .ownerRequest(OwnerRequest.builder()
                .identifier("1234")
                .operatorType(CUSTOMER)
                .build())
            .executionsToUpdate(List.of(ExecutionData.builder()
                .executionId("exec1")
                .lineData(List.of(LineData.builder()
                    .lineId("line1")
                    .quantity(BigDecimal.ONE)
                    .reason("test")
                    .build()))
                .build())).build();

        StepVerifier.create(updateExecutionApplicationService.apply(input)).verifyComplete();

        existingExec1Line1.expectHasBeenSubscribed();

        existingAction.expectHasBeenSubscribed();
        savedEvent.expectHasBeenSubscribed();

    }

    @Test
    void should_send_event_when_all_is_OK_V1_compatibility() {

        final var executionData = Map.of("order1", Map.of("exec1", Map.of(1, List.of("line1", "line2")), "exec2", Map.of(1, List.of("line3", "line4"))));
        final var allLines = generateLines(executionData);
        FluxMock<LineExecution> existingExec1Line1 = FluxMock.fromIterable(allLines.stream().filter(lineExecution -> lineExecution.getExecutionId().equals("exec1") && lineExecution.getLineId().equals("line1")).collect(Collectors.toList()));

        FluxMock<ExecutionAction> existingAction = FluxMock.empty();
        MonoMock<Void> savedEvent = MonoMock.empty();

        when(lineExecutionRepository.getFromExecutionAndLine("exec1", "line1"))
            .thenReturn(existingExec1Line1);
        when(executionActionRepository.getExecutionActionsFromOrder(anyString(), anyString(), any(ExecutionActionType.class)))
            .thenReturn(existingAction);
        when(eventProducer.sendEvents(anyList(), anyString(), anyString(), any(UpdateExecution.class)))
            .thenReturn(savedEvent);
        when(lineExecutionRepository.getByCustomerOrderId("order1", "001")).thenReturn(Flux.fromIterable(allLines));

        final var input = UpdateExecutionInput.builder()
            .action(ActionType.DECREASE_QUANTITY)
            .customerOrderId("order1")
            .buCode("001")
            .appSource("TEST")
            .requestId("request1")
            .ownerRequest(OwnerRequest.builder()
                .identifier("1234")
                .operatorType(CUSTOMER)
                .build())
            .executionsToUpdate(List.of(ExecutionData.builder()
                .executionId("order1")
                .lineData(List.of(LineData.builder()
                    .lineId("line1")
                    .quantity(BigDecimal.ONE)
                    .reason("test")
                    .build()))
                .build())).build();

        StepVerifier.create(updateExecutionApplicationService.applyV1(input)).verifyComplete();

        existingExec1Line1.expectHasBeenSubscribed();

        existingAction.expectHasBeenSubscribed();
        savedEvent.expectHasBeenSubscribed();

    }

    @Test
    void should_send_event_when_all_is_OK_with_multiple_executions() {

        final var executionData = Map.of("order1", Map.of("exec1", Map.of(1, List.of("line1", "line2")), "exec2", Map.of(1, List.of("line3", "line4"))));
        final var allLines = generateLines(executionData);
        FluxMock<LineExecution> existingExec1Line1 = FluxMock.fromIterable(allLines.stream().filter(lineExecution -> lineExecution.getExecutionId().equals("exec1") && lineExecution.getLineId().equals("line1")).collect(Collectors.toList()));
        FluxMock<LineExecution> existingExec2Line4 = FluxMock.fromIterable(allLines.stream().filter(lineExecution -> lineExecution.getExecutionId().equals("exec2") && lineExecution.getLineId().equals("line4")).collect(Collectors.toList()));

        FluxMock<ExecutionAction> existingAction = FluxMock.empty();
        MonoMock<Void> savedEvent = MonoMock.empty();

        when(lineExecutionRepository.getFromExecutionAndLine("exec1", "line1"))
            .thenReturn(existingExec1Line1);
        when(lineExecutionRepository.getFromExecutionAndLine("exec2", "line4"))
            .thenReturn(existingExec2Line4);
        when(executionActionRepository.getExecutionActionsFromOrder(anyString(), anyString(), any(ExecutionActionType.class)))
            .thenReturn(existingAction);
        when(eventProducer.sendEvents(anyList(), anyString(), anyString(), any(UpdateExecution.class)))
            .thenReturn(savedEvent);

        final var input = UpdateExecutionInput.builder()
            .action(ActionType.DECREASE_QUANTITY)
            .requestId("request1")
            .customerOrderId("order1")
            .buCode("001")
            .appSource("TEST")
            .ownerRequest(OwnerRequest.builder()
                .identifier("1234")
                .operatorType(CUSTOMER)
                .build())
            .executionsToUpdate(List.of(ExecutionData.builder()
                    .executionId("exec1")
                    .lineData(List.of(LineData.builder()
                        .lineId("line1")
                        .quantity(BigDecimal.ONE)
                        .reason("test")
                        .build()))
                    .build(),
                ExecutionData.builder()
                    .executionId("exec2")
                    .lineData(List.of(LineData.builder()
                        .lineId("line4")
                        .quantity(BigDecimal.ONE)
                        .reason("test")
                        .build()))
                    .build())).build();

        StepVerifier.create(updateExecutionApplicationService.apply(input)).verifyComplete();

        existingExec1Line1.expectHasBeenSubscribed();
        existingExec2Line4.expectHasBeenSubscribed();

        existingAction.expectHasBeenSubscribed();
        savedEvent.expectHasBeenSubscribed();

    }

    @Test
    void should_send_event_when_all_is_OK_with_multiple_executions_V1_compatibility() {

        final var executionData = Map.of("order1", Map.of("exec1", Map.of(1, List.of("line1", "line2")), "exec2", Map.of(1, List.of("line3", "line4"))));
        final var allLines = generateLines(executionData);
        FluxMock<LineExecution> existingExec1Line1 = FluxMock.fromIterable(allLines.stream().filter(lineExecution -> lineExecution.getExecutionId().equals("exec1") && lineExecution.getLineId().equals("line1")).collect(Collectors.toList()));
        FluxMock<LineExecution> existingExec2Line4 = FluxMock.fromIterable(allLines.stream().filter(lineExecution -> lineExecution.getExecutionId().equals("exec2") && lineExecution.getLineId().equals("line4")).collect(Collectors.toList()));

        FluxMock<ExecutionAction> existingAction = FluxMock.empty();
        MonoMock<Void> savedEvent = MonoMock.empty();

        when(lineExecutionRepository.getByCustomerOrderId("order1", "001"))
            .thenReturn(Flux.fromIterable(allLines));
        when(lineExecutionRepository.getFromExecutionAndLine("exec1", "line1"))
            .thenReturn(existingExec1Line1);
        when(lineExecutionRepository.getFromExecutionAndLine("exec2", "line4"))
            .thenReturn(existingExec2Line4);
        when(executionActionRepository.getExecutionActionsFromOrder(anyString(), anyString(), any(ExecutionActionType.class)))
            .thenReturn(existingAction);
        when(eventProducer.sendEvents(anyList(), anyString(), anyString(), any(UpdateExecution.class)))
            .thenReturn(savedEvent);

        final var input = UpdateExecutionInput.builder()
            .action(ActionType.DECREASE_QUANTITY)
            .requestId("request1")
            .customerOrderId("order1")
            .buCode("001")
            .appSource("TEST")
            .ownerRequest(OwnerRequest.builder()
                .identifier("1234")
                .operatorType(CUSTOMER)
                .build())
            .executionsToUpdate(List.of(ExecutionData.builder()
                .executionId("order1")
                .lineData(List.of(LineData.builder()
                        .lineId("line1")
                        .quantity(BigDecimal.ONE)
                        .reason("test")
                        .build(),
                    LineData.builder()
                        .lineId("line4")
                        .quantity(BigDecimal.ONE)
                        .reason("test")
                        .build()))
                .build())).build();

        StepVerifier.create(updateExecutionApplicationService.applyV1(input)).verifyComplete();

        existingExec1Line1.expectHasBeenSubscribed();
        existingExec2Line4.expectHasBeenSubscribed();

        existingAction.expectHasBeenSubscribed();
        savedEvent.expectHasBeenSubscribed();

    }


    @Test
    void should_not_send_event_when_request_is_on_splitted_line_V1() {

        final var executionData = Map.of("order1", Map.of("exec1", Map.of(1, List.of("line1", "line2")), "exec2", Map.of(1, List.of("line1"))));
        final var allLines = generateLines(executionData);
        FluxMock<LineExecution> existingExec1Line1 = FluxMock.fromIterable(allLines.stream().filter(lineExecution -> lineExecution.getExecutionId().equals("exec1") && lineExecution.getLineId().equals("line1")).collect(Collectors.toList()));

        FluxMock<ExecutionAction> existingAction = FluxMock.empty();
        when(lineExecutionRepository.getByCustomerOrderId("order1", "001"))
            .thenReturn(Flux.fromIterable(allLines));

        final var input = UpdateExecutionInput.builder()
            .action(ActionType.DECREASE_QUANTITY)
            .customerOrderId("order1")
            .buCode("001")
            .requestId("request1")
            .ownerRequest(OwnerRequest.builder()
                .identifier("1234")
                .operatorType(CUSTOMER)
                .build())
            .executionsToUpdate(List.of(ExecutionData.builder()
                .executionId("exec1")
                .lineData(List.of(LineData.builder()
                    .lineId("line1")
                    .quantity(new BigDecimal("1"))
                    .build()))
                .build())).build();

        StepVerifier.create(updateExecutionApplicationService.applyV1(input)).verifyError(SplittedExecutionNotManagedError.class);

        existingExec1Line1.expectHasNotBeenSubscribed();

        existingAction.expectHasNotBeenSubscribed();

    }

    @Test
    void should_not_send_event_when_quantity_requested_is_wrong() {

        final var executionData = Map.of("order1", Map.of("exec1", Map.of(1, List.of("line1", "line2")), "exec2", Map.of(1, List.of("line3", "line4"))));
        final var allLines = generateLines(executionData);
        FluxMock<LineExecution> existingExec1Line1 = FluxMock.fromIterable(allLines.stream().filter(lineExecution -> lineExecution.getExecutionId().equals("exec1") && lineExecution.getLineId().equals("line1")).collect(Collectors.toList()));

        FluxMock<ExecutionAction> existingAction = FluxMock.empty();

        when(lineExecutionRepository.getFromExecutionAndLine("exec1", "line1"))
            .thenReturn(existingExec1Line1);
        when(executionActionRepository.getExecutionActionsFromOrder(anyString(), anyString(), any(ExecutionActionType.class)))
            .thenReturn(existingAction);

        final var input = UpdateExecutionInput.builder()
            .action(ActionType.DECREASE_QUANTITY)
            .customerOrderId("order1")
            .requestId("request1")
            .ownerRequest(OwnerRequest.builder()
                .identifier("1234")
                .operatorType(CUSTOMER)
                .build())
            .executionsToUpdate(List.of(ExecutionData.builder()
                .executionId("exec1")
                .lineData(List.of(LineData.builder()
                    .lineId("line1")
                    .quantity(new BigDecimal("3"))
                    .build()))
                .build())).build();

        StepVerifier.create(updateExecutionApplicationService.apply(input)).verifyError(QuantityNotValidError.class);

        existingExec1Line1.expectHasBeenSubscribed();

        existingAction.expectHasBeenSubscribed();

    }

    @Test
    void should_not_send_event_when_cancelable_is_not_true() {

        final var executionData = Map.of("order1", Map.of("exec1", Map.of(1, List.of("line1", "line2")), "exec2", Map.of(1, List.of("line3", "line4"))));
        final var allLines = generateLines(executionData);
        allLines.forEach(l -> l.getComposition().setCancelable(false));
        FluxMock<LineExecution> existingExec1Line1 = FluxMock.fromIterable(allLines.stream().filter(lineExecution -> lineExecution.getExecutionId().equals("exec1") && lineExecution.getLineId().equals("line1")).collect(Collectors.toList()));

        FluxMock<ExecutionAction> existingAction = FluxMock.empty();

        when(lineExecutionRepository.getFromExecutionAndLine("exec1", "line1"))
            .thenReturn(existingExec1Line1);
        when(executionActionRepository.getExecutionActionsFromOrder(anyString(), anyString(), any(ExecutionActionType.class)))
            .thenReturn(existingAction);

        final var input = UpdateExecutionInput.builder()
            .action(ActionType.DECREASE_QUANTITY)
            .customerOrderId("order1")
            .requestId("request1")
            .ownerRequest(OwnerRequest.builder()
                .identifier("1234")
                .operatorType(CUSTOMER)
                .build())
            .executionsToUpdate(List.of(ExecutionData.builder()
                .executionId("exec1")
                .lineData(List.of(LineData.builder()
                    .lineId("line1")
                    .quantity(new BigDecimal("3"))
                    .build()))
                .build())).build();

        StepVerifier.create(updateExecutionApplicationService.apply(input)).verifyError(QuantityNotValidError.class);

        existingExec1Line1.expectHasBeenSubscribed();

        existingAction.expectHasBeenSubscribed();

    }

    @Test
    void should_not_send_event_when_quantity_requested_is_wrong_with_existing_request() {

        final var executionData = Map.of("order1", Map.of("exec1", Map.of(1, List.of("line1", "line2")), "exec2", Map.of(1, List.of("line3", "line4"))));
        final var allLines = generateLines(executionData);
        FluxMock<LineExecution> existingExec1Line1 = FluxMock.fromIterable(allLines.stream().filter(lineExecution -> lineExecution.getExecutionId().equals("exec1") && lineExecution.getLineId().equals("line1")).collect(Collectors.toList()));

        FluxMock<ExecutionAction> existingAction = FluxMock.fromIterable(List.of(ExecutionAction.builder()
            .impactedExecutions(List.of(ImpactedExecution.builder()
                .initialExecutionId("exec1")
                .impactedLines(List.of(ImpactedLine.builder()
                    .quantity(BigDecimal.ONE)
                    .lineId("line1")
                    .build()))
                .build()))
            .build()));

        when(lineExecutionRepository.getFromExecutionAndLine("exec1", "line1"))
            .thenReturn(existingExec1Line1);
        when(executionActionRepository.getExecutionActionsFromOrder(anyString(), anyString(), any(ExecutionActionType.class)))
            .thenReturn(existingAction);

        final var input = UpdateExecutionInput.builder()
            .action(ActionType.DECREASE_QUANTITY)
            .customerOrderId("order1")
            .requestId("request1")
            .ownerRequest(OwnerRequest.builder()
                .identifier("1234")
                .operatorType(CUSTOMER)
                .build())
            .executionsToUpdate(List.of(ExecutionData.builder()
                .executionId("exec1")
                .lineData(List.of(LineData.builder()
                    .lineId("line1")
                    .quantity(BigDecimal.ONE)
                    .build()))
                .build())).build();

        StepVerifier.create(updateExecutionApplicationService.apply(input)).verifyError(QuantityNotValidError.class);

        existingExec1Line1.expectHasBeenSubscribed();

        existingAction.expectHasBeenSubscribed();

    }

    @Test
    void should_not_send_event_when_quantity_requested_is_wrong_with_existing_request_with_multiple_exec() {

        final var executionData = Map.of("order1", Map.of("exec1", Map.of(1, List.of("line1", "line2")), "exec2", Map.of(1, List.of("line3", "line4"))));
        final var allLines = generateLines(executionData);

        FluxMock<LineExecution> existingExec1Line1 = FluxMock.fromIterable(allLines.stream().filter(lineExecution -> lineExecution.getExecutionId().equals("exec1") && lineExecution.getLineId().equals("line1")).collect(Collectors.toList()));
        FluxMock<ExecutionAction> existingAction = FluxMock.fromIterable(List.of(ExecutionAction.builder()
            .impactedExecutions(List.of(ImpactedExecution.builder()
                .initialExecutionId("exec1")
                .impactedLines(List.of(ImpactedLine.builder()
                    .quantity(BigDecimal.ONE)
                    .lineId("line1")
                    .build()))
                .build()))
            .build()));
        when(lineExecutionRepository.getFromExecutionAndLine("exec1", "line1"))
            .thenReturn(existingExec1Line1);

        when(executionActionRepository.getExecutionActionsFromOrder(anyString(), anyString(), any(ExecutionActionType.class)))
            .thenReturn(existingAction);

        final var input = UpdateExecutionInput.builder()
            .action(ActionType.DECREASE_QUANTITY)
            .customerOrderId("order1")
            .requestId("request1")
            .ownerRequest(OwnerRequest.builder()
                .identifier("1234")
                .operatorType(CUSTOMER)
                .build())
            .executionsToUpdate(List.of(ExecutionData.builder()
                    .executionId("exec1")
                    .lineData(List.of(LineData.builder()
                        .lineId("line1")
                        .quantity(BigDecimal.ONE)
                        .build()))
                    .build(),
                ExecutionData.builder()
                    .executionId("exec2")
                    .lineData(List.of(LineData.builder()
                        .lineId("line4")
                        .quantity(BigDecimal.ONE)
                        .build()))
                    .build())).build();

        StepVerifier.create(updateExecutionApplicationService.apply(input)).verifyError(QuantityNotValidError.class);

        existingExec1Line1.expectHasBeenSubscribed();

        existingAction.expectHasBeenSubscribed();

    }

    @Test
    void should_not_send_event_when_line_does_not_exist() {

        FluxMock<LineExecution> existingExec1Line1 = FluxMock.empty();

        FluxMock<ExecutionAction> existingAction = FluxMock.fromIterable(List.of(ExecutionAction.builder()
            .impactedExecutions(List.of(ImpactedExecution.builder()
                .initialExecutionId("exec1")
                .impactedLines(List.of(ImpactedLine.builder()
                    .quantity(BigDecimal.ONE)
                    .lineId("line1")
                    .build()))
                .build()))
            .build()));

        when(lineExecutionRepository.getFromExecutionAndLine("exec1", "line1"))
            .thenReturn(existingExec1Line1);
        when(executionActionRepository.getExecutionActionsFromOrder(anyString(), anyString(), any(ExecutionActionType.class)))
            .thenReturn(existingAction);

        final var input = UpdateExecutionInput.builder()
            .action(ActionType.DECREASE_QUANTITY)
            .customerOrderId("order1")
            .requestId("request1")
            .ownerRequest(OwnerRequest.builder()
                .identifier("1234")
                .operatorType(CUSTOMER)
                .build())
            .executionsToUpdate(List.of(ExecutionData.builder()
                .executionId("exec1")
                .lineData(List.of(LineData.builder()
                    .lineId("line1")
                    .quantity(BigDecimal.ONE)
                    .build()))
                .build())).build();

        StepVerifier.create(updateExecutionApplicationService.apply(input)).verifyError(ExecutionAndLineNotFoundError.class);

        existingExec1Line1.expectHasBeenSubscribed();

        existingAction.expectHasBeenSubscribed();

    }

    private List<LineExecution> generateLines(Map<String, Map<String, Map<Integer, List<String>>>> executionData) {
        final var lines = new ArrayList<LineExecution>();
        executionData.entrySet().stream()
            .forEach(stringMapEntry -> stringMapEntry.getValue().entrySet().stream()
                .forEach(stringMapEntry1 -> stringMapEntry1.getValue().entrySet().stream()
                    .forEach(integerListEntry -> integerListEntry.getValue().stream()
                        .forEach(lineId -> {
                            lines.add(LineExecution.builder()
                                .lineId(lineId)
                                .executionId(stringMapEntry1.getKey())
                                .customerOrderId(stringMapEntry.getKey())
                                .buCode("001")
                                .quantity(BigDecimal.valueOf(integerListEntry.getKey()))
                                .initialQuantity(BigDecimal.valueOf(integerListEntry.getKey()))
                                .composition(LineExecutionComposition.builder()
                                    .cancelable(true)
                                    .build())
                                .build());
                        }))));
        return lines;

    }

}
