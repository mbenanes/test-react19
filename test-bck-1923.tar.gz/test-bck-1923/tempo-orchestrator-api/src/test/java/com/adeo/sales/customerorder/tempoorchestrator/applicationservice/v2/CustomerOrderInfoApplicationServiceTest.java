package com.adeo.sales.customerorder.tempoorchestrator.applicationservice.v2;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.jackson.SerializeSpecificRecordBase;
import com.adeo.sales.customerorder.tempoorchestrator.controller.v2.order.CustomerOrderResponse;
import com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.execution.ExecutionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderLineRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionActionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LineExecutionRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import org.apache.avro.specific.SpecificRecordBase;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CustomerOrderInfoApplicationServiceTest {

    @Mock
    CustomerOrderRepository customerOrderRepository;
    @Mock
    CustomerOrderLineRepository customerOrderLineRepository;
    @Mock
    LineExecutionRepository lineExecutionRepository;
    @Mock
    ExecutionActionRepository executionActionRepository;
    @Mock
    ExecutionRepository executionRepository;

    CustomerOrderInfoApplicationService customerOrderInfoApplicationService;

    ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        customerOrderInfoApplicationService = new CustomerOrderInfoApplicationService(customerOrderRepository, customerOrderLineRepository,  lineExecutionRepository, executionActionRepository, executionRepository);
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new SimpleModule().addSerializer(SpecificRecordBase.class, new SerializeSpecificRecordBase()));
        objectMapper.registerModule(new Jdk8Module());
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.registerModule(new ParameterNamesModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Test
    void shouldReturnCustomerOrderInfo() throws IOException {
        // Given
        var givenCustomerOrderId = UUID.randomUUID().toString();
        var givenBuCode = "buCode";
        var givenCustomerOrder = objectMapper.readValue(this.getClass().getResource("/data/customerorder/customer-order.json"), CustomerOrder.class);
        List<LineExecution> givenLineExecution = objectMapper.readValue(this.getClass().getResource("/data/customerorder/line-execution.json"), new TypeReference<>() {});
        List<ExecutionAction> givenExecutionAction = objectMapper.readValue(this.getClass().getResource("/data/customerorder/execution-action-with-flag.json"), new TypeReference<>() {});
        var givenExecution = Execution.builder()
            .id("005e218b-c2e3-4ac4-b6f7-90d56cc53a8a")
            .build();
        givenExecution.getExecutionStatus().raiseFlag(ExecutionStatus.CREATED);

        when(customerOrderRepository.getById(givenCustomerOrderId, givenBuCode)).thenReturn(Mono.just(givenCustomerOrder));
        when(lineExecutionRepository.getByCustomerOrderId(givenCustomerOrderId, givenBuCode)).thenReturn(Flux.fromIterable(givenLineExecution));
        when(executionActionRepository.getExecutionActionsFromOrder(givenCustomerOrderId, givenBuCode)).thenReturn(Flux.fromIterable(givenExecutionAction));
        when(executionRepository.getExecutionFromOrder(givenCustomerOrderId, givenBuCode)).thenReturn(Flux.just(givenExecution));
        // When
        var result = customerOrderInfoApplicationService.apply(givenCustomerOrderId, givenBuCode);
        // Then
        StepVerifier.create(result)
            .expectNextMatches(customerOrderInfoResponse -> {
                customerOrderInfoResponse.getUpdateExecutionActions().forEach(
                    executionAction -> executionAction.getImpactedExecutions().forEach(
                        impactedExecution -> impactedExecution.getImpactedLines().forEach(
                            impactedLine -> {
                                assertThat("EXECUTE_ADJUSTMENT_TPP").isEqualTo(impactedLine.getCurrentStep().getStep());
                                assertThat("PROCESSING").isEqualTo(impactedLine.getCurrentStep().getStatus());
                            }
                        )
                    )
                );
                return true;
            })
            .verifyComplete();
        verify(customerOrderRepository).getById(givenCustomerOrderId, givenBuCode);
        verify(lineExecutionRepository).getByCustomerOrderId(givenCustomerOrderId, givenBuCode);
        verify(executionActionRepository).getExecutionActionsFromOrder(givenCustomerOrderId, givenBuCode);
        verify(executionRepository).getExecutionFromOrder(givenCustomerOrderId, givenBuCode);
    }

    @Test
    void shouldNotReturnCustomerOrderInfo_whenLineExecutionIsInvalid() throws IOException {
        // Given
        var givenCustomerOrderId = UUID.randomUUID().toString();
        var givenBuCode = "buCode";
        var givenCustomerOrder = objectMapper.readValue(this.getClass().getResource("/data/customerorder/customer-order.json"), CustomerOrder.class);
        List<ExecutionAction> givenExecutionAction = objectMapper.readValue(this.getClass().getResource("/data/customerorder/execution-action-with-flag.json"), new TypeReference<>() {});
        var givenExecution = Execution.builder()
            .id("005e218b-c2e3-4ac4-b6f7-90d56cc53a8a")
            .build();
        givenExecution.getExecutionStatus().raiseFlag(ExecutionStatus.CREATED);

        when(customerOrderRepository.getById(givenCustomerOrderId, givenBuCode)).thenReturn(Mono.just(givenCustomerOrder));
        when(lineExecutionRepository.getByCustomerOrderId(givenCustomerOrderId, givenBuCode)).thenReturn(Flux.empty());
        when(executionActionRepository.getExecutionActionsFromOrder(givenCustomerOrderId, givenBuCode)).thenReturn(Flux.fromIterable(givenExecutionAction));
        when(executionRepository.getExecutionFromOrder(givenCustomerOrderId, givenBuCode)).thenReturn(Flux.just(givenExecution));

        // When
        var result = customerOrderInfoApplicationService.apply(givenCustomerOrderId, givenBuCode);

        // Then
        StepVerifier.create(result)
            .expectError(NullPointerException.class)
            .verify();
    }


    @DisplayName("Should return customer order with execution action")
    void shouldReturnOrderInfoCorrectly() throws IOException {
        CustomerOrder customerOrder = objectMapper.readValue(this.getClass().getResource("/data/getorderinfov2/customer-order.json"), CustomerOrder.class);

        List<LineExecution> lineExecutions = objectMapper.readValue(this.getClass().getResource("/data/getorderinfov2/line-executions.json"), new TypeReference<>() {
        });
        List<ExecutionAction> executionActions = objectMapper.readValue(this.getClass().getResource("/data/getorderinfov2/execution-actions.json"), new TypeReference<>() {
        });

        CustomerOrderResponse customerOrderResponse = objectMapper.readValue(this.getClass().getResource("/data/getorderinfov2/customer-order-response.json"), CustomerOrderResponse.class);

        List<Execution> executions = objectMapper.readValue(this.getClass().getResource("/data/getorderinfov2/executions.json"), new TypeReference<>() {
        });

        Mockito.when(customerOrderRepository.getById(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(Mono.just(customerOrder));
        Mockito.when(lineExecutionRepository.getByCustomerOrderId(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(Flux.fromIterable(lineExecutions));
        Mockito.when(executionActionRepository.getExecutionActionsFromOrder(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(Flux.fromIterable(executionActions));
        Mockito.when(executionRepository.getExecutionFromOrder(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(Flux.fromIterable (executions));

        Mono<CustomerOrderResponse> apply = customerOrderInfoApplicationService.apply(customerOrder.getId(), customerOrder.getBuCode());

        StepVerifier.create(apply)
            .expectNext(customerOrderResponse)
            .verifyComplete();
    }
}
