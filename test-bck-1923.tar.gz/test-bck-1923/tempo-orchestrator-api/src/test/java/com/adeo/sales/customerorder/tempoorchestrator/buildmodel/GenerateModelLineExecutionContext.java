package com.adeo.sales.customerorder.tempoorchestrator.buildmodel;

import com.adeo.sales.customerorder.tempoorchestrator.model.CollectStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.DeliveryType;
import com.adeo.sales.customerorder.tempoorchestrator.model.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecutionDelivery;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecutionDeliveryCollect;

import java.math.BigDecimal;

public interface GenerateModelLineExecutionContext {

    default LineExecution buildLineExecution(String executionId, String lineId, String customerOrderId, BigDecimal quantity, DeliveryType deliveryType, LineExecutionDeliveryCollect lineExecutionDeliveryCollect) {

        final LineExecutionDelivery lineExecutionDelivery = buildLineExecutionDelivery(deliveryType, lineExecutionDeliveryCollect);

        return LineExecution.builder()
            .executionId(executionId)
            .lineId(lineId)
            .customerOrderId(customerOrderId)
            .quantity(quantity)
            .delivery(lineExecutionDelivery)
            .build();
    }

    private static LineExecutionDelivery buildLineExecutionDelivery(DeliveryType deliveryType, LineExecutionDeliveryCollect lineExecutionDeliveryCollect){
        return LineExecutionDelivery.builder()
            .collect(lineExecutionDeliveryCollect)
            .deliveryType(deliveryType)
            .build();
    }

    default LineExecutionDeliveryCollect buildLineExecutionDeliveryCollect(CollectStatus collectStatus){
        final var collectStatusFlags = new Flags<CollectStatus>();
        collectStatusFlags.raiseFlagIfNot(collectStatus);

        return LineExecutionDeliveryCollect.builder()
            .flags(collectStatusFlags)
            .globalCollectStatus(collectStatus)
            .build();
    }
}
