package com.adeo.sales.customerorder.tempoorchestrator.applicationservice;

import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.CustomerOrderResponse;
import com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.execution.Execution;
import com.adeo.sales.customerorder.tempoorchestrator.model.execution.ExecutionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderLineRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.CustomerOrderRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionActionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.ExecutionRepository;
import com.adeo.sales.customerorder.tempoorchestrator.repository.LineExecutionRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class GetCustomerOrderApplicationServiceTest {
    @Mock
    CustomerOrderLineRepository customerOrderLineRepository;
    @Mock
    CustomerOrderRepository customerOrderRepository;
    @Mock
    LineExecutionRepository lineExecutionRepository;
    @Mock
    ExecutionActionRepository executionActionRepository;
    @Mock
    ExecutionRepository executionRepository;

    GetCustomerOrderApplicationService getCustomerOrderApplicationService;

    ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        getCustomerOrderApplicationService = new GetCustomerOrderApplicationService(customerOrderLineRepository, customerOrderRepository, lineExecutionRepository, executionActionRepository, executionRepository);
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new Jdk8Module());
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.registerModule(new ParameterNamesModule());
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Test
    @DisplayName("Should return customer order with execution action")
    void shouldReturnCustomerOrderInfoWithExecutionAction() throws IOException {
        //GIVEN
        CustomerOrder customerOrder = objectMapper.readValue(this.getClass().getResource("/data/customerorder/customer-order.json"), CustomerOrder.class);
        List<LineExecution> lineExecutions = objectMapper.readValue(this.getClass().getResource("/data/customerorder/line-execution.json"), new TypeReference<>() {
        });
        List<ExecutionAction> executionActions = objectMapper.readValue(this.getClass().getResource("/data/customerorder/execution-action.json"), new TypeReference<>() {
        });

        CustomerOrderResponse customerOrderResponse = objectMapper.readValue(this.getClass().getResource("/data/customerorder/customer-order-response-with-execution-action.json"), CustomerOrderResponse.class);

        Execution execution = Execution.builder()
            .id("005e218b-c2e3-4ac4-b6f7-90d56cc53a8a")
            .build();
        execution.getExecutionStatus().raiseFlag(ExecutionStatus.CREATED);

        Mockito.when(customerOrderRepository.getById(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(Mono.just(customerOrder));
        Mockito.when(lineExecutionRepository.getByCustomerOrderId(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(Flux.fromIterable(lineExecutions));
        Mockito.when(executionActionRepository.getExecutionActionsFromOrder(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(Flux.fromIterable(executionActions));
        Mockito.when(executionRepository.getExecutionFromOrder(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(Flux.just(execution));

        //WHEN
        Mono<CustomerOrderResponse> apply = getCustomerOrderApplicationService.apply(customerOrder.getId(), customerOrder.getBuCode());
        //THEN
        StepVerifier.create(apply)
            .expectNext(customerOrderResponse)
            .verifyComplete();
    }

    @Test
    @DisplayName("Should return customer order without execution action")
    void shouldReturnCustomerOrderInfoWithoutExecutionAction() throws IOException {
        //GIVEN
        CustomerOrder customerOrder = objectMapper.readValue(this.getClass().getResource("/data/customerorder/customer-order.json"), CustomerOrder.class);
        List<LineExecution> lineExecutions = objectMapper.readValue(this.getClass().getResource("/data/customerorder/line-execution.json"), new TypeReference<>() {
        });

        CustomerOrderResponse customerOrderResponse = objectMapper.readValue(this.getClass().getResource("/data/customerorder/customer-order-response-without-execution-action.json"), CustomerOrderResponse.class);


        Mockito.when(customerOrderRepository.getById(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(Mono.just(customerOrder));
        Mockito.when(lineExecutionRepository.getByCustomerOrderId(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(Flux.fromIterable(lineExecutions));
        Mockito.when(executionActionRepository.getExecutionActionsFromOrder(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(Flux.empty());
        Mockito.when(executionRepository.getExecutionFromOrder(customerOrder.getId(), customerOrder.getBuCode())).thenReturn(Flux.empty());

        //WHEN
        Mono<CustomerOrderResponse> apply = getCustomerOrderApplicationService.apply(customerOrder.getId(), customerOrder.getBuCode());
        //THEN
        StepVerifier.create(apply)
            .expectNext(customerOrderResponse)
            .verifyComplete();
    }
}
