package com.adeo.sales.customerorder.tempoorchestrator.buildmodel;

import com.adeo.sales.customerorder.external.api.client.tpp.model.SimulatePaymentRequirementActionExecutionRequest;
import com.adeo.sales.customerorder.external.api.client.tpp.model.SimulatePaymentRequirementActionExecutionRequestExecutionPlan;
import com.adeo.sales.customerorder.external.api.client.tpp.model.PaymentRequirementActionExecution;
import com.adeo.sales.customerorder.external.api.client.tpp.model.SimulatePaymentRequirementActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.CustomerOrder;
import com.adeo.sales.customerorder.tempoorchestrator.model.LineExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.tpp.simulation.SimulationRequirementRequest;
import com.adeo.sales.customerorder.tempoorchestrator.model.tpp.simulation.SimulationRequirementRequestItem;

import java.math.BigDecimal;
import java.util.List;

public interface GenerateModelTPPContext {

    default SimulationRequirementRequest getSimulationRequirementRequest(List<LineExecution> lineExecutions, SimulatePaymentRequirementActionType actionType) {
        final List<SimulationRequirementRequestItem> simulationRequirementRequestItems = lineExecutions.stream()
            .map(GenerateModelTPPContext::getSimulationRequirementRequestItems)
            .toList();

        return SimulationRequirementRequest.builder()
            .paymentRequirementActionType(actionType)
            .simulationRequirementRequestItems(simulationRequirementRequestItems)
            .build();
    }

    private static SimulationRequirementRequestItem getSimulationRequirementRequestItems(LineExecution lineExecution) {
        final SimulationRequirementRequestItem simulationRequirementRequestItem = SimulationRequirementRequestItem.builder()
            .lineId(lineExecution.getLineId())
            .quantity(BigDecimal.ONE)
            .build();
        return simulationRequirementRequestItem;
    }

    default SimulatePaymentRequirementActionExecutionRequest getSimulatePaymentRequirementActionExecutionRequest(List<LineExecution> lineExecutions, String executionId, CustomerOrder customerOrder, SimulatePaymentRequirementActionType actionType) {
        final List<PaymentRequirementActionExecution> simulatePaymentRequirementActionExecutionRequestItems = getSimulatePaymentRequirementActionExecutionRequestItems(lineExecutions);

        final SimulatePaymentRequirementActionExecutionRequestExecutionPlan simulatePaymentRequirementActionExecutionRequestExecutionPlan = getSimulatePaymentRequirementActionExecutionRequestExecutionPlan(executionId, simulatePaymentRequirementActionExecutionRequestItems);

        return SimulatePaymentRequirementActionExecutionRequest.builder()
            .customerOrderPaymentExecutionPolicyVersion(customerOrder.getPaymentExecutionPolicy().getVersion())
            .paymentRequirementExecutionPlan(List.of(simulatePaymentRequirementActionExecutionRequestExecutionPlan))
            .paymentRequirementActionType(actionType)
            .customerOrderId(customerOrder.getId())
            .build();
    }

    default SimulatePaymentRequirementActionExecutionRequestExecutionPlan getSimulatePaymentRequirementActionExecutionRequestExecutionPlan(String executionId, List<PaymentRequirementActionExecution> simulatePaymentRequirementActionExecutionRequestItems) {
        return SimulatePaymentRequirementActionExecutionRequestExecutionPlan.builder()
            .customerOrderExecutionPlanId(executionId)
            .paymentRequirementActionExecution(simulatePaymentRequirementActionExecutionRequestItems)
            .build();
    }

    default List<PaymentRequirementActionExecution> getSimulatePaymentRequirementActionExecutionRequestItems(List<LineExecution> lineExecutions) {
        return lineExecutions.stream()
            .map(GenerateModelTPPContext::getSimulatePaymentRequirementActionExecutionRequestItems)
            .toList();

    }

    private static PaymentRequirementActionExecution getSimulatePaymentRequirementActionExecutionRequestItems(LineExecution lineExecution) {
        return PaymentRequirementActionExecution.builder()
            .quantity(BigDecimal.ONE)
            .customerOrderCartItemId(lineExecution.getLineId())
            .build();
    }
}
