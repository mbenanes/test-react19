package com.adeo.sales.customerorder.tempoorchestrator.buildmodel;

import com.adeo.sales.customerorder.tempoorchestrator.model.Flags;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionAction;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionActionStatus;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ExecutionActionType;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ImpactedExecution;
import com.adeo.sales.customerorder.tempoorchestrator.model.executionaction.ImpactedLine;

import java.util.List;

public interface GenerateModelExecutionActionContext {

    default ExecutionAction buildExecutionAction(String id, String lineId, ExecutionActionStatus executionActionStatus, ExecutionActionType executionActionType) {
        final var processingExecutionActionFlag = new Flags<ExecutionActionStatus>();
        processingExecutionActionFlag.raiseFlagIfNot(executionActionStatus);
        return ExecutionAction.builder()
            .requestId(id)
            .actionType(executionActionType.toString())
            .flags(processingExecutionActionFlag)
            .impactedExecutions(List.of(ImpactedExecution.builder()
                .impactedLines(List.of(ImpactedLine.builder()
                    .lineId(lineId)
                    .build()))
                .build()))
            .build();
    }
}
