package com.adeo.sales.customerorder.tempoorchestrator;

import com.adeo.sales.customerorder.tempoorchestrator.configuration.property.kafka.TopicsProperties;
import io.micrometer.core.instrument.Clock;
import io.micrometer.core.instrument.MeterRegistry;
import org.mockito.Mockito;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Bean;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

@EnableWebFluxSecurity
@TestConfiguration
public class ConfigurationTest {

    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
        return http
            .csrf().disable()
            .build();
    }

    @Bean
    Tracer tracer() {
        return Mockito.mock(Tracer.class);
    }

    @Bean
    Clock clock(){
        return Clock.SYSTEM;
    }

    @Bean
    MeterRegistry meterRegistry(){
        return Mockito.mock(MeterRegistry.class);
    }

    @Bean
    DatabaseClient databaseClient() {
        return Mockito.mock(DatabaseClient.class);
    }

    @Bean
    TopicsProperties topicsProperties(){
        return Mockito.mock(TopicsProperties.class);
    }

    @Bean
    MeterRegistry.More more(){
        return Mockito.mock(MeterRegistry.More.class);
    }
}
