package com.adeo.sales.customerorder.tempoorchestrator.controller;

import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.UpdateExecutionApplicationService;
import com.adeo.sales.customerorder.tempoorchestrator.applicationservice.input.UpdateExecutionInput;
import com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.User;
import com.adeo.sales.customerorder.tempoorchestrator.controller.v2.order.ExecutionUpdateRequest;
import com.adeo.sales.customerorder.tempoorchestrator.controller.v2.order.ImpactedExecution;
import io.micrometer.core.instrument.MeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;
import util.MonoMock;

import java.math.BigDecimal;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
@AutoConfigureWebTestClient
public class CustomerOrderControllerUnitTest {

    @MockBean
    private UpdateExecutionApplicationService updateExecutionApplicationService;
    @Mock
    private MeterRegistry meterRegistry;

    @Autowired
    private WebTestClient webClient;

    @BeforeEach
    void setUp() {
    }

    @Test
    void should_send_201_response() {
        MonoMock<Void> empty = MonoMock.empty();

        when(updateExecutionApplicationService.apply(any(UpdateExecutionInput.class)))
            .thenReturn(empty);

        final var user = new User();
        user.setCustomerIdentifier("1234");
        final var request = new ExecutionUpdateRequest();
        final var line = new com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.ImpactedLine();
        line.setLineId("line1");
        line.setQuantity(BigDecimal.ONE);
        line.setReason("test");
        final var lines = List.of(line);
        final var impactedExecution = new ImpactedExecution();
        impactedExecution.setExecutionId("exec1");
        impactedExecution.setImpactedLines(lines);
        final var impactedActions = List.of(impactedExecution);
        request.setRequestSourceId("request1");
        request.setRequestedBy(user);
        request.setActionType("DECREASE_QUANTITY");
        request.setImpactedExecutions(impactedActions);

        this.webClient.post().uri("/customer-orders/{customerOrderId}/executionUpdateRequest", "TEST")
            .header("Adeo-Bu-Code", "001")
            .header("Adeo-App-Source", "123")
            .header("X-API-Version", "1")
            .body(BodyInserters.fromObject(request))
            .exchange()
            .expectStatus().isCreated();

    }

    @Test
    public void should_send_400_response_when_request_action_is_null() {

        final var user = new User();
        user.setCustomerIdentifier("1234");
        final var request = new ExecutionUpdateRequest();
        final var line = new com.adeo.sales.customerorder.tempoorchestrator.controller.dtos.ImpactedLine();
        line.setLineId("line1");
        line.setQuantity(BigDecimal.ONE);
        final var lines = List.of(line);
        final var impactedExecution = new ImpactedExecution();
        impactedExecution.setExecutionId("exec1");
        impactedExecution.setImpactedLines(lines);
        final var impactedActions = List.of(impactedExecution);
        request.setRequestSourceId("request1");
        request.setRequestedBy(user);
        request.setImpactedExecutions(impactedActions);

        this.webClient.post().uri("/customer-orders/{customerOrderId}/executionUpdateRequest", "TEST")
            .header("Adeo-Bu-Code", "001")
            .header("Adeo-App-Source", "123")
            .header("X-API-Version", "1")
            .body(BodyInserters.fromValue(request))
            .exchange()
            .expectStatus().isBadRequest();

    }
}
