package util;

import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class MonoMockTest {

    @Test
    public void should_allow_to_test_if_mono_is_not_subscribed() {
        var monoTest = MonoMock.just(1);

        var result = Mono.just(1).map(it -> monoTest);

        StepVerifier
            .create(result)
            .expectNextCount(1)
            .verifyComplete();

        monoTest.expectHasNotBeenSubscribed();
    }

    @Test
    public void should_allow_to_test_if_mono_is_subscribed() {
        var monoTest = MonoMock.just(1);

        var result = Mono.just(1).flatMap(it -> monoTest);

        StepVerifier
            .create(result)
            .expectNextCount(1)
            .verifyComplete();

        monoTest.expectHasBeenSubscribed();
    }

    @Test
    public void should_fail_test_if_mono_is_subscribed_and_expect_no_subscription() {
        var monoTest = MonoMock.just(1);

        var result = Mono.just(1).flatMap(it -> monoTest);

        StepVerifier
            .create(result)
            .expectNextCount(1)
            .verifyComplete();

        try {
            monoTest.expectHasNotBeenSubscribed();
            fail("the error has not be thrown");
        } catch (AssertionError error) {
            assertEquals("Mono should not be subscribed", error.getMessage());
        }
    }

    @Test
    public void should_fail_test_if_mono_is_no_subscribed_and_expect_one_subscription() {
        var monoTest = MonoMock.just(1);

        var result = Mono.just(1).map(it -> monoTest);

        StepVerifier
            .create(result)
            .expectNextCount(1)
            .verifyComplete();

        try {
            monoTest.expectHasBeenSubscribed();
            fail("the error has not be thrown");
        } catch (AssertionError error) {
            assertEquals("Mono should be subscribed", error.getMessage());
        }
    }
}
