package util;

import org.opentest4j.AssertionFailedError;
import reactor.core.CoreSubscriber;
import reactor.core.publisher.Mono;

public class MonoMock<T> extends Mono<T> {

    private final Mono<T> delegate;

    private boolean isSubscribed = false;

    private MonoMock(Mono<T> delegate) {
        this.delegate = delegate;
    }

    public static <T> MonoMock<T> just(T object) {
        return new MonoMock<>(Mono.just(object));
    }

    public static <T> MonoMock<T> error(Throwable object) {
        return new MonoMock<>(Mono.error(object));
    }

    public static <T> MonoMock<T> from(Mono<T> from) {
        return new MonoMock<>(from);
    }

    public static <T> MonoMock<T> empty() {
        return new MonoMock<>(Mono.empty());
    }

    @Override
    public void subscribe(CoreSubscriber<? super T> actual) {
        this.isSubscribed = true;
        this.delegate.subscribe(actual);
    }

    public void expectHasBeenSubscribed() {
        if (!isSubscribed) {
            throw new AssertionFailedError("Mono should be subscribed");
        }
    }

    public void expectHasNotBeenSubscribed() {
        if (isSubscribed) {
            throw new AssertionFailedError("Mono should not be subscribed");
        }
    }

}
