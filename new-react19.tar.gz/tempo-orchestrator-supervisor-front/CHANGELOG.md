# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.23.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.6.2...tempo-orchestrator-supervisor-front@1.23.0) (2024-12-12)


### Bug Fixes

* add buton on right event ([c99eb98](https://github.com/adeo/tempo-orchestrator--sources/commit/c99eb98981d3f413ee19d965f9f18d320f2809ff))
* add missing labels ([dc788b3](https://github.com/adeo/tempo-orchestrator--sources/commit/dc788b35ee2babd3a3154be98702dcb01fd65f50))
* add page and pageSize on /alerts call ([a507781](https://github.com/adeo/tempo-orchestrator--sources/commit/a5077812a8bb2d5dde5e0c8eaadb66a221128af7))
* bpmn editor label update name ([ddab95c](https://github.com/adeo/tempo-orchestrator--sources/commit/ddab95c70a8d8e2467c073d569e5298a6a4f477d))
* **css:** margin issue on the welcome page ([d074802](https://github.com/adeo/tempo-orchestrator--sources/commit/d074802cb58defea6ac31a3256ca1e3c7dbab369))
* customer order line tree not displayed ([6c4883b](https://github.com/adeo/tempo-orchestrator--sources/commit/6c4883bef6cd1bae29e3369b34d4d2956e8b31a8))
* don't close multi select on checkbox click ([c22fdc2](https://github.com/adeo/tempo-orchestrator--sources/commit/c22fdc23027044a0d11248a67d604426f7721711))
* event sorting in supervisor front ([#4026](https://github.com/adeo/tempo-orchestrator--sources/issues/4026)) ([1a6a1a8](https://github.com/adeo/tempo-orchestrator--sources/commit/1a6a1a8b235b4184d49e7a5ae132b645bb68904e))
* links overflow issue ([3105c87](https://github.com/adeo/tempo-orchestrator--sources/commit/3105c87e310f6043958acef17787c4230f2ba5d1))
* NSREDIRECT cookie host ([ba9e8d6](https://github.com/adeo/tempo-orchestrator--sources/commit/ba9e8d6a3d785d25fb1834dd9f01803914ca412a))
* only solved alert issue when select other filter ([59ebe01](https://github.com/adeo/tempo-orchestrator--sources/commit/59ebe01d18c424e3f7d10638ce2983fa3016f730))
* overflow issue on filter ([d41f1bd](https://github.com/adeo/tempo-orchestrator--sources/commit/d41f1bd9bd8c1e253d6ca566f73207aec7d1bb09))
* replace all {orderId} on url ([a862cf5](https://github.com/adeo/tempo-orchestrator--sources/commit/a862cf55782cd69c92a05f90c9d72a0bae1c9e0f))
* retry button position + mono consumer retry issue ([153b77c](https://github.com/adeo/tempo-orchestrator--sources/commit/153b77c4e67ac48a4e2cece893ae0d214f30196c))
* retry popin button display issue ([6793a48](https://github.com/adeo/tempo-orchestrator--sources/commit/6793a485268e796e36fc808474964fffb1eadf2d))
* set scheme to http on non-local ens ([369a6e9](https://github.com/adeo/tempo-orchestrator--sources/commit/369a6e943fdfe7643ce59ad7a3c7b2caa8b67c7a))
* show gateway as warning if previous event is warning ([2c6d64e](https://github.com/adeo/tempo-orchestrator--sources/commit/2c6d64e139f043638980a2e48b9db1d3c465ccff))
* use the initial customer order line on graph execution ([58aee81](https://github.com/adeo/tempo-orchestrator--sources/commit/58aee817af1e73f7fe4d45c2080de6bc756eb9bb))
* xss injection issue on oauth implementation ([3162fac](https://github.com/adeo/tempo-orchestrator--sources/commit/3162facb1c0356452837425d64d80696c2c155c5))


### Features

* add alerts on customer order view ([6d9cdbf](https://github.com/adeo/tempo-orchestrator--sources/commit/6d9cdbf5ce0a1639029e942ccdf1e21d5321d167))
* add alerts page ([41277d1](https://github.com/adeo/tempo-orchestrator--sources/commit/41277d1e32acee6360ae6f47c97159370076486a))
* add bage on comment button ([4af12a2](https://github.com/adeo/tempo-orchestrator--sources/commit/4af12a20f354f34e92e78e41db682ae869556c39))
* add bpm editor view ([27df410](https://github.com/adeo/tempo-orchestrator--sources/commit/27df410254002f1b7aa6dfd22a1a862d2b90efc7))
* add bu flag on customer order view ([a096cdb](https://github.com/adeo/tempo-orchestrator--sources/commit/a096cdbbfc48cad8d5876b8347565146df02c03c))
* add bu name filter on alert list ([c4d6cba](https://github.com/adeo/tempo-orchestrator--sources/commit/c4d6cba11b0b83ebb61ad30aaac2bd83e031e650))
* add checkbox to filter only solved alerts ([141dc53](https://github.com/adeo/tempo-orchestrator--sources/commit/141dc5309d6ee4b29e6392cf66e0cf9aac8751c6))
* add delete alert button ([c299076](https://github.com/adeo/tempo-orchestrator--sources/commit/c299076d49a53cc9aa78449de350211d6546f9ec))
* add delete alert button on event list ([20d76e8](https://github.com/adeo/tempo-orchestrator--sources/commit/20d76e8ef89e797efdb0871849452b512d2f30ce))
* add delivery type on alert table ([ee5a901](https://github.com/adeo/tempo-orchestrator--sources/commit/ee5a90128d23f83ec91502cd87627f96df50dfba))
* add dependencies filter  ([868d607](https://github.com/adeo/tempo-orchestrator--sources/commit/868d607c6da1d4f8f43a77ec225b8bd84d143d6c))
* add event filter by line ids ([26ca33a](https://github.com/adeo/tempo-orchestrator--sources/commit/26ca33ae019be7a8c474809e27adc8301e56da7f))
* add filter alert in UI ([2decaf0](https://github.com/adeo/tempo-orchestrator--sources/commit/2decaf0ff0b13bc13acd316fe3e6c0eec20ed792))
* add frontend to add comments ([fa6a28e](https://github.com/adeo/tempo-orchestrator--sources/commit/fa6a28ee26d20cc14764ddf7e045475c8eac5d8e))
* add ping on supervisor front ([c5ffbfc](https://github.com/adeo/tempo-orchestrator--sources/commit/c5ffbfcf08ab69477ec4ba8c525cf51f5a67a73d))
* add retry button ([428444b](https://github.com/adeo/tempo-orchestrator--sources/commit/428444bfaddf047df96ee1fb4f65ca08dde82d52))
* add rule engine button ([7d4853b](https://github.com/adeo/tempo-orchestrator--sources/commit/7d4853b3296ddfa9678504c7508052a30c24783d))
* add snow ticket number on alert screen ([4ea9294](https://github.com/adeo/tempo-orchestrator--sources/commit/4ea92940f5e33300b6e81064f54520c234c08ce3))
* add with or without ticket filter and ticket creation date in IHM  ([705e17b](https://github.com/adeo/tempo-orchestrator--sources/commit/705e17b3155fa718b669821213112b31e12e7181))
* allow to match only 1P or 3P on event ([5d76b06](https://github.com/adeo/tempo-orchestrator--sources/commit/5d76b060b233b2faa556898ee629b6fc72919efb))
* change the default docker repo to adeo  ([ee1c1d2](https://github.com/adeo/tempo-orchestrator--sources/commit/ee1c1d26f12ee1a6703804cc754ff0fdf32e89d8))
* colorize bpm graph with received events ([a70a638](https://github.com/adeo/tempo-orchestrator--sources/commit/a70a63817c6e6833902d46d6e73a3db828652db4))
* delete env file with app url and use vault ([#2445](https://github.com/adeo/tempo-orchestrator--sources/issues/2445)) ([c2edb8e](https://github.com/adeo/tempo-orchestrator--sources/commit/c2edb8e6b21dd268141bbe6b6a0a34742e28eada))
* display multiple link on the header ([f996ffd](https://github.com/adeo/tempo-orchestrator--sources/commit/f996ffd0c78ac08692a2278dc15ce5af31aafe7a))
* don't open event panel when no event ([4287259](https://github.com/adeo/tempo-orchestrator--sources/commit/428725935489b3a8c6ccbf5af944507c9ff0888c))
* **editor:** add import button to load a bpm ([87095fc](https://github.com/adeo/tempo-orchestrator--sources/commit/87095fc7766dd14439e0765117b9bf04eb1dccb8))
* force valuate stock backo ([#4519](https://github.com/adeo/tempo-orchestrator--sources/issues/4519)) ([76d95ea](https://github.com/adeo/tempo-orchestrator--sources/commit/76d95eac36a19cd4706bc8bb02e3dc50d1307600))
* go live 1.0.0 ([8f9c6b0](https://github.com/adeo/tempo-orchestrator--sources/commit/8f9c6b0d4736809cf189d3b44af4f0d152531152))
* manage {buCode} variable on external links  ([8b85785](https://github.com/adeo/tempo-orchestrator--sources/commit/8b85785054b844b23d29cceb3bac148128966c66))
* manage functional type for CustomerOrderValidated event ([8746954](https://github.com/adeo/tempo-orchestrator--sources/commit/874695477de5f6452fd13afb5ff20eadadfbaa36))
* remove openshift code and scripts ([c57a318](https://github.com/adeo/tempo-orchestrator--sources/commit/c57a3182dd040ee4427e7e3dbe58f180d8f475ba))
* reverse add comment and delete button ([c8f01e9](https://github.com/adeo/tempo-orchestrator--sources/commit/c8f01e98c0b7fae93e8c58b596357b298c4c93ca))
* **supervisor:** add menu and bpm tabs for the bpm  ([dbd6166](https://github.com/adeo/tempo-orchestrator--sources/commit/dbd6166c0da8a0c81af751351ff8d476e6a0c03a))
* update some css style ([63600d5](https://github.com/adeo/tempo-orchestrator--sources/commit/63600d5a3e595809165cc54c53233801917b7c7b))


### Reverts

* Revert "build(npm): fix vulnerabilities" ([81a6ed1](https://github.com/adeo/tempo-orchestrator--sources/commit/81a6ed17e404d3b4e694af9c431a3eb0d57f88d2))





## [1.22.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.22.2...tempo-orchestrator-supervisor-front@1.22.3) (2024-12-10)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## [1.22.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.22.1...tempo-orchestrator-supervisor-front@1.22.2) (2024-12-04)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## [1.22.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.22.0...tempo-orchestrator-supervisor-front@1.22.1) (2024-12-02)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





# [1.22.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.21.0...tempo-orchestrator-supervisor-front@1.22.0) (2024-11-22)


### Features

* add rule engine button ([a07b02d](https://github.com/adeo/tempo-orchestrator--sources/commit/a07b02d0c7d8c5bc6bba91174bb5d70b5748ba05))





# [1.21.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.20.1...tempo-orchestrator-supervisor-front@1.21.0) (2024-10-21)


### Features

* change the default docker repo to adeo  ([9b6d05e](https://github.com/adeo/tempo-orchestrator--sources/commit/9b6d05e2bb481da4b3f7a17f70efe3c003460c2b))





## [1.20.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.20.0...tempo-orchestrator-supervisor-front@1.20.1) (2024-07-30)


### Bug Fixes

* add buton on right event ([da4dd36](https://github.com/adeo/tempo-orchestrator--sources/commit/da4dd368f5b41035c5299c67c4def44983835021))





# [1.20.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.19.2...tempo-orchestrator-supervisor-front@1.20.0) (2024-07-29)


### Features

* force valuate stock backo ([#4519](https://github.com/adeo/tempo-orchestrator--sources/issues/4519)) ([7fe6c56](https://github.com/adeo/tempo-orchestrator--sources/commit/7fe6c56cbf9d42c73a318f816eec77f7e89c7188))





## [1.19.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.19.1...tempo-orchestrator-supervisor-front@1.19.2) (2024-05-22)


### Bug Fixes

* add missing labels ([83ea32b](https://github.com/adeo/tempo-orchestrator--sources/commit/83ea32b18ffd1cd2568b28605dd46a0ff81c12db))





## [1.19.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.19.0...tempo-orchestrator-supervisor-front@1.19.1) (2024-05-17)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





# [1.19.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.18.0...tempo-orchestrator-supervisor-front@1.19.0) (2023-04-03)


### Features

* add with or without ticket filter and ticket creation date in IHM  ([689b112](https://github.com/adeo/tempo-orchestrator--sources/commit/689b112a30ee7e2843f61c2b5f55672433be5beb))





# [1.18.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.17.1...tempo-orchestrator-supervisor-front@1.18.0) (2023-02-27)


### Features

* add snow ticket number on alert screen ([a6ad23c](https://github.com/adeo/tempo-orchestrator--sources/commit/a6ad23cf08e511e5e2d606d8f10d7fd546953ee2))





## [1.17.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.17.0...tempo-orchestrator-supervisor-front@1.17.1) (2023-02-22)


### Bug Fixes

* event sorting in supervisor front ([#4026](https://github.com/adeo/tempo-orchestrator--sources/issues/4026)) ([421346d](https://github.com/adeo/tempo-orchestrator--sources/commit/421346de0e76552f91aab306e65ca99a13db8cfa))





# [1.17.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.16.1...tempo-orchestrator-supervisor-front@1.17.0) (2022-10-13)


### Features

* manage {buCode} variable on external links  ([1e57160](https://github.com/adeo/tempo-orchestrator--sources/commit/1e571606dc87d9fbfb20b7cd9422d74640263e98))





## [1.16.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.16.0...tempo-orchestrator-supervisor-front@1.16.1) (2022-08-12)


### Bug Fixes

* only solved alert issue when select other filter ([c7c20ed](https://github.com/adeo/tempo-orchestrator--sources/commit/c7c20ed641d745ddc444f08605c4e7e989743e77))





# [1.16.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.15.0...tempo-orchestrator-supervisor-front@1.16.0) (2022-08-11)


### Features

* add dependencies filter  ([02c1739](https://github.com/adeo/tempo-orchestrator--sources/commit/02c1739536fd27e399da376e936e5aa91cd03568))





# [1.15.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.14.0...tempo-orchestrator-supervisor-front@1.15.0) (2022-08-01)


### Features

* reverse add comment and delete button ([97ec15d](https://github.com/adeo/tempo-orchestrator--sources/commit/97ec15dc9445b0914c13f63ed3e59c72cbcd5bbb))





# [1.14.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.13.0...tempo-orchestrator-supervisor-front@1.14.0) (2022-08-01)


### Features

* add bage on comment button ([58ffd35](https://github.com/adeo/tempo-orchestrator--sources/commit/58ffd3595211b8cd72d2124e5768a9b095e73854))
* add frontend to add comments ([616c96d](https://github.com/adeo/tempo-orchestrator--sources/commit/616c96d855ac5720a093f4bd076c00327d13e2f9))





# [1.13.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.12.1...tempo-orchestrator-supervisor-front@1.13.0) (2022-07-29)


### Features

* add checkbox to filter only solved alerts ([a02a994](https://github.com/adeo/tempo-orchestrator--sources/commit/a02a994ae73acd1fe47a45fb58295e76b931d84c))





## [1.12.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.12.0...tempo-orchestrator-supervisor-front@1.12.1) (2022-07-21)


### Bug Fixes

* retry popin button display issue ([f3a07d5](https://github.com/adeo/tempo-orchestrator--sources/commit/f3a07d59ee21d2eb1c2851eb600c427de6925012))





# [1.12.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.11.1...tempo-orchestrator-supervisor-front@1.12.0) (2022-07-20)


### Features

* add delete alert button ([232698a](https://github.com/adeo/tempo-orchestrator--sources/commit/232698a07216335676fd2f284304a9064e08ef09))
* add delete alert button on event list ([3d9b774](https://github.com/adeo/tempo-orchestrator--sources/commit/3d9b774c99b88389c8abe0d4999964f7e89099f7))





## [1.11.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.11.0...tempo-orchestrator-supervisor-front@1.11.1) (2022-07-20)


### Bug Fixes

* links overflow issue ([8d42977](https://github.com/adeo/tempo-orchestrator--sources/commit/8d42977a5ca0596ff6ffcfed44a20773ecb173c8))





# [1.11.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.10.0...tempo-orchestrator-supervisor-front@1.11.0) (2022-07-18)


### Features

* add bu flag on customer order view ([cc64b58](https://github.com/adeo/tempo-orchestrator--sources/commit/cc64b58c7db6ec3e54180d960b8c10f75d079682))





# [1.10.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.9.3...tempo-orchestrator-supervisor-front@1.10.0) (2022-07-18)


### Features

* add bu name filter on alert list ([0ce665f](https://github.com/adeo/tempo-orchestrator--sources/commit/0ce665fec6497b8f867b28dbc16c9d6177b60f58))





## [1.9.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.9.2...tempo-orchestrator-supervisor-front@1.9.3) (2022-07-05)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## [1.9.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.9.1...tempo-orchestrator-supervisor-front@1.9.2) (2022-07-05)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## [1.9.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.9.0...tempo-orchestrator-supervisor-front@1.9.1) (2022-06-29)


### Bug Fixes

* replace all {orderId} on url ([70c23a7](https://github.com/adeo/tempo-orchestrator--sources/commit/70c23a79045a85f35fa9613d715472b0a3f9c013))





# [1.9.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.8.1...tempo-orchestrator-supervisor-front@1.9.0) (2022-06-29)


### Features

* display multiple link on the header ([d20eb5e](https://github.com/adeo/tempo-orchestrator--sources/commit/d20eb5e79b9e70452297199d24ff20c615e59fd2))





## [1.8.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.8.0...tempo-orchestrator-supervisor-front@1.8.1) (2022-06-24)


### Bug Fixes

* add page and pageSize on /alerts call ([a4a92ee](https://github.com/adeo/tempo-orchestrator--sources/commit/a4a92eed09075dbb11d2fe7abe3e6114ca4c9947))





# [1.8.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.7.0...tempo-orchestrator-supervisor-front@1.8.0) (2022-06-02)


### Bug Fixes

* don't close multi select on checkbox click ([6f0a74a](https://github.com/adeo/tempo-orchestrator--sources/commit/6f0a74aaccb388d0af8cd2670f2fcf3ff080f41d))


### Features

* add delivery type on alert table ([c03cb13](https://github.com/adeo/tempo-orchestrator--sources/commit/c03cb13f7409ab0dca615df9b62cc387b78525fe))





# [1.7.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.6.0...tempo-orchestrator-supervisor-front@1.7.0) (2022-05-31)


### Features

* add filter alert in UI ([c06e4f3](https://github.com/adeo/tempo-orchestrator--sources/commit/c06e4f3fc68939cceda4240fee4710a8871352ea))





# [1.6.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.5.0...tempo-orchestrator-supervisor-front@1.6.0) (2022-05-11)


### Features

* add alerts on customer order view ([6b533b2](https://github.com/adeo/tempo-orchestrator--sources/commit/6b533b26d676ae5aee056d7fded395a6430aea53))





# [1.5.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.4.2...tempo-orchestrator-supervisor-front@1.5.0) (2022-05-10)


### Features

* add alerts page ([4559193](https://github.com/adeo/tempo-orchestrator--sources/commit/45591933516314b364884b4f58aec31af7632e88))





## [1.4.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.4.1...tempo-orchestrator-supervisor-front@1.4.2) (2022-04-28)


### Bug Fixes

* overflow issue on filter ([66ba762](https://github.com/adeo/tempo-orchestrator--sources/commit/66ba762f660c4709ed86df33727f76e6017adc91))





## [1.4.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.4.0...tempo-orchestrator-supervisor-front@1.4.1) (2022-04-15)


### Bug Fixes

* customer order line tree not displayed ([d071216](https://github.com/adeo/tempo-orchestrator--sources/commit/d07121677f5c675da296a51464414b3e421fbc74))





# [1.4.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.3.10...tempo-orchestrator-supervisor-front@1.4.0) (2022-04-14)


### Features

* add event filter by line ids ([7352b7b](https://github.com/adeo/tempo-orchestrator--sources/commit/7352b7bc47a25a41ec14a2acd93db15ebfeade22))





## [1.3.10](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.3.9...tempo-orchestrator-supervisor-front@1.3.10) (2022-03-28)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## [1.3.9](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.3.8...tempo-orchestrator-supervisor-front@1.3.9) (2022-03-24)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## 1.3.8 (2022-03-23)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## 1.3.7 (2022-03-01)


### Bug Fixes

* catch timeout exception ([29e08e5](https://github.com/adeo/tempo-orchestrator--sources/commit/29e08e5f48bb06142cce46b70d4d147ef5eb1649))





## [1.3.6](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.3.5...tempo-orchestrator-supervisor-front@1.3.6) (2022-02-17)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## [1.3.5](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.3.4...tempo-orchestrator-supervisor-front@1.3.5) (2022-02-15)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## [1.3.4](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.3.3...tempo-orchestrator-supervisor-front@1.3.4) (2022-02-15)


### Reverts

* Revert "build(npm): fix vulnerabilities" ([5644b87](https://github.com/adeo/tempo-orchestrator--sources/commit/5644b87486a141855c4bfa799ff322e517ba4fa4))





## [1.3.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.3.2...tempo-orchestrator-supervisor-front@1.3.3) (2022-02-03)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## 1.3.2 (2022-02-03)


### Bug Fixes

* remove increase version for payment operation ([41d82a3](https://github.com/adeo/tempo-orchestrator--sources/commit/41d82a3b356d67d7c52082e57e49cb1991ce3834))





## [1.3.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.3.0...tempo-orchestrator-supervisor-front@1.3.1) (2021-12-09)


### Bug Fixes

* retry button position + mono consumer retry issue ([e0d8cf4](https://github.com/adeo/tempo-orchestrator--sources/commit/e0d8cf4932e0e20d736d688f6a182d183e1190c8))





# 1.3.0 (2021-12-09)


### Features

* add retry button ([5c111d9](https://github.com/adeo/tempo-orchestrator--sources/commit/5c111d9b1436b6884735ddafa4bd677ba6adda85))
* add tempo payment orchestrator avro package ([72ae34c](https://github.com/adeo/tempo-orchestrator--sources/commit/72ae34ce5a7d7088a67a58fec1eb2b4f237682ed))





## [1.2.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.2.2...tempo-orchestrator-supervisor-front@1.2.3) (2021-09-28)


### Bug Fixes

* NSREDIRECT cookie host ([e7fe452](https://github.com/adeo/tempo-orchestrator--sources/commit/e7fe452723775df9c87d581a1f801fc75c16784a))





## 1.2.2 (2021-09-20)


### Bug Fixes

* add relay point use case  ([b034e05](https://github.com/adeo/tempo-orchestrator--sources/commit/b034e054143e02415aaabd30a99d149994b555f3))
* xss injection issue on oauth implementation ([750dbb9](https://github.com/adeo/tempo-orchestrator--sources/commit/750dbb9fb9747a86074ade6bef8a68df989dbb04))





## [1.2.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.2.0...tempo-orchestrator-supervisor-front@1.2.1) (2021-08-26)


### Bug Fixes

* set scheme to http on non-local ens ([8c85011](https://github.com/adeo/tempo-orchestrator--sources/commit/8c8501171f6d7cd7f82c6e99bf35fd9cf448c542))





# 1.2.0 (2021-08-23)


### Features

* add datadog span/trace id on cdc messages to send ([619ff23](https://github.com/adeo/tempo-orchestrator--sources/commit/619ff237f57b135b8c033d32460d3fce8816731c))
* add ping on supervisor front ([d84d741](https://github.com/adeo/tempo-orchestrator--sources/commit/d84d741e2972c75a512fe9590486e1490c245623))





# 1.1.0 (2021-07-28)


### Features

* add operation id on commercial gesture execution mail ([33407fa](https://github.com/adeo/tempo-orchestrator--sources/commit/33407faaf4ea6e7e7e242964fd7a22c2a79585a3))





## 1.0.4 (2021-06-28)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## [1.0.3](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.0.2...tempo-orchestrator-supervisor-front@1.0.3) (2021-05-05)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## [1.0.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.0.1...tempo-orchestrator-supervisor-front@1.0.2) (2021-04-12)


### Bug Fixes

* use the initial customer order line on graph execution ([3883895](https://github.com/adeo/tempo-orchestrator--sources/commit/38838951cd545799d710f4fc768de247f7350003))





## [1.0.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@1.0.0...tempo-orchestrator-supervisor-front@1.0.1) (2021-04-06)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





# [1.0.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.16.2...tempo-orchestrator-supervisor-front@1.0.0) (2021-04-02)


### Features

* go live 1.0.0 ([cfade6e](https://github.com/adeo/tempo-orchestrator--sources/commit/cfade6eba194e6c165cd64de9879b3a1fb4fb9d8))





## [0.16.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.16.1...tempo-orchestrator-supervisor-front@0.16.2) (2021-04-02)


### Bug Fixes

* bpmn editor label update name ([530725e](https://github.com/adeo/tempo-orchestrator--sources/commit/530725e79821bd74a65fcf5a85b3aa6c501779f0))





## [0.16.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.16.0...tempo-orchestrator-supervisor-front@0.16.1) (2021-04-02)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





# [0.16.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.15.1...tempo-orchestrator-supervisor-front@0.16.0) (2021-04-01)


### Bug Fixes

* show gateway as warning if previous event is warning ([8cab09e](https://github.com/adeo/tempo-orchestrator--sources/commit/8cab09ee79984f3276265172edfe29fe3c964f57))


### Features

* don't open event panel when no event ([77cc1a8](https://github.com/adeo/tempo-orchestrator--sources/commit/77cc1a8f336b59ca8f07b09118ea2dbbd27e8d01))





## [0.15.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.15.0...tempo-orchestrator-supervisor-front@0.15.1) (2021-03-30)


### Bug Fixes

* **css:** margin issue on the welcome page ([c1d739d](https://github.com/adeo/tempo-orchestrator--sources/commit/c1d739d625053b07bba74c66f4413ce4b96d911d))





# [0.15.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.14.0...tempo-orchestrator-supervisor-front@0.15.0) (2021-03-30)


### Features

* allow to match only 1P or 3P on event ([d15b064](https://github.com/adeo/tempo-orchestrator--sources/commit/d15b064a2ff07974a087f73eff915a049bd88b91))





# [0.14.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.13.0...tempo-orchestrator-supervisor-front@0.14.0) (2021-03-30)


### Features

* update some css style ([2b4b688](https://github.com/adeo/tempo-orchestrator--sources/commit/2b4b688bd887b259e4a1c838c664128a08b157f2))





# [0.13.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.12.0...tempo-orchestrator-supervisor-front@0.13.0) (2021-03-26)


### Features

* colorize bpm graph with received events ([2cd28d8](https://github.com/adeo/tempo-orchestrator--sources/commit/2cd28d84cba4a01655734db3e9cd050b1d24435a))





# [0.12.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.11.0...tempo-orchestrator-supervisor-front@0.12.0) (2021-03-26)


### Features

* **supervisor:** add menu and bpm tabs for the bpm  ([2ced152](https://github.com/adeo/tempo-orchestrator--sources/commit/2ced152fa608c6c613d6c246955c81ed3afe86e7))





# [0.11.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.10.0...tempo-orchestrator-supervisor-front@0.11.0) (2021-03-26)


### Features

* **editor:** add import button to load a bpm ([a8684c5](https://github.com/adeo/tempo-orchestrator--sources/commit/a8684c5a4474eab3a765a58138a9eda53be4530a))





# [0.10.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.9.0...tempo-orchestrator-supervisor-front@0.10.0) (2021-03-24)


### Features

* add bpm editor view ([dcb14b6](https://github.com/adeo/tempo-orchestrator--sources/commit/dcb14b6deea259524dcd107a9c78e3dd51a1f2e8))





# 0.9.0 (2021-03-19)


### Features

* manage functional type for CustomerOrderValidated event ([9f10435](https://github.com/adeo/tempo-orchestrator--sources/commit/9f10435378b704bfa6285833de15bb9b95220f45))





# 0.8.0 (2021-03-08)


### Bug Fixes

* add content type on cashing /items ([27467a7](https://github.com/adeo/tempo-orchestrator--sources/commit/27467a7e4b8af78abcd83b68f7ea4e06806e1e7e))


### Features

* delete env file with app url and use vault ([#2445](https://github.com/adeo/tempo-orchestrator--sources/issues/2445)) ([fc94f2e](https://github.com/adeo/tempo-orchestrator--sources/commit/fc94f2e2a6a1eb755e304217ec09da4205fca3ff))





## [0.7.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.7.0...tempo-orchestrator-supervisor-front@0.7.1) (2021-02-19)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





# [0.7.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.6.2...tempo-orchestrator-supervisor-front@0.7.0) (2021-02-18)


### Features

* remove openshift code and scripts ([b93d096](https://github.com/adeo/tempo-orchestrator--sources/commit/b93d0964984a2ed01a07e3e74fc0f9ef5aa83769))





## [0.6.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.6.1...tempo-orchestrator-supervisor-front@0.6.2) (2020-11-18)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## [0.6.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.6.0...tempo-orchestrator-supervisor-front@0.6.1) (2020-11-18)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





# 0.6.0 (2020-11-10)


### Features

* **deploy:** use turbine-based urls for supervisor api ([7ac8c00](https://github.com/adeo/tempo-orchestrator--sources/commit/7ac8c000d9c453a63b5ff88900b70901c3049620))





## [0.5.2](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.5.1...tempo-orchestrator-supervisor-front@0.5.2) (2020-10-30)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## [0.5.1](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.5.0...tempo-orchestrator-supervisor-front@0.5.1) (2020-10-30)


### Bug Fixes

* deploy on sit ([f9b9441](https://github.com/adeo/tempo-orchestrator--sources/commit/f9b9441d02a25aec26d5b00c361dcc8fd094c8cd))





# 0.5.0 (2020-10-30)


### Bug Fixes

* **publish:** use package version ([b98ce0d](https://github.com/adeo/tempo-orchestrator--sources/commit/b98ce0df2047fd58919f447b7baf80d9d8adcd58))


### Features

* deploy on sit ([b6080f2](https://github.com/adeo/tempo-orchestrator--sources/commit/b6080f224e14f3dc14e32c78baf458139bc63813))





## 0.4.3 (2020-10-22)


### Bug Fixes

* **notify:** use the new notify event name ([a2b07e2](https://github.com/adeo/tempo-orchestrator--sources/commit/a2b07e2168c95be4171b252c693a47a52726cd2d))





## 0.4.2 (2020-10-14)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





## 0.4.1 (2020-06-08)

**Note:** Version bump only for package tempo-orchestrator-supervisor-front





# [0.4.0](https://github.com/adeo/tempo-orchestrator--sources/compare/tempo-orchestrator-supervisor-front@0.3.0...tempo-orchestrator-supervisor-front@0.4.0) (2020-06-03)


### Bug Fixes

* **supervisor:** tempo composer link ([5201830](https://github.com/adeo/tempo-orchestrator--sources/commit/5201830ce76508a1b974ebb653a5b3ba20e9c89f))


### Features

* add link to tco supervisor and kafka meta ([b7682f2](https://github.com/adeo/tempo-orchestrator--sources/commit/b7682f2e6fb45662c1b26d3acccd6b22cc05f2b2))





# 0.3.0 (2020-06-02)


### Features

* **deploy:** activate eco mode and low replicas ([db0044f](https://github.com/adeo/tempo-orchestrator--sources/commit/db0044fdd795b23ab8c5e2c68ab03651e860e78c))





# 0.2.0 (2020-05-12)


### Features

* **supervisor:** add frontend ([e4189a1](https://github.com/adeo/tempo-orchestrator--sources/commit/e4189a11d24aa176b30d2bbdf7a4be115c5caae3))
