const proxyConfig = {
  target: process.env.API_URL ? process.env.API_URL : 'http://localhost:8080',
  pathRewrite: {},
  logLevel: 'debug',
  secure: false,
  autoRewrite: true,
  cookieDomainRewrite: {
    '*': ''
  }
}

let pathRewrite = {}
if (process.env.WITH_NGINX !== 'true') {
  pathRewrite = {
    '^/backend/': '/'
  }
}

module.exports = {
  devServer: {
    proxy: {
      '/backend': {
        ...proxyConfig,
        pathRewrite: pathRewrite
      },
      '/login/*': proxyConfig,
      '/oauth2/*': proxyConfig
    }
  }
}
