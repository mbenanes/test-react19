export interface OrchestratorEvent {
  id: string;
  metadata: { consumerApi: string[]; timestamp: string; source: string; eventType: string; traceId: string; functionalType: string; customerOrderLineIds: string[] };
  value: object;
}

export interface CustomerOrderInfo {
  id: string;
  number: string;
  buCode: string;
  version: number;
  offerLines: CustomerOrderLineMetadata[];
  delivery: string;
}

export interface CustomerOrderMetadata {
  customerOrderId: string;
  buCode: string;
  customerOrderLines: CustomerOrderLineMetadata[];
}

export interface CustomerOrderLineMetadata {
  id: string;
  soldByAThirdParty: boolean;
  refLM: string;
  adeoKey: string;
  vendorName: string;
  deliveryType: string;
}
export interface RetryReponse {
  id: string;
  topic: string;
  offset: number;
  partition: number;
}
