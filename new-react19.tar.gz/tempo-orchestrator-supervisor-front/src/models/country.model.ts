export type UUID = string

export type BuCodeType = '001' | '002' | '003' | '005' | '006'

export interface Country {
  code: string;
  name: string;
  flag: string;
}

export const COUNTRY_CODES: Record<BuCodeType, Country> = {
  '001': { code: 'FR', name: 'France', flag: 'fr' },
  '002': { code: 'ES', name: 'Spain', flag: 'es' },
  '003': { code: 'PT', name: 'Portugal', flag: 'pt' },
  '005': { code: 'IT', name: 'Italy', flag: 'it' },
  '006': { code: 'PL', name: 'Poland', flag: 'pl' }
}
