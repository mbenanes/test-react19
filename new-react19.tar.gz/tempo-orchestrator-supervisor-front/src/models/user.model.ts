export interface Actor {
  name: string;
  logURL: string;
}

export interface Configuration {
  actors: Actor[];
  tempoComposerSupervisor: string;
  environmentName: string;
  actionButtons: ActionButton[];
}

export interface ActionButton {
  name: string;
  url: string;
  displayedOnHome: boolean;
  displayedOnCustomerOrderPage: boolean;
  authoritiesRestrictions: string[];
}

export interface User {
  authorities: string[];
}
