export interface Bpm {
  id: string;
  version: number;
  name: string;
  bpmXML: string;
}
