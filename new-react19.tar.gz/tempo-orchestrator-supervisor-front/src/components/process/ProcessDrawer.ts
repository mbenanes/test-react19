export interface Event {
  metadata: {timestamp: string; source: string; eventType: string; functionalType: string};
  value: object;
}

export interface Group {
  group: string;
  lifeLines: Sequence[];
}

export interface Sequence {
  actor: string;
  input: ProcessFlow;
  sequence: ProcessFlow[];
}

export interface Process {
  actors: {[key: string]: Actor};
  sequences: Group[];
}

export interface Actor {
  name: string;
  logURL: string;
}

export interface ProcessFlow {
  from?: string;
  to?: string;
  event?: EventPattern;
  step?: string;
  group?: ProcessFlow[];
  activate?: string;
  desactivate?: string;
}

export interface EventPattern {
  type: string;
  functionalType: string;
}

export interface LifeLine {
  actor: string;
  color: string;
  linkTemplate: string;
  inputEvents: Event[];
}

export interface CssMap {
  [key: string]: string;
}

export class ProcessDrawer {
  public actors: string[];

  public currentLifeLines: LifeLine[];

  private lifeLinesColor: string[] = [
    '#3498db',
    '#2ecc71',
    '#e74c3c',
    '#f39c12',
    '#bdc3c7',
    '#2c3e50',
    '#16a085'
  ]

  private MAX_WIDTH_PERCENT = 100;

  constructor (
    private events: Event[],
    private process: Process
  ) {
    this.actors = Object.values(process.actors).map(actor => actor.name)
    this.currentLifeLines = []
  }

  public get numberOfActor (): number {
    return this.actors.length
  }

  public columnWidth (): number {
    return this.MAX_WIDTH_PERCENT / this.numberOfActor
  }

  public lineWidth (): number {
    return this.columnWidth() / 2
  }

  public lineLeftPosition (actorIdx: number): number {
    return (actorIdx * 2 + 1) * this.lineWidth()
  }

  public actorIndex (actorName?: string): number {
    return actorName ? this.actors.indexOf(actorName) : -1
  }

  public columnStyle (actorIdx: number): CssMap {
    const numberOfActor = this.numberOfActor
    const columnWidth = this.columnWidth()
    const right = (numberOfActor - actorIdx - 1) * columnWidth
    const left = actorIdx * columnWidth

    return {
      'margin-right': `${right}%`,
      'margin-left': `${left}%`
    }
  }

  public lineStyle (actorIdx: number): CssMap {
    return {
      'margin-left': `${this.lineLeftPosition(actorIdx)}%`
    }
  }

  public eventStatusClass (action: ProcessFlow): 'found' | 'not-found' {
    const foundEvents = this.associatedEvents(action)
    if (foundEvents) {
      return 'found'
    } else {
      return 'not-found'
    }
  }

  public numberOfEvent (action: ProcessFlow): number {
    return this.associatedEvents(action).length
  }

  public associatedEvents (action: ProcessFlow): Event[] {
    if (this.events) {
      return this.events.filter(value => this.eventMatch(value, action))
    }
    return []
  }

  public eventMatch (event: Event, action: ProcessFlow): boolean {
    const eventType = action.event?.type
    const functionalType = action.event?.functionalType
    if (!eventType || !event.metadata.eventType.endsWith(eventType)) {
      return false
    }
    return !functionalType || functionalType === event.metadata.functionalType
  }

  public actionStyle (action: ProcessFlow): CssMap {
    const fromIndex = this.actorIndex(action.from)
    const toIndex = this.actorIndex(action.to)

    const leftLinePercent = this.lineLeftPosition((fromIndex < toIndex) ? fromIndex : toIndex)
    const rightLinePercent = this.lineLeftPosition((fromIndex < toIndex) ? toIndex : fromIndex)

    return {
      'margin-left': `calc(${leftLinePercent}% + 5px)`,
      'margin-right': `calc(${this.MAX_WIDTH_PERCENT - rightLinePercent}% + 5px)`
    }
  }

  public activate (actor: string, input: ProcessFlow): void {
    this.currentLifeLines.push({
      actor: actor,
      color: this.popColor(),
      linkTemplate: this.process.actors[actor].logURL,
      inputEvents: this.associatedEvents(input)
    })
  }

  public desactivate (actor: string): void {
    const lastActorLifeLine = this.currentLifeLines.slice().reverse().find(lifeLine => lifeLine.actor === actor)
    if (lastActorLifeLine) {
      const lastActorIndex = this.currentLifeLines.lastIndexOf(lastActorLifeLine)
      this.currentLifeLines.splice(lastActorIndex, 1)
    }
  }

  public lifeLines (): LifeLine[] {
    return [...this.currentLifeLines]
  }

  public lifeLineStyle (lifeLine: LifeLine): CssMap {
    return {
      'margin-left': `calc(${this.lineStyle(this.actorIndex(lifeLine.actor))['margin-left']} - 5px)`,
      'border-left': '10px solid ' + lifeLine.color
    }
  }

  private popColor (): string {
    const color = this.lifeLinesColor.pop() || 'black'
    this.lifeLinesColor.unshift(color)
    return color
  }
}
