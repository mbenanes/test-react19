<template>
  <actionGroup v-if="action.group" :action="action" :processDrawer="processDrawer"/>
  <div v-else-if="action.step" class="section-title">{{action.step}}</div>
  <div v-else-if="action.from" class="action-container">
    <div class="lifeline"
         v-for="(lifeLine, lifeLineIndex) in lifeLines"
        :key="lifeLineIndex"
        :style="processDrawer.lifeLineStyle(lifeLine)"
        :class="{'with-link': canOpenLogs(lifeLine)}"
        @click="openLink(lifeLine, lifeLineIndex)"
    >
      <div class="event-log-links"
        v-if="lifeLine.linkTemplate !== undefined && lifeLine.inputEvents.length > 1"
        :class="{opened: isLifeLineOpen[lifeLineIndex]}">
        <div class="links">
          <div
            v-for="(event, index) of lifeLine.inputEvents"
            :key="'link' + lifeLineIndex + index" class="event-link"
            >
            <span>traceId: {{event.metadata.traceId}} at: <!-- {{event.metadata.timestamp | moment('DD/MM/YYYY HH:mm:ss')}} --> </span>
            <a :href="logURL(lifeLine, event)" target="_blank"> open logs </a>
          </div>
        </div>
        <div class="close"> <span> X </span> </div>
      </div>
    </div>
    <div class="action"
        :style="processDrawer.actionStyle(action)"
        :class="{'found': associatedEvents.length > 0}">
      <div class="arrow">
        <svg v-if="processDrawer.actorIndex(action.from) < processDrawer.actorIndex(action.to)" alt="-->" width="100%" height="14" preserveAspectRatio="xMaxYMid slice" viewBox="0 0 1400 14"><polygon points="1400,7 1385,1 1390,6 0,6 0,8 1390,8 1385,13 1400,7"></polygon></svg>
        <svg v-if="processDrawer.actorIndex(action.from) > processDrawer.actorIndex(action.to)" alt="<--" width="100%" height="14" preserveAspectRatio="xMinYMid slice" viewBox="0 0 1400 14"><polygon points="0,7 15,1 10,6 1400,6 1400,8 10,8 15,13 0,7"></polygon></svg>
      </div>
      <span class="event-info"
            :title="associatedEvents.length + '*' + action.event.type + ' ' + action.event.functionalType"
            @click="showAssociatedEvents = !showAssociatedEvents">
            {{associatedEvents.length}} * {{action.event.type}} {{action.event.functionalType}}
      </span>
      <div class="associated-events" v-if="associatedEvents.length > 0" :class="{'show': showAssociatedEvents}">
        <event-list :events="associatedEvents">
          <template #header="{event}">
              <div class="traceId">traceId: {{event.metadata.traceId}}</div>
              <div class="timestamp">at {{formatDate(event.metadata.timestamp)}}</div>
          </template>
        </event-list>
        <div class="header" @click="showAssociatedEvents = false">
          {{action.event.type}} {{action.event.functionalType}}
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-facing-decorator'
import { ProcessFlow, ProcessDrawer, LifeLine, Event } from './ProcessDrawer'
import EventList from '../EventList.vue'
import { formatDate } from '@/utils/utils'

@Component({
  methods: {
  formatDate
  },
  components: { EventList }
  })
export default class Action extends Vue {
  @Prop()
  public action?: ProcessFlow;

  @Prop()
  public lifeLines?: LifeLine[];

  @Prop()
  public processDrawer?: ProcessDrawer;

  public showAssociatedEvents = false;

  public isLifeLineOpen: boolean[] = [false, false, false];

  public get associatedEvents (): Event[] {
    if (this.action && this.processDrawer) {
      return this.processDrawer.associatedEvents(this.action)
    } else {
      return []
    }
  }

  public openLink (lifeLine: LifeLine, lifeLineIndex: number) {
    if (this.canOpenLogs(lifeLine)) {
      if (lifeLine.inputEvents.length === 1) {
        window.open(this.logURL(lifeLine, lifeLine.inputEvents[0]), '_blank')
      } else {
        Vue.set(this.isLifeLineOpen, lifeLineIndex, !this.isLifeLineOpen[lifeLineIndex])
      }
    }
  }

  public logURL (lifeLine: LifeLine, event: Event): string {
    const replaced = lifeLine.linkTemplate.replace(/\{([^}]+)\}/g, (original, matched) => {
      // eslint-disable-next-line
      return eval(matched)
    })
    return replaced
  }

  public canOpenLogs (lifeLine: LifeLine): boolean {
    return lifeLine.linkTemplate !== undefined && lifeLine.inputEvents.length > 0
  }
}
</script>

<style scoped lang="scss">

.actors {
  display: flex;

  .actor {
    flex: 1 1 auto;
    padding: 10px;
    border: 1px solid black;
  }
}

.action-container {
  position: relative;
  padding-top: 5px;
  z-index: 1000;

  .lifeline {
    position: absolute;
    height: 100%;
    top: 0;

    &.with-link {
      cursor: pointer;
    }

    .event-log-links {
      position: absolute;
      width: 500px;
      bottom: 35px;
      right: 0;
      margin-right: -250px;
      background: white;
      border: 1px solid rgba(0,0,0,.125);

      display: none;
      &.opened {
        display: flex;
        align-items: stretch;
      }

      .links {
        flex: 1 1 auto;
        .event-link {
          padding: 10px;
          border-bottom: 1px solid rgba(0,0,0,.125);
          cursor: default;
        }
      }

      .close {
        flex: 1 1 auto;
        display: flex;
        align-items: center;

        > span {
          flex: 1 1 auto;
        }

        border-left: 1px solid rgba(0,0,0,.125);
        text-align: center;
        &:hover {
          background-color: rgba(128, 128, 128, .11);
          flex: 1 1 auto;
        }
      }
    }
  }

  .action {
    color: #b4abab;
    padding-bottom: 10px;
    line-height: 1;
    margin-top: 0;
    position: relative;
    text-align: center;
    margin-top: 0.5em;
    padding-bottom: 10px;
    line-height: 1;

    &.found {
      color: green;
      font-weight: bold;

      .event-info {
        cursor: pointer;
      }
    }

    .event-info {
      text-overflow: ellipsis;
      white-space: nowrap;
      display: block;
      margin-left: 10px;
      width: 94%;
      overflow: hidden;
      z-index: 5;
      position: relative;
    }
  }

  .associated-events {
    position: absolute;
    left: 50%;
    margin-left: -250px;
    width: 500px;
    background-color: white;
    bottom: 10px;
    border: 1px solid black;
    z-index: 10;
    display: none;

    &.show {
      display: block;
    }

    .header {
      padding-top: 5px;
      cursor: pointer;
      border-top: 1px solid rgba(0, 0, 0, 0.26);
      &::after {
        content: 'X';
        float: right;
        padding-right: 10px;
      }
    }
  }

  .arrow {
    position: absolute;
    bottom: 0;
    width: 100%;
    z-index: 0;
  }
}

.section-title {
  font-size: 1.2em;
  color: #888;
  margin-left: 0.5em;
  text-align: left;
  position: relative;
  top: -0.2em;
  border-bottom: 3px dashed #DDD;
}

</style>
