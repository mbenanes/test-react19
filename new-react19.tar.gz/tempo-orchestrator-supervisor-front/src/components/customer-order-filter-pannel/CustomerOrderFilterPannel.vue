<template>
    <div class="filter-pannel">
      <div class="filter-global">
        <span @click="resetFilters()" class="link">Reset filters</span>
      </div>
      <div class="filter-lines">
        <h2>Lines:</h2>
        <div class="lines-options">
          <span @click="resetFilters()" class="link">Select all</span> |
          <span @click="unselectAll()" class="link">Unselect all</span>
        </div>
        <CustomerOrderLinesTree :tree="filterTree" :value="selectedLines" :lineIdsForVisibleEvents="eventLineIds" @input="updateSelectedLinesFilter($event)"/>
      </div>
      <div class="filter-dependencies">
        <h2>Dependencies:</h2>
        <CustomerOrderDependencies :allDependencies="allDependencies" :dependencies="filterDependencies" :value="selectedDependencies" @input="updateSelectedDependenciesFilter($event)"/>
      </div>
    </div>
</template>

<script lang="ts">
import { Component, Emit, Prop, Vue } from 'vue-facing-decorator'
import CustomerOrderLinesTree from '@/components/customer-order-lines-tree/CustomerOrderLinesTree.vue'
import CustomerOrderDependencies from '@/components/customer-order-dependencies/CustomerOrderDependencies.vue'
import { CustomerOrderLineMetadata, CustomerOrderMetadata, OrchestratorEvent } from '@/models'
import { useCommandStore } from '@/store'

function groupBy (array: CustomerOrderLineMetadata[], keyGenerator: (line: CustomerOrderLineMetadata) => string) {
  const result: {[key: string]: any} = {}
  for (const item of array) {
    const key = keyGenerator(item)
    result[key] = result[key] || []
    result[key].push(item)
  }
  return result
}

function extract3PCheckboxes (lines: CustomerOrderLineMetadata[]) {
  const thirdPartyLines = lines.filter(line => line.deliveryType === 'THIRD_PARTY')
  return groupBy(thirdPartyLines, line => line.vendorName)
}

function extract1PCheckboxes (lines: CustomerOrderLineMetadata[]) {
  const firstPartyLines = lines.filter(line => line.deliveryType !== 'THIRD_PARTY')
  return groupBy(firstPartyLines, line => line.deliveryType)
}

function createCheckboxes (lines: CustomerOrderLineMetadata[]) {
  const result: {[key: string]: any} = {}
  const thirdParty = extract3PCheckboxes(lines)
  const firstParty = extract1PCheckboxes(lines)

  if (Object.keys(thirdParty)?.length > 0) {
    result['3P'] = thirdParty
  }
  if (Object.keys(firstParty)?.length > 0) {
    result['1P'] = firstParty
  }

  return result
}

@Component({
  components: {
  CustomerOrderLinesTree,
  CustomerOrderDependencies
  },
  })
export default class CustomerOrderFilterPannel extends Vue {
  private store = useCommandStore();
  @Prop()
  public filters?: any;

  public allDependencies: any = {}
  public filterDependencies: any = {}
  public filterTree: any = {}
  public selectedDependencies: string[] = []
  public selectedLines: string[] = []

  created () {
    this.store.$subscribe((mutation, state) => {
      if (mutation.type === 'updateCustomerOrderMetadata' || mutation.type === 'updateFilteredEvents') {
        this.updateCustomerOrderMetadata(state.customerOrderMetadata)
        this.updateDependencies(state.filteredEvents)
        if (this.filters && 'lines' in this.filters) {
          this.selectedLines = this.filters.lines
        }
        if (this.filters && 'dependencies' in this.filters) {
          this.selectedDependencies = this.filters.dependencies
        }
      }
    })
    this.updateFilters()
  }

  private updateFilters () {
    this.updateCustomerOrderMetadata(this.store.customerOrderMetadata)
    this.updateDependencies(this.store.filteredEvents)
    if (this.filters && 'lines' in this.filters) {
      this.selectedLines = this.filters.lines
    }
    if (this.filters && 'dependencies' in this.filters) {
      this.selectedDependencies = this.filters.dependencies
    }
  }

  updateCustomerOrderMetadata (customerOrderMetadata?: CustomerOrderMetadata) {
    if (customerOrderMetadata) {
      this.filterTree = createCheckboxes(customerOrderMetadata?.customerOrderLines)
      this.selectedLines = customerOrderMetadata?.customerOrderLines?.map((line: CustomerOrderLineMetadata) => line.id) ?? []
    } else {
      this.filterTree = undefined
      this.selectedLines = []
    }
  }

  get eventLineIds () {
    return [...new Set(this.store.filteredEvents
      ?.filter((event: OrchestratorEvent) => this.selectedDependencies?.length === 0 || this.selectedDependencies.includes(event.metadata.source))
      ?.flatMap((event: OrchestratorEvent) => event.metadata?.customerOrderLineIds?.map(value => value)))]
  }

  updateDependencies (events?: OrchestratorEvent[]) {
    if (events) {
      this.allDependencies = this.getDependenciesFromEvents(this.store.events)
      this.filterDependencies = this.getDependenciesFromEvents(events)
      this.selectedDependencies = this.filterDependencies
    } else {
      this.allDependencies = undefined
      this.filterDependencies = undefined
      this.selectedDependencies = []
    }
  }

  getDependenciesFromEvents (events?: OrchestratorEvent[]) {
    return [...new Set(events?.map((event: OrchestratorEvent) => event.metadata.source))]
  }

  public updateSelectedFilter () {
    const filtersUpdatedData: {lines?: string[]; dependencies?: string[]} = {}
    if (this.selectedLines?.length !== this.store.customerOrderMetadata?.customerOrderLines?.length) {
      filtersUpdatedData.lines = this.selectedLines
    }
    if (this.selectedDependencies?.length !== this.getDependenciesFromEvents(this.store.events)?.length) {
      filtersUpdatedData.dependencies = this.selectedDependencies
    }
    this.emitFiltersUpdated(filtersUpdatedData)
  }

  public resetFilters () {
    this.emitFiltersUpdated({})
  }

  @Emit('filtersUpdated')
  private emitFiltersUpdated (filters: {}) {
    return filters
  }

  public unselectAll () {
    this.updateSelectedLinesFilter([])
  }

  public updateSelectedLinesFilter (lines: string[]) {
    this.selectedLines = lines
    this.updateSelectedFilter()
  }

  public updateSelectedDependenciesFilter (dependencies: string[]) {
    this.selectedDependencies = dependencies
    this.updateSelectedFilter()
  }
}
</script>

<style scoped lang="scss">
  .filter-pannel{
    min-width: fit-content;
  }

  h2{
    font-size: 16px;
  }

  .filter-global {
    float: right;
  }

  .filter-lines {
    margin-top: 40px;
  }

  .filter-dependencies{
    border-top: solid thin grey;
    margin-top: 20px;
    padding-top: 20px;
  }

  .lines-options {
    margin-left: 40px;
  }

</style>
