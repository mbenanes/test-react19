<template>
  <div class="bpmn-editor">
    <div id="bpmn"></div>
    <div id="js-properties-panel"></div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch } from 'vue-facing-decorator'

import BpmnModeler from 'bpmn-js/lib/Modeler'
import keyboardFeature from 'bpmn-js/lib/features/keyboard'
import propertiesPanelModule from 'bpmn-js-properties-panel'

import propertiesProviderModule from '../tor-extension'
import torModdleDescriptor from '../tor-extension/tor.json'

import 'bpmn-js/dist/assets/diagram-js.css'
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css'
import 'bpmn-js-properties-panel/dist/assets/bpmn-js-properties-panel.css'

const defaultBPM =
`
<?xml version="1.0" encoding="UTF-8"?>
<bpmn2:definitions xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:bpmn2="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xsi:schemaLocation="http://www.omg.org/spec/BPMN/20100524/MODEL BPMN20.xsd" id="sample-diagram" targetNamespace="http://bpmn.io/schema/bpmn">
  <bpmn2:process id="Process_1" isExecutable="false">
  </bpmn2:process>
  <bpmndi:BPMNDiagram id="BPMNDiagram_1">
    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1">
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</bpmn2:definitions>
`

@Component({})
export default class BpmnEditor extends Vue {
  @Prop({
    default: defaultBPM
  })
  public value?: string;

  private viewer: any;

  @Watch('value', { immediate: true })
  public async eventsChanged () {
    if (this.value && this.viewer) {
      const currentValue = (await this.currentXML()).xml
      if (currentValue !== this.value) {
        this.viewer.importXML(this.value)
      }
    }
  }

  async mounted (): Promise<void> {
    this.viewer = new BpmnModeler({
      container: '#bpmn',
      propertiesPanel: {
        parent: '#js-properties-panel'
      },
      additionalModules: [
        propertiesPanelModule,
        propertiesProviderModule,
        keyboardFeature
      ],
      moddleExtensions: {
        tempo: torModdleDescriptor
      },
      keyboard: { bindTo: document }
    })

    this.viewer.on('element.changed', async () => {
      const savedBpm = await this.currentXML()
      this.emitNewValue(savedBpm.xml)
    })

    await this.viewer.importXML(this.value)
  }

  private emitNewValue (value: string): void {
    this.$emit('input', value)
  }

  private async currentXML (): Promise<{xml: string}> {
    return await this.viewer.saveXML()
  }
}
</script>

<style scoped lang="scss">
.bpmn-editor {
  height: 100%;
  display: flex;
  flex-direction: row;
  width: 100%;

  #js-properties-panel {
    width: 20vw;
    height: 100%;
    background-color: #f8f8f8;
  }

  #bpmn {
    width: 80vw;
    height: 100%;
  }
}
</style>

<!-- This is a bpm properties pannel fix -->
<style lang="scss">
.bpp-textfield input {
  padding-right: 0;
  width: calc(100% - 28px);
}
</style>
