import TORPropertiesProvider from './TORPropertiesProvider'

export default {
  __init__: ['propertiesProvider'],
  propertiesProvider: ['type', ['eventBus', 'bpmnFactory', 'canvas', 'elementRegistry', 'translate', TORPropertiesProvider]]
}
