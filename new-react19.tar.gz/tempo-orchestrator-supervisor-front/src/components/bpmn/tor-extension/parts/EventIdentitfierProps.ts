import entryFactory from 'bpmn-js-properties-panel/lib/factory/EntryFactory'
import { is } from 'bpmn-js/lib/util/ModelUtil'

export default function (group: any, element: any) {
  if (is(element, 'bpmn:Event')) {
    group.entries.push(entryFactory.textField((it: any) => it, {
      id: 'eventType',
      description: 'The type of the event (example: PaymentUpdated)',
      label: 'Event type',
      modelProperty: 'eventType'
    }))

    group.entries.push(entryFactory.textField((it: any) => it, {
      id: 'functionalType',
      description: 'The event functional meaning (example CAPTURE_SUCCEED)',
      label: 'Event functional type',
      modelProperty: 'eventFunctionalType'
    }))

    group.entries.push(entryFactory.checkbox((it: any) => it, {
      id: 'isWarning',
      description: 'The event is a functional error case  ',
      label: 'Is warning',
      modelProperty: 'isWarning'
    }))

    group.entries.push(entryFactory.checkbox((it: any) => it, {
      id: 'match1P',
      description: 'the event should match 1P lines',
      label: 'Match 1P',
      modelProperty: 'match1P'
    }))

    group.entries.push(entryFactory.checkbox((it: any) => it, {
      id: 'match3P',
      description: 'the event should match 3P lines',
      label: 'Match 3P',
      modelProperty: 'match3P'
    }))
  }

  if (is(element, 'bpmn:Task')) {
    group.entries.push(entryFactory.textField((it: any) => it, {
      id: 'logUrl',
      description: 'Url to access logs',
      label: 'Log URL',
      modelProperty: 'logUrl'
    }))

    group.entries.push(entryFactory.checkbox((it: any) => it, {
      id: 'keepTraceId',
      description: 'If checked the trace will be used to correlate input events with output events. Check it only if lines can not be read on events',
      label: 'Keep trace id',
      modelProperty: 'keepTraceId'
    }))
  }
}
