<template>
  <div class="bpmn-view">
    <nav-tab>
      <tab v-for="item in bpmViews" :key="item.id" @click="showBpm(item)" :selected="item.name === currentBpmName">
        {{ item.name }}
      </tab>
    </nav-tab>

    <div id="bpmn"></div>

    <div class="event-view" v-if="showSelectedEvent">
      <div class="close-view" @click="showSelectedEvent = false"> close </div>
      <event-list class="events" :events="selectedEvents"/>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-facing-decorator'
import { buildBpmnObject } from './bpmn-reader'
import { BpmnFlow, buildBpmnFlow } from './graph-execution'

import NavTab from '@/components/nav-tabs/NavTabs.vue'
import Tab from '@/components/nav-tabs/Tab.vue'
import EventList from '@/components/EventList.vue'
import BpmnViewer from 'bpmn-js/lib/Viewer'
import torModdleDescriptor from '../tor-extension/tor.json'

import 'bpmn-js/dist/assets/diagram-js.css'
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css'
import 'bpmn-js-properties-panel/dist/assets/bpmn-js-properties-panel.css'

import { Bpm, CustomerOrderLineMetadata, CustomerOrderMetadata, OrchestratorEvent } from '@/models'
import { useAppStore } from '@/store'

function groupByLineId (linesMetadata: CustomerOrderLineMetadata[]): {[lineId: string]: CustomerOrderLineMetadata} {
  return linesMetadata.reduce(
    (accumulator, line) => {
      accumulator[line.id] = line
      return accumulator
    },
    {} as {[lineId: string]: CustomerOrderLineMetadata}
  )
}

@Component({
  components: {
  EventList,
  NavTab,
  Tab
  }
  })
export default class BpmnView extends Vue {
  private store = useAppStore();

  @Prop({})
  public bpmViews?: Bpm[];

  @Prop({})
  public events?: OrchestratorEvent[];

  @Prop({})
  public customerOrderMetadata?: CustomerOrderMetadata;

  private viewer: any
  private showSelectedEvent = false
  private selectedEvents: OrchestratorEvent[] = []
  private currentBpmFlow?: BpmnFlow
  public currentBpmName = ''

  async mounted (): Promise<void> {
    this.viewer = new BpmnViewer({
      container: '#bpmn',
      moddleExtensions: {
        tempo: torModdleDescriptor
      }
    })
    if (this.bpmViews) {
      this.showBpm(this.bpmViews[0])
    }
  }

  async showBpm (bpm: Bpm): Promise<void> {
    if (this.viewer) {
      this.currentBpmName = bpm.name
      await this.viewer.importXML(bpm.bpmXML)
      const canvas = this.viewer.get('canvas')
      canvas.zoom('fit-viewport')

      // Use setTimeout because process can take more than 500ms and without that the screen will freez
      setTimeout(() => {
        if (this.customerOrderMetadata && this.events) {
          if (this.currentBpmFlow) {
            this.currentBpmFlow.unbind(this.viewer)
          }
          const graph = buildBpmnObject(this.viewer.getDefinitions().rootElements)
          this.currentBpmFlow = buildBpmnFlow(graph, {
            events: this.events || [],
            linesMetaData: groupByLineId(this.customerOrderMetadata.customerOrderLines)
          })
          this.currentBpmFlow.colorizeBpmn(this.viewer, {
            onEventClick: (events) => {
              this.selectedEvents = events
              this.showSelectedEvent = true
            },
            environment: {
              name: this.store.configuration?.environmentName
            }
          })
        }
      }, 0)
    }
  }
}
</script>

<style scoped lang="scss">
  .bpmn-view {
    display: flex;
    flex-direction: column;
    height: 100%;
  }

  .tabs {
    display: flex;
    flex-direction: row;
  }

  .tabs a {
    width: 10vh;
    flex: 1;
    background-color: #eee;
    color: black;
    display: block;
    padding: 12px;
    text-decoration: none;
  }

  .tabs a:hover {
    background-color: #ccc;
    text-decoration: none;
  }

  #bpmn {
    height: 100%;
  }

  .event-view {
    display: flex;
    align-items: center;
    position: absolute;
    width: 50vw;
    height: 100vh;
    right: 0;
    top: 0;
    overflow: scroll;

    .events {
      background-color: white;
      border-left: 1px solid #908b8b;
      height: 100%;
      flex-grow: 1;
      box-shadow: 0px 0px 10px #a78e8e;
    }

    .close-view {
      writing-mode: vertical-lr;
      text-orientation: mixed;
      transform: scale(-1, -1);
      height: 100px;
      text-align: center;
      background-color: #dacbcb;
      border-right: 1px solid #908b8b;
      border-top: 1px solid #908b8b;
      border-bottom: 1px solid #908b8b;
      border-radius: 0px 5px 5px 0;
      cursor: pointer;

      box-shadow: 0px 0px 10px #a78e8e69;
      margin-left: 5px;

      &:hover {
        background-color: #c5b9b9;
      }
    }
  }
</style>

<!-- style used to customize the bpmn-js -->
<style lang="scss">
  .received:not(.djs-connection) .djs-visual > :nth-child(1) {
    fill: #2ecc71 !important;
  }

  .received.warning:not(.djs-connection) .djs-visual > :nth-child(1) {
    fill: #e67e22 !important;
  }

 .should-have-been-received:not(.djs-connection) .djs-visual {
    animation-duration: 3s;
    animation-name: clignoter;
    animation-iteration-count: infinite;
    transition: none;
  }

  .number-of-received-event {
    background-color: red;
  }

  .logs {
    white-space: nowrap;
    z-index: 100;
    position: relative;
    & > div {
      background-color: #fff;
      border: 1px solid rgba(0,0,0,.125);
      padding: 10px;
    }
  }

  .number-of-received-event {
      background-color: #e4e4e4;
      padding: 5px;
      border-radius: 15px;
      padding-top: 3px;
      padding-bottom: 3px;
  }

  @keyframes clignoter {
    0%   { opacity:1; }
    40%   {opacity:0; }
    100% { opacity:1; }
  }
</style>
