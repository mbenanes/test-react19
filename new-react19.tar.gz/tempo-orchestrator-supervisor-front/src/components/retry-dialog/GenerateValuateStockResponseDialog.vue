<template>
  <popin @close="close()">
      <template v-slot:header> Generate valuate stock backo response manually</template>
      <template v-slot:body>
        <template v-if="!isSendDone">
          <div>
          Are you sure you want to generate valuate stock backo response manually for the customer order <span class="highlighted">{{customerOrderId}}</span>
          ?
          </div>
          <div class="error" v-if="sendError != ''">
            {{ sendError }}
          </div>
        </template>
        <template v-else>
          <div>
            The valuate stock backo response has been generated
          </div>
        </template>
      </template>
      <template v-slot:footer v-if="!isSendDone">
        <button @click="generateEvent()" class="danger"> Send </button>
        <button @click="close()"> Cancel </button>
      </template>
      <template v-slot:footer v-else>
        <button @click="close()" class="primary"> Understood </button>
      </template>
  </popin>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-facing-decorator'
import Popin from './Popin.vue'
import { generateValuateStockBackoResponse } from '@/services/alerts.service'
import { OrchestratorEvent } from '@/models'

@Component({
  components: {
  Popin
  }
  })
export default class GenerateValuateStockResponseDialog extends Vue {
  @Prop()
  public event?: OrchestratorEvent;

  public isSendDone = false;

  public sendError = '';

  public close (): void {
    this.$emit('close', { isSendDone: this.isSendDone })
  }

  public async generateEvent (): Promise<void> {
    try {
      if (this.event) {
        await generateValuateStockBackoResponse(this.event.id)
      }
      this.isSendDone = true
    } catch (error) {
      if (error?.response?.data.detail) {
        this.sendError = error.response.data.detail
      } else {
        this.sendError = 'Sorry! The server seems to be down. Please try later.'
      }
    }
  }
}
</script>

<style scoped lang="scss">
</style>
