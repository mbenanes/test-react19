<template>
  <div class="comment-popin">
    <form @submit="addComment($event)" class="add-comment">
      <textarea-autosize placeholder="add new comment" name="comment" v-model="commentValue"></textarea-autosize>
      <button type="submit">
        <comment-plus-icon title="Add a comment"></comment-plus-icon>
      </button>
    </form>
    <div class="comments">
      <div class="comment" v-for="comment in comments" v-bind:key="comment.id">
        <div class="message" v-html="marked(comment.comment)">
        </div>
        <div class="metadata">
          <div class="name">
            {{comment.createdBy}}
          </div>
          <div class="date" :title="formatDate(comment.createdAt)">
            <!-- {{durationFromNow(comment.createdAt ) | duration('humanize')}} -->
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { addComment, Alert, AlertComment, getComments } from '@/services/alerts.service'
import { Component, Prop, Vue } from 'vue-facing-decorator'
import TextareaAutosize from 'vue-textarea-autosize/src/components/TextareaAutosize.vue'
import CommentPlusIcon from 'vue-material-design-icons/CommentPlus.vue'
import { marked } from 'marked'
import DOMPurify from 'dompurify'
import { formatDate, durationFromNow } from '@/utils/utils'

@Component({
  methods: {durationFromNow},
  components: {
  TextareaAutosize,
  CommentPlusIcon
  }
  })
export default class ManageCommentsDialog extends Vue {
  @Prop()
  public alerts?: Alert[];

  @Prop({ default: 'right' })
  public popinAlign?: 'right' | 'left';

  public comments: AlertComment[] = [];

  public commentValue = '';

  async addComment (event: any) {
    event.preventDefault()
    if (this.commentValue.trim().length > 0) {
      const comment = await addComment(this.alerts![0].id, this.commentValue)
      this.comments.splice(0, 0, comment)
      this.commentValue = ''
      this.$emit('commentAdded', comment)
    }
  }

  async created () {
    if (this.alerts && this.alerts.length > 0) {
      const comments = (await Promise.all(this.alerts.map(alert => getComments(alert.id)))).flatMap(it => it)
      this.comments = comments.sort((c1, c2) => c1.createdAt < c2.createdAt ? 1 : -1)
    }
  }

  mounted () {
    setTimeout(() => document.addEventListener('click', this.onDocumentClick), 100)
    window.addEventListener('resize', this.positionElement)
    document.addEventListener('keydown', this.onKeyPress, false)
  }

  beforeDestroy () {
    document.removeEventListener('click', this.onDocumentClick)
    window.removeEventListener('resize', this.positionElement)
    document.removeEventListener('keydown', this.onKeyPress)
  }

  updated () {
    this.positionElement()
  }

  onKeyPress (e: any) {
    if (e.key === 'Escape') {
      this.$emit('clickOutside')
    }
  }

  positionElement () {
    const element = this.$el as HTMLElement
    const parentElement = element.parentNode as HTMLElement
    const elBottomPosition = element.offsetTop + element.offsetHeight
    const parentBouding = parentElement?.getBoundingClientRect()

    if (elBottomPosition > window.innerHeight) {
      element.style.top = `${window.innerHeight - element.offsetHeight}px`
    } else {
      element.style.top = `${parentBouding.top + parentElement.offsetHeight}px`
    }
    if (this.popinAlign === 'right') {
      element.style.left = (parentBouding.right - element.offsetWidth) + 'px'
    } else {
      element.style.left = parentElement?.getBoundingClientRect().left + 'px'
    }
  }

  marked (text: string) {
    return marked(DOMPurify.sanitize(text))
  }

  onDocumentClick (event: any) {
    const containerElement = this.$el
    const pathContainsLinkPannel = event.path.filter((pathItem: any) => pathItem === containerElement).length > 0

    if (!pathContainsLinkPannel) {
      this.$emit('clickOutside')
    }
  }
}
</script>

<style scoped lang="scss">
.comment-popin {
  min-width: 400px;
  position: fixed;
  z-index: 1003;
  background: #eee;
  font-weight: normal;
  text-align: left;
  border-radius: 4px;
  border: 1px solid #383535a3;
  overflow: hidden;

  .add-comment {
    display: flex;
    box-shadow: 0px -4px 6px black;

    textarea {
      flex: 1 1 auto;
      border: none;
      outline: none;
      padding-left: 10px;
      padding-top: 5px;
    }

    button {
      background: white;
      border: none;
      cursor: pointer;
      color: rgba(0, 0, 0, 0.8);
      outline: none;

      &:hover, &:focus {
        color: rgba(0, 0, 0, 1);
      }
    }
  }

  .comments {
    max-height: 400px;
    overflow: auto;

    .comment {
      padding-left: 10px;
      padding-right: 10px;
      padding-bottom: 5px;
      border-bottom: 1px solid #383535a3;

      &:last-child {
        border-bottom: none;
      }

      .message p {
        padding: 0;
        margin: 0;
      }
    }
  }

  .metadata {
    display: flex;
    justify-content: space-between;
    opacity: 0.6;
  }
}
</style>
