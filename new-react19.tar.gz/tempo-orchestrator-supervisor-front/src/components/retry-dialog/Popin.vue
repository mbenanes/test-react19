<template>
  <div class="popin-background">
    <div class="popin">
      <div class="header">
        <span class="header-title">
          <slot name="header" />
        </span>
        <button @click="close()" class="close-btn">x</button>
      </div>
      <div class="body">
        <slot name="body" />
      </div>
      <div class="footer">
        <slot name="footer" />
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-facing-decorator'

@Component({})
export default class Popin extends Vue {
  public close (): void {
    this.$emit('close')
  }
}
</script>

<style scoped lang="scss">
.popin-background {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 999;
}

.popin {
  background-color: white;
  border-radius: 8px;
  width: 90%;
  max-width: 600px;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
}

.header {
  padding: 16px;
  display: flex;
  align-items: center;
  background-color: #f7f7f7;
  border-bottom: 1px solid #ccc;
  position: relative;
  justify-content: center; /* Center the content */
}

.close-btn {
  position: absolute;
  right: 16px; /* Close button on the right side */
  top: 50%;
  transform: translateY(-50%); /* Center the button vertically */
  background: transparent;
  border: none;
  font-size: 20px;
  cursor: pointer;
  color: #333;
  transition: color 0.2s;

  &:hover {
    color: #f00; /* Change color on hover */
  }
}

.header-title {
  font-size: 18px;
  font-weight: bold;
  text-align: center; /* Center the title */
  flex-grow: 1; /* Make sure the title takes up the available space */
}

.body {
  padding: 20px;
  flex-grow: 1;
  overflow-y: auto; /* Allow scroll if content overflows */
}

.footer {
  padding: 16px;
  border-top: 1px solid #ccc;
  display: flex;
  justify-content: flex-end;
  background-color: #f7f7f7;
}

footer button {
  background-color: #007bff;
  color: white;
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

footer button:hover {
  background-color: #0056b3;
}

/* Responsive design */
@media (max-width: 600px) {
  .popin {
    width: 95%;
    max-width: 100%;
  }
}
</style>
