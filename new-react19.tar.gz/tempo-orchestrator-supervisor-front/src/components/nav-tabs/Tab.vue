<template>
    <div class="tab"
        @click="onClick(value)"
        :class="{selected: selected}"
    >
      <slot>
        <contenteditable tag="span"
            :value="label"
            :noNL="true"
            :noHTML="true"
            @input="onLabelUpdated($event)"
            :contenteditable="isLabelEditable"
        />
        <span v-if="isUpdated"> * </span>
        <span class="delete" v-if="isDeletable" @click="onDelete(value)"> x </span>
      </slot>
    </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-facing-decorator'

@Component({
  components: { }
  })
export default class Tab extends Vue {
  @Prop()
  public value?: any[];

  @Prop()
  public label?: string;

  @Prop({
    default: false
  })
  public isUpdated?: boolean;

  @Prop({
    default: false
  })
  public isLabelEditable?: boolean;

  @Prop({
    default: false
  })
  public isDeletable?: boolean;

  @Prop({
    default: false
  })
  public selected?: boolean;

  onClick (item: any) {
    this.$emit('click', item)
  }

  onDelete (item: any) {
    this.$emit('delete', item)
  }

  onLabelUpdated (newValue: string) {
    this.$emit('labelUpdated', newValue)
  }
}
</script>

<style scoped lang="scss">
.tab {
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 3px;
    padding-bottom: 3px;
    border-left: 1px solid rgba(0,0,0,.125);

    &:hover {
        background-color: fade-in(rgba(0,0,0,.03), 0.03);
        cursor: pointer;

        .delete {
        display: inline;
        }
    }

    &.selected {
        background-color: fade-in(rgba(0,0,0,.03), 0.02);
    }

    .delete {
        display: none;
    }
}
</style>
