<template>
  <ul>
      <template v-if="isListOfLine()">
          <li class="line" v-for="line in tree" v-bind:key="line.id">
            <input :id="line.id" type="checkbox" :checked="value.includes(line.id)" :disabled="isLineDisabled(line.id)" @change="updateLineFilter(line.id, $event.target.checked)"/>
            <label :for="line.id"> {{line.refLM}} - {{line.id}} </label>
            <span @click="selectOnlyLineId(line.id)" class="only" v-if="!isLineDisabled(line.id)">Only</span>
          </li>
      </template>
      <template v-else>
          <li class="group"  v-for="(tree, groupName) in tree" v-bind:key="groupName">
            <span @click="toggleisOpened(groupName)" class="toggle">
              <template v-if="isOpened[groupName]">
                <ChevronDown class="chevron-icon" :size=20 />
              </template>
              <template v-else>
                <ChevronUp class="chevron-icon" :size=20 />
              </template>
            </span>
            <input :id="groupName" type="checkbox" :checked="isTreeGroupFullSelected(tree)" :indeterminate.prop="isTreeGroupPartialySelected(tree)" @change="toggleTreeGroup(tree, $event.target.checked)"/>
            <label :for="groupName"> {{groupName}} </label>
            <span @click="selectOnlyTreeGroup(tree)" class="only" v-if="!isTreeGroupDisabled(tree)">Only</span>

            <customer-order-lines-tree v-bind:hidden="!isOpened[groupName]" :line-ids-for-visible-events="lineIdsForVisibleEvents" :tree="tree" :value="value" @input="sendInput($event)"/>
          </li>
      </template>
  </ul>
</template>

<script lang="ts">
import { CustomerOrderLineMetadata } from '@/models'
import { Component, Emit, Prop, Vue } from 'vue-facing-decorator'
import ChevronDown from 'vue-material-design-icons/ChevronDown.vue'
import ChevronUp from 'vue-material-design-icons/ChevronUp.vue'
import { reactive } from 'vue'

type TreeGroup = {[key: string]: Tree}
type TreeLineList = CustomerOrderLineMetadata[]
type Tree = TreeGroup | TreeLineList

function getLineIdsOnTree (tree: Tree): string[] {
  if (Array.isArray(tree)) {
    return tree?.map(line => line.id)
  } else {
    const result = []
    for (const groupName in tree) {
      result.push(...getLineIdsOnTree(tree[groupName]))
    }
    return result
  }
}

@Component({
  name: 'CustomerOrderLinesTree',
  components: {
  ChevronDown,
  ChevronUp
  }
  })
export default class CustomerOrderLinesTree extends Vue {
  @Prop()
  public tree?: Tree;

  @Prop()
  public value?: string[];

  @Prop()
  public lineIdsForVisibleEvents?: string[];

  public isOpened = reactive<{ [key: string]: boolean }>({});

  created () {
    if (!Array.isArray(this.tree)) {
      for (const groupName in this.tree) {
        this.isOpened[groupName] = false
      }
    }
  }

  isListOfLine () {
    return Array.isArray(this.tree)
  }

  updateLineFilter (lineId: string, selected: boolean) {
    if (selected) {
      const valueCopy = [...this.value || []]
      valueCopy.push(lineId)
      this.sendInput(valueCopy)
    } else if (this.value) {
      this.sendInput((this.value.filter(it => it !== lineId)))
    }
  }

  selectOnlyLineId (lineId: string) {
    this.sendInput([lineId])
  }

  isTreeGroupFullSelected (tree: TreeGroup) {
    if (!this.value) {
      return false
    }

    const lineIds = getLineIdsOnTree(tree)
    const selectedTreeLines = lineIds.filter(lineId => this.value?.includes(lineId))
    return selectedTreeLines?.length === lineIds?.length
  }

  isTreeGroupPartialySelected (tree: TreeGroup) {
    if (!this.value) {
      return false
    }

    const lineIds = getLineIdsOnTree(tree)
    const selectedTreeLines = lineIds.filter(lineId => this.value?.includes(lineId))
    return selectedTreeLines?.length > 0 && selectedTreeLines?.length < lineIds?.length
  }

  isTreeGroupDisabled (tree: TreeGroup) {
    const lineIds = getLineIdsOnTree(tree)
    const disabledLines = lineIds.filter(lineId => this.isLineDisabled(lineId))
    return disabledLines?.length === lineIds?.length
  }

  isLineDisabled (lineId: string) {
    return !this.lineIdsForVisibleEvents?.includes(lineId)
  }

  toggleTreeGroup (tree: TreeGroup, selected: boolean) {
    const lineIds = getLineIdsOnTree(tree)
    if (selected) {
      const valueClone = [...this.value || []]
      valueClone.push(...lineIds)
      this.sendInput([...new Set(valueClone)])
    } else if (this.value) {
      this.sendInput(this.value.filter(lineId => !lineIds.includes(lineId)))
    }
  }

  selectOnlyTreeGroup (tree: TreeGroup) {
    this.sendInput(getLineIdsOnTree(tree))
  }

  @Emit('input')
  private sendInput (value: string[]) {
    return value
  }

  toggleisOpened (groupName: string) {
    this.isOpened[groupName] = !this.isOpened[groupName]
  }
}
</script>

<style scoped lang="scss">

.group, .line {
  padding: 6px 0;
}

ul {
  list-style: none;

  .chevron-icon {
    margin-top: 3px;
  }

  .toggle, .only {
    cursor: pointer;
    transition: color 0.3s ease;
  }

  .all {
    color: #3498db;

    &:hover {
      color: #7d3c98;
    }
  }

  .only {
    color: #aea2a2;
    margin-left: 10px;

    &:hover {
      color: #7d3c98;
    }
  }
}
</style>
