<template>
  <ul>
    <li class="alldependency" v-if="dependencies">
      <span @click="selectAllDependencies()" class="all link">Select all</span> |
      <span @click="unSelectAllDependencies()" class="all link">Unselect all</span>
    </li>
    <li class="dependency" v-for="dependency in allDependencies" v-bind:key="dependency">
      <input :id="dependency" type="checkbox" :disabled="isDisabledDependency(dependency)" :checked="value.includes(dependency)"
             @change="updateDependenciesFilter(dependency, $event.target.checked)"/>
      <label :for="dependency"> {{ dependency }} </label>
      <span @click="selectOnlyDependency(dependency)" class="only" v-if="!isDisabledDependency(dependency)">Only</span>
    </li>
  </ul>
</template>

<script lang="ts">
import { Component, Emit, Prop, Vue } from 'vue-facing-decorator'

@Component({
  name: 'CustomerOrderDependencies',
  components: {}
  })
export default class CustomerOrderDependencies extends Vue {
  @Prop()
  public dependencies?: string[]

  @Prop()
  public allDependencies?: string[]

  @Prop()
  public value?: string[]

  updateDependenciesFilter (dependency: string, selected: boolean) {
    if (selected) {
      const valueCopy = [...this.value || []]
      valueCopy.push(dependency)
      this.sendInput(valueCopy)
    } else if (this.value) {
      this.sendInput(this.value.filter(it => it !== dependency))
    }
  }

  isDisabledDependency (dependency: string) {
    return !this.dependencies?.includes(dependency)
  }

  selectAllDependencies () {
    this.sendInput(this.allDependencies)
  }

  unSelectAllDependencies () {
    this.sendInput([])
  }

  selectOnlyDependency (dependency: string) {
    this.sendInput([dependency])
  }

  @Emit('input')
  private sendInput (value: string[] | undefined) {
    return value
  }
}
</script>

<style scoped lang="scss">

ul {
  list-style: none;

  .dependency {
    padding: 3px 0;
  }

  .toggle, .only, .all {
    cursor: pointer;
    transition: color 0.3s ease;
  }

  .alldependency {
    margin-bottom: 10px;
  }

  .all {
    color: #3498db;

    &:hover {
      color: #7d3c98;
    }
  }

  .only {
    color: #aea2a2;
    margin-left: 10px;

    &:hover {
      color: #7d3c98;
    }
  }
}
</style>
