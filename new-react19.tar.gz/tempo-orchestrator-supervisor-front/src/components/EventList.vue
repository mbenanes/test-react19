<template>
  <div class="events">
    <div class="event" v-for="(event, index) in events" :key="index">
      <div class="event-header" @click="toggle(index)"
        :class="{ collapsed: collapseStatus[index], 'with-alert': alertsByEventId[event.id] !== undefined }">
        <slot name="header" :event="event">
          <div class="dependencyName">from: {{ event.metadata.source }}</div>
          <div class="eventType">
            <span> {{ event.metadata.eventType.split('.').reverse()[0] }} {{ event.metadata.functionalType }} </span>
            <div class="alert-icon" style="height: 18px" v-if="alertsByEventId[event.id] !== undefined">
              <alert-decagram-icon :size=18 />
            </div>
          </div>
          <div class="timestamp">{{ formatDate(event.metadata.timestamp) }}</div>
        </slot>
      </div>
      <div class="event-body" :class="{ collapsed: collapseStatus[index] }">
        <div class="alert-data" v-if="alertsByEventId[event.id] !== undefined">
          <alert-decagram-icon />
          <ul>
            <li v-for="(alerts, name) in groupByAlertName(alertsByEventId[event.id])" v-bind:key="name">
              <badge :show="numberOfComment(alerts) > 0" :content="numberOfComment(alerts)" class="cursor">
                <comment-multiple-icon
                  :title="'Comment the alert ' + name + ' for the order ' + alerts[0].customerOrderId"
                  @click="openCommentAlertPopin(name, event.id)" class="delete" />
              </badge>
              <delete v-if="isUserAdmin()"
                :title="'Delete the alert ' + name + ' for the order ' + alerts[0].customerOrderId"
                @click="openDeleteAlertPopin(alerts)" class="delete" />
              <span class="alert-name">{{ name }}</span> for lines {{ alerts.map(alert => alert.lineId).join(', ') }}
              <manage-comments-dialog :alerts="alerts" :popin-align="'left'"
                v-if="commentsToDisplay === name + event.id" @clickOutside="commentsToDisplay = ''"
                @commentAdded="alerts[0].numberOfComment++" />
            </li>
          </ul>
        </div>
        <div class="kafka-metadata">
          <div> Topic: {{ event.metadata.topic }}</div>
          <div> Offset: {{ event.metadata.offset }}</div>
          <div> Partition: {{ event.metadata.partition }}</div>
        </div>
        <button class="retry" v-if="isUserAdmin() && eventHasConsumerApi(event)" @click="openRetryPopup(event)"> retry
        </button>
        <button class="retry" v-if="isUserAdmin() && eventIsValuateStockEvent(event)"
          @click="openGenerateValuateStockResponsePopin(event)"> by pass the valuate stock backo </button>
        <json-viewer :value="event.value" class="json" :copyable="true" :boxed="false" :expanded="false"></json-viewer>
      </div>
    </div>

    <retry-dialog v-if="retryPopinOpenned" :event="eventToRetry" @close="retryPopinOpenned = false"></retry-dialog>
    <delete-alert-dialog :alerts="alertsToDelete" @close="onDeleteDialogClosed($event)"
      v-if="alertsToDelete.length > 0" />
    <generate-valuate-stock-response-dialog :event="eventBacko" @close="onValuateBackoResponseDialogClosed($event)"
      v-if="forceValuateStockBacko" />
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch } from 'vue-facing-decorator'
import { reactive } from 'vue'
import JsonViewer from 'vue-json-viewer'
import DeleteAlertDialog from '@/components/retry-dialog/DeleteAlertDialog.vue'
import ManageCommentsDialog from '@/components/retry-dialog/ManageCommentsDialog.vue'
import RetryDialog from './retry-dialog/RetryDialog.vue'
import Badge from '@/components/badged/Badge.vue'
import { Alert } from '@/services/alerts.service'
import AlertDecagramIcon from 'vue-material-design-icons/AlertDecagram.vue'
import CommentMultipleIcon from 'vue-material-design-icons/CommentMultiple.vue'
import Delete from 'vue-material-design-icons/Delete.vue'
import GenerateValuateStockResponseDialog from '@/components/retry-dialog/GenerateValuateStockResponseDialog.vue'
import { OrchestratorEvent } from '@/models'
import { formatDate } from '@/utils/utils'
import { useCommandStore, useAppStore } from '@/store'

@Component({
  methods: {
  formatDate
  },
  components: {
  GenerateValuateStockResponseDialog,
  JsonViewer,
  RetryDialog,
  AlertDecagramIcon,
  Delete,
  DeleteAlertDialog,
  ManageCommentsDialog,
  CommentMultipleIcon,
  Badge
  }
  })
export default class EventList extends Vue {
  private store = useAppStore();

  @Prop()
  public events?: OrchestratorEvent[];

  @Prop()
  public alerts?: Alert[];

  public alertsToDelete: Alert[] = [];

  public commentsToDisplay = '';

  public retryPopinOpenned = false;

  public forceValuateStockBacko = false;

  public eventToRetry?: OrchestratorEvent = undefined;

  public eventBacko?: OrchestratorEvent = undefined;

  private collapseStatus = reactive<boolean[]>([]);

  @Watch('events', { immediate: true })
  public eventsChanged () {
    if (this.events) {
      this.collapseStatus = this.events.map(() => true)
    } else {
      this.collapseStatus = []
    }
  }

  public toggle (index: number) {
    this.collapseStatus[index] = !this.collapseStatus[index]
  }

  public openRetryPopup (event: OrchestratorEvent): void {
    this.eventToRetry = event
    this.retryPopinOpenned = true
  }

  public openCommentAlertPopin (alertName: string, eventId: string): void {
    this.commentsToDisplay = alertName + eventId
  }

  public eventHasConsumerApi (event: OrchestratorEvent): boolean {
    return event.metadata.consumerApi.length > 0
  }

  public eventIsValuateStockEvent (event: OrchestratorEvent): boolean {
    if (event) {
      return event.metadata.eventType.split('.').reverse()[0] === 'ValuateStockBacko'
    } else {
      return false
    }
  }

  public isUserAdmin (): boolean {
    return this.store.user?.authorities?.indexOf('ADMIN') >= 0
  }

  public get alertsByEventId (): { [eventId: string]: Alert[] } {
    if (this.alerts === undefined) {
      return {}
    }

    const alertsByEventId: { [eventId: string]: Alert[] } = {}

    for (const alert of this.alerts) {
      if (alertsByEventId[alert.eventId]) {
        alertsByEventId[alert.eventId].push(alert)
      } else {
        alertsByEventId[alert.eventId] = [alert]
      }
    }

    return alertsByEventId
  }

  public openDeleteAlertPopin (alerts: Alert[]): void {
    this.alertsToDelete = alerts
  }

  public openGenerateValuateStockResponsePopin (event: OrchestratorEvent): void {
    this.forceValuateStockBacko = true
    this.eventBacko = event
  }

  public onDeleteDialogClosed (event: any): void {
    if (event.isDeleteDone && this.alerts) {
      this.alerts = this.alerts.filter(alert => !this.alertsToDelete.includes(alert))
    }
    this.alertsToDelete = []
  }

  public onValuateBackoResponseDialogClosed (): void {
    this.forceValuateStockBacko = false
  }

  public groupByAlertName (alerts: Alert[]): { [alertName: string]: Alert[] } {
    const alertsByAlertType: { [alertName: string]: Alert[] } = {}

    for (const alert of alerts) {
      if (alertsByAlertType[alert.alertName]) {
        alertsByAlertType[alert.alertName].push(alert)
      } else {
        alertsByAlertType[alert.alertName] = [alert]
      }
    }

    return alertsByAlertType
  }

  public numberOfComment (alerts: Alert[]): number {
    return alerts.reduce((acc, alert) => acc + alert.numberOfComment, 0)
  }
}
</script>

<style lang="scss">
button.retry,
.jv-container.jv-light .jv-button {
  color: white !important;
  border: none;
  padding: 5px;
  font-family: Arial;
  border-radius: 5px;
}

.jv-container.jv-light .jv-button {
  background-color: #3498db;

  &:hover {
    background-color: #247cb8;
  }
}

button.retry {
  position: absolute;
  z-index: 1000;
  right: 75px;
  background-color: #ED8C0C;
  cursor: pointer;

  &:hover {
    background-color: #D57E0B;
  }
}
</style>

<style scoped lang="scss">
.events {
  text-align: left;
  font-weight: normal;
  color: black;
}

.alert-data {
  background-color: #f4bdbd;
  display: flex;
  flex-direction: row;
  align-items: center;
  padding-left: 10px;

  ul {
    li {
      list-style-type: none;
      position: relative;
    }
  }

  .alert-name {
    font-weight: bold;
    padding-left: 10px;
  }
}

.event-header {
  display: flex;
  flex-direction: row;
  align-items: center;

  background-color: rgba(0, 0, 0, .03);
  border-bottom: 1px solid rgba(0, 0, 0, .125);
  padding: 15px;

  cursor: pointer;

  &.with-alert {
    background-color: #f4bdbd;

    &:hover {
      background-color: #f6a5a5;
    }
  }

  div {
    flex: 1 1 auto;
  }

  &:hover {
    background-color: fade-in(rgba(0, 0, 0, .03), 0.03);
  }

  &::after {
    content: "v";
    color: #3b483d75;
  }

  &.collapsed::after {
    content: '>';
  }

  .dependencyName {
    width: 30%;
    flex: 0 0 30%;
  }

  .eventType {
    font-weight: bold;
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: 10px;
  }

  .timestamp {
    color: rgba(63, 63, 63, 0.38);
    text-align: right;
    padding-right: 10px;
  }
}

.event-body {
  // The position should be relative, because the retry button is on position: absolute
  position: relative;

  &.collapsed {
    display: none;
  }

  .kafka-metadata {
    background-color: rgba(0, 0, 0, .02);
    color: rgba(63, 63, 63, 0.38);
    padding-top: 3px;
    padding-bottom: 3px;
    padding-left: 20px;
    display: flex;

    div {
      flex: 1 1 auto;
    }
  }
}

.delete {
  cursor: pointer;
  color: rgba(0, 0, 0, 0.65);

  &:hover {
    color: rgba(0, 0, 0, 0.90);
  }
}
</style>
