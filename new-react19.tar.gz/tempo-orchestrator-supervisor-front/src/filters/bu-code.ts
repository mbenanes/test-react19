import { BuCodeType, COUNTRY_CODES } from '@/models'

export const findBuCode = (countryCode: string): BuCodeType | undefined => {
  const buCode = Object.keys(COUNTRY_CODES).find(buCode => COUNTRY_CODES[buCode as BuCodeType].code === countryCode)
  return buCode as BuCodeType | undefined
}

export const getBuCode = (value: BuCodeType): string => {
  if (!value) return ''

  const country = COUNTRY_CODES[value]
  return country ? country.code : value
}

export const getFlagCode = (value: BuCodeType): string | undefined => {
  if (!value) return undefined

  const country = COUNTRY_CODES[value]
  return country ? country.flag : undefined
}

/* export const registerFilters = (): void => {
  Vue.filter('bu-Code', getBuCode)
  Vue.filter('flag-code', getFlagCode)
}

registerFilters() */
