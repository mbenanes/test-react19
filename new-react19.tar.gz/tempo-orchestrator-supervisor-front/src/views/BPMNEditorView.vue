<template>
  <div class="container">
    <nav-tabs @add="addBpm()" allowToAddTab="true">
      <tab v-for="bpmWrapper in allBpm" :key="bpmWrapper.bpm.id"
        :value="bpm" :label="bpmWrapper.bpm.name"
        :selected="currentBpm === bpmWrapper"
        :isUpdated="bpmWrapper.isUpdated" :isLabelEditable="bpmWrapper.isNameEditable" isDeletable="true"
        @delete="askToDeleteBpm(bpmWrapper)"
        @click="switchBpm(bpmWrapper)"
        @labelUpdated="bpmWrapper.bpm.name = $event;bpmWrapper.isUpdated = true"
      />
    </nav-tabs>
    <bpmn-editor v-if="currentBpm" class="editor" v-model="currentBpm.bpm.bpmXML" @input="currentBpm.isUpdated = true" />
    <div v-if="currentBpm" class="toolbar">
      <button @click="save()" :disabled="saving"> Save </button>
      <button @click="exportXML()"> Export </button>
      <label for="upload-file" class="button">
        Import
        <input id="upload-file" type="file" hidden @input="onFileSelected($event)" />
      </label>
    </div>
    <div v-if="!currentBpm"> Loading... </div>
  </div>
</template>

<script>
import BpmnEditor from '@/components/bpmn/editor/BpmnEditor'
import NavTabs from '@/components/nav-tabs/NavTabs'
import Tab from '@/components/nav-tabs/Tab'
import { createBpm, updateBpm, listBpm, deleteBpm, DuplicatedBpmError, OutdatedVersionError } from '@/services/bpmn.service'

function readFile (file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve({
      content: reader.result,
      name: file.name
    })
    reader.onerror = reject
    reader.readAsBinaryString(file)
  })
}

export default {
  name: 'BPMN',
  components: {
    BpmnEditor,
    NavTabs,
    Tab
  },
  data: function () {
    return {
      allBpm: [],
      currentBpm: undefined,
      saving: false
    }
  },
  methods: {
    async save (force = false) {
      try {
        this.saving = true
        const currentBpm = this.currentBpm
        if (currentBpm.bpm?.id) {
          currentBpm.bpm = await updateBpm(currentBpm.bpm, force)
        } else {
          currentBpm.bpm = await createBpm(currentBpm.bpm)
        }
        currentBpm.isUpdated = false
        this.saving = false
      } catch (e) {
        this.saving = false
        if (e instanceof DuplicatedBpmError) {
          this.openPopin('Error', 'The name of the BPM is already use. Change the name and retry.')
        } else if (e instanceof OutdatedVersionError) {
          this.openPopin('Error', 'Your BPM version is outdated. Another use has updated it.', {
            Reload: () => this.load(),
            'Force update': () => this.save(true)
          })
        } else {
          console.error(e)
          this.openPopin('Error', 'Unknow error ' + e.message)
        }
      }
    },
    askToDeleteBpm (bpmData) {
      this.openPopin(
        'Warning',
        'Do You realy want to delete <b>' + bpmData.bpm.name + '</b>',
        {
          Cancel: undefined,
          'Export and Delete': async () => {
            this.exportXML()
            this.deleteBpm(bpmData)
          },
          Delete: async () => this.deleteBpm(bpmData)
        }
      )
    },
    async deleteBpm (bpmData) {
      try {
        if (bpmData.bpm.id) {
          await deleteBpm(bpmData.bpm)
        }
        this.allBpm = this.allBpm.filter(it => it !== bpmData)
        this.setDefaultBpmTab()
      } catch (e) {
        console.error(e)
        // Use setTimeout without that the error popin is not displayed
        setTimeout(() => this.openPopin('Error', 'Unknow error ' + e.message), 400)
      }
    },
    exportXML () {
      const blob = new Blob([this.currentBpm.bpm.bpmXML], { type: 'application/xml' })
      const link = document.createElement('a')
      link.href = URL.createObjectURL(blob)
      link.download = this.currentBpm.bpm.name + '.bpmn'
      link.click()
      URL.revokeObjectURL(link.href)
    },
    async load () {
      try {
        this.bpm = undefined
        const bpmList = await listBpm()
        this.allBpm = bpmList.map(bpm => ({ isUpdated: false, isNameEditable: false, bpm }))
        this.setDefaultBpmTab()
      } catch (e) {
        this.showError('Unable to load existing BPM. ' + e.message)
      }
    },
    addBpm (bpmName = 'new bpm', xml = undefined) {
      const alreadyExists = this.allBpm.some(it => it.bpm.name === bpmName)
      if (alreadyExists) {
        this.addBpm(bpmName + '1', xml)
      } else {
        const newBpm = { isUpdated: false, isNameEditable: false, bpm: { name: bpmName, bpmXML: xml } }
        this.allBpm.push(newBpm)
        this.currentBpm = newBpm
      }
    },
    switchBpm (bpm) {
      this.allBpm.forEach((it) => { it.isNameEditable = false })
      this.currentBpm = bpm
      bpm.isNameEditable = true
    },
    setDefaultBpmTab () {
      if (this.allBpm.length === 0) {
        this.addBpm()
      } else {
        this.currentBpm = this.allBpm[0]
      }
    },
    openPopin (title, message, availableButtons = { Ok: undefined }) {
      const buttons = []
      for (const name in availableButtons) {
        buttons.push({
          title: name,
          handler: () => {
            this.$modal.hide('dialog')
            if (availableButtons[name]) {
              availableButtons[name]()
            }
          }
        })
      }

      this.$modal.show('dialog', {
        title: 'Error',
        text: message,
        buttons
      })
    },
    onFileSelected: async function (event) {
      const file = await readFile(event.srcElement.files[0])
      this.addBpm(file.name.substring(0, file.name.lastIndexOf('.')), file.content)
    }
  },
  created: async function () {
    this.load()
  }
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;

  .editor {
    flex: 1 1 auto;
  }

  .toolbar {
    padding: 5px;
    background-color: rgba(0,0,0,.03);
    border-top: 2px solid rgba(0,0,0,.125);

    button, .button {
      font-size: 13px;
      font-family: Avenir, Helvetica, Arial, sans-serif;
      margin-right: 5px;
      cursor: pointer;
      border: 1px solid rgba(63, 82, 123, 0.767);
      background-color: rgba(10,86,136,0.78);
      border-radius: 5px;
      padding-top: 5px;
      padding-bottom: 5px;
      padding-right: 10px;
      padding-left: 10px;
      color: white;
      text-decoration: none;

      &:hover {
        background-color: rgba(10,86,136,0.90);
      }

      &:disabled, &[disabled] {
        background-color: rgba(10,86,136,0.44);
        border: 1px solid rgba(63, 82, 123, 0.44);
      }
    }
  }
}
</style>
