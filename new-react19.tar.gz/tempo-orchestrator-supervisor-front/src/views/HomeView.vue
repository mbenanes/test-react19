<template>
  <div class="message">
    Bienvenue, Merci de saisir votre numéro de commande ci-dessus.
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-facing-decorator'

@Component({})
export default class HomeView extends Vue {
}
</script>
