<template>
  <div class="message">
    Flow chart is coming soon!
  </div>
</template>

<script>
import { Component, Vue } from 'vue-facing-decorator'

@Component({
  components: { }
  })
export default class FlowChartView extends Vue {
}

</script>
