<template>
  <div class="alerts-view">
    <div class="search-form">
      <div class="filter">
        <label for="customerOrderId"> Customer order id : </label>
        <div>
          <input type="text" id="customerOrderId" :value="customerOrderId" v-on:change="updateCustomerOrderId"/>
          <span v-if="this.customerOrderIdInvalid" class="validation-error">The customerOrderId must be an UUID</span>
        </div>
      </div>

      <div class="filter" v-for="alertFilter in alertFilters" v-bind:key="alertFilter.name">
        <label :for="alertFilter.name"> {{alertFilter.name}} : </label>
        <multi-select
          :options="buildOptions(alertFilter.values, alertFilter.name)"
          :value="selectedFilters[alertFilter.name]"
          @input="updateFilters(alertFilter.name, $event)"
          :input-id="alertFilter.name"
          />
      </div>

      <div class="filter">
        <label :for="withOrWithoutSupportTicket"> With Or Without support ticket : </label>
        <select id="withOrWithoutSupportTicket" v-model="withOrWithoutSupportTicket" v-on:change="updateAlertRoute">
          <option>ALL</option>
          <option>WITH</option>
          <option>WITHOUT</option>
        </select>
      </div>

      <div class="filter">
        <label for="solved"> only solved alerts : </label>
        <input type="checkbox" id="solved" :checked="onlySolvedAlerts" v-on:change="updateSolved"/>
      </div>
    </div>
    <div class="table">
      <table class="alerts">
        <thead>
          <tr>
            <th> business unit </th>
            <th> customer order id </th>
            <th> line id </th>
            <th> delivery type </th>
            <th> alert name </th>
            <th @click="updateSortingDirection(sortingDirection === 'DESC' ? 'ASC' : 'DESC')" class="cursor">
                alert since
                <menu-up v-if="sortingDirection === 'ASC'"  :size="16"/>
                <menu-down v-if="sortingDirection === 'DESC'" :size="16"/>
            </th>
            <th :title="'Ticket Creation Date'">
              Ticket CD
            </th>
            <th>
              SNOW
            </th>
            <th>
              actions
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="alert in alerts" v-bind:key="alert.id">
            <td>
              {{getBuCode(alert.buCode)}}
            </td>
            <td>
              <a :href="`/customer-order/${alert.customerOrderId}`" target="_blank">
                {{alert.customerOrderId}}
                <open-in-new :size="15"/>
              </a>
            </td>
            <td>
              <a :href="`/customer-order/${alert.customerOrderId}?filters.lines=${alert.lineId}`" target="_blank">
               {{alert.lineId}}
                <open-in-new :size="15"/>
              </a>
            </td>
            <td>
               {{alert.deliveryType}}
            </td>
            <td>{{alert.alertName}}</td>
            <td>
              <span :title="formatDate(alert.expectedClosingEventDate)">{{formatDate(durationFromNow(alert.expectedClosingEventDate))}}</span>
            </td>
            <td>
              <span v-if="alert.expectedSupportTicketCreationDate != null">
                {{ formatDate(alert.expectedSupportTicketCreationDate) }}
              </span>
            </td>
            <td>
              <span :title="alert.ticketNumber">
                <a  v-if="alert.ticketNumber" :href="getTicketUrl(alert.ticketNumber)" target="_blank" >
                  {{alert.ticketNumber}}
                </a>
              </span>
            </td>
            <td class="actions">
              <badge :show="alert.numberOfComment > 0" :content="alert.numberOfComment" align-badge="right" class="cursor">
                <comment-multiple-icon :title="'Comment the alert ' + alert.alertName + ' for the order ' + alert.customerOrderId" size="19" @click="openCommentPopin(alert)" class="cursor icon-button"/>
              </badge>
              <delete :title="'Delete the alert ' + alert.alertName + ' for the order ' + alert.customerOrderId" v-if="isUserAdmin()" @click="openDeletePopin(alert)" class="cursor icon-button"/>
              <manage-comments-dialog
                :alerts="[alertToComment]"
                v-if="alertToComment === alert"
                @clickOutside="alertToComment = undefined"
                @commentAdded="alert.numberOfComment++"/>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="footer" v-if="pagination !== undefined">
      <ul class="pagination">
        <li
          v-for="page in pages"
          v-bind:key="page.id"
          @click="updatePage(page.id)"
          :class="{'selected': currentPage === page.id}"
        >
          {{ page.label }}
        </li>
      </ul>
      <span> Total: {{pagination.totalCount}} results </span>
    </div>
    <delete-alert-dialog :alerts="[alertToDelete]" @close="onDeleteDialogClosed($event)" v-if="alertToDelete" />
  </div>
</template>

<script>
import { listAlertFilters, listAlerts } from '@/services/alerts.service'
import MultiSelect from '@/components/multi-select/MultiSelect.vue'
import DeleteAlertDialog from '@/components/retry-dialog/DeleteAlertDialog.vue'
import ManageCommentsDialog from '@/components/retry-dialog/ManageCommentsDialog.vue'
import OpenInNew from 'vue-material-design-icons/OpenInNew.vue'
import MenuDown from 'vue-material-design-icons/MenuDown.vue'
import MenuUp from 'vue-material-design-icons/MenuUp.vue'
import Delete from 'vue-material-design-icons/Delete.vue'
import CommentMultipleIcon from 'vue-material-design-icons/CommentMultiple.vue'
import { getBuCode } from '@/filters/bu-code'
import Badge from '@/components/badged/Badge.vue'
import { formatDate, durationFromNow } from '@/utils/utils'
import { useAppStore } from '@/store'

export default {
  name: 'AlertsView',
  components: {
    OpenInNew,
    MenuDown,
    MenuUp,
    MultiSelect,
    DeleteAlertDialog,
    Delete,
    ManageCommentsDialog,
    CommentMultipleIcon,
    Badge
  },
  data: () => {
    return {
      alerts: [],
      alertFilters: [],
      selectedFilters: {},
      pagination: undefined,
      currentPage: 1,
      sortingDirection: 'DESC',
      customerOrderId: '',
      onlySolvedAlerts: false,
      withOrWithoutSupportTicket: 'ALL',
      customerOrderIdInvalid: false,
      alertName: '',
      ticketNumber: '',
      deliveryType: '',
      staticParams: ['customerOrderId', 'sortingDirection', 'page', 'pageSize'],
      alertToDelete: undefined,
      alertToComment: undefined,
      store: useAppStore()
    }
  },
  created () {
    this.loadAlertFilters()
    this.loadSelectedFiltersFromParams()
    this.loadAlerts()
  },
  watch: {
    $route () {
      this.loadSelectedFiltersFromParams()
      this.loadAlerts()
    }
  },
  methods: {
    formatDate,
    getBuCode,
    durationFromNow,
    getTicketUrl (ticketNumber) {
      const buttons = this.store.configuration?.actionButtons
      for (const button of buttons) {
        if (button.name === 'Ticket ServiceNow') {
          return button.url.replaceAll('{ticketNumber}', ticketNumber || '')
        }
      }
      return null
    },
    updateFilters (filterName, values) {
      // Vue.set(this.selectedFilters, filterName, values)
      this.updateAlertRoute()
    },
    loadSelectedFiltersFromParams () {
      const params = { ...this.$route.query }
      this.customerOrderId = params.customerOrderId ? params.customerOrderId : ''
      this.onlySolvedAlerts = params.onlySolvedAlerts ? params.onlySolvedAlerts === 'true' : false
      this.withOrWithoutSupportTicket = params.withOrWithoutSupportTicket ? params.withOrWithoutSupportTicket : 'ALL'
      this.sortingDirection = params.sortingDirection ? params.sortingDirection : 'DESC'
      this.currentPage = params.page ? params.page : 1

      for (const param of Object.entries(params)) {
        const paramName = param[0]
        const paramValues = param[1]
        if (this.staticParams.indexOf(paramName) === -1) {
          if (Array.isArray(paramValues)) {
            // Vue.set(this.selectedFilters, paramName, [...paramValues])
          } else {
            // Vue.set(this.selectedFilters, paramName, [paramValues])
          }
        }
      }
    },
    async loadAlerts () {
      const alerts = await listAlerts(this.currentPage, this.customerOrderId, this.selectedFilters, this.sortingDirection)
      this.alerts = alerts.data
      this.pagination = alerts.pagination
    },
    updateAlertRoute () {
      this.$router.push({ name: 'AlertsView', query: this.buildQueryMap() })
    },
    buildQueryMap () {
      const queryMap = { ...this.selectedFilters }

      if (this.customerOrderId && this.customerOrderId !== '') {
        queryMap.customerOrderId = this.customerOrderId
      } else {
        // Vue.delete(queryMap, 'customerOrderId')
      }
      queryMap.sortingDirection = this.sortingDirection
      queryMap.onlySolvedAlerts = this.onlySolvedAlerts ? 'true' : 'false'
      queryMap.withOrWithoutSupportTicket = this.withOrWithoutSupportTicket
      return queryMap
    },
    buildOptions (values, filterName) {
      let valueMapping = (value) => value
      if (filterName === 'buCode') {
        valueMapping = getBuCode
      }
      return values?.map(value => ({ value: value.value, label: valueMapping(value.value), count: value.count }))
    },
    async loadAlertFilters () {
      this.alertFilters = await listAlertFilters()
    },
    async updatePage (page) {
      this.currentPage = page
      await this.loadAlerts()
    },
    async updateSortingDirection (sortingDirection) {
      this.sortingDirection = sortingDirection
      this.updateAlertRoute()
    },
    async updateCustomerOrderId (event) {
      const inputCustomerOrderId = event.target.value
      this.customerOrderIdInvalid = inputCustomerOrderId && inputCustomerOrderId.length !== 36 && inputCustomerOrderId.length !== 0
      if (!this.customerOrderIdInvalid) {
        this.customerOrderId = inputCustomerOrderId
        this.updateAlertRoute()
      }
    },
    async updateSolved (event) {
      const inputSolved = event.target.checked
      this.onlySolvedAlerts = inputSolved
      this.updateAlertRoute()
    },
    openDeletePopin (alert) {
      this.alertToDelete = alert
    },
    openCommentPopin (alert) {
      this.alertToComment = alert
    },
    onDeleteDialogClosed (event) {
      this.alertToDelete = undefined
      if (event.isDeleteDone) {
        this.loadAlerts()
        this.loadAlertFilters()
      }
    },
    isUserAdmin () {
      return this.store.user?.authorities?.indexOf('ADMIN') >= 0
    }
  },
  computed: {
    pages () {
      if (this.pagination) {
        return Array(this.pagination.totalPageCount)
          .fill(1)
          .map((_, index) => ({ id: index + 1, label: index + 1 }))
      } else {
        return []
      }
    }
  }
}
</script>

<style scoped lang="scss">

div.search-form {
  display: flex;
  justify-content: space-around;
  padding: 10px;
  background-color: #f2eaea;
  gap: 30px;

  .filter {
    width: 30%;
  }

  input[type=text] {
    width: 100%;
    display: block;

    border: none;
    background-color: transparent;
    border-bottom: 1px solid rgba(0, 0, 0, 0.42);
    outline: none;
    height: 1.4em;

    &:hover {
      border-bottom: 1px solid rgba(0, 0, 0, 0.60);
    }
  }
}

div.alerts-view {
  height: calc(100% - 10px)!important;
  padding-left: 10px;
  padding-right: 10px;
  padding-top: 10px;

  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  row-gap: 10px;
}

div.table {
  overflow: auto;
  flex: 1 1 auto;
}

table.alerts {
  width: 100%;
  border-spacing: 0;

  thead {
    tr {
      background-color: #b3a2a2;
      padding-top: 10px;
      padding-bottom: 10px;
    }
  }

  tbody {
    a {
      text-decoration: none;
      color: black;
    }

    td {
      padding: 5px;
    }

    tr:nth-child(even) {
      background-color: #d6d1d1;
    }
    tr:nth-child(odd) {
      background-color: #ede7e7;
    }

    tr:hover {
      background-color: rgb(189, 186, 186);
    }

    td.actions {
      position: relative;
      padding: 0;
    }
  }
}

.validation-error {
  color: red;
}

.footer {
  display: flex;
  align-items: center;
  justify-content: center;
  padding-bottom: 10px;

  ul.pagination {
    text-align: center;
    flex: 1 1 auto;
    margin  : 0;
    padding: 0;

    li {
      display: inline-block;
      text-align: center;
      list-style-type: none;
      cursor: pointer;
      width: 20px;
      padding-top: 5px;
      padding-bottom: 5px;
      border: 1px solid black;
      border-right: none;

      &:last-child {
        border-right: 1px solid black;
      }

      &.selected {
        font-weight: bold;
      }
    }
  }
}

.cursor {
  cursor: pointer;
}

.icon-button {
  color: rgba(0, 0, 0, 0.65);

  &:hover {
    color: rgba(0, 0, 0, 0.90);
  }
}
</style>
