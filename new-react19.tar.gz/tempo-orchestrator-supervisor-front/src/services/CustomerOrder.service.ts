import { UUID } from '@/models'
import { CustomerOrderInfo, CustomerOrderMetadata, OrchestratorEvent, RetryReponse } from '@/models/command.model'
import axios from 'axios'

export const getEvents = async (customerOrderId: UUID): Promise<OrchestratorEvent[]> => {
  const response = await axios.get(`/backend/supervisor/customer-order/${customerOrderId}/events`)
  return response.data
}

export const getCustomerOrder = async (customerOrderNumber: string, buCode: string): Promise<CustomerOrderInfo> => {
  const response = await axios.get(`/backend/supervisor/customer-orders?customerOrderNumber=${customerOrderNumber}`, {
    headers: { buCode }
  })
  return response.data
}

export const getCustomerOrderMetadata = async (customerOrderId: UUID): Promise<CustomerOrderMetadata> => {
  const response = await axios.get(`/backend/supervisor/customer-order/${customerOrderId}/metadata`)
  return response.data
}

export const retryEvent = async (event: OrchestratorEvent, consumerApi: string): Promise<RetryReponse> => {
  const response = await axios.post(`/backend/supervisor/event/${event.id}/retry`, { consumerApi })
  return response.data
}
