import { Bpm } from '@/models'
import axios from 'axios'

export class DuplicatedBpmError extends Error {
  constructor () {
    super('The BPM name already exists on database')
  }
}

export class OutdatedVersionError extends Error {
  constructor () {
    super('The version of the BPM is outdated')
  }
}

export const createBpm = async (bpm: Bpm): Promise<Bpm> => {
  if (bpm.bpmXML === undefined) {
    throw new Error('can not save the BPM, the body is empty')
  }
  try {
    const response = await axios.post('/backend/supervisor/bpm', bpm)
    return response.data
  } catch (error) {
    if (error?.response?.data?.code === 'DUPLICATED_BPM') {
      throw new DuplicatedBpmError()
    } else {
      throw error
    }
  }
}

export const updateBpm = async (bpm: Bpm, force = false): Promise<Bpm> => {
  try {
    const response = await axios.put('/backend/supervisor/bpm/' + bpm.id, bpm, { headers: { FORCE_UPDATE: force } })
    return response.data
  } catch (error) {
    if (error?.response?.data?.code === 'DUPLICATED_BPM') {
      throw new DuplicatedBpmError()
    } else if (error?.response?.data?.code === 'OUTDATED_VERSION') {
      throw new OutdatedVersionError()
    } else {
      throw error
    }
  }
}

export const listBpm = async (): Promise<Bpm[]> => {
  const result = await axios.get('/backend/supervisor/bpm')
  return result.data
}

export const deleteBpm = async (bpm: Bpm): Promise<void> => {
  await axios.delete('/backend/supervisor/bpm/' + bpm.id)
}
