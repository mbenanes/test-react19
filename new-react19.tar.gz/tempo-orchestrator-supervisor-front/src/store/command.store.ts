import { defineStore } from 'pinia'
import { ref } from 'vue'
import type { Bpm, CustomerOrderMetadata, OrchestratorEvent } from '@/models'
import { listBpm } from '@/services/bpmn.service'

// Define the store
export const useCommandStore = defineStore('command', () => {
  // State properties
  const customerOrderId = ref<string | undefined>(undefined)
  const buCode = ref<string | undefined>(undefined)
  const customerOrderMetadata = ref<CustomerOrderMetadata | undefined>(undefined)
  const events = ref<OrchestratorEvent[] | undefined>(undefined)
  const filteredEvents = ref<OrchestratorEvent[] | undefined>(undefined)
  const bpms = ref<Bpm[] | undefined>(undefined)

  // Mutations (in Pinia, these are simply functions that modify the state)
  const updateCustomerOrderId = (id: string) => {
    customerOrderId.value = id
  }

  const updateCustomerOrderMetadata = (metadata?: CustomerOrderMetadata) => {
    customerOrderMetadata.value = metadata
  }

  const updateEvents = (newEvents: OrchestratorEvent[]) => {
    events.value = newEvents
  }

  const updateFilteredEvents = (newFilteredEvents: OrchestratorEvent[]) => {
    filteredEvents.value = newFilteredEvents
  }

  const updateBpmsSchemes = (newBpms: Bpm[]) => {
    bpms.value = newBpms
  }

  const loadBpmnSchemes = async () => {
    try {
      const bpmsList = await listBpm()
      updateBpmsSchemes(bpmsList)
    } catch (error) {
      console.error('Error loading BPMN schemes', error)
    }
  }

  // Return state, getters, and actions
  return {
    customerOrderId,
    buCode,
    customerOrderMetadata,
    events,
    filteredEvents,
    bpms,
    updateCustomerOrderId,
    updateCustomerOrderMetadata,
    updateEvents,
    updateFilteredEvents,
    updateBpmsSchemes,
    loadBpmnSchemes
  }
})
