import { Bpm, Configuration, CustomerOrderMetadata, OrchestratorEvent, User } from '@/models'
import axios from 'axios'

interface RootState {
  customerOrderId?: string;
  customerOrderMetadata?: CustomerOrderMetadata;
  configuration?: Configuration;
  events?: OrchestratorEvent[];
  filteredEvents?: OrchestratorEvent[];
  bpms?: Bpm[];
  isAuthenticated?: boolean;
  user?: User;
}

const store = new Vuex.Store<RootState>({
  state: {
    customerOrderId: undefined,
    customerOrderMetadata: undefined,
    configuration: undefined,
    bpms: undefined,
    user: undefined,
    events: undefined,
    filteredEvents: undefined,
    isAuthenticated: true
  },
  mutations: {
    isAuthenticated (state: RootState, isAuthenticated: boolean): void {
      state.isAuthenticated = isAuthenticated
    },
    updateCustomerOrderId (state: RootState, customerOrderId: string): void {
      state.customerOrderId = customerOrderId
    },
    updateCustomerOrderMetadata (state: RootState, customerOrderMetadata: CustomerOrderMetadata) {
      state.customerOrderMetadata = customerOrderMetadata
    },
    updateEvents (state: RootState, events: OrchestratorEvent[]) {
      state.events = events
    },
    updateFilteredEvents (state: RootState, events: OrchestratorEvent[]) {
      state.filteredEvents = events
    },
    updateConfiguration (state: RootState, configuration: Configuration): void {
      state.configuration = configuration
    },
    updateUser (state: RootState, user: User): void {
      state.user = user
    },
    updateBpmsSchemes (state: RootState, bpms: Bpm[]): void {
      state.bpms = bpms
    }
  },
  actions: {
    loadConfiguration (context: ActionContext<RootState, RootState>): void {
      axios.get('/backend/supervisor/configuration')
        .then(response => {
          context.commit('updateConfiguration', response.data)
        })
    },
    loadBpmnSchemes (context: ActionContext<RootState, RootState>): void {
      listBpm()
        .then(bpms => {
          context.commit('updateBpmsSchemes', bpms)
        })
    },
    loadUserInfo (context: ActionContext<RootState, RootState>): void {
      axios.get('/login/me')
        .then(response => {
          context.commit('updateUser', response.data)
        })
    }
  },
  modules: {
  }
})

axios.interceptors.response.use(undefined, function (error) {
  if (error?.response?.status === 401) {
    store.commit('isAuthenticated', false)
  }

  return Promise.reject(error)
})

export default store
