import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { Configuration, User } from '@/models/user.model'
import axios from 'axios'

// Define the store
export const useAppStore = defineStore('app', () => {
  const configuration = ref<Configuration | undefined>(undefined)
  const isAuthenticated = ref<boolean>(true)
  const user = ref<User | undefined>(undefined)

  // Computed properties or getters (if needed)
  const isAuthenticatedComputed = computed(() => isAuthenticated.value)

  const updateConfiguration = (newConfiguration: Configuration) => {
    configuration.value = newConfiguration
  }

  const updateUser = (newUser: User) => {
    user.value = newUser
  }

  const loadConfiguration = async () => {
    try {
      const response = await axios.get('/backend/supervisor/configuration')
      updateConfiguration(response.data)
    } catch (error) {
      console.error('Error loading configuration', error)
    }
  }

  const loadUserInfo = async () => {
    try {
      const response = await axios.get('/login/me')
      updateUser(response.data)
    } catch (error) {
      console.error('Error loading user info', error)
    }
  }

  // Return state, getters, and actions
  return {
    configuration,
    isAuthenticated,
    user,
    isAuthenticatedComputed,
    updateConfiguration,
    updateUser,
    loadConfiguration,
    loadUserInfo
  }
})
