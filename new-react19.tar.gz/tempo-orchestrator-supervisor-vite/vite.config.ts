import { fileURLToPath, URL } from 'node:url'
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import vueJsx from '@vitejs/plugin-vue-jsx'
import vueDevTools from 'vite-plugin-vue-devtools'

export default defineConfig({
  plugins: [vue(), vueJsx(), vueDevTools()],
  server: {
    open: true,
    port: 8082, // Frontend runs on port 8082
    proxy: {
      '/backend/*': {
        target: 'http://localhost:8080', // Backend runs on port 8080
        secure: false, // Allow unsecured connections if using HTTP
      },
      '/login/*': {
        target: 'http://localhost:8080', // Proxy login requests to backend

        changeOrigin: true,
        secure: false,
      },
      '/oauth2/*': {
        target: 'http://localhost:8080', // Proxy oauth2 requests to backend
        changeOrigin: true,
        secure: false,
      },
    },
  },
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
})
