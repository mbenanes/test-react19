#!/usr/bin/env bash

vault_url="https://vault.factory.adeo.cloud/"
namespace="adeo/tempo-orchestrator/tempo-orchestrator-supervisor"

echo "Log to the vault namespace"
if [ -z "${LDAP_NUMBER:-}" ]
  then
    echo "LDAP number: "
    read -r _ldap
else
  _ldap="$LDAP_NUMBER"
fi
echo "Use '$_ldap' as LDAP account"
VAULT_ADDR=${vault_url} VAULT_NAMESPACE=${namespace} \
  vault login -no-print -method=ldap username="${_ldap}"
vault kv get -namespace=$namespace -format=json secret/front/$1 | jq -r '.data.data|to_entries|map("\(.key)=\(.value|tostring)")|.[]' > .env.$1
