import axios from 'axios'

/*const proxyConfig = {
  target: process.env.API_URL ? process.env.API_URL : 'http://localhost:8080',
  pathRewrite: {},
  logLevel: 'debug',
  secure: false,
  autoRewrite: true,
  cookieDomainRewrite: {
    '*': '',
  },
}*/

const axiosInstance = axios.create({
  baseURL: 'http://localhost:8080', // Backend URL
  timeout: 5000, // Optional: set a timeout for requests
  headers: {
    'Content-Type': 'application/json',
    // Add any other headers you need, e.g., Authorization
  },
})

// Add a request interceptor
axiosInstance.interceptors.request.use(
  (config) => {
    config.url = config.url?.replace('/backend', '') ?? config.url
    console.log(config.url)
    // Do something before the request is sent
    const token = localStorage.getItem('authToken') // Retrieve auth token from localStorage
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    // Handle the error
    return Promise.reject(error)
  },
)

// Add a response interceptor
/*axiosInstance.interceptors.response.use(
  function (response) {
    // Do something with the response data
    console.log('Response:', response)
    return response
  },
  function (error) {
    // Handle the response error
    if (error.response && error.response.status === 401) {
      // Handle unauthorized error
      console.error('Unauthorized, logging out...')
      // Perform any logout actions or redirect to login page
    }
    return Promise.reject(error)
  },
)*/

/*axios.interceptors.response.use(
  (response) => response,
  (error) => {
    const appStore = useAppStore()
    if (error?.response?.status === 401) {
      appStore.isAuthenticated = false
    }
    return Promise.reject(error)
  },
)*/

export default axiosInstance
