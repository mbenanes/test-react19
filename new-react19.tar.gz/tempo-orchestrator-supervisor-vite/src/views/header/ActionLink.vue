<template>
  <div>
    <template v-if="actionButtons.length === 1">
      <a :href="actionButtons[0].url" target="_blank" class="link-button">
        {{actionButtons[0].name}}
      </a>
    </template>
    <template v-else>
      <div class="links-container">
        <div class="link-button more-link" @click="linkPanelIsOpenned = !linkPanelIsOpenned">
          <div class="content">
            <ChevronDown class="chevron-icon" :size="18" />
            <span>Links</span>
          </div>
        </div>
        <ul class="links" v-show="linkPanelIsOpenned">
          <li v-for="button in actionButtons" :key="button.name">
            <a v-if="button.displayedOnHome" :href="button.url" target="_blank">
              {{button.name}}
            </a>
          </li>
        </ul>
      </div>
    </template>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-facing-decorator';
import ChevronDown from 'vue-material-design-icons/ChevronDown.vue'
import { ActionButton } from '@/store'
import { useAppStore } from '../../stores/store';

@Component({
  components: {
    ChevronDown
  }
})
export default class ActionLink extends Vue {
  public linkPanelIsOpenned = false;

  private store = useAppStore();

  mounted () {
    document.addEventListener('click', this.onDocumentClick)
  }

  onDocumentClick (event: any) {
    if (this.linkPanelIsOpenned) {
      const containerElement = this.$el.querySelector('.links-container')
      const pathContainsLinkPannel = event.path.filter((pathItem: any) => pathItem === containerElement).length > 0
      if (!pathContainsLinkPannel) {
        this.linkPanelIsOpenned = false
      }
    }
  }

  get actionButtons (): {name: string; url: string; displayedOnHome: boolean}[] {
    const buttons = this.store.configuration?.actionButtons
       ?.filter((button: ActionButton) => button.displayedOnHome && (button.authoritiesRestrictions.length === 0 || this.userHasAnAuthorities(button.authoritiesRestrictions)))
       ?.map((button: ActionButton) => ({ name: button.name, url: this.replaceURLVars(button.url), displayedOnHome: button.displayedOnHome }))

    return buttons
  }

  private userHasAnAuthorities (authorities: string[]): boolean {
    return authorities
      .filter(authority => this.store.user?.authorities.includes(authority))
      .length > 0
  }

  private replaceURLVars (url: string): string {
    return url
      .replace('{orderId}', this.store.customerOrderId || '')
      .replace('{buCode}', this.store.customerOrderMetadata?.buCode || '')
      .replace('{environment}', this.store.configuration?.environmentName || '')
  }
}
</script>

<style scoped lang="scss">

.link-button {
  flex: 0 1 auto;
  margin-right: 50px;
  border: 1px solid rgba(63, 82, 123, 0.767);
  background-color: #0a56886b;
  border-radius: 5px;
  padding-top: 5px;
  padding-bottom: 5px;
  padding-right: 10px;
  padding-left: 10px;
  color: white;
  text-decoration: none;
  cursor: pointer;

  &:hover {
    background-color: #0a5688bd;
  }

  &.more-link {
    margin-right: 0;
    display: inline-block;

    .content {
      display: flex;
      flex-direction: row;
      gap: 3px;
      align-items: center;

      .material-design-icon {
        display: inline-block;
        height: 16px;
      }
    }
  }
}

.links-container {
  position: relative;
  min-width: fit-content;
  display: flex;
  justify-content: flex-end;
  margin-right: 40px;

  ul.links {
    box-shadow: 0 2px 8px #00000026;
    border-radius: 5px;
    background-color: white;
    position: absolute;
    z-index: 1100;
    list-style: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    top: 2.5em;
    min-width: max-content;

    li {
      padding: 5px 10px 5px 10px;

      &:hover {
        background-color: #0b9eff2e;
      }

      a {
        text-decoration: none;
        color: black;
        display: block;
        width: 100%;
      }
    }
  }
}
</style>
