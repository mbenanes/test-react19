<template>
  <header>
      <a class="title-link" href="/">
        <img src="/logo-tempo.png" alt="log-tempo" class="temp-icon"/>
        <h1 class="title">Tempo Supervisor</h1>
      </a>

      <div class="search-form">
        <search-box />
      </div>

      <div class="rule-engine">
        <div class="rule-engine-container" :class="{ 'loading-spinner': isRuleEngineReLoading }">
          <cached-icon
            :size=28
            :show="hasLoadedCustomerOrder && isUserAdmin"
            @click="launchTorRuleEngineAndReload()"
          />
        </div>
        <div class="rule-engine-container-error-message-container">
          <span class="rule-engine-container-error-message" v-if="ruleEngineReloadError != ''">{{ ruleEngineReloadError }}</span>
          <span class="rule-engine-container-error-message" v-if="ruleEngineReloaded">TOR rule engine reloaded !</span>
        </div>
      </div>

      <action-link />

      <div class="environment">
        {{environmentName}}
      </div>
  </header>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-facing-decorator';
import { launchTorRuleEngine } from '@/services/alerts.service'
import ActionLink from './ActionLink.vue'
import { useAppStore } from '@/stores';
import { useRouter } from 'vue-router';
import SearchBox from './SearchBox.vue';

@Component({
  methods: { launchTorRuleEngine },
  components: {
    ActionLink,
    SearchBox,
  }
})
export default class Header extends Vue {
  private store = useAppStore();
  private  router = useRouter();

  public ruleEngineReloadError = '';
  public ruleEngineReloaded = false;
  public isRuleEngineReLoading = false;



  get environmentName (): string {
    const environment = this.store.configuration?.environmentName ?? ''
    if (environment.length < 1) return environment
    return environment.charAt(0).toUpperCase() + environment.slice(1)
  }

  get customerOrderId (): string {
    return this.store.customerOrderId ?? ''
  }

  get buCode (): string {
    // return this.store.buCode
    return ""
  }

  get hasLoadedCustomerOrder (): boolean {
    // return this.store.customerOrderMetadata !== undefined
    return true
  }

  public isUserAdmin (): boolean {
    // return this.store.user?.authorities?.indexOf('ADMIN') >= 0
    return true
  }

  public async launchTorRuleEngineAndReload (): Promise<void> {
    // Initiate Variables
    this.isRuleEngineReLoading = true
    this.ruleEngineReloaded = false
    this.ruleEngineReloadError = ''

    try {
      await launchTorRuleEngine(this.customerOrderId, this.buCode)
      setTimeout(() => this.reloadOrder(), 3000)
    } catch (error) {
      if (error?.response?.data.detail) {
        this.ruleEngineReloadError = 'Error : ' + error.response.data.status
      } else {
        this.ruleEngineReloadError = 'Sorry! The server seems to be down. Please try later.'
      }
    } finally {
      setTimeout(() => { this.isRuleEngineReLoading = false }, 700)
    }
  }

  private reloadOrder () {
    this.router.push({ name: 'CustomerOrderView', params: { id: this.customerOrderId } })
    this.ruleEngineReloaded = true
  }
}

</script>


<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  position: relative;
  top: -10px;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {
  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
