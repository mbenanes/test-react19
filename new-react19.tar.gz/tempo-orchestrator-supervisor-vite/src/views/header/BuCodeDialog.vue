<template>
  <popin @close="close()">
    <template v-slot:header>
      <span>Choose the Business Unit</span>
    </template>

    <template v-slot:body>
      <div class="dialog-body">
        <div class="country-flags-selector">
          <div
            class="country-flag"
            v-for="(country, index) in countries"
            :key="index"
            @click="selectFlag(country)"
          >
            <flag :iso="country.flag" :title="country.name" class="flag-icon" />
            <span>{{ country.name }}</span>
          </div>
        </div>
      </div>
    </template>
  </popin>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-facing-decorator';
import { findBuCode } from '@/filters/bu-code'
import { COUNTRY_CODES, type Country } from '@/models';

@Component({
  components: {
  }
})
export default class BuCodeDialog extends Vue {
  @Prop() public event?: any

  public isSendDone = false

  public countries = Object.values(COUNTRY_CODES);

  public selectFlag (country: Country): void {
    this.$emit('select', findBuCode(country.code))
    this.close()
  }

  public close (): void {
    this.$emit('close', { isSendDone: this.isSendDone })
  }
}
</script>

<style scoped lang="scss">
.dialog-header {
  font-size: 18px;
  font-weight: bold;
  padding-bottom: 10px;
  border-bottom: 1px solid #ccc;
}

.dialog-body {
  padding-top: 20px;
}

.country-flags-selector {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: space-between;
  padding-top: 20px;
}

.country-flag {
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  transition: background-color 0.3s ease;
  width: 48%; /* Display flags in 2 per row on wider screens */

  &:hover {
    background-color: #f0f0f0;
  }

  .flag-icon {
    width: 50px;
    height: 30px;
    object-fit: cover;
  }

  span {
    font-size: 14px;
  }
}

/* On smaller screens, use 3 flags per row */
@media (max-width: 480px) {
  .country-flag {
    width: 30%;
  }
}
</style>
