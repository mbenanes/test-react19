<template>
  <div class="search-box" :class="{'invalid-input': !isValidInput()}">
    <magnify-icon class="search-icon" :size=25 @click="searchCommandById" />
    <input
      type="text"
      v-model="customerOrderReference"
      @input="updateCustomerOrderId"
      placeholder="Search for customer order number or Id..."
    />

    <div class="filter-block" v-if="isValidInput()">
      <badge :show="hasActiveFilter && hasLoadedCustomerOrder" class="badge-icon" />
      <filter-icon
        class="filter icon-wrapper"
        :size=25
        :class="{'visible': hasLoadedCustomerOrder}"
        @click="isFilterPanelOpened = !isFilterPanelOpened"
      />
    </div>

    <div v-if="validCmdNumber()" class="bucode-menu" @click="onOpenBuCodeDialog" >
      <ChevronDown class="bucode-chevron" :size=18 />
      <Web v-if="!buCodeSelected" class="web-icon" :size=22 />
      <!--<flag v-if="buCodeSelected" class="bucode-flag bucode-flag-select" :iso="buCodeSelected | flag-code" :squared="false" :title="buCodeSelected | bu-Code" /> -->
    </div>

    <!--<flag v-if="validUUid() && buCode" class="bucode-flag" :iso="buCode | flag-code" :squared="false" :title="buCode | bu-Code" /> -->

    <div class="filter-container" v-if="isValidInput()">
      <customer-order-filter-pannel
        :filters="existingFilters"
        @filtersUpdated="updateSelectedLinesFilter($event)"
        v-if="hasLoadedCustomerOrder"
        v-show="isFilterPanelOpened"
      />
      <div v-if="isFilterPanelOpened" class="filter-background" @click="isFilterPanelOpened = false"></div>
    </div>

    <bu-code-dialog
      v-if="!!isBuCodeDialogOpened"
      @select="onSelectBuCode"
      @close="onCloseBuCodeDialog"
    />
  </div>
</template>

<script lang="ts">
import Badge from '@/components/badged/Badge.vue';
import { isValidCommandNumber, isValidUUid, queryParamToJson } from '@/utils/utils';
import { Component, Vue } from 'vue-facing-decorator';
import { useRouter } from 'vue-router';
import BuCodeDialog from './BuCodeDialog.vue';
import FilterIcon from 'vue-material-design-icons/Filter.vue';
import CachedIcon from 'vue-material-design-icons/Cached.vue';
import ChevronDown from 'vue-material-design-icons/ChevronDown.vue';
import MagnifyIcon from 'vue-material-design-icons/Magnify.vue';
import type { BuCodeType, UUID } from '@/models';
import { useAppStore } from '@/stores';
import Web from 'vue-material-design-icons/Web.vue';

@Component({
  methods: { isValidUUid, isValidCommandNumber },
  components: {
    Badge,
    FilterIcon,
    MagnifyIcon,
    Web,
    // CustomerOrderFilterPannel,
    BuCodeDialog,
    ChevronDown
  }
})
export default class SearchBox extends Vue {
  private store = useAppStore();
  private  router = useRouter();

  // customerOrderReference could be the customerOrderId or customerOrderNumber
  public customerOrderReference: string | UUID = '';
  public existingFilters = {};
  public isFilterPanelOpened = false;

  public isBuCodeDialogOpened? = false;
  public buCodeSelected: BuCodeType | string = '';

  created () {
    this.customerOrderReference = this.$route.params.id ?? this.store.customerOrderId
    this.existingFilters = queryParamToJson(this.$route.query, 'filters')
  }

  mounted () {
    document.addEventListener('keydown', this.onEnterKeyPress)
  }

  beforeDestroy () {
    document.removeEventListener('keydown', this.onEnterKeyPress)
  }

  onEnterKeyPress (event: KeyboardEvent) {
    if (event.key === 'Enter') {
      this.searchCommandById()
    }
  }

  public onOpenBuCodeDialog () {
    this.isBuCodeDialogOpened = true
  }

  public onCloseBuCodeDialog () {
    this.isBuCodeDialogOpened = false
  }

  public onSelectBuCode (buCode: BuCodeType): void {
    this.buCodeSelected = buCode
    this.isBuCodeDialogOpened = false
    this.searchCommandOrder()
  }

  private async searchCommandOrder () {
    if (!this.customerOrderReference || !this.buCodeSelected) {
      return
    }

    let customerOrderId = ''
    try {
      customerOrderId = (await getCustomerOrder(this.customerOrderReference, this.buCodeSelected))?.id ?? ''
    } catch (e) {
      console.error('customer order not found by ', this.customerOrderReference, this.buCodeSelected)
    }

    this.store.updateCustomerOrderId(customerOrderId)
    const targetRoute = { name: 'CustomerOrderView', params: { id: customerOrderId } }
    this.$router.push(targetRoute)
  }

  get buCode (): string {
    return this.store?.customerOrderMetadata?.buCode ?? this.store?.buCode
  }

  public isValidInput (): boolean {
    return isValidUUid(this.customerOrderReference) || isValidCommandNumber(this.customerOrderReference)
  }

  public validUUid (): boolean {
    return isValidUUid(this.customerOrderReference)
  }

  public validCmdNumber (): boolean {
    return isValidCommandNumber(this.customerOrderReference)
  }

  get hasActiveFilter () {
    return this.existingFilters && Object.keys(this.existingFilters).length > 0
  }

  get hasLoadedCustomerOrder (): boolean {
    return this.store.customerOrderMetadata !== undefined
  }

  public updateSelectedLinesFilter (filters: any) {
    this.existingFilters = filters
    this.$router.push({
      name: 'CustomerOrderView',
      params: { id: this.store.customerOrderId },
      query: jsonToQueryParamObject(filters, 'filters')
    })
  }

  public updateCustomerOrderId (event: any): void {
    this.customerOrderReference = event.target.value

    if (isValidCommandNumber(this.customerOrderReference) && !this.buCodeSelected) {
      this.isBuCodeDialogOpened = true
      return
    }

    const oldCustomerOrderId = this.store.customerOrderId
    if (this.isValidInput() && oldCustomerOrderId !== this.customerOrderReference) {
      // In case of new custom order Id, we should update the whole context
      this.searchCommandById()
    }
  }

  private searchCommandById (): void {
    if (this.validCmdNumber()) {
      this.searchCommandOrder()
    }

    if (this.validUUid() && this.customerOrderReference !== this.$route.params.id) {
      this.existingFilters = {}
      this.store.updateCustomerOrderId(this.customerOrderReference)
      this.store.updateCustomerOrderMetadata(undefined)
      const targetRoute = { name: 'CustomerOrderView', params: { id: this.customerOrderReference } }

      // Prevent navigation if the target route is the same as the current one
      if (this.$route.fullPath !== this.$router.resolve(targetRoute).href) {
        this.$router.push(targetRoute)
      }
    }
  }
}
</script>

<style scoped lang="scss">
.search-box {
  display: flex;
  height: 36px;
  width: 70%;
  border: none;
  border: 1px solid #b2c9e0;
  background-color: whitesmoke;
  padding: 0 6px;
  max-width: 800px;
  border-radius: 2px;

  .bucode-menu {
    display: flex;
    flex-direction: row;
    align-items: center;
    background-color: lightgray;
    border-radius: 4px;
    align-self: center;
    padding: 1px;
    padding-right: 3px;

    .bucode-chevron, .web-icon {
      padding-top: 3px;
    }

    .bucode-flag {
      margin: unset;
    }
  }

  .bucode-menu:hover {
    background-color: gray;
  }

  .bucode-flag {
    margin-top: 5px;
    width: 26px;
    height: 26px;
  }

  .search-icon {
    padding-top: 6px;
    padding-right: 4px;
    :hover {
      cursor: pointer;
    }
  }

  .filter-icon {
    color: currentcolor;
  }

  .filter-block {
    display: absolute;
    padding-top: 6px;
    padding-right: 10px;
  }

  .badge-icon {
    display: block;
  }

  input {
    background-color: unset;
    border: none;
    width: 100%;
    height: 100%;
    outline: none;
    font-size: 18px;
    font-style: italic;
  }

  &:hover, &:active, &:focus {
    background-color: lightgray;
  }
}

.invalid-input {
  border: 2px solid red;
}

.filter-container {
  position: absolute;
  margin-top: 60px;
  z-index: 10;

  .filter {
    color: white;
    display: block;
    opacity: 0;
    padding-top: 5px;

    &.visible {
      opacity: 1;
      cursor: pointer;
    }

    &:hover {
      color: #dddddd;
    }
  }

  .filter-pannel {
    overflow: auto;
    text-align: initial;
    width: 50vw;
    height: 60vh;
    margin-left: -4vw;
    background-color: white;
    border: 1px solid #d4cfcf;
    position: absolute;
    z-index: 11100;
    padding: 20px;
  }

  .filter-background {
    background-color: black;
    position: fixed;
    width: 100vw;
    height: 100vh;
    z-index: 11000;
    top: 0;
    left: 0;
    opacity: 0.1;
  }
}
</style>
