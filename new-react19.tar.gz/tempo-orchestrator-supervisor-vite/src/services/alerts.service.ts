import axiosInstance from '@/config/axios.config'
import queryString from 'query-string'

export interface Pagination {
  page: number
  pageSize: number
  totalPageCount: number
  totalCount: number
}

export interface AlertEvent {
  eventType: string
  functionalType: string
}

export interface Alert {
  id: string
  eventId: string
  lineId: string
  buCode: string
  customerOrderId: string
  deliveryType: string
  alertName: string
  closingEvents: AlertEvent[]
  createdAt: string
  expectedClosingEventDate: string
  ticketNumber: string
  numberOfComment: number
}

export interface Alerts {
  pagination: Pagination
  data: Alert[]
}

export interface AlertComment {
  id: string
  comment: string
  createdAt: string
  createdBy: string
}

export interface AlertFilters {
  name: string
  values: FilterValueResponse[]
}

export interface FilterValueResponse {
  value: string
  count: number
}

export const listAlerts = async (
  page: number,
  customerOrderId: string,
  selectedFilters: { [key: string]: string[] },
  sortingDirection: string,
): Promise<Alerts> => {
  const params: { [key: string]: string[] | string } = {}

  if (customerOrderId.length > 0) {
    params.customerOrderId = customerOrderId
  }
  for (const filter of Object.entries(selectedFilters)) {
    const filterName = filter[0]
    params[filterName] = filter[1]
  }

  params.sortingDirection = sortingDirection
  params.page = `${page}`
  params.pageSize = '20'

  const result = await axiosInstance.get('/backend/supervisor/alerts', {
    params: params,
    paramsSerializer: function (params) {
      return queryString.stringify(params, { arrayFormat: 'none' })
    },
  })
  return result.data
}

export const listAlertFilters = async (): Promise<AlertFilters[]> => {
  const query = '/backend/supervisor/alerts/filters'

  const result = await axiosInstance.get(query)
  return result.data
}

export const getAlertsForCustomerOrder = async (customerOrderId: string): Promise<Alert[]> => {
  const result = await axiosInstance.get(
    '/backend/supervisor/alerts?pageSize=100&customerOrderId=' + customerOrderId,
  )
  return result.data.data
}

export const deleteAlert = async (alertId: string): Promise<void> => {
  const result = await axiosInstance.delete('/backend/supervisor/alerts/' + alertId)
  return result.data
}

export const generateValuateStockBackoResponse = async (eventId: string): Promise<void> => {
  const result = await axiosInstance.post(
    '/backend/supervisor/alerts/' + eventId + '/generateValuateStockResponse',
  )
  return result.data
}

export const launchTorRuleEngine = async (
  customerOrderId: string,
  buCode: string,
): Promise<void> => {
  const result = await axiosInstance.post(
    '/backend/supervisor/technical/customerOrder/' +
      customerOrderId +
      '/launchTorRuleEngine?buCode=' +
      buCode,
  )
  return result.data
}

export const addComment = async (alertId: string, comment: string): Promise<AlertComment> => {
  const result = await axiosInstance.post('/backend/supervisor/alerts/' + alertId + '/comments', {
    comment: comment,
  })
  return result.data
}

export const getComments = async (alertId: string): Promise<AlertComment[]> => {
  const result = await axiosInstance.get('/backend/supervisor/alerts/' + alertId + '/comments')
  return result.data
}
