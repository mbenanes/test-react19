import axiosInstance from '@/config/axios.config'
import type { UUID } from '@/models/country.model'

export interface OrchestratorEvent {
  id: string
  metadata: {
    consumerApi: string[]
    timestamp: string
    source: string
    eventType: string
    traceId: string
    functionalType: string
    customerOrderLineIds: string[]
  }
  value: object
}

export interface CustomerOrderInfo {
  id: string
  number: string
  buCode: string
  version: number
  offerLines: CustomerOrderLineMetadata[]
  delivery: string
}

export interface CustomerOrderMetadata {
  customerOrderId: string
  buCode: string
  customerOrderLines: CustomerOrderLineMetadata[]
}

export interface CustomerOrderLineMetadata {
  id: string
  soldByAThirdParty: boolean
  refLM: string
  adeoKey: string
  vendorName: string
  deliveryType: string
}
export interface RetryReponse {
  id: string
  topic: string
  offset: number
  partition: number
}

export const getEvents = async (customerOrderId: UUID): Promise<OrchestratorEvent[]> => {
  const response = await axiosInstance.get(
    `/backend/supervisor/customer-order/${customerOrderId}/events`,
  )
  return response.data
}

export const getCustomerOrder = async (
  customerOrderNumber: string,
  buCode: string,
): Promise<CustomerOrderInfo> => {
  const response = await axiosInstance.get(
    `/backend/supervisor/customer-orders?customerOrderNumber=${customerOrderNumber}`,
    {
      headers: { buCode },
    },
  )
  return response.data
}

export const getCustomerOrderMetadata = async (
  customerOrderId: UUID,
): Promise<CustomerOrderMetadata> => {
  const response = await axiosInstance.get(
    `/backend/supervisor/customer-order/${customerOrderId}/metadata`,
  )
  return response.data
}

export const retryEvent = async (
  event: OrchestratorEvent,
  consumerApi: string,
): Promise<RetryReponse> => {
  const response = await axiosInstance.post(`/backend/supervisor/event/${event.id}/retry`, {
    consumerApi,
  })
  return response.data
}
