import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { CustomerOrderMetadata, OrchestratorEvent } from '@/services/CustomerOrder.service'
import type { Configuration, User } from '@/models/user.model'
import axiosInstance from '@/config/axios.config'
import type { Bpm } from '@/models'
import { listBpm } from '@/services/bpmn.service'

// Define the store
export const useAppStore = defineStore('app', () => {
  // State properties
  const customerOrderId = ref<string | undefined>(undefined)
  const customerOrderMetadata = ref<CustomerOrderMetadata | undefined>(undefined)
  const configuration = ref<Configuration | undefined>(undefined)
  const events = ref<OrchestratorEvent[] | undefined>(undefined)
  const filteredEvents = ref<OrchestratorEvent[] | undefined>(undefined)
  const bpms = ref<Bpm[] | undefined>(undefined)
  const isAuthenticated = ref<boolean>(true)
  const user = ref<User | undefined>(undefined)

  // Computed properties or getters (if needed)
  const isAuthenticatedComputed = computed(() => isAuthenticated.value)

  // Mutations (in Pinia, these are simply functions that modify the state)
  const updateCustomerOrderId = (id: string) => {
    customerOrderId.value = id
  }

  const updateCustomerOrderMetadata = (metadata?: CustomerOrderMetadata) => {
    customerOrderMetadata.value = metadata
  }

  const updateEvents = (newEvents: OrchestratorEvent[]) => {
    events.value = newEvents
  }

  const updateFilteredEvents = (newFilteredEvents: OrchestratorEvent[]) => {
    filteredEvents.value = newFilteredEvents
  }

  const updateConfiguration = (newConfiguration: Configuration) => {
    configuration.value = newConfiguration
  }

  const updateUser = (newUser: User) => {
    user.value = newUser
  }

  const updateBpmsSchemes = (newBpms: Bpm[]) => {
    bpms.value = newBpms
  }

  // Actions (side-effects or async functions)
  const loadConfiguration = async () => {
    try {
      const response = await axiosInstance.get('/backend/supervisor/configuration')
      updateConfiguration(response.data)
    } catch (error) {
      console.error('Error loading configuration', error)
    }
  }

  const loadBpmnSchemes = async () => {
    try {
      const bpmsList = await listBpm()
      updateBpmsSchemes(bpmsList)
    } catch (error) {
      console.error('Error loading BPMN schemes', error)
    }
  }

  const loadUserInfo = async () => {
    try {
      // const response = await axiosInstance.get('/login/me')
      //updateUser(response.data)
    } catch (error) {
      console.error('Error loading user info', error)
    }
  }

  // Return state, getters, and actions
  return {
    customerOrderId,
    customerOrderMetadata,
    configuration,
    events,
    filteredEvents,
    bpms,
    isAuthenticated,
    user,
    isAuthenticatedComputed,
    updateCustomerOrderId,
    updateCustomerOrderMetadata,
    updateEvents,
    updateFilteredEvents,
    updateConfiguration,
    updateUser,
    updateBpmsSchemes,
    loadConfiguration,
    loadBpmnSchemes,
    loadUserInfo,
  }
})
