<template>
  <div id="app">
    <Header />
    <div class="page">
      <RouterView />
      <router-view v-if="configurationLoaded"/>
      <div class="message" v-else-if="isUnauthenticated">
        You are not authenticated.
        <button @click="login"> Login </button>
      </div>
      <div class="message" v-else>
        <div class="loader"/>
        Chargement de la configuration
      </div>
    </div>
    <v-dialog />
  </div>
</template>

<!-- <template>
  <Header />

  <header>
    <img alt="Vue logo" class="logo" src="@/assets/logo.svg" width="125" height="125" />

    <div class="wrapper">
      <HelloWorld msg="You did it!" />
      <Header />

      <nav>
        <RouterLink to="/">Home</RouterLink>
        <RouterLink to="/about">About</RouterLink>
        <RouterLink to="/header">Header</RouterLink>
      </nav>
    </div>
  </header>

  <RouterView />
</template> -->

<script lang="ts">
import { Component, Vue } from 'vue-facing-decorator';
import Header from './views/header/HeaderView.vue';
import { useAppStore } from './stores/store';

@Component({
  components: { Header}
})
export default class App extends Vue {

    // Setup Pinia store
    private appStore = useAppStore();

  // Computed property for checking if the configuration is loaded
  get configurationLoaded(): boolean {
    return this.appStore.configuration !== undefined && this.appStore.bpms !== undefined;
  }

  // Computed property for checking authentication status
  get isUnauthenticated(): boolean {
    return this.appStore.isAuthenticated === false;
  }

  // Method for login redirection
  login(): void {
    document.cookie = 'NSREDIRECT=' + this.$router.currentRoute.fullPath + ';path=/';
    location.href = '/login/authorize';
  }

  // Lifecycle hook before the component is mounted
  beforeMount(): void {
    // Dispatch actions to load configuration, BPMN schemes, and user info
    this.appStore.loadConfiguration();
    this.appStore.loadBpmnSchemes();
    this.appStore.loadUserInfo();
  }

}

</script>

<style lang="scss" scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  height: 100vh;

  display: flex;
  flex-flow: column;

  .page {
    flex: 1 1 auto;
    overflow: hidden;
    display: flex;

    >div {
      width: 100%;
      height: 100%;
    }
  }
}

header {
  flex: 0 0 48px;
}

.message {
  background-color: #f5f5f9;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
}

.loader {
  color: black;
  font-size: 90px;
  text-indent: -9999em;
  overflow: hidden;
  width: 1em;
  height: 1em;
  border-radius: 50%;
  margin: 72px auto;
  position: relative;
  transform: translateZ(0);
  animation: load6 1.7s infinite ease, round 1.7s infinite ease;
}

@keyframes load6 {
  0% {
    box-shadow: 0 -0.83em 0 -0.4em, 0 -0.83em 0 -0.42em, 0 -0.83em 0 -0.44em, 0 -0.83em 0 -0.46em, 0 -0.83em 0 -0.477em;
  }
  5%,
  95% {
    box-shadow: 0 -0.83em 0 -0.4em, 0 -0.83em 0 -0.42em, 0 -0.83em 0 -0.44em, 0 -0.83em 0 -0.46em, 0 -0.83em 0 -0.477em;
  }
  10%,
  59% {
    box-shadow: 0 -0.83em 0 -0.4em, -0.087em -0.825em 0 -0.42em, -0.173em -0.812em 0 -0.44em, -0.256em -0.789em 0 -0.46em, -0.297em -0.775em 0 -0.477em;
  }
  20% {
    box-shadow: 0 -0.83em 0 -0.4em, -0.338em -0.758em 0 -0.42em, -0.555em -0.617em 0 -0.44em, -0.671em -0.488em 0 -0.46em, -0.749em -0.34em 0 -0.477em;
  }
  38% {
    box-shadow: 0 -0.83em 0 -0.4em, -0.377em -0.74em 0 -0.42em, -0.645em -0.522em 0 -0.44em, -0.775em -0.297em 0 -0.46em, -0.82em -0.09em 0 -0.477em;
  }
  100% {
    box-shadow: 0 -0.83em 0 -0.4em, 0 -0.83em 0 -0.42em, 0 -0.83em 0 -0.44em, 0 -0.83em 0 -0.46em, 0 -0.83em 0 -0.477em;
  }
}

@keyframes round {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
</style>

<style lang="scss">
body {
  margin: 0;
  padding: 0;
}
</style>
