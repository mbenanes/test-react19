<template>
  <div class="badge-container">
    <slot></slot>
    <div class="badge" :class="alignBadge" v-if="show">{{content}}</div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-facing-decorator';

@Component({})
export default class Badge extends Vue {
  @Prop()
  public show?: boolean;

  @Prop()
  public content?: string;

  @Prop({ default: 'right' })
  public alignBadge?: 'right' | 'left';
}
</script>

<style scoped lang="scss">

.badge-container {
  display: inline-block;
  position: relative;

  .badge {
    width: 9px;
    height: 9px;
    background-color: var(--secondary-color);
    border: 1px solid var(--secondary-color);
    border-radius: 7px;
    position: absolute;

    font-size: 7px;
    text-align: center;
    overflow: hidden;

    top: -3px;
    &.right {
      right: -3px;
    }

    &.left {
      left: -3px;
    }
  }
}
</style>
