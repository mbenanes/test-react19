import { COUNTRY_CODES, type BuCodeType } from '@/models'

// Find BU code based on country code
export const findBuCode = (countryCode: string): BuCodeType | undefined => {
  const buCode = Object.keys(COUNTRY_CODES).find(
    (buCode) => COUNTRY_CODES[buCode as BuCodeType].code === countryCode,
  )
  return buCode as BuCodeType | undefined
}

// Get country code based on BU code
export const getBuCode = (value: BuCodeType): string => {
  if (!value) return ''

  const country = COUNTRY_CODES[value]
  return country ? country.code : value
}

// Get flag code based on BU code
export const getFlagCode = (value: BuCodeType): string | undefined => {
  if (!value) return undefined

  const country = COUNTRY_CODES[value]
  return country ? country.flag : undefined
}
