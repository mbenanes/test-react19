#!/bin/bash -ae

## Use the file containing Vault secrets placed here by Turbine
if [[ -f /opt/vault_secrets/component-conf.bash ]];
then
    source /opt/vault_secrets/component-conf.bash
fi

export ENV="${ENV:-local}"

envsubst '$API_URL,$ENV' < /etc/nginx/conf.d/default.conf.template >/etc/nginx/conf.d/default.conf
rm -rf /etc/nginx/conf.d/default.conf.template

exec "$@"
