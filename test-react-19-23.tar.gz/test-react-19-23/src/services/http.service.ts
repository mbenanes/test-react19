import axios, { type AxiosRequestConfig } from 'axios'

export const get = async <T>(url: string, config?: AxiosRequestConfig<any>): Promise<T> => {
  const response = await (config ? axios.get(url, config) : axios.get(url))
  return response.data
}

export interface Pagination {
  page: number
  pageSize: number
  totalPageCount: number
  totalCount: number
}

export interface Page<T> {
  pagination: Pagination
  data: T[]
}

export interface HttpError {
  response?: {
    data: {
      detail?: string
      status?: string
      code?: string
    }
  }
}
