import type {
  CustomerOrderInfo,
  CustomerOrderMetadata,
  OrchestratorEvent,
  RetryReponse,
  UUID,
} from '@/models'
import axios from 'axios'
const apiUrl = import.meta.env.VITE_API_URL

export const getEvents = async (customerOrderId: UUID): Promise<OrchestratorEvent[]> => {
  const response = await axios.get(apiUrl + `/supervisor/customer-order/${customerOrderId}/events`)
  return response.data
}

export const getCustomerOrder = async (
  customerOrderNumber: string,
  buCode: string,
): Promise<CustomerOrderInfo> => {
  const response = await axios.get(
    apiUrl + `/supervisor/customer-orders?customerOrderNumber=${customerOrderNumber}`,
    {
      headers: { buCode },
    },
  )
  return response.data
}

export const getCustomerOrderMetadata = async (
  customerOrderId: UUID,
): Promise<CustomerOrderMetadata> => {
  const response = await axios.get(
    apiUrl + `/supervisor/customer-order/${customerOrderId}/metadata`,
  )
  return response.data
}

export const retryEvent = async (
  event: OrchestratorEvent,
  consumerApi: string,
): Promise<RetryReponse> => {
  const response = await axios.post(apiUrl + `/supervisor/event/${event.id}/retry`, {
    consumerApi,
  })
  return response.data
}
