import type { Bpm } from '@/models'
import axios from 'axios'
import type { HttpError } from './http.service'

const apiUrl = import.meta.env.VITE_API_URL

export class DuplicatedBpmError extends Error {
  constructor() {
    super('The BPM name already exists on database')
  }
}

export class OutdatedVersionError extends Error {
  constructor() {
    super('The version of the BPM is outdated')
  }
}

export const createBpm = async (bpm: Bpm): Promise<Bpm> => {
  if (bpm.bpmXML === undefined) {
    throw new Error('can not save the BPM, the body is empty')
  }
  try {
    const response = await axios.post(apiUrl + '/supervisor/bpm', bpm)
    return response.data
  } catch (e) {
    const error = e as HttpError
    if (error?.response?.data?.code === 'DUPLICATED_BPM') {
      throw new DuplicatedBpmError()
    } else {
      throw error
    }
  }
}

export const updateBpm = async (bpm: Bpm, force = false): Promise<Bpm> => {
  try {
    const response = await axios.put(apiUrl + '/supervisor/bpm/' + bpm.id, bpm, {
      headers: { FORCE_UPDATE: force },
    })
    return response.data
  } catch (e) {
    const error = e as HttpError
    if (error?.response?.data?.code === 'DUPLICATED_BPM') {
      throw new DuplicatedBpmError()
    } else if (error?.response?.data?.code === 'OUTDATED_VERSION') {
      throw new OutdatedVersionError()
    } else {
      throw error
    }
  }
}

export const listBpm = async (): Promise<Bpm[]> => {
  const result = await axios.get(apiUrl + '/supervisor/bpm')
  return result.data
}

export const deleteBpm = async (bpm: Bpm): Promise<void> => {
  await axios.delete(apiUrl + '/supervisor/bpm/' + bpm.id)
}
