<template>
  <div
    class="select-box"
    tabindex="0"
    @focus="toggleOptions(true)"
    @blur="toggleOptions(false)"
    :id="inputId"
  >
    <div class="selected-values">
      <span class="values">
        <span></span>
      </span>
      <span
        class="clear"
        @click="(clear(), $event.stopPropagation(), $event.preventDefault())"
        v-if="value && value.length > 0"
      >
        x
      </span>
    </div>

    <ul class="select-box" :class="{ opened: isOpened }">
      <li
        v-for="option in options"
        v-bind:key="option.value"
        @click="toggleValue(option.value.value, !isSelected(option.value.value))"
      >
        <input
          tabindex="-1"
          @mousedown="$event.preventDefault()"
          type="checkbox"
          :checked="isSelected(option.value.value)"
          @change="toggleValue(option.value.value, $event.target.checked)"
        />
        <span> {{ option.label }} ({{ option.value.count }})</span>
      </li>
    </ul>
  </div>
</template>

<script lang="ts">
import { FilterOption } from '@/services/alerts.service'
import { Component, Emit, Prop, Vue, Watch } from 'vue-facing-decorator'

export interface SelectOption {
  label: string
  value: FilterOption | string
}

@Component({})
class MultiSelect extends Vue {
  @Prop()
  public options?: SelectOption[]

  @Prop()
  public value?: string[]

  @Prop()
  public inputId?: string

  public isOpened = false

  @Emit('input')
  toggleValue(value: string, selected: boolean) {
    if (selected) {
      const valueClone = [...(this.value || [])]
      valueClone.push(value)
      return valueClone
    } else if (this.value) {
      return this.value.filter((it) => it !== value)
    }
  }

  @Emit('input')
  clear() {
    return []
  }

  isSelected(value: string): boolean {
    if (this.value) {
      return this.value.indexOf(value) >= 0
    }
    return false
  }

  toggleOnLabelClick() {
    ;(this.$el as HTMLElement).focus()
  }

  mounted() {
    const associatedLabel = document.querySelector(`label[for=${this.inputId}]`)
    if (associatedLabel) {
      associatedLabel.addEventListener('click', this.toggleOnLabelClick)
    }
    this.refreshValues()
  }

  @Watch('value')
  onPropertyChanged() {
    this.refreshValues()
  }

  refreshValues() {
    if (!this.value) {
      return []
    }
    const valuesLabels = this.value?.map((value) => {
      const option = this.options?.find(
        (it) => it?.value == value || (it?.value as FilterOption)?.value === value,
      )
      return option ? option.label : value
    })
    const valueOrderedBySize = valuesLabels.sort((a, b) => a.length - b.length)
    const valuesOuterSpan = this.$el.querySelector('span.values') as HTMLElement
    const valuesSpan = this.$el.querySelector('span.values span') as HTMLElement

    let numberOfDeleted = 0
    do {
      valuesSpan.innerHTML =
        valueOrderedBySize.join(', ') + (numberOfDeleted > 0 ? `, +${numberOfDeleted} more` : '')
      ++numberOfDeleted
      valueOrderedBySize.pop()
    } while (valuesOuterSpan.offsetWidth < valuesSpan.offsetWidth && valueOrderedBySize.length > 0)
  }

  beforeDestroy() {
    const associatedLabel = document.querySelector(`label[for=${this.inputId}]`)
    if (associatedLabel) {
      associatedLabel.removeEventListener('click', this.toggleOnLabelClick)
    }
  }

  toggleOptions(opened: boolean) {
    this.isOpened = opened
  }
}

export default MultiSelect
</script>

<style scoped lang="scss">
div.select-box {
  position: relative;
  outline: none;
}

.selected-values {
  border-bottom: 1px solid rgba(0, 0, 0, 0.42);
  width: 100%;
  min-height: 1.4em;
  cursor: pointer;

  display: flex;
  flex-direction: row;

  .values {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;

    flex: 1 1 auto;
  }

  .clear {
    color: rgba(0, 0, 0, 0.65);

    &:hover {
      color: rgba(0, 0, 0, 0.9);
    }
  }

  &:hover {
    border-bottom: 1px solid rgba(0, 0, 0, 0.6);
  }
}

ul.select-box {
  position: absolute;
  background: white;
  display: none;
  margin: 0;
  padding: 0;
  box-shadow:
    0 5px 5px -3px rgb(0 0 0 / 20%),
    0 8px 10px 1px rgb(0 0 0 / 14%),
    0 3px 14px 2px rgb(0 0 0 / 12%);
  width: 100%;
  z-index: 1100;

  &.opened {
    display: block;
  }

  li {
    list-style-type: none;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    padding: 5px;

    &:hover {
      background-color: #eeeeee;
    }

    &,
    input {
      cursor: pointer;
    }
  }
}
</style>
