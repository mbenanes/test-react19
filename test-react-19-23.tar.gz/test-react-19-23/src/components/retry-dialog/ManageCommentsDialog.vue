<template>
  <div class="comment-popin">
    <form @submit="addComment($event)" class="add-comment">
      <textarea-autosize
        placeholder="Add new comment"
        name="comment"
        v-model="commentValue"
      ></textarea-autosize>
      <button type="submit" class="submit-button">
        <comment-plus-icon title="Add a comment"></comment-plus-icon>
      </button>
      <button @click="close" class="close-popin">&times;</button>
    </form>

    <div class="comments">
      <div class="comment" v-for="comment in comments" :key="comment.id">
        <div class="message" v-html="marked(comment.comment)"></div>
        <div class="metadata">
          <div class="name">{{ comment.createdBy }}</div>
          <div class="date" :title="formatDate(comment.createdAt)">
            {{ durationFromNow(comment.createdAt) }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { addComment, Alert, AlertComment, getComments } from '@/services/alerts.service'
import { Component, Emit, Prop, Vue } from 'vue-facing-decorator'
import TextareaAutosize from 'vue-textarea-autosize/src/components/TextareaAutosize.vue'
import CommentPlusIcon from 'vue-material-design-icons/CommentPlus.vue'
import { marked } from 'marked'
import DOMPurify from 'dompurify'
import { formatDate, durationFromNow } from '@/utils/utils'

@Component({
  methods: { durationFromNow, formatDate },
  components: {
    TextareaAutosize,
    CommentPlusIcon,
  },
})
class ManageCommentsDialog extends Vue {
  @Prop() public alerts?: Alert[]
  @Prop({ default: 'right' }) public popinAlign?: 'right' | 'left'

  public comments: AlertComment[] = []
  public commentValue = ''

  @Emit('commentAdded')
  async addComment(event: any) {
    event.preventDefault()
    if (this.commentValue.trim()?.length > 0) {
      const comment = await addComment(this.alerts![0].id, this.commentValue)
      this.comments.unshift(comment) // Add the comment to the top
      this.commentValue = ''
      return comment
    }
  }

  close() {
    this.$emit('clickOutside')
  }

  async created() {
    if (this.alerts?.length && this.alerts?.length > 0) {
      const comments = (
        await Promise.all(this.alerts.map((alert) => getComments(alert.id)))
      ).flatMap((it) => it)
      this.comments = comments.sort((c1, c2) => (c1.createdAt < c2.createdAt ? 1 : -1))
    }
  }

  mounted() {
    // setTimeout(() => document.addEventListener('click', this.onDocumentClick), 100)
    window.addEventListener('resize', this.positionElement)
    document.addEventListener('keydown', this.onKeyPress, false)
  }

  beforeDestroy() {
    // document.removeEventListener('click', this.onDocumentClick)
    window.removeEventListener('resize', this.positionElement)
    document.removeEventListener('keydown', this.onKeyPress)
  }

  updated() {
    this.positionElement()
  }

  onKeyPress(e: any) {
    if (e.key === 'Escape') {
      this.$emit('clickOutside')
    }
  }

  positionElement() {
    const element = this.$el as HTMLElement
    const parentElement = element.parentNode as HTMLElement
    const elBottomPosition = element.offsetTop + element.offsetHeight
    const parentBounding = parentElement?.getBoundingClientRect()

    if (elBottomPosition > window.innerHeight) {
      element.style.top = `${window.innerHeight - element.offsetHeight}px`
    } else {
      element.style.top = `${parentBounding.top + parentElement.offsetHeight}px`
    }

    if (this.popinAlign === 'right') {
      element.style.left = parentBounding.right - element.offsetWidth + 'px'
    } else {
      element.style.left = parentElement?.getBoundingClientRect().left + 'px'
    }
  }

  marked(text: string) {
    return marked(DOMPurify.sanitize(text))
  }
}

export default ManageCommentsDialog
</script>

<style scoped lang="scss">
.comment-popin {
  min-width: 400px;
  position: fixed;
  z-index: 1003;
  background: #ffffff;
  font-weight: normal;
  text-align: left;
  border-radius: 8px;
  border: 1px solid #ddd;
  overflow: hidden;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  max-height: 80%;
  display: flex;
  flex-direction: column;

  .add-comment {
    display: flex;
    align-items: center;
    padding: 10px;
    box-shadow: 0px -4px 6px rgba(0, 0, 0, 0.1);
    background: #fafafa;
    border-bottom: 1px solid #ddd;

    textarea {
      flex-grow: 1;
      border: 1px solid #ccc;
      border-radius: 4px;
      padding: 8px;
      font-size: 14px;
      resize: none;
      outline: none;
      transition: border 0.3s ease;
    }

    button {
      background: transparent;
      border: none;
      cursor: pointer;
      margin-left: 8px;
      color: #333;

      &:hover,
      &:focus {
        color: #007bff;
      }
    }

    .close-popin {
      font-size: 24px;
      font-weight: bold;
      background: transparent;
      border: none;
      cursor: pointer;
      color: #888;

      &:hover {
        color: #ff4c4c;
      }
    }
  }

  .comments {
    max-height: 400px;
    overflow: auto;
    padding: 8px;

    .comment {
      padding: 10px;
      margin-bottom: 8px;
      background: #f9f9f9;
      border-radius: 4px;
      border: 1px solid #f1f1f1;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
      word-wrap: break-word;

      .message p {
        margin: 0;
        font-size: 14px;
        line-height: 1.5;
      }
    }
  }

  .metadata {
    display: flex;
    justify-content: space-between;
    font-size: 12px;
    opacity: 0.7;
    color: #666;
  }
}
</style>
