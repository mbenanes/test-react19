<template>
  <popin @close="close()">
    <template v-slot:header> Delete the alert </template>
    <template v-slot:body>
      <template v-if="!isDeleteDone">
        <div>
          Are you sure you want to delete the alert
          <span class="highlighted">{{ alertName }}</span> for the customer order
          <span class="highlighted">{{ customerOrderId }}</span> and
          {{ 'line' | pluralize(alerts.length) }}
          <span class="highlighted" v-for="alert of alerts" v-bind:key="alert.lineId">{{
            alert.lineId
          }}</span>
          ?
        </div>
        <div class="error" v-if="deleteError != ''">
          {{ deleteError }}
        </div>
      </template>
      <template v-else>
        <div>The alert has been deleted</div>
      </template>
    </template>
    <template v-slot:footer v-if="!isDeleteDone">
      <button @click="deleteAlert()" class="danger">Delete</button>
      <button @click="close()">Cancel</button>
    </template>
    <template v-slot:footer v-else>
      <button @click="close()" class="primary">Understood</button>
    </template>
  </popin>
</template>

<script lang="ts">
import { Component, Emit, Prop, Vue } from 'vue-facing-decorator'
import Popin from './Popin.vue'
import { Alert, deleteAlert } from '@/services/alerts.service'
import { HttpError } from '@/services/http.service'

@Component({
  components: {
    Popin,
  },
})
class RetryDialog extends Vue {
  @Prop()
  public alerts?: Alert[]

  public isDeleteDone = false

  public deleteError = ''

  @Emit('close')
  public close(): { isDeleteDone: boolean } {
    return { isDeleteDone: this.isDeleteDone }
  }

  public async deleteAlert(): Promise<void> {
    try {
      for (const alert of this.alerts || []) {
        await deleteAlert(alert.id)
      }
      this.isDeleteDone = true
    } catch (e) {
      const error = e as HttpError
      if (error?.response?.data.detail) {
        this.deleteError = error.response.data.detail
      } else {
        this.deleteError = 'Sorry! The server seems to be down. Please try later.'
      }
    }
  }

  get alertName() {
    if (!this.alerts) {
      return ''
    }
    return this.alerts[0].alertName
  }

  get customerOrderId() {
    if (!this.alerts) {
      return ''
    }
    return this.alerts[0].customerOrderId
  }
}

export default RetryDialog
</script>

<style scoped lang="scss"></style>
