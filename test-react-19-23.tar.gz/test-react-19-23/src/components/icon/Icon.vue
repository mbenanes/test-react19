<template>
  <svg
    :width="size"
    :height="size"
    :viewBox="`0 0 ${size} ${size}`"
    xmlns="http://www.w3.org/2000/svg"
    @mouseover="hover = true"
    @mouseleave="hover = false"
    :style="svgStyle"
  >
    <circle :cx="center" :cy="center" :r="radius" :fill="color" />
    <text
      :x="center"
      :y="center"
      alignment-baseline="middle"
      text-anchor="middle"
      :font-size="fontSize"
      font-family="Arial"
      fill="white"
    >
      {{ formattedTitle }}
    </text>
  </svg>
</template>

<script>
export default {
  props: {
    title: {
      type: String,
      required: true,
    },
    size: {
      type: Number,
      default: 100,
    },
  },
  data() {
    return {
      hover: false,
    }
  },
  computed: {
    formattedTitle() {
      return this.extractInitials(this.title)
    },
    center() {
      return this.size / 2
    },
    radius() {
      return this.size / 2 - 5
    },
    fontSize() {
      return this.size / 3
    },
    color() {
      return this.generateColorFromText(this.title)
    },
    svgStyle() {
      return {
        transition: 'transform 0.3s ease, opacity 0.3s ease',
        transform: this.hover ? 'scale(1.1)' : 'scale(1)',
        opacity: this.hover ? '0.9' : '1',
      }
    },
  },
  methods: {
    extractInitials(name) {
      const words = name.split('-')
      if (words.length < 2) {
        return name.slice(0, 2).toUpperCase()
      }
      return words.map((word) => word.slice(0, 1).toUpperCase()).join('')
    },
    generateColorFromText(text) {
      let hash = 0
      for (let i = 0; i < text.length; i++) {
        hash = text.charCodeAt(i) + ((hash << 5) - hash)
      }

      const r = (hash >> 23) & 0xff
      const g = (hash >> 17) & 0xff
      const b = (hash >> 8) & 0xff

      const darkenedR = Math.max(0, r + 20)
      const darkenedG = Math.max(0, g + 20)
      const darkenedB = Math.max(0, b + 20)

      return `rgb(${darkenedR}, ${darkenedG}, ${darkenedB})`
    },
  },
}
</script>

<style scoped>
svg {
  cursor: pointer;
}
</style>
