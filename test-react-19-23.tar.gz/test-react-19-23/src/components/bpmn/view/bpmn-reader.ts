import type { OrchestratorEvent } from '@/models'
import type { BPMNExecutionContext } from './graph-execution'

export class BpmnObject {
  public constructor(private process: Process[]) {}

  getProcessStartingBy(event: OrchestratorEvent, context: BPMNExecutionContext): Process[] {
    return this.process.filter((it) => it.startWith(event, context))
  }
}

export abstract class Step {
  public incominSteps: Step[] = []
  public outgoingSteps: Step[] = []

  public constructor(public id: string) {}

  addIncommingStep(incommingStep: Step): void {
    this.incominSteps.push(incommingStep)
  }

  addOutgoingStep(nextStep: Step): void {
    this.outgoingSteps.push(nextStep)
    nextStep.addIncommingStep(this)
  }

  abstract match(event: OrchestratorEvent, context: BPMNExecutionContext): boolean
  abstract isStartedBy(event: OrchestratorEvent, context: BPMNExecutionContext): boolean
}

export class Task extends Step {
  public constructor(
    public id: string,
    public logUrl: string,
    public keepTraceId: string,
  ) {
    super(id)
  }

  match(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    return false
  }

  isStartedBy(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    for (const step of this.incominSteps) {
      if (step.match(event, context)) {
        return true
      }
    }
    return false
  }
}

export class TimerEvent extends Step {
  public constructor(
    public id: string,
    private nextTasks: Task[],
  ) {
    super(id)
  }

  public nextTaskIs(task: Task): void {
    this.nextTasks.push(task)
  }

  match(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    for (const next of this.outgoingSteps) {
      if (next.match(event, context)) {
        return true
      }
    }
    return false
  }

  isStartedBy(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    for (const step of this.incominSteps) {
      if (step.match(event, context)) {
        return true
      }
    }
    return false
  }
}

export class Event extends Step {
  public constructor(
    public id: string,
    private type: string,
    private functionalType: string,
    public isWarning: boolean,
    public match1P: boolean,
    public match3P: boolean,
  ) {
    super(id)
  }

  match(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    return (
      this.type === event.metadata.eventType &&
      (this.functionalType === undefined ||
        this.functionalType === event.metadata.functionalType) &&
      this.eventLinesRespect1PAnd3PConditions(event, context)
    )
  }

  eventLinesRespect1PAnd3PConditions(
    event: OrchestratorEvent,
    context: BPMNExecutionContext,
  ): boolean {
    // condition optimisation lines can not be something else than 1P or 3P, no need to iterate over the lines
    if ((this.match1P && this.match3P) || Object.keys(context.linesMetaData).length === 0) {
      return true
    }

    const linesMetadata = event.metadata.customerOrderLineIds
      .map((lineId) => context.linesMetaData[lineId])
      .filter((it) => it !== undefined)

    if (this.match1P) {
      return linesMetadata.some((line) => line.soldByAThirdParty === false)
    }
    if (this.match3P) {
      return linesMetadata.some((line) => line.soldByAThirdParty === true)
    }
    return false
  }

  isStartedBy(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    for (const step of this.incominSteps) {
      if (step.match(event, context)) {
        return true
      }
    }
    return false
  }
}

export class ExclusiveGateway extends Step {
  public constructor(public id: string) {
    super(id)
  }

  match(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    return false
  }

  isStartedBy(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    return false
  }
}

export class ParallelGateway extends Step {
  public constructor(public id: string) {
    super(id)
  }

  match(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    return false
  }

  isStartedBy(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    return false
  }
}

export class InclusiveGateway extends Step {
  public constructor(public id: string) {
    super(id)
  }

  match(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    return false
  }

  isStartedBy(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    return false
  }
}

export class Process {
  public constructor(public startSteps: Step[]) {}

  startWith(event: OrchestratorEvent, context: BPMNExecutionContext): boolean {
    for (const step of this.startSteps) {
      if (step.match(event, context)) {
        return true
      }
    }
    return false
  }
}

function buildStep(bpmnStep: any): Step {
  if (bpmnStep.$type.endsWith('Event')) {
    if (
      bpmnStep.eventDefinitions &&
      bpmnStep.eventDefinitions.length > 0 &&
      bpmnStep.eventDefinitions[0].$type === 'bpmn:TimerEventDefinition'
    ) {
      return new TimerEvent(bpmnStep.id, [])
    } else if (bpmnStep.eventType != null) {
      return new Event(
        bpmnStep.id,
        bpmnStep.eventType,
        bpmnStep.eventFunctionalType,
        bpmnStep.isWarning,
        bpmnStep.match1P,
        bpmnStep.match3P,
      )
    } else {
      console.warn('the event ' + bpmnStep.id + ' has no tempo event matching definition')
      return new Event(bpmnStep.id, 'unknown', 'unknown', false, false, false)
    }
  }
  if (bpmnStep.$type.endsWith('Task')) {
    return new Task(bpmnStep.id, bpmnStep.logUrl, bpmnStep.keepTraceId)
  }
  if (bpmnStep.$type === 'bpmn:ExclusiveGateway') {
    return new ExclusiveGateway(bpmnStep.id)
  }
  if (bpmnStep.$type === 'bpmn:ParallelGateway') {
    return new ParallelGateway(bpmnStep.id)
  }
  if (bpmnStep.$type === 'bpmn:ParallelGateway') {
    return new ParallelGateway(bpmnStep.id)
  }
  if (bpmnStep.$type === 'bpmn:InclusiveGateway') {
    return new InclusiveGateway(bpmnStep.id)
  }

  throw new Error('the element ' + bpmnStep.$type + ' is not managed')
}

function buildProcess(bpmnXmlProcess: any) {
  const flow: any[] = bpmnXmlProcess.flowElements
  const allSteps = flow
    .filter((element: any) => !element.$type.endsWith('SequenceFlow'))
    .map((element: any) => buildStep(element))

  const allStepsById = allSteps.reduce((r: any, a) => {
    r[a.id] = a
    return r
  }, {})

  flow
    .filter((element: any) => element.$type.endsWith('SequenceFlow'))
    .filter(
      (element: any) =>
        element.sourceRef.id in allStepsById && element.targetRef.id in allStepsById,
    )
    .forEach((element: any) =>
      allStepsById[element.sourceRef.id].addOutgoingStep(allStepsById[element.targetRef.id]),
    )

  const startEvents = allSteps
    .filter((e) => e instanceof Event || e instanceof TimerEvent)
    .filter((e) => e.incominSteps.length === 0)

  return new Process(startEvents)
}

export function buildBpmnObject(elements: any[]): BpmnObject {
  const process = elements
    .filter((element) => element.$type === 'bpmn:Process')
    .map((process: any) => buildProcess(process))

  return new BpmnObject(process)
}
