import type { CustomerOrderLineMetadata, OrchestratorEvent } from '@/models'
import {
  BpmnObject,
  Event,
  ExclusiveGateway,
  InclusiveGateway,
  ParallelGateway,
  Process,
  Step,
  Task,
} from './bpmn-reader'

type LogData = { url: string; traceId: string; date?: Date }

export interface Environment {
  name: string
}

export interface GraphOptions {
  onEventClick: (events: any[]) => void
  environment: Environment
}

enum MatchingMode {
  TRACE_ID,
  CUSTOMER_ORDER_LINE,
}

export class BpmnFlow {
  private onClickOnElement?: (bpmnElement: any) => void

  constructor(private processFlowList: ProcessFlow[]) {}

  // viewer is a bpmnviewer
  public colorizeBpmn(viewer: any, options: GraphOptions) {
    const canvas = viewer.get('canvas')
    const overlays = viewer.get('overlays')

    const executedFlows = this.processFlowList.flatMap((p) => p.getExecutedSteps())
    const numberOfExecutedSteps: { [stepId: string]: { flow: Flow<Step>; number: number } } =
      executedFlows.reduce((a: any, flow) => {
        const step = flow.step
        a[step.id] =
          step.id in a
            ? { flow: a[step.id], number: a[step.id].number + 1 }
            : { flow: flow, number: 1 }
        return a
      }, {})

    for (const stepId in numberOfExecutedSteps) {
      canvas.addMarker(stepId, 'received')
      if (numberOfExecutedSteps[stepId].flow.isWarning) {
        canvas.addMarker(stepId, 'warning')
      }
      overlays.add(stepId, 'numberOfEvent', {
        position: {
          top: -20,
          left: -20,
        },
        html:
          '<div class="number-of-received-event"> *' +
          numberOfExecutedSteps[stepId].number +
          ' </div>',
      })
    }

    const nextStepsToExecute = this.processFlowList
      .flatMap((it) => it.getNextFlowToExecute())
      .map((flow) => flow.step)
      .map((step) => step.id)
    for (const stepId of nextStepsToExecute) {
      canvas.addMarker(stepId, 'should-have-been-received')
    }

    const eventBus = viewer.get('eventBus')
    this.onClickOnElement = (e: any) => {
      const element = e.element
      if (element.type.endsWith('Event')) {
        const events = this.getAllFlowForStepId<EventFlow>(element.id)
          .flatMap((eventFlow) => eventFlow.event)
          .filter((e) => e !== undefined)

        if (events.length > 0) {
          options.onEventClick(events)
        }
      } else if (element.type.endsWith('Task')) {
        const flow = this.getAllFlowForStepId<TaskFlow>(element.id)
        const logsData = flow
          .map((stepFlow) => stepFlow.getLogData(options.environment))
          .filter((it): it is LogData => it !== undefined)

        const logsHTMl = logsData
          .map(
            (log) =>
              `
          <div>` +
              (log.traceId ? `<span class="traceId"> traceId: ${log.traceId} </span>` : '') +
              (log.date ? `<span class="date"> date: ${log.date.toLocaleString()} </span>` : '') +
              `<a href="${log.url}" target="_blank"> log </a>
          </div>
        `,
          )
          .join('')

        const overlayId = 'logs' + element.id
        const existingEventsDiv = overlays.get({ type: overlayId })
        if (existingEventsDiv.length === 0) {
          overlays.add(e.element, overlayId, {
            position: {
              bottom: 0,
              left: 0,
            },
            html: '<div class="logs">' + logsHTMl + '</div>',
          })
        } else {
          overlays.remove({ type: overlayId })
        }
      }
    }
    eventBus.on('element.click', this.onClickOnElement)
  }

  public unbind(viewer: any): void {
    const eventBus = viewer.get('eventBus')
    eventBus.off('element.click', this.onClickOnElement)
  }

  getAllFlowForStepId<T extends Flow<Step>>(id: any): T[] {
    return this.processFlowList
      .map((process) => process.getFlowForId(id))
      .filter((it): it is Flow<Step> => it !== undefined) as T[]
  }
}

export class ProcessFlow {
  constructor(private firstFlow: Flow<Step>) {}

  getExecutedSteps(): Flow<Step>[] {
    return this.firstFlow.getExecutedSteps()
  }

  getFlowForId(id: string): Flow<Step> | undefined {
    return this.firstFlow.getFlowForId(id)
  }

  getNextFlowToExecute(): Flow<Step>[] {
    return this.firstFlow.getNextFlowToExecute()
  }
}

export abstract class Flow<T extends Step> {
  protected nextFlows: Flow<Step>[] = []

  constructor(public step: T) {}

  abstract hasBeenExecuted(): boolean

  abstract traceId(): string

  abstract customerOrderLines(): string[]

  abstract matchingMode(): MatchingMode

  abstract executionDate(): Date | undefined

  abstract execute(context: BPMNExecutionContext, from?: Flow<Step>): void

  abstract get isWarning(): boolean

  getNextFlowToExecute(): Flow<Step>[] {
    if (!this.hasBeenExecuted()) {
      return [this]
    }
    return this.nextFlows.flatMap((it) => it.getNextFlowToExecute())
  }

  getExecutedSteps(): Flow<Step>[] {
    if (this.hasBeenExecuted()) {
      return [this, ...this.nextFlows.flatMap((it) => it.getExecutedSteps())]
    }
    return []
  }

  getFlowForId(id: string): Flow<Step> | undefined {
    if (this.step.id === id) {
      return this
    }
    for (const next of this.nextFlows) {
      const flowForId = next.getFlowForId(id)
      if (flowForId) {
        return flowForId
      }
    }
  }

  protected executeNextFlows(context: BPMNExecutionContext): void {
    for (const nextStep of this.step.outgoingSteps) {
      const nextFlow = buildFlow(nextStep)
      nextFlow.execute(context, this)
      this.nextFlows.push(nextFlow)
    }
  }
}

export class TaskFlow extends Flow<Task> {
  private fromFlow?: Flow<Step>

  constructor(step: Task) {
    super(step)
  }

  hasBeenExecuted(): boolean {
    return this.step.outgoingSteps.length > 0 && this.nextFlows.length > 0
  }

  execute(context: BPMNExecutionContext, from?: Flow<Step>): void {
    this.fromFlow = from
    this.executeNextFlows(context)
  }

  traceId(): string {
    return this.fromFlow?.traceId() || ''
  }

  customerOrderLines(): string[] {
    return this.fromFlow?.customerOrderLines() || []
  }

  executionDate(): Date | undefined {
    return this.fromFlow?.executionDate()
  }

  matchingMode(): MatchingMode {
    return this.step.keepTraceId === 'true'
      ? MatchingMode.TRACE_ID
      : MatchingMode.CUSTOMER_ORDER_LINE
  }

  getLogData(env: Environment): LogData | undefined {
    if (!(this.fromFlow instanceof EventFlow)) {
      return undefined
    }
    const event = this.fromFlow?.event
    const replaced = this.step.logUrl.replace(/\{([^}]+)\}/g, (original, matched) => {
      return eval(matched)
    })

    return {
      url: replaced,
      traceId: this.traceId(),
      date: this.executionDate(),
    }
  }

  get isWarning(): boolean {
    return this.fromFlow?.isWarning || false
  }
}

export class EventFlow extends Flow<Event> {
  public event?: OrchestratorEvent
  private fromFlow?: Flow<Step>

  constructor(step: Event) {
    super(step)
  }

  hasBeenExecuted(): boolean {
    return this.event !== undefined
  }

  execute(context: BPMNExecutionContext, from?: Flow<Step>): void {
    this.fromFlow = from
    if (this.event === undefined) {
      for (const event of getEventSentAfter(context, from?.executionDate())) {
        if (this.step.match(event, context)) {
          let eventMatch: boolean
          if (from === undefined) {
            eventMatch = true
          } else if (from.matchingMode() === MatchingMode.TRACE_ID) {
            eventMatch = event.metadata.traceId === from?.traceId() || from?.traceId() === ''
          } else {
            eventMatch = event.metadata.customerOrderLineIds.some((id) =>
              from?.customerOrderLines().includes(id),
            )
          }

          if (eventMatch) {
            this.event = event
            this.executeNextFlows(context)
            break
          }
        }
      }
    }
  }

  traceId(): string {
    return this.event?.metadata.traceId || ''
  }

  customerOrderLines(): string[] {
    if (this.fromFlow) {
      const customerOrderLines = this.fromFlow.customerOrderLines()
      if (customerOrderLines.length > 0) {
        return customerOrderLines
      }
    }
    return this.event?.metadata.customerOrderLineIds || []
  }

  matchingMode(): MatchingMode {
    return this.fromFlow?.matchingMode() || MatchingMode.TRACE_ID
  }

  executionDate(): Date | undefined {
    if (this.event?.metadata.timestamp) {
      return new Date(this.event?.metadata.timestamp)
    }
    return undefined
  }

  get isWarning(): boolean {
    return this.step.isWarning
  }
}

export class ExclusiveGatewayFlow extends Flow<ExclusiveGateway> {
  private fromFlow?: Flow<Step>

  constructor(step: ExclusiveGateway) {
    super(step)
  }

  hasBeenExecuted(): boolean {
    return this.nextFlows.length > 0
  }

  execute(context: BPMNExecutionContext, from?: Flow<Step>): void {
    this.fromFlow = from

    const allExecutedNextFlow = []
    for (const nextStep of this.step.outgoingSteps) {
      const nextFlow = buildFlow(nextStep)
      nextFlow.execute(context, this)
      if (nextFlow.hasBeenExecuted()) {
        allExecutedNextFlow.push(nextFlow)
      }
    }

    if (allExecutedNextFlow.length > 0) {
      const nextFlow = allExecutedNextFlow.sort(
        (a, b) => (a.executionDate()?.getTime() || 0) - (b.executionDate()?.getTime() || 0),
      )[0]
      this.nextFlows.push(nextFlow)
    }
  }

  matchingMode(): MatchingMode {
    return this.fromFlow?.matchingMode() || MatchingMode.TRACE_ID
  }

  traceId(): string {
    return this.fromFlow?.traceId() || ''
  }

  customerOrderLines(): string[] {
    return this.fromFlow?.customerOrderLines() || []
  }

  executionDate(): Date | undefined {
    return this.fromFlow?.executionDate()
  }

  get isWarning(): boolean {
    return this.fromFlow?.isWarning || false
  }
}

/**
 * This is a fake flow (not linked with a step on the bpmn graph)
 * This is used to start a flow using a specific event
 */
export class StartFlow extends Flow<any> {
  constructor(private event: OrchestratorEvent) {
    super(undefined)
  }

  hasBeenExecuted(): boolean {
    return true
  }

  execute(context: BPMNExecutionContext, from?: Flow<Step>): void {
    super.executeNextFlows(context)
  }

  matchingMode(): MatchingMode {
    return MatchingMode.TRACE_ID
  }

  traceId(): string {
    return this.event.metadata.traceId
  }

  customerOrderLines(): string[] {
    return this.event.metadata.customerOrderLineIds
  }

  executionDate(): Date | undefined {
    return new Date(this.event.metadata.timestamp)
  }

  get isWarning(): boolean {
    return false
  }
}

export class InclusiveGatewayFlow extends Flow<InclusiveGateway> {
  private fromFlow?: Flow<Step>

  constructor(step: InclusiveGateway) {
    super(step)
  }

  hasBeenExecuted(): boolean {
    return this.nextFlows.length > 0
  }

  execute(context: BPMNExecutionContext, from?: Flow<Step>): void {
    this.fromFlow = from
    super.executeNextFlows(context)
  }

  getNextFlowToExecute(): Flow<Step>[] {
    if (!this.hasBeenExecuted()) {
      return [this]
    }

    const executedNextFlow = this.nextFlows.filter((it) => it.hasBeenExecuted())
    if (executedNextFlow.length === 0) {
      return super.getNextFlowToExecute()
    } else {
      return executedNextFlow[0].getNextFlowToExecute()
    }
  }

  traceId(): string {
    return this.fromFlow?.traceId() || ''
  }

  customerOrderLines(): string[] {
    return this.fromFlow?.customerOrderLines() || []
  }

  executionDate(): Date | undefined {
    return this.fromFlow?.executionDate()
  }

  matchingMode(): MatchingMode {
    return this.fromFlow?.matchingMode() || MatchingMode.TRACE_ID
  }

  get isWarning(): boolean {
    return this.fromFlow?.isWarning || false
  }
}

export class ParallelGatewayFlow extends Flow<ParallelGateway> {
  private fromFlow?: Flow<Step>

  constructor(step: ParallelGateway) {
    super(step)
  }

  hasBeenExecuted(): boolean {
    return this.nextFlows.length > 0
  }

  execute(context: BPMNExecutionContext, from?: Flow<Step>): void {
    this.fromFlow = from
    super.executeNextFlows(context)
  }

  getNextFlowToExecute(): Flow<Step>[] {
    if (!this.hasBeenExecuted()) {
      return [this]
    }
    return this.nextFlows.flatMap((it) => it.getNextFlowToExecute())
  }

  traceId(): string {
    return this.fromFlow?.traceId() || ''
  }

  customerOrderLines(): string[] {
    return this.fromFlow?.customerOrderLines() || []
  }

  executionDate(): Date | undefined {
    return this.fromFlow?.executionDate()
  }

  matchingMode(): MatchingMode {
    return this.fromFlow?.matchingMode() || MatchingMode.TRACE_ID
  }

  get isWarning(): boolean {
    return this.fromFlow?.isWarning || false
  }
}

function getEventSentAfter(
  context: BPMNExecutionContext,
  date: Date | undefined,
): OrchestratorEvent[] {
  if (date === undefined) {
    return context.events
  }
  return context.events.filter((event) => new Date(event.metadata.timestamp) >= date)
}

function buildFlow(step: Step): Flow<Step> {
  if (step instanceof Task) {
    // tslint:disable @typescript-eslint/no-use-before-define
    return new TaskFlow(step)
  } else if (step instanceof Event) {
    return new EventFlow(step)
  } else if (step instanceof ExclusiveGateway) {
    return new ExclusiveGatewayFlow(step)
  } else if (step instanceof ParallelGateway) {
    return new ParallelGatewayFlow(step)
  } else if (step instanceof InclusiveGateway) {
    return new InclusiveGatewayFlow(step)
  } else {
    throw new Error('The ' + step + ' is not managed')
  }
}

function buildProcessFlow(
  process: Process,
  startEvent: OrchestratorEvent,
  context: BPMNExecutionContext,
): ProcessFlow {
  const firstFlowStep: Flow<Step> | undefined = process.startSteps
    .filter((it) => it.match(startEvent, context))
    .map(buildFlow)[0]

  if (firstFlowStep) {
    firstFlowStep.execute(context, new StartFlow(startEvent))
    return new ProcessFlow(firstFlowStep)
  }

  throw new Error('Can not find any step matching event ' + startEvent.metadata.eventType)
}

export interface BPMNExecutionContext {
  events: OrchestratorEvent[]
  linesMetaData: { [lineId: string]: CustomerOrderLineMetadata }
}

export function buildBpmnFlow(bpm: BpmnObject, context: BPMNExecutionContext): BpmnFlow {
  const sortedEvents = context.events.sort((a, b) =>
    a.metadata.timestamp < b.metadata.timestamp ? -1 : 1,
  )
  const allFlow: ProcessFlow[] = []

  for (const event of sortedEvents) {
    const processStartingByEvent = bpm.getProcessStartingBy(event, context)
    const allProcessFlow = processStartingByEvent.map((it) => buildProcessFlow(it, event, context))
    for (const processFlow of allProcessFlow) {
      allFlow.push(processFlow)
    }
  }

  return new BpmnFlow(allFlow)
}
