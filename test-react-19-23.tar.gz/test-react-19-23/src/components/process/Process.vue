<template>
  <div class="sequence-diagram-layout">
    <div class="header">
      <div
        v-for="(actor, index) in processDrawer.actors"
        :key="actor"
        class="entity"
        :alt="index"
        :style="processDrawer.columnStyle(index)"
      >
        {{ actor }}
      </div>
    </div>
    <div class="body">
      <action
        v-for="(action, actionIndex) in processWithLifeLines"
        :key="'action' + actionIndex"
        :action="action.action"
        :processDrawer="processDrawer"
        :lifeLines="action.lifeLines"
      />

      <div
        v-for="(actor, actorIndex) in processDrawer.actors"
        :key="'line' + actor"
        class="line"
        :style="processDrawer.lineStyle(actorIndex)"
      ></div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-facing-decorator'
import {
  ProcessFlow,
  ProcessDrawer,
  Event,
  LifeLine,
  Process as ProcessTemplate,
  Sequence,
  EventPattern,
} from './ProcessDrawer'
import Action from './Action.vue'

// inspied by https://github.com/geraintluff/sequence-diagram-html
@Component({
  components: {
    Action,
  },
})
class Process extends Vue {
  @Prop()
  public events?: Event[]

  @Prop()
  public process?: ProcessTemplate

  public processDrawer: ProcessDrawer = new ProcessDrawer([], { actors: {}, sequences: [] })

  created() {
    if (this.events && this.process) {
      this.processDrawer = new ProcessDrawer(this.events, this.process)
    }
  }

  get processWithLifeLines(): { action: ProcessFlow; lifeLines: LifeLine[] }[] {
    const result: { action: ProcessFlow; lifeLines: LifeLine[] }[] = []
    for (const group of this.process?.sequences || []) {
      if (group.group) {
        result.push({
          action: { step: group.group },
          lifeLines: this.processDrawer.lifeLines(),
        })
      }
      let sequenceToDo = group.lifeLines
      while (sequenceToDo.length > 0) {
        const addedSequences = this.addSequence(sequenceToDo[0], sequenceToDo, result)
        sequenceToDo = sequenceToDo.filter((lifeLine) => addedSequences.indexOf(lifeLine) === -1)
      }
    }
    return result
  }

  private addSequence(
    sequence: Sequence,
    allSequences: Sequence[],
    actions: { action: ProcessFlow; lifeLines: LifeLine[] }[],
    showInput = true,
  ): Sequence[] {
    const addedSequences = [sequence]
    const actor = sequence.actor
    if (showInput && sequence.input) {
      const inputEvent = { from: sequence.input.from, to: actor, event: sequence.input.event }
      this.processDrawer.activate(actor, inputEvent)
      actions.push({
        action: inputEvent,
        lifeLines: this.processDrawer.lifeLines(),
      })
    }
    const nextLifelines = []
    for (const process of sequence.sequence) {
      const startingSequences = this.getSequenceStartingWithEvent(process.event, allSequences)
      const inputEvent = { from: actor, to: process.to, event: process.event }
      startingSequences.forEach((sequence) =>
        this.processDrawer.activate(sequence.actor, inputEvent),
      )
      nextLifelines.push(...startingSequences)
      actions.push({
        action: inputEvent,
        lifeLines: this.processDrawer.lifeLines(),
      })
    }
    this.processDrawer.desactivate(actor)
    for (const nextSequence of nextLifelines) {
      addedSequences.push(...this.addSequence(nextSequence, allSequences, actions, false))
    }
    return addedSequences
  }

  private getSequenceStartingWithEvent(
    eventMatcher?: EventPattern,
    sequences?: Sequence[],
  ): Sequence[] {
    if (eventMatcher && sequences) {
      return sequences.filter(
        (sequence) =>
          sequence.input?.event?.type === eventMatcher.type &&
          sequence.input?.event?.functionalType === eventMatcher.functionalType,
      )
    } else {
      return []
    }
  }
}

export default Process
</script>

<style scoped lang="scss">
.actors {
  display: flex;

  .actor {
    flex: 1 1 auto;
    padding: 10px;
    border: 1px solid black;
  }
}

.header {
  border-bottom: 2px solid #888;
  position: relative;
  height: 2em;
}

.body {
  position: relative;
  padding-top: 0.5em;
  padding-bottom: 0.5em;
}

.line {
  position: absolute;
  top: 0;
  bottom: 0;
  border-left: 2px solid #ddd;
}

.entity {
  display: block;
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  text-align: center;
  font-weight: bold;
}
</style>
