import moment from 'moment'

const UUID_REGEX = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/

export const isValidUUid = (value: string): boolean => UUID_REGEX.test(value)

const COMMAND_NUMBER_REGEX = /^\d{5}[A-Z]\d{1,15}$/
export const isValidCommandNumber = (value: string): boolean => COMMAND_NUMBER_REGEX.test(value)

const ARRAY_SEPARATOR = ','

export function jsonToQueryParamObject(json: any, prefix?: string) {
  if (Array.isArray(json)) {
    return json.join(ARRAY_SEPARATOR)
  } else if (typeof json === 'object') {
    const buildKey = (value: string) => (prefix ? prefix + '.' + value : value)
    const value: any = {}
    for (const key in json) {
      const paramValue = jsonToQueryParamObject(json[key], prefix)
      value[buildKey(key)] = paramValue
    }
    return value
  }
}

export function queryParamToJson(queryParams: { [key: string]: any }, prefix?: string) {
  const removePrefix = (key: string) =>
    prefix && key.startsWith(prefix) ? key.substring(prefix.length + 1) : key
  const value: { [key: string]: any } = {}

  for (const key in queryParams) {
    if (typeof queryParams[key] === 'string') {
      if (queryParams[key].length === 0) {
        value[removePrefix(key)] = []
      } else {
        value[removePrefix(key)] = queryParams[key].split(',')
      }
    } else {
      value[removePrefix(key)] = queryParamToJson(queryParams[key])
    }
  }

  return value
}

export function formatDate(timestamp: string): string {
  return moment(timestamp).format('DD/MM/YYYY HH:mm:ss')
}

export function formatDateTime(timestamp: string): string {
  return moment(timestamp).format('DD/MM/YYYY HH:mm:ss SS')
}

export function durationFromNow(date: string): string {
  return moment(date).fromNow()
}

export function toPascalCase(input: string): string {
  return input
    .split('-')
    .map((word) => word.replace(/(?:^|\s|-)(\w)/g, (match, p1) => p1.toUpperCase()))
    .join('-')
}
