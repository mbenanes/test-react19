<template>
  <div class="message">Flow chart is coming soon!</div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-facing-decorator'

@Component({})
class FlowChartView extends Vue {}

export default FlowChartView
</script>
