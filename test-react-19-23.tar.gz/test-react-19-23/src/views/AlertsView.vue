<template>
  <div class="alerts-view">
    <div class="search-form">
      <div class="filter">
        <label for="customerOrderId"> Customer orderId : </label>
        <div>
          <input
            type="text"
            id="customerOrderId"
            :value="customerOrderId"
            @change="updateCustomerOrderId"
          />
          <span v-if="customerOrderIdInvalid" class="validation-error">
            The customerOrderId must be an UUID
          </span>
        </div>
      </div>

      <div class="filter" v-for="alertFilter in alertFilters" :key="alertFilter.name">
        <label :for="alertFilter.name">{{ alertFilter.name }} : </label>
        <multi-select
          :options="buildOptions(alertFilter.name, alertFilter.values)"
          :value="selectedFilters[alertFilter.name]"
          @input="updateFilters(alertFilter.name, $event)"
          :input-id="alertFilter.name"
        />
      </div>

      <div class="filter">
        <label for="withOrWithoutSupportTicket"> With Or Without support ticket : </label>
        <select
          id="withOrWithoutSupportTicket"
          v-model="withOrWithoutSupportTicket"
          @change="updateAlertRoute"
        >
          <option>ALL</option>
          <option>WITH</option>
          <option>WITHOUT</option>
        </select>
      </div>

      <div class="filter">
        <label for="solved"> only solved alerts : </label>
        <input type="checkbox" id="solved" :checked="onlySolvedAlerts" @change="updateSolved" />
      </div>
    </div>

    <div class="table">
      <table class="alerts">
        <thead>
          <tr>
            <th>Business unit</th>
            <th>Customer order Id</th>
            <th>Line Id</th>
            <th>Delivery Type</th>
            <th>Alert name</th>
            <th
              @click="updateSortingDirection(sortingDirection === 'DESC' ? 'ASC' : 'DESC')"
              class="cursor"
            >
              alert since
              <menu-up v-if="sortingDirection === 'ASC'" :size="16" />
              <menu-down v-if="sortingDirection === 'DESC'" :size="16" />
            </th>
            <th title="Ticket Creation Date">Ticket CD</th>
            <th>SNOW</th>
            <th>actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="alert in alerts" :key="alert.id">
            <td>
              <flag
                :iso="getFlagCode(alert.buCode)"
                :squared="false"
                :title="getBuCode(alert.buCode)"
              />
            </td>
            <td>
              <a :href="`/customer-order/${alert.customerOrderId}`" target="_blank">
                {{ alert.customerOrderId }}
                <open-in-new :size="15" />
              </a>
            </td>
            <td>
              <a
                :href="`/customer-order/${alert.customerOrderId}?filters.lines=${alert.lineId}`"
                target="_blank"
              >
                {{ alert.lineId }}
                <open-in-new :size="15" />
              </a>
            </td>
            <td>{{ alert.deliveryType }}</td>
            <td>{{ alert.alertName }}</td>
            <td>
              <span :title="formatDate(alert.expectedClosingEventDate)">
                {{ durationFromNow(alert.expectedClosingEventDate) }}
              </span>
            </td>
            <td>
              <span v-if="alert.expectedSupportTicketCreationDate != null">
                {{ formatDate(alert.expectedSupportTicketCreationDate) }}
              </span>
            </td>
            <td>
              <span :title="alert.ticketNumber">
                <a
                  v-if="alert.ticketNumber"
                  :href="getTicketUrl(alert.ticketNumber)"
                  target="_blank"
                >
                  {{ alert.ticketNumber }}
                </a>
              </span>
            </td>
            <td class="actions">
              <badge
                :show="alert.numberOfComment > 0"
                :content="alert.numberOfComment"
                align-badge="right"
                class="cursor"
              >
                <comment-multiple-icon
                  :title="
                    'Comment the alert ' +
                    alert.alertName +
                    ' for the order ' +
                    alert.customerOrderId
                  "
                  :size="19"
                  @click="openCommentPopin(alert)"
                  class="cursor icon-button"
                />
              </badge>
              <delete
                :title="
                  'Delete the alert ' + alert.alertName + ' for the order ' + alert.customerOrderId
                "
                v-if="isUserAdmin()"
                @click="openDeletePopin(alert)"
                class="cursor icon-button"
              />
              <manage-comments-dialog
                :alerts="[alertToComment]"
                v-if="alertToComment === alert"
                @clickOutside="alertToComment = undefined"
                @commentAdded="alert.numberOfComment++"
              />
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="footer" v-if="pagination">
      <ul class="pagination">
        <!-- Previous Page Button -->
        <li
          @click="updatePage(1)"
          :class="{ disabled: currentPage <= 1 }"
          :disabled="currentPage <= 1"
        >
          &laquo;
        </li>

        <li
          @click="updatePage(currentPage - 1)"
          :class="{ disabled: currentPage <= 1 }"
          :disabled="currentPage <= 1"
        >
          &laquo; Previous
        </li>

        <li
          v-for="pageIdx in gePaginationPages()"
          :key="pageIdx"
          @click="updatePage(pageIdx)"
          :class="{ selected: currentPage === pageIdx }"
        >
          {{ pageIdx }}
        </li>

        <!-- Next Page Button -->
        <li
          @click="updatePage(currentPage + 1)"
          :class="{ disabled: currentPage >= pagination.totalPageCount }"
          :disabled="currentPage >= pagination.totalPageCount"
        >
          Next &raquo;
        </li>

        <li
          @click="updatePage(pagination.totalPageCount)"
          :class="{ disabled: currentPage >= pagination.totalPageCount }"
          :disabled="currentPage >= pagination.totalPageCount"
        >
          &raquo;
        </li>
      </ul>
      <span> Total: {{ pagination.totalCount }} results </span>
    </div>

    <delete-alert-dialog
      :alerts="[alertToDelete]"
      @close="onDeleteDialogClosed($event)"
      v-if="alertToDelete"
    />
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-facing-decorator'
import {
  Alert,
  AlertFilters,
  FilterOption,
  getAlertFilters,
  getAlerts,
} from '@/services/alerts.service'
import MultiSelect, { SelectOption } from '@/components/multi-select/MultiSelect.vue'
import DeleteAlertDialog from '@/components/retry-dialog/DeleteAlertDialog.vue'
import ManageCommentsDialog from '@/components/retry-dialog/ManageCommentsDialog.vue'
import OpenInNew from 'vue-material-design-icons/OpenInNew.vue'
import MenuDown from 'vue-material-design-icons/MenuDown.vue'
import MenuUp from 'vue-material-design-icons/MenuUp.vue'
import Delete from 'vue-material-design-icons/Delete.vue'
import CommentMultipleIcon from 'vue-material-design-icons/CommentMultiple.vue'
import Badge from '@/components/badged/Badge.vue'
import { getBuCode, getFlagCode } from '@/filters/bu-code'
import { formatDate, durationFromNow } from '@/utils/utils'
import { useAppStore } from '@/store'
import { BuCodeType } from '@/models'
import { Page, Pagination } from '@/services/http.service'

@Component({
  methods: {
    formatDate,
    getBuCode,
    getFlagCode,
    durationFromNow,
  },
  components: {
    OpenInNew,
    MenuDown,
    MenuUp,
    MultiSelect,
    DeleteAlertDialog,
    Delete,
    ManageCommentsDialog,
    CommentMultipleIcon,
    Badge,
  },
})
class AlertsView extends Vue {
  alerts: Alert[] = []
  alertFilters: AlertFilters[] = []
  selectedFilters: Record<string, any> = {}
  pagination?: Pagination
  currentPage = 1
  sortingDirection = 'DESC'
  customerOrderId = ''
  onlySolvedAlerts = false
  withOrWithoutSupportTicket = 'ALL'
  customerOrderIdInvalid = false
  alertToDelete: any = undefined
  alertToComment: any = undefined
  store = useAppStore()

  created() {
    this.loadAlertFilters()
    this.loadSelectedFiltersFromParams()
    this.loadAlerts()
  }

  @Watch('$route')
  private onRouteChange(to: any, from: any) {
    this.loadSelectedFiltersFromParams()
    this.loadAlerts()
  }

  // Methods
  updateFilters(filterName: string, values: any) {
    this.selectedFilters[filterName] = values
    this.updateAlertRoute()
  }

  loadSelectedFiltersFromParams() {
    this.customerOrderId = (this.$route.query.customerOrderId as string) ?? ''
    this.onlySolvedAlerts = this.$route.query.onlySolvedAlerts === 'true'
    this.withOrWithoutSupportTicket = (this.$route.query.customerOrderId as string) ?? 'ALL'
    this.sortingDirection = (this.$route.query.sortingDirection as string) ?? 'DESC'

    const page = this.$route.query.page
    this.currentPage = page ? parseInt(page as string) : 1
  }

  async loadAlerts() {
    const alertsPage: Page<Alert> = await getAlerts(
      this.currentPage,
      this.customerOrderId,
      this.selectedFilters,
      this.sortingDirection,
    )
    this.alerts = alertsPage.data
    this.pagination = alertsPage.pagination
  }

  updateAlertRoute() {
    this.$router.push({ name: 'AlertsView', query: this.buildQueryMap() })
  }

  buildQueryMap() {
    const queryMap: any = { ...this.selectedFilters }

    if (this.customerOrderId && this.customerOrderId !== '') {
      queryMap.customerOrderId = this.customerOrderId
    }

    queryMap.sortingDirection = this.sortingDirection
    queryMap.onlySolvedAlerts = this.onlySolvedAlerts ? 'true' : 'false'
    queryMap.withOrWithoutSupportTicket = this.withOrWithoutSupportTicket
    return queryMap
  }

  buildOptions(filterName: string, optionValues: FilterOption[]): SelectOption[] {
    return optionValues?.map((option: FilterOption) => {
      return {
        label: filterName === 'buCode' ? getBuCode(option.value as BuCodeType) : option.value,
        value: option,
      }
    })
  }

  public gePaginationPages(): number[] {
    const indices = []
    const totalPages = this.pagination?.totalPageCount ?? 1

    let startPage = Math.max(this.currentPage - 7, 1)
    const endPage = Math.min(startPage + 16, totalPages)

    if (endPage - startPage + 1 < 16) {
      startPage = Math.max(endPage - 16, 1)
    }

    for (let i = startPage; i <= endPage; i++) {
      indices.push(i)
    }

    return indices
  }

  async loadAlertFilters() {
    this.alertFilters = await getAlertFilters()
  }

  isUserAdmin() {
    return this.store.isUserAdmin()
  }

  openDeletePopin(alert: any) {
    this.alertToDelete = alert
  }

  openCommentPopin(alert: any) {
    this.alertToComment = alert
  }

  onDeleteDialogClosed(deleted: boolean) {
    this.alertToDelete = undefined
    if (deleted) {
      this.loadAlerts()
    }
  }

  updatePage(page: number) {
    this.currentPage = page
    this.updateAlertRoute()
    this.loadAlerts()
  }

  updateSortingDirection(direction: string) {
    this.sortingDirection = direction
    this.updateAlertRoute()
  }

  updateCustomerOrderId(event: any) {
    this.customerOrderId = event.target.value
    this.customerOrderIdInvalid = !this.isValidUuid(this.customerOrderId)
    this.updateAlertRoute()
  }

  isValidUuid(value: string) {
    const regex = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/
    return regex.test(value)
  }

  updateSolved(event: any) {
    this.onlySolvedAlerts = event.target.checked
    this.updateAlertRoute()
  }
}

export default AlertsView
</script>

<style scoped>
/* General body settings for a cleaner and more modern look */
body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background-color: #f4f6f8;
  color: #333;
  padding: 20px;
}

/* Alerts view container */
.alerts-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  padding: 20px;
}

/* Filters section - flex container */
.search-form {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  justify-content: flex-start;
  align-items: center;
  background: whitesmoke;
  padding: 16px;
}

/* Filter individual filter styles */
.filter {
  display: flex;
  flex-direction: column;
  gap: 5px;
  min-width: 180px;
  flex-grow: 1;
}

/* Styling for the label inside each filter */
.filter label {
  font-size: 14px;
  color: #555;
}

/* Input, select styles for filters */
.filter select,
.filter input {
  padding: 8px 12px;
  border-radius: 4px;
  border: 1px solid #ccc;
  background-color: #fafafa;
  transition: border 0.3s ease-in-out;
  width: 100%; /* Ensure input fields take full available width */
}

/* Focus state on inputs and select fields */
.filter input:focus,
.filter select:focus {
  border-color: #357cc8;
  outline: none;
}

/* Checkbox specific styling */
.filter input[type='checkbox'] {
  margin-top: 6px;
}

/* Validation error message */
.validation-error {
  color: red;
  font-size: 12px;
  margin-top: 5px;
}

/* Table styling */
.table {
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  overflow-y: visible;
}

/* Table Header and Data Cells */
.alerts {
  width: 100%;
}

.alerts th,
.alerts td {
  padding: 10px 18px;
  text-align: left;
}

.alerts th {
  background-color: #357cc8;
  color: white;
  cursor: pointer;
}

.alerts tr:nth-child(even) {
  background-color: #f9f9f9;
}

.alerts tr:hover {
  background-color: #f1f1f1;
}

.cursor {
  cursor: pointer;
}

/* Links in table */
.alerts td a {
  text-decoration: none;
  color: #357cc8;
  display: inline-flex;
  align-items: center;
}

.alerts td a:hover {
  text-decoration: underline;
}

/* Action buttons inside table cells */
.alerts td .actions {
  display: flex;
  gap: 12px;
  align-items: center;
}

.alerts td .actions .icon-button {
  transition: transform 0.3s;
}

.alerts td .actions .icon-button:hover {
  transform: scale(1.2);
}

/* Pagination styles */
.pagination {
  display: flex;
  justify-content: center;
  gap: 15px;
}

.pagination li {
  padding: 10px 15px;
  background-color: #357cc8;
  color: white;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s;
  list-style: none;
}

li.disabled {
  background-color: lightgrey;
  cursor: not-allowed;
  pointer-events: none;
}

.pagination li:hover {
  background-color: #0056b3;
}

.pagination li.selected {
  background-color: #0056b3;
  font-weight: bold;
}

.footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

/* Hover effect on filter dropdowns */
.filter select:hover,
.filter input:hover {
  background-color: #f0f0f0;
}

/* Small animations for table cells */
.alerts td span {
  display: inline-block;
  transition: color 0.3s;
}

.alerts td span:hover {
  color: #357cc8;
}

/* Badge styling for comments */
.badge {
  background-color: #28a745;
  color: white;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 12px;
}

.badge.show {
  display: inline-block;
}

/* Enhanced interactions for multi-select dropdown */
.multi-select {
  position: relative;
}

.multi-select input {
  padding: 10px 15px;
  border-radius: 4px;
  border: 1px solid #ccc;
  width: 100%;
}

.multi-select-options {
  max-height: 200px;
  overflow-y: auto;
  background-color: white;
  position: absolute;
  width: 100%;
  z-index: 10;
}

.multi-select-options li {
  padding: 8px 12px;
  cursor: pointer;
}

.multi-select-options li:hover {
  background-color: #357cc8;
  color: white;
}
</style>
