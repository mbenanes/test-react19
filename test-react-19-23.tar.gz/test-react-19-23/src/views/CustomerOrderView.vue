<template>
  <div class="customerOrderView">
    <template v-if="!loading && error">
      <div class="message">
        <alert-circle-icon :size="90" />
        <span>An error has occurred</span>
        <span>{{ error }}</span>
      </div>
    </template>
    <template v-else-if="!loading && tempoOrchestatorEvents?.length == 0">
      <div class="message">
        <magnify-remove-outline-icon :size="90" />
        Unknown order. It may not have been validated yet.
        <span v-if="tempoComposerSupervisorLink">
          You can check in the supervisor of the command composition if it exists.
          <a :href="tempoComposerSupervisorLink" target="_blank"> here </a>
        </span>
      </div>
    </template>
    <template v-else-if="!loading">
      <div class="container">
        <div class="vertical-menu">
          <a @click="menu = 'timeline'" :class="{ selected: menu === 'timeline' }">
            <timeline-text-outline-icon />
            <span>Timeline</span>
          </a>
          <a @click="menu = 'FlowchartView'" :class="{ selected: menu === 'FlowchartView' }">
            <sitemap-icon />
            <span>Flow Chart</span>
          </a>
          <a @click="navigateToAlerts" :class="{ selected: menu === 'alerts' }">
            <message-icon />
            <span>Alerts</span>
          </a>
        </div>
        <div class="content">
          <event-list
            v-if="menu === 'timeline'"
            :events="filteredOrchestratorEvents"
            :alerts="alerts"
          />
          <FlowChartView v-if="menu === 'FlowchartView'" />
        </div>
      </div>
    </template>
    <template v-else>
      <div class="message">
        <magnify-icon class="search-move" :size="90" /> Search for your current customer order...
      </div>
    </template>
  </div>
</template>

<script>
import EventList from '@/components/EventList.vue'
import { getEvents, getCustomerOrderMetadata } from '@/services/CustomerOrder.service.ts'
import { getAlertsForCustomerOrder } from '@/services/alerts.service'
import SitemapIcon from 'vue-material-design-icons/Sitemap.vue'
import TimelineTextOutlineIcon from 'vue-material-design-icons/TimelineTextOutline.vue'
import MessageIcon from 'vue-material-design-icons/MessageBulleted.vue'
import MagnifyIcon from 'vue-material-design-icons/Magnify.vue'
import MagnifyRemoveOutlineIcon from 'vue-material-design-icons/MagnifyRemoveOutline.vue'
import AlertCircleIcon from 'vue-material-design-icons/AlertCircle.vue'
import { queryParamToJson } from '@/utils/utils'
import { useCommandStore } from '@/store'
import FlowChartView from './FlowChartView.vue'

export async function fillWithDefaultMetadataOn404(promise) {
  try {
    return await promise
  } catch (error) {
    return Promise.resolve({
      customerOrderId: '',
      customerOrderLines: [],
    })
  }
}

export default {
  name: 'CustomerOrderView',
  components: {
    EventList,
    FlowChartView,
    SitemapIcon,
    TimelineTextOutlineIcon,
    MessageIcon,
    MagnifyIcon,
    MagnifyRemoveOutlineIcon,
    AlertCircleIcon,
  },
  data: () => {
    return {
      tempoOrchestatorEvents: [],
      filteredOrchestratorEvents: [],
      lineIdsToDisplay: undefined,
      dependenciesToDisplay: undefined,
      customerOrderMetadata: undefined,
      loading: true,
      error: undefined,
      menu: 'timeline',
      alerts: [],
      store: useCommandStore(),
    }
  },
  created() {
    const customerOrderId = this.$route.params.id
    this.loadCustomerOrder(customerOrderId)
    this.updateFilters(queryParamToJson(this.$route.query))
  },
  methods: {
    async loadCustomerOrder(id) {
      getAlertsForCustomerOrder(id).then((alerts) => {
        this.alerts = alerts
      })

      this.store.updateCustomerOrderId(id)
      this.loading = true
      this.tempoOrchestatorEvents = []
      this.error = undefined

      try {
        const [events, customerOrderMetadata] = await Promise.all([
          getEvents(id),
          fillWithDefaultMetadataOn404(getCustomerOrderMetadata(id)),
        ])

        this.store.updateCustomerOrderMetadata(customerOrderMetadata)
        this.store.updateEvents(events)

        this.customerOrderMetadata = customerOrderMetadata
        this.tempoOrchestatorEvents = events.slice().sort((a, b) => {
          if (a.metadata.timestamp === b.metadata.timestamp) {
            return 0
          }
          return a.metadata.timestamp < b.metadata.timestamp ? -1 : 1
        })
        this.filteredOrchestratorEvents = this.tempoOrchestatorEvents
        this.updateLineIdsToDisplay(this.lineIdsToDisplay, this.dependenciesToDisplay)
        this.updateDependenciesToDisplay(this.dependenciesToDisplay)
        this.loading = false
      } catch (error) {
        console.error(error)
        if (error.response?.status !== 404) {
          this.error = error.response.data
        }
        this.loading = false
      }
    },
    updateLineIdsToDisplay(lineIds) {
      this.lineIdsToDisplay = lineIds

      if (!this.customerOrderMetadata) {
        return
      }
      if (this.lineIdsToDisplay === undefined) {
        this.lineIdsToDisplay = this.store.customerOrderMetadata?.customerOrderLines.map(
          (line) => line.id,
        )
      }
      // this if is done for optimisation + display events not associated with customer order lines
      if (
        this.lineIdsToDisplay?.length === this.customerOrderMetadata?.customerOrderLines?.length
      ) {
        this.filteredOrchestratorEvents = this.tempoOrchestatorEvents
      } else {
        this.filteredOrchestratorEvents = this.tempoOrchestatorEvents.filter((it) => {
          return (
            it.metadata.customerOrderLineIds.filter((it2) => {
              return this.lineIdsToDisplay.includes(it2)
            })?.length > 0
          )
        })
      }
      this.store.updateFilteredEvents(this.filteredOrchestratorEvents)
    },
    updateDependenciesToDisplay(dependencies) {
      this.dependenciesToDisplay = dependencies
      if (
        this.filteredOrchestratorEvents?.length === 0 ||
        this.dependenciesToDisplay === undefined
      ) {
        return this.filteredOrchestratorEvents
      }
      // this if is done for optimisation + display events not associated with customer order lines
      if (
        this.dependenciesToDisplay?.length !==
        this.getDependenciesFromEvents(this.filteredOrchestratorEvents)?.length
      ) {
        this.filteredOrchestratorEvents = this.filteredOrchestratorEvents.filter((event) => {
          return this.dependenciesToDisplay.includes(event.metadata.source)
        })
      }
    },
    getDependenciesFromEvents(events) {
      return [...new Set(events.map((event) => event.metadata.source))]
    },
    updateFilters(filters) {
      if ('filters.lines' in filters) {
        this.updateLineIdsToDisplay(filters['filters.lines'])
      } else {
        this.updateLineIdsToDisplay(undefined)
      }
      if ('filters.dependencies' in filters) {
        this.updateDependenciesToDisplay(filters['filters.dependencies'])
      } else {
        this.updateDependenciesToDisplay(undefined)
      }
    },
    navigateToAlerts() {
      this.$router.push('/alerts')
    },
  },
  watch: {
    $route() {
      this.loadCustomerOrder(this.$route.params.id)
      this.updateFilters(queryParamToJson(this.$route.query))
    },
  },
  computed: {
    tempoComposerSupervisorLink() {
      const supervisorUri = this.store.configuration.tempoComposerSupervisor
      const customerOrderNumber = this.store.customerOrderId
      if (supervisorUri) {
        return supervisorUri.replace('{orderId}', customerOrderNumber || '')
      }
      return undefined
    },
    bpms() {
      return this.store.bpms
    },
    customerOrderId() {
      return this.$route.params.id
    },
  },
}
</script>

<style lang="scss" scoped>
.container {
  width: 100%;
  display: flex;
  flex-direction: row;
  height: 100%;
  justify-content: space-between;
}

.content {
  flex: 4;
  overflow: auto;
  background-color: white;
}

.vertical-menu {
  width: 80px;
  background-color: whitesmoke;
  border-right: 1px solid lightgrey;

  a {
    color: royalblue;
    display: block;
    padding: 40px 12px;
    text-decoration: none;
    text-align: center;
    cursor: pointer;

    > span {
      display: block;
    }

    &.selected,
    &:hover {
      background-color: lightgrey;
    }
  }
}

.message {
  height: 100%;
  background-color: #f5f5f9;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
}

.search-move {
  animation: move 3s infinite linear;
  transform-origin: 50% 50%;
  padding: 50px;
}

@keyframes move {
  0% {
    transform: translate(-25px, 25px);
  }
  25% {
    transform: translate(25px, -25px);
  }
  50% {
    transform: translate(-25px, -25px);
  }
  75% {
    transform: translate(25px, 25px);
  }
  100% {
    transform: translate(-25px, 25px);
  }
}
</style>
