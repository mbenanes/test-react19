import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'HomeView',
      component: () => import('../views/HomeView.vue'),
    },
    {
      path: '/customer-order/:id',
      name: 'CustomerOrderView',
      component: () => import('../views/CustomerOrderView.vue'),
    },
    {
      path: '/flowchart',
      name: 'FlowChartView',
      component: () => import('../views/FlowChartView.vue'),
    },
    {
      path: '/alerts',
      name: 'AlertsView',
      component: () => import('../views/AlertsView.vue'),
    },
    {
      path: '/:catchAll(.*)',
      redirect: { name: 'HomeView' },
    },
  ],
})

export default router
